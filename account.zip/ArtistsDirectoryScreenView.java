package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.autofill.HintConstants;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.media3.exoplayer.upstream.CmcdData;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import coil.Coil;
import coil.ImageLoader;
import coil.request.ImageRequest;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.account.ArtistsDirectoryScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.actions.SearchIntents;
import com.google.android.gms.common.Scopes;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000°\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\b\u0007\u0018\u0000 X2\u00020\u0001:\u0006VWXYZ[B[\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007\u00126\u0010\b\u001a2\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\r\u0012\u0004\u0012\u00020\u000e0\t¢\u0006\u0002\u0010\u000fJ\u0010\u00108\u001a\u00020\u00112\u0006\u00109\u001a\u00020\u0011H\u0002J\u0010\u0010:\u001a\u00020;2\u0006\u00109\u001a\u00020\u0011H\u0002J\b\u0010<\u001a\u00020\u000eH\u0002J\u0018\u0010=\u001a\u00020\u000e2\u0006\u0010>\u001a\u00020\u00112\u0006\u0010?\u001a\u00020#H\u0002J\b\u0010@\u001a\u00020\u000eH\u0002J\b\u0010A\u001a\u00020\u000eH\u0014J\u001c\u0010B\u001a\u00020\u00052\u0012\u0010C\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050DH\u0002J\b\u0010E\u001a\u00020\u000eH\u0002J(\u0010F\u001a\u00020G2\u0006\u0010H\u001a\u00020\u00112\u0006\u0010I\u001a\u00020\u00112\u0006\u0010J\u001a\u00020\u00112\u0006\u0010K\u001a\u00020;H\u0002J\b\u0010L\u001a\u00020\u000eH\u0002JH\u0010M\u001a\u00020\u000e2\u0006\u0010N\u001a\u00020\u00052\u0018\u0010O\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00170\u00072\u0006\u0010P\u001a\u00020\u00052\u0014\u0010Q\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0004\u0012\u00020\u000e0RH\u0002J\u0010\u0010S\u001a\u00020\u000e2\u0006\u0010T\u001a\u00020\u0005H\u0002J\b\u0010U\u001a\u00020\u000eH\u0002R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082D¢\u0006\u0002\n\u0000R\u0012\u0010\u0012\u001a\u00060\u0013R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0011X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0011X\u0082D¢\u0006\u0002\n\u0000R \u0010\u0016\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00170\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u001d\u001a\n \u001f*\u0004\u0018\u00010\u001e0\u001eX\u0082\u0004¢\u0006\u0002\n\u0000R \u0010 \u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u00170\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020#X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010%\u001a\u0012\u0012\u0004\u0012\u00020'0&j\b\u0012\u0004\u0012\u00020'`(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082\u0004¢\u0006\u0002\n\u0000R>\u0010\b\u001a2\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\f\u0012\u0013\u0012\u00110\u0005¢\u0006\f\b\n\u0012\b\b\u000b\u0012\u0004\b\b(\r\u0012\u0004\u0012\u00020\u000e0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00102\u001a\u0004\u0018\u000103X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u000206X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\\"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "endpointPaths", "", "onOpenArtistArchive", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "queryName", "displayName", "", "(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;Lkotlin/jvm/functions/Function2;)V", "accent", "", "adapter", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistAdapter;", "cardFill", "cardStroke", "careerOptions", "Lkotlin/Pair;", "careerSelector", "Landroid/widget/TextView;", "currentCareer", "currentGender", "currentPage", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "genderOptions", "genderSelector", "hasMore", "", "isTouchDevice", FirebaseAnalytics.Param.ITEMS, "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistItem;", "Lkotlin/collections/ArrayList;", "list", "Landroidx/recyclerview/widget/RecyclerView;", "loading", "loadingMoreOverlay", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "queryText", "searchRunnable", "Ljava/lang/Runnable;", "stateButton", "stateOverlay", "Landroid/widget/LinearLayout;", "stateText", "dp", "v", "dpF", "", "hideState", "loadPage", "page", "reset", "maybeLoadNext", "onDetachedFromWindow", "requestArtists", SearchIntents.EXTRA_QUERY, "", "resetAndLoad", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "scheduleSearch", "showChoiceSheet", "title", "options", "selectedKey", "onSelected", "Lkotlin/Function1;", "showState", NotificationCompat.CATEGORY_MESSAGE, "updateSelectorLabels", "ArtistAdapter", "ArtistItem", "Companion", "GridSpacingDecoration", "ParseResult", "Parser", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class ArtistsDirectoryScreenView extends FrameLayout {
    private static final int PER_PAGE = 24;
    private final int accent;
    private final ArtistAdapter adapter;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private final List<Pair<String, String>> careerOptions;
    private final TextView careerSelector;
    private final Context ctx;
    private String currentCareer;
    private String currentGender;
    private int currentPage;
    private final List<String> endpointPaths;
    private final ExecutorService executor;
    private final List<Pair<String, String>> genderOptions;
    private final TextView genderSelector;
    private boolean hasMore;
    private final boolean isTouchDevice;
    private final ArrayList<ArtistItem> items;
    private final RecyclerView list;
    private boolean loading;
    private final FrameLayout loadingMoreOverlay;
    private final ProgressBar loadingView;
    private final Handler mainHandler;
    private final Function2<String, String, Unit> onOpenArtistArchive;
    private String queryText;
    private Runnable searchRunnable;
    private final TextView stateButton;
    private final LinearLayout stateOverlay;
    private final TextView stateText;
    public static final int $stable = 8;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public ArtistsDirectoryScreenView(Context ctx, String apiBase, List<String> endpointPaths, Function2<? super String, ? super String, Unit> onOpenArtistArchive) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        Intrinsics.checkNotNullParameter(endpointPaths, "endpointPaths");
        Intrinsics.checkNotNullParameter(onOpenArtistArchive, "onOpenArtistArchive");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.endpointPaths = endpointPaths;
        this.onOpenArtistArchive = onOpenArtistArchive;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.hasMore = true;
        this.currentPage = 1;
        this.queryText = "";
        this.currentCareer = "any";
        this.currentGender = "any";
        this.careerOptions = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.m787to("any", "نوع"), TuplesKt.m787to("actor", "بازیگر"), TuplesKt.m787to("director", "کارگردان"), TuplesKt.m787to("writer", "نویسنده")});
        this.genderOptions = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.m787to("any", "جنسیت"), TuplesKt.m787to("male", "مرد"), TuplesKt.m787to("female", "زن")});
        ArrayList<ArtistItem> arrayList = new ArrayList<>();
        this.items = arrayList;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout2 = new LinearLayout(ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setPadding(0, 0, 0, 0);
        linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        View view = new View(ctx);
        view.setBackgroundColor(1438173401);
        linearLayout2.addView(view, new LinearLayout.LayoutParams(-1, m378dp(1)));
        LinearLayout linearLayout3 = new LinearLayout(ctx);
        linearLayout3.setOrientation(0);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setGravity(16);
        linearLayout3.setMinimumHeight(m378dp(50));
        linearLayout3.setPadding(0, 0, 0, 0);
        linearLayout2.addView(linearLayout3, new LinearLayout.LayoutParams(-1, -2));
        AppCompatEditText appCompatEditText = new AppCompatEditText(ctx);
        appCompatEditText.setHint("جستجوی هنرمند");
        appCompatEditText.setHintTextColor(2144394989);
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setTextSize(14.0f);
        appCompatEditText.setGravity(8388627);
        appCompatEditText.setTextAlignment(5);
        appCompatEditText.setLayoutDirection(1);
        appCompatEditText.setTextDirection(4);
        appCompatEditText.setBackground(null);
        appCompatEditText.setPadding(m378dp(14), m378dp(10), m378dp(14), m378dp(10));
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        appCompatEditText.setTypeface(typefaceMedium == null ? appCompatEditText.getTypeface() : typefaceMedium);
        appCompatEditText.setMaxLines(1);
        appCompatEditText.setImeOptions(3);
        appCompatEditText.setSingleLine(true);
        appCompatEditText.addTextChangedListener(new TextWatcher() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$searchInput$1$1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String string;
                ArtistsDirectoryScreenView artistsDirectoryScreenView = this.this$0;
                String string2 = (s == null || (string = s.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
                if (string2 == null) {
                    string2 = "";
                }
                artistsDirectoryScreenView.queryText = string2;
                this.this$0.scheduleSearch();
            }
        });
        linearLayout3.addView(appCompatEditText, new LinearLayout.LayoutParams(0, -2, 1.0f));
        View view2 = new View(ctx);
        view2.setBackgroundColor(1438173401);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(m378dp(1), -1);
        layoutParams.topMargin = m378dp(7);
        layoutParams.bottomMargin = m378dp(7);
        Unit unit = Unit.INSTANCE;
        linearLayout3.addView(view2, layoutParams);
        TextView textView = new TextView(ctx);
        textView.setTextColor(-251658241);
        textView.setTextSize(13.0f);
        textView.setGravity(17);
        textView.setTextAlignment(4);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium2 == null ? textView.getTypeface() : typefaceMedium2);
        textView.setIncludeFontPadding(false);
        textView.setPadding(m378dp(12), m378dp(10), m378dp(12), m378dp(10));
        textView.setMaxLines(1);
        textView.setClickable(true);
        textView.setFocusable(true);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                ArtistsDirectoryScreenView.lambda$8$lambda$7(this.f$0, view3);
            }
        });
        this.careerSelector = textView;
        linearLayout3.addView(textView, new LinearLayout.LayoutParams(m378dp(108), -2));
        View view3 = new View(ctx);
        view3.setBackgroundColor(1438173401);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(m378dp(1), -1);
        layoutParams2.topMargin = m378dp(7);
        layoutParams2.bottomMargin = m378dp(7);
        Unit unit2 = Unit.INSTANCE;
        linearLayout3.addView(view3, layoutParams2);
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-251658241);
        textView2.setTextSize(13.0f);
        textView2.setGravity(17);
        textView2.setTextAlignment(4);
        Typeface typefaceMedium3 = NativeFonts.INSTANCE.medium(ctx);
        textView2.setTypeface(typefaceMedium3 == null ? textView2.getTypeface() : typefaceMedium3);
        textView2.setIncludeFontPadding(false);
        textView2.setPadding(m378dp(12), m378dp(10), m378dp(12), m378dp(10));
        textView2.setMaxLines(1);
        textView2.setClickable(true);
        textView2.setFocusable(true);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view4) {
                ArtistsDirectoryScreenView.lambda$12$lambda$11(this.f$0, view4);
            }
        });
        this.genderSelector = textView2;
        linearLayout3.addView(textView2, new LinearLayout.LayoutParams(m378dp(108), -2));
        View view4 = new View(ctx);
        view4.setBackgroundColor(1438173401);
        linearLayout2.addView(view4, new LinearLayout.LayoutParams(-1, m378dp(1)));
        updateSelectorLabels();
        ArtistAdapter artistAdapter = new ArtistAdapter(this, arrayList, zHasSystemFeature);
        this.adapter = artistAdapter;
        RecyclerView recyclerView = new RecyclerView(ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new GridLayoutManager(ctx, 2));
        recyclerView.setAdapter(artistAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(m378dp(4), m378dp(10), m378dp(4), m378dp(96));
        recyclerView.addItemDecoration(new GridSpacingDecoration(m378dp(8), m378dp(10)));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$9$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                GridLayoutManager gridLayoutManager = layoutManager instanceof GridLayoutManager ? (GridLayoutManager) layoutManager : null;
                if (gridLayoutManager == null) {
                    return;
                }
                int itemCount = gridLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = gridLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 4) {
                    return;
                }
                this.this$0.maybeLoadNext();
            }
        });
        this.list = recyclerView;
        linearLayout.addView(recyclerView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        ProgressBar progressBar = new ProgressBar(ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(-676591);
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        Unit unit3 = Unit.INSTANCE;
        addView(progressBar, layoutParams3);
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(0);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setGravity(16);
        linearLayout4.setPadding(m378dp(12), m378dp(8), m378dp(12), m378dp(8));
        linearLayout4.setBackground(roundedBg(-653454566, 654311423, m378dp(1), dpF(12)));
        ProgressBar progressBar2 = new ProgressBar(ctx);
        progressBar2.setIndeterminate(true);
        Drawable indeterminateDrawable2 = progressBar2.getIndeterminateDrawable();
        if (indeterminateDrawable2 != null) {
            indeterminateDrawable2.setTint(-676591);
        }
        TextView textView3 = new TextView(ctx);
        textView3.setText("در حال بارگیری بیشتر...");
        textView3.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView3.setTextSize(12.0f);
        Typeface typefaceMedium4 = NativeFonts.INSTANCE.medium(ctx);
        textView3.setTypeface(typefaceMedium4 == null ? textView3.getTypeface() : typefaceMedium4);
        textView3.setGravity(16);
        textView3.setIncludeFontPadding(false);
        linearLayout4.addView(progressBar2, new LinearLayout.LayoutParams(m378dp(14), m378dp(14)));
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.setMarginStart(m378dp(8));
        Unit unit4 = Unit.INSTANCE;
        linearLayout4.addView(textView3, layoutParams4);
        FrameLayout frameLayout = new FrameLayout(ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        this.loadingMoreOverlay = frameLayout;
        FrameLayout.LayoutParams layoutParams5 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams5.gravity = 81;
        layoutParams5.bottomMargin = m378dp(18);
        Unit unit5 = Unit.INSTANCE;
        frameLayout.addView(linearLayout4, layoutParams5);
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout5 = new LinearLayout(ctx);
        linearLayout5.setOrientation(1);
        linearLayout5.setLayoutDirection(1);
        linearLayout5.setGravity(17);
        linearLayout5.setVisibility(8);
        linearLayout5.setPadding(m378dp(24), m378dp(24), m378dp(24), m378dp(24));
        linearLayout5.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout5;
        TextView textView4 = new TextView(ctx);
        textView4.setTextColor(-419430401);
        textView4.setTextSize(15.0f);
        textView4.setGravity(17);
        Typeface typefaceMedium5 = NativeFonts.INSTANCE.medium(ctx);
        textView4.setTypeface(typefaceMedium5 == null ? textView4.getTypeface() : typefaceMedium5);
        this.stateText = textView4;
        TextView textView5 = new TextView(ctx);
        textView5.setTextColor(-16052459);
        textView5.setTextSize(14.0f);
        textView5.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView5.setTypeface(typefaceBold == null ? textView5.getTypeface() : typefaceBold);
        textView5.setPadding(m378dp(16), m378dp(10), m378dp(16), m378dp(10));
        textView5.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView5.setFocusable(!zHasSystemFeature);
        textView5.setFocusableInTouchMode(!zHasSystemFeature);
        textView5.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view5) {
                ArtistsDirectoryScreenView.lambda$26$lambda$25(this.f$0, view5);
            }
        });
        this.stateButton = textView5;
        linearLayout5.addView(textView4);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams6.topMargin = m378dp(12);
        Unit unit6 = Unit.INSTANCE;
        linearLayout5.addView(textView5, layoutParams6);
        addView(linearLayout5, new FrameLayout.LayoutParams(-1, -1));
        resetAndLoad();
    }

    /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003JE\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\fR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\f¨\u0006 "}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistItem;", "", TtmlNode.ATTR_ID, "", "persianName", "", "englishName", "career", "imageUrl", "imdbUrl", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCareer", "()Ljava/lang/String;", "getEnglishName", "getId", "()J", "getImageUrl", "getImdbUrl", "getPersianName", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class ArtistItem {
        private final String career;
        private final String englishName;
        private final long id;
        private final String imageUrl;
        private final String imdbUrl;
        private final String persianName;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getPersianName() {
            return this.persianName;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getEnglishName() {
            return this.englishName;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getCareer() {
            return this.career;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getImageUrl() {
            return this.imageUrl;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getImdbUrl() {
            return this.imdbUrl;
        }

        public final ArtistItem copy(long id, String persianName, String englishName, String career, String imageUrl, String imdbUrl) {
            Intrinsics.checkNotNullParameter(persianName, "persianName");
            Intrinsics.checkNotNullParameter(englishName, "englishName");
            Intrinsics.checkNotNullParameter(career, "career");
            Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
            Intrinsics.checkNotNullParameter(imdbUrl, "imdbUrl");
            return new ArtistItem(id, persianName, englishName, career, imageUrl, imdbUrl);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ArtistItem)) {
                return false;
            }
            ArtistItem artistItem = (ArtistItem) other;
            return this.id == artistItem.id && Intrinsics.areEqual(this.persianName, artistItem.persianName) && Intrinsics.areEqual(this.englishName, artistItem.englishName) && Intrinsics.areEqual(this.career, artistItem.career) && Intrinsics.areEqual(this.imageUrl, artistItem.imageUrl) && Intrinsics.areEqual(this.imdbUrl, artistItem.imdbUrl);
        }

        public int hashCode() {
            return (((((((((Long.hashCode(this.id) * 31) + this.persianName.hashCode()) * 31) + this.englishName.hashCode()) * 31) + this.career.hashCode()) * 31) + this.imageUrl.hashCode()) * 31) + this.imdbUrl.hashCode();
        }

        public String toString() {
            return "ArtistItem(id=" + this.id + ", persianName=" + this.persianName + ", englishName=" + this.englishName + ", career=" + this.career + ", imageUrl=" + this.imageUrl + ", imdbUrl=" + this.imdbUrl + ")";
        }

        public ArtistItem(long j, String persianName, String englishName, String career, String imageUrl, String imdbUrl) {
            Intrinsics.checkNotNullParameter(persianName, "persianName");
            Intrinsics.checkNotNullParameter(englishName, "englishName");
            Intrinsics.checkNotNullParameter(career, "career");
            Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
            Intrinsics.checkNotNullParameter(imdbUrl, "imdbUrl");
            this.id = j;
            this.persianName = persianName;
            this.englishName = englishName;
            this.career = career;
            this.imageUrl = imageUrl;
            this.imdbUrl = imdbUrl;
        }

        public final long getId() {
            return this.id;
        }

        public final String getPersianName() {
            return this.persianName;
        }

        public final String getEnglishName() {
            return this.englishName;
        }

        public final String getCareer() {
            return this.career;
        }

        public final String getImageUrl() {
            return this.imageUrl;
        }

        public final String getImdbUrl() {
            return this.imdbUrl;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0016\b\u0082\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u0003¢\u0006\u0002\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\t\u0010\u0019\u001a\u00020\nHÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003JC\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u00032\b\u0010\u001d\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001e\u001a\u00020\nHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006 "}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ParseResult;", "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistItem;", "page", "", "hasMore", "(ZLjava/lang/String;Ljava/util/List;IZ)V", "getHasMore", "()Z", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "getPage", "()I", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ParseResult {
        private final boolean hasMore;
        private final List<ArtistItem> items;
        private final String message;
        private final boolean ok;
        private final int page;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, boolean z, String str, List list, int i, boolean z2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                z = parseResult.ok;
            }
            if ((i2 & 2) != 0) {
                str = parseResult.message;
            }
            String str2 = str;
            if ((i2 & 4) != 0) {
                list = parseResult.items;
            }
            List list2 = list;
            if ((i2 & 8) != 0) {
                i = parseResult.page;
            }
            int i3 = i;
            if ((i2 & 16) != 0) {
                z2 = parseResult.hasMore;
            }
            return parseResult.copy(z, str2, list2, i3, z2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<ArtistItem> component3() {
            return this.items;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getPage() {
            return this.page;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final boolean getHasMore() {
            return this.hasMore;
        }

        public final ParseResult copy(boolean ok, String message, List<ArtistItem> items, int page, boolean hasMore) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new ParseResult(ok, message, items, page, hasMore);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return this.ok == parseResult.ok && Intrinsics.areEqual(this.message, parseResult.message) && Intrinsics.areEqual(this.items, parseResult.items) && this.page == parseResult.page && this.hasMore == parseResult.hasMore;
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            return ((((((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode()) * 31) + Integer.hashCode(this.page)) * 31) + Boolean.hashCode(this.hasMore);
        }

        public String toString() {
            return "ParseResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ", page=" + this.page + ", hasMore=" + this.hasMore + ")";
        }

        public ParseResult(boolean z, String str, List<ArtistItem> items, int i, boolean z2) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
            this.page = i;
            this.hasMore = z2;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public final List<ArtistItem> getItems() {
            return this.items;
        }

        public final int getPage() {
            return this.page;
        }

        public final boolean getHasMore() {
            return this.hasMore;
        }
    }

    static final void lambda$8$lambda$7(final ArtistsDirectoryScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.showChoiceSheet("نوع هنرمند", this$0.careerOptions, this$0.currentCareer, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$4$1$1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String str) {
                if (str == null) {
                    str = "any";
                }
                if (Intrinsics.areEqual(str, this.this$0.currentCareer)) {
                    return;
                }
                this.this$0.currentCareer = str;
                this.this$0.updateSelectorLabels();
                this.this$0.resetAndLoad();
            }
        });
    }

    static final void lambda$12$lambda$11(final ArtistsDirectoryScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.showChoiceSheet("جنسیت", this$0.genderOptions, this$0.currentGender, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$7$1$1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String str) {
                if (str == null) {
                    str = "any";
                }
                if (Intrinsics.areEqual(str, this.this$0.currentGender)) {
                    return;
                }
                this.this$0.currentGender = str;
                this.this$0.updateSelectorLabels();
                this.this$0.resetAndLoad();
            }
        });
    }

    static final void lambda$26$lambda$25(ArtistsDirectoryScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.resetAndLoad();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void scheduleSearch() {
        Runnable runnable = this.searchRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        Runnable runnable2 = new Runnable() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                ArtistsDirectoryScreenView.scheduleSearch$lambda$29(this.f$0);
            }
        };
        this.searchRunnable = runnable2;
        this.mainHandler.postDelayed(runnable2, 380L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleSearch$lambda$29(ArtistsDirectoryScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.resetAndLoad();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetAndLoad() {
        int size = this.items.size();
        this.items.clear();
        if (size > 0) {
            this.adapter.notifyItemRangeRemoved(0, size);
        }
        this.currentPage = 1;
        this.hasMore = true;
        loadPage(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNext() {
        if (this.loading || !this.hasMore) {
            return;
        }
        loadPage(this.currentPage + 1, false);
    }

    private final void loadPage(final int page, final boolean reset) {
        if (this.loading) {
            return;
        }
        this.loading = true;
        if (reset) {
            this.loadingView.setVisibility(0);
            this.loadingMoreOverlay.setVisibility(8);
        } else {
            this.loadingMoreOverlay.setVisibility(0);
        }
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                ArtistsDirectoryScreenView.loadPage$lambda$33(this.f$0, page, reset);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$33(final ArtistsDirectoryScreenView this$0, final int i, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            linkedHashMap.put("page", String.valueOf(i));
            linkedHashMap.put("per_page", "24");
            linkedHashMap.put("postsperpage", "24");
            if (!StringsKt.isBlank(this$0.queryText)) {
                linkedHashMap.put("str", this$0.queryText);
            }
            if (!Intrinsics.areEqual(this$0.currentCareer, "any")) {
                linkedHashMap.put("career", this$0.currentCareer);
            }
            if (!Intrinsics.areEqual(this$0.currentGender, "any")) {
                linkedHashMap.put(HintConstants.AUTOFILL_HINT_GENDER, this$0.currentGender);
            }
            final ParseResult parseResult = Parser.INSTANCE.parse(this$0.requestArtists(linkedHashMap), i, 24);
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    ArtistsDirectoryScreenView.loadPage$lambda$33$lambda$31(this.f$0, parseResult, z, i);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    ArtistsDirectoryScreenView.loadPage$lambda$33$lambda$32(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$33$lambda$31(ArtistsDirectoryScreenView this$0, ParseResult parsed, boolean z, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        if (!parsed.getOk()) {
            this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت هنرمندان"));
            return;
        }
        if (z) {
            int size = this$0.items.size();
            this$0.items.clear();
            if (size > 0) {
                this$0.adapter.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.items.size();
        this$0.items.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            this$0.adapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentPage = RangesKt.coerceAtLeast(parsed.getPage(), i);
        this$0.hasMore = parsed.getHasMore();
        if (this$0.items.isEmpty()) {
            this$0.showState("هنرمندی پیدا نشد.");
        } else {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$33$lambda$32(ArtistsDirectoryScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت هنرمندان"));
    }

    private final String requestArtists(Map<String, String> query) {
        Iterator<String> it = this.endpointPaths.iterator();
        FkApiClient.ApiException th = null;
        while (it.hasNext()) {
            try {
                return FkApiClient.INSTANCE.signedGet(this.apiBase, it.next(), query);
            } finally {
                th = th;
            }
        }
        if (th == null) {
            throw new RuntimeException("Endpoint not available");
        }
        throw th;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateSelectorLabels() {
        Object obj;
        Object next;
        String str;
        String str2;
        Iterator<T> it = this.careerOptions.iterator();
        while (true) {
            obj = null;
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (Intrinsics.areEqual(((Pair) next).getFirst(), this.currentCareer)) {
                    break;
                }
            }
        }
        Pair pair = (Pair) next;
        if (pair == null || (str = (String) pair.getSecond()) == null) {
            str = "نوع";
        }
        Iterator<T> it2 = this.genderOptions.iterator();
        while (true) {
            if (!it2.hasNext()) {
                break;
            }
            Object next2 = it2.next();
            if (Intrinsics.areEqual(((Pair) next2).getFirst(), this.currentGender)) {
                obj = next2;
                break;
            }
        }
        Pair pair2 = (Pair) obj;
        if (pair2 == null || (str2 = (String) pair2.getSecond()) == null) {
            str2 = "جنسیت";
        }
        this.careerSelector.setText(Intrinsics.areEqual(this.currentCareer, "any") ? "نوع" : str);
        this.genderSelector.setText(Intrinsics.areEqual(this.currentGender, "any") ? "جنسیت" : str2);
        boolean z = !Intrinsics.areEqual(this.currentCareer, "any");
        boolean z2 = !Intrinsics.areEqual(this.currentGender, "any");
        this.careerSelector.setTextColor(z ? this.accent : -251658241);
        this.genderSelector.setTextColor(z2 ? this.accent : -251658241);
    }

    private final void showChoiceSheet(String title, List<Pair<String, String>> options, String selectedKey, final Function1<? super String, Unit> onSelected) {
        Typeface typefaceMedium;
        GradientDrawable gradientDrawableRoundedBg;
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this.ctx);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setBackgroundColor(Color.parseColor("#0C121A"));
        linearLayout.setPadding(m378dp(16), m378dp(14), m378dp(16), m378dp(12));
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        int i = 5;
        textView.setGravity(5);
        textView.setTextAlignment(5);
        textView.setLayoutDirection(1);
        int i2 = 4;
        textView.setTextDirection(4);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        linearLayout.addView(textView, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setPadding(0, m378dp(10), 0, 0);
        linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        Iterator<T> it = options.iterator();
        while (it.hasNext()) {
            final Pair pair = (Pair) it.next();
            boolean zAreEqual = Intrinsics.areEqual(pair.getFirst(), selectedKey);
            TextView textView2 = new TextView(this.ctx);
            textView2.setText((CharSequence) pair.getSecond());
            textView2.setTextColor(zAreEqual ? -15460068 : -318767105);
            textView2.setTextSize(14.0f);
            NativeFonts nativeFonts = NativeFonts.INSTANCE;
            Context context = this.ctx;
            if (!zAreEqual ? (typefaceMedium = nativeFonts.medium(context)) == null : (typefaceMedium = nativeFonts.bold(context)) == null) {
                typefaceMedium = textView2.getTypeface();
            }
            textView2.setTypeface(typefaceMedium);
            textView2.setGravity(21);
            textView2.setTextAlignment(i);
            textView2.setLayoutDirection(1);
            textView2.setTextDirection(i2);
            textView2.setMinHeight(m378dp(44));
            textView2.setPadding(m378dp(12), m378dp(8), m378dp(12), m378dp(8));
            if (zAreEqual) {
                gradientDrawableRoundedBg = roundedBg(-676591, ViewCompat.MEASURED_SIZE_MASK, 0, dpF(11));
            } else {
                gradientDrawableRoundedBg = roundedBg(287057459, 961437812, m378dp(1), dpF(11));
            }
            textView2.setBackground(gradientDrawableRoundedBg);
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ArtistsDirectoryScreenView.showChoiceSheet$lambda$42$lambda$40$lambda$39(bottomSheetDialog, onSelected, pair, view);
                }
            });
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.bottomMargin = m378dp(6);
            Unit unit = Unit.INSTANCE;
            linearLayout2.addView(textView2, layoutParams);
            i = 5;
            i2 = 4;
        }
        bottomSheetDialog.setContentView(linearLayout);
        bottomSheetDialog.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showChoiceSheet$lambda$42$lambda$40$lambda$39(BottomSheetDialog dialog, Function1 onSelected, Pair option, View view) {
        Intrinsics.checkNotNullParameter(dialog, "$dialog");
        Intrinsics.checkNotNullParameter(onSelected, "$onSelected");
        Intrinsics.checkNotNullParameter(option, "$option");
        dialog.dismiss();
        onSelected.invoke(option.getFirst());
    }

    private final void showState(String msg) {
        this.stateText.setText(SafeUserMessage.INSTANCE.fromRaw(msg, "خطا در دریافت هنرمندان"));
        this.stateButton.setText("تلاش دوباره");
        this.stateOverlay.setVisibility(0);
    }

    private final void hideState() {
        this.stateOverlay.setVisibility(8);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.searchRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0014B\u001b\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\n\u001a\u00020\u000bH\u0016J \u0010\f\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistAdapter$VH;", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistItem;", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView;Ljava/util/List;Z)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class ArtistAdapter extends RecyclerView.Adapter<C2650VH> {
        private final List<ArtistItem> data;
        private final boolean isTouchDevice;
        final /* synthetic */ ArtistsDirectoryScreenView this$0;

        public ArtistAdapter(ArtistsDirectoryScreenView artistsDirectoryScreenView, List<ArtistItem> data, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = artistsDirectoryScreenView;
            this.data = data;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2650VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            ArtistsDirectoryScreenView artistsDirectoryScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(artistsDirectoryScreenView.m378dp(8), artistsDirectoryScreenView.m378dp(8), artistsDirectoryScreenView.m378dp(8), artistsDirectoryScreenView.m378dp(9));
            linearLayout.setBackground(artistsDirectoryScreenView.roundedBg(artistsDirectoryScreenView.cardFill, artistsDirectoryScreenView.cardStroke, artistsDirectoryScreenView.m378dp(1), artistsDirectoryScreenView.dpF(12)));
            linearLayout.setClickable(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2650VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2650VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$ArtistAdapter$VH */
        /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
        @Metadata(m779d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistAdapter;Landroid/widget/LinearLayout;)V", "career", "Landroid/widget/TextView;", "englishName", "persianName", "poster", "Landroid/widget/ImageView;", "bind", "", "item", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ArtistItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2650VH extends RecyclerView.ViewHolder {
            private final TextView career;
            private final TextView englishName;
            private final TextView persianName;
            private final ImageView poster;
            private final LinearLayout root;
            final /* synthetic */ ArtistAdapter this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2650VH(ArtistAdapter artistAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = artistAdapter;
                this.root = root;
                ImageView imageView = new ImageView(artistAdapter.this$0.ctx);
                ArtistsDirectoryScreenView artistsDirectoryScreenView = artistAdapter.this$0;
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setBackground(artistsDirectoryScreenView.roundedBg(-15920358, 587202559, artistsDirectoryScreenView.m378dp(1), artistsDirectoryScreenView.dpF(9)));
                imageView.setClipToOutline(true);
                this.poster = imageView;
                TextView textView = new TextView(artistAdapter.this$0.ctx);
                ArtistsDirectoryScreenView artistsDirectoryScreenView2 = artistAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(13.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(artistsDirectoryScreenView2.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setGravity(17);
                textView.setTextAlignment(4);
                textView.setMaxLines(1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                this.englishName = textView;
                TextView textView2 = new TextView(artistAdapter.this$0.ctx);
                ArtistsDirectoryScreenView artistsDirectoryScreenView3 = artistAdapter.this$0;
                textView2.setTextColor(-3088914);
                textView2.setTextSize(12.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(artistsDirectoryScreenView3.ctx);
                textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
                textView2.setIncludeFontPadding(false);
                textView2.setGravity(17);
                textView2.setTextAlignment(4);
                textView2.setMaxLines(1);
                textView2.setEllipsize(TextUtils.TruncateAt.END);
                this.persianName = textView2;
                TextView textView3 = new TextView(artistAdapter.this$0.ctx);
                ArtistsDirectoryScreenView artistsDirectoryScreenView4 = artistAdapter.this$0;
                textView3.setTextColor(-7100225);
                textView3.setTextSize(10.0f);
                Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(artistsDirectoryScreenView4.ctx);
                textView3.setTypeface(typefaceRegular2 == null ? textView3.getTypeface() : typefaceRegular2);
                textView3.setIncludeFontPadding(false);
                textView3.setGravity(17);
                textView3.setTextAlignment(4);
                textView3.setMaxLines(1);
                textView3.setEllipsize(TextUtils.TruncateAt.END);
                this.career = textView3;
                root.addView(imageView, new LinearLayout.LayoutParams(-1, artistAdapter.this$0.m378dp(170)));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = artistAdapter.this$0.m378dp(8);
                Unit unit = Unit.INSTANCE;
                root.addView(textView, layoutParams);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = 0;
                Unit unit2 = Unit.INSTANCE;
                root.addView(textView2, layoutParams2);
                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams3.topMargin = artistAdapter.this$0.m378dp(6);
                Unit unit3 = Unit.INSTANCE;
                root.addView(textView3, layoutParams3);
            }

            public final void bind(ArtistItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.englishName.setText(item.getEnglishName());
                this.persianName.setText(item.getPersianName());
                this.career.setText(item.getCareer());
                this.career.setVisibility(StringsKt.isBlank(item.getCareer()) ? 8 : 0);
                if (!StringsKt.isBlank(item.getImageUrl())) {
                    ImageView imageView = this.poster;
                    String imageUrl = item.getImageUrl();
                    ImageLoader imageLoader = Coil.imageLoader(imageView.getContext());
                    ImageRequest.Builder builderTarget = new ImageRequest.Builder(imageView.getContext()).data(imageUrl).target(imageView);
                    builderTarget.crossfade(true);
                    imageLoader.enqueue(builderTarget.build());
                } else {
                    this.poster.setImageDrawable(null);
                }
                String englishName = item.getEnglishName();
                if (StringsKt.isBlank(englishName)) {
                    englishName = item.getPersianName();
                }
                final String string = StringsKt.trim((CharSequence) englishName).toString();
                String persianName = item.getPersianName();
                if (StringsKt.isBlank(persianName)) {
                    persianName = item.getEnglishName();
                }
                final String string2 = StringsKt.trim((CharSequence) persianName).toString();
                LinearLayout linearLayout = this.root;
                final ArtistsDirectoryScreenView artistsDirectoryScreenView = this.this$0.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ArtistsDirectoryScreenView$ArtistAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ArtistsDirectoryScreenView.ArtistAdapter.C2650VH.bind$lambda$10(string, artistsDirectoryScreenView, string2, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$10(String queryName, ArtistsDirectoryScreenView this$0, String displayName, View view) {
                Intrinsics.checkNotNullParameter(queryName, "$queryName");
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(displayName, "$displayName");
                if (!StringsKt.isBlank(queryName)) {
                    this$0.onOpenArtistArchive.invoke(queryName, displayName);
                }
            }
        }
    }

    /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
    @Metadata(m779d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J(\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$GridSpacingDecoration;", "Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;", CmcdData.Factory.STREAMING_FORMAT_HLS, "", "v", "(II)V", "getItemOffsets", "", "outRect", "Landroid/graphics/Rect;", "view", "Landroid/view/View;", "parent", "Landroidx/recyclerview/widget/RecyclerView;", "state", "Landroidx/recyclerview/widget/RecyclerView$State;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class GridSpacingDecoration extends RecyclerView.ItemDecoration {
        private final int h;
        private final int v;

        public GridSpacingDecoration(int i, int i2) {
            this.h = i;
            this.v = i2;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.ItemDecoration
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            Intrinsics.checkNotNullParameter(outRect, "outRect");
            Intrinsics.checkNotNullParameter(view, "view");
            Intrinsics.checkNotNullParameter(parent, "parent");
            Intrinsics.checkNotNullParameter(state, "state");
            int childAdapterPosition = parent.getChildAdapterPosition(view);
            if (childAdapterPosition == -1) {
                return;
            }
            RecyclerView.LayoutManager layoutManager = parent.getLayoutManager();
            GridLayoutManager gridLayoutManager = layoutManager instanceof GridLayoutManager ? (GridLayoutManager) layoutManager : null;
            if (gridLayoutManager == null) {
                return;
            }
            outRect.top = childAdapterPosition < gridLayoutManager.getSpanCount() ? 0 : this.v;
            outRect.left = this.h / 2;
            outRect.right = this.h / 2;
            outRect.bottom = 0;
        }
    }

    /* JADX INFO: compiled from: ArtistsDirectoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0002J\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH\u0002J \u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u00042\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eJ-\u0010\u0010\u001a\u0004\u0018\u00010\u00042\b\u0010\b\u001a\u0004\u0018\u00010\t2\u0012\u0010\u0011\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0012\"\u00020\u0004H\u0002¢\u0006\u0002\u0010\u0013J\u0012\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u0002J\u0019\u0010\u0017\u001a\u0004\u0018\u00010\u000e2\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0018J\u0019\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u001b¨\u0006\u001c"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$Parser;", "", "()V", "normalizeCareer", "", "raw", "numericObjectToArray", "Lorg/json/JSONArray;", "obj", "Lorg/json/JSONObject;", "parse", "Lcom/filmkio/nativescreen/account/ArtistsDirectoryScreenView$ParseResult;", "json", "requestedPage", "", "perPage", "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "toBool", "", "v", "toInt", "(Ljava/lang/Object;)Ljava/lang/Integer;", "toLong", "", "(Ljava/lang/Object;)Ljava/lang/Long;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class Parser {
        public static final Parser INSTANCE = new Parser();

        private Parser() {
        }

        /* JADX WARN: Removed duplicated region for block: B:133:0x0232  */
        /* JADX WARN: Removed duplicated region for block: B:134:0x0235  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final ParseResult parse(String json, int requestedPage, int perPage) {
            JSONArray jSONArrayNumericObjectToArray;
            JSONObject jSONObjectOptJSONObject;
            boolean z;
            boolean bool;
            String str = json;
            if (str == null || StringsKt.isBlank(str)) {
                return new ParseResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
            try {
                Object objNextValue = new JSONTokener(json).nextValue();
                JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("data");
                boolean z2 = toBool(jSONObject.opt("flag")) || toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS)) || jSONObject.length() > 0;
                String strPickString = pickString(jSONObject, "message", NotificationCompat.CATEGORY_MESSAGE);
                if (strPickString == null) {
                    strPickString = pickString(jSONObjectOptJSONObject2, "message", NotificationCompat.CATEGORY_MESSAGE);
                }
                String str2 = strPickString;
                if ((jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS) : null) != null) {
                    jSONArrayNumericObjectToArray = jSONObjectOptJSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                } else if (jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS) != null) {
                    jSONArrayNumericObjectToArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                } else if (jSONObject.optJSONArray("data") != null) {
                    jSONArrayNumericObjectToArray = jSONObject.optJSONArray("data");
                } else {
                    jSONArrayNumericObjectToArray = objNextValue instanceof JSONArray ? (JSONArray) objNextValue : numericObjectToArray(jSONObject);
                }
                if (jSONArrayNumericObjectToArray == null) {
                    jSONArrayNumericObjectToArray = new JSONArray();
                }
                ArrayList arrayList = new ArrayList(jSONArrayNumericObjectToArray.length());
                int length = jSONArrayNumericObjectToArray.length();
                for (int i = 0; i < length; i++) {
                    JSONObject jSONObjectOptJSONObject3 = jSONArrayNumericObjectToArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject3 != null) {
                        Long l = toLong(jSONObjectOptJSONObject3.opt("ID"));
                        long jLongValue = (l == null && (l = toLong(jSONObjectOptJSONObject3.opt(TtmlNode.ATTR_ID))) == null) ? 0L : l.longValue();
                        String strPickString2 = pickString(jSONObjectOptJSONObject3, "persian_name", "title");
                        if (strPickString2 == null) {
                            strPickString2 = "";
                        }
                        String string = StringsKt.trim((CharSequence) strPickString2).toString();
                        String strPickString3 = pickString(jSONObjectOptJSONObject3, "name", "english_name");
                        if (strPickString3 == null) {
                            strPickString3 = "";
                        }
                        String string2 = StringsKt.trim((CharSequence) strPickString3).toString();
                        String strPickString4 = pickString(jSONObjectOptJSONObject3, "career");
                        if (strPickString4 == null) {
                            strPickString4 = "";
                        }
                        String strNormalizeCareer = normalizeCareer(strPickString4);
                        String str3 = string2;
                        if (StringsKt.isBlank(str3)) {
                            str3 = string;
                        }
                        String str4 = str3;
                        String str5 = string;
                        if (StringsKt.isBlank(str5)) {
                            str5 = str4;
                        }
                        String str6 = str5;
                        if (StringsKt.isBlank(str6)) {
                            str6 = "بدون نام";
                        }
                        String str7 = str6;
                        String str8 = str4;
                        if (StringsKt.isBlank(str8)) {
                            str8 = "Unknown";
                        }
                        String str9 = str8;
                        String strPickString5 = pickString(jSONObjectOptJSONObject3, Scopes.PROFILE, "image", "thumbnail");
                        String str10 = strPickString5 == null ? "" : strPickString5;
                        String strPickString6 = pickString(jSONObjectOptJSONObject3, "imdb_url");
                        arrayList.add(new ArtistItem(jLongValue, str7, str9, strNormalizeCareer, str10, strPickString6 == null ? "" : strPickString6));
                    }
                }
                if (jSONObjectOptJSONObject2 == null || (jSONObjectOptJSONObject = jSONObjectOptJSONObject2.optJSONObject("pagination")) == null) {
                    jSONObjectOptJSONObject = jSONObject.optJSONObject("pagination");
                }
                Integer num = toInt(jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.opt("page") : null);
                int iIntValue = num != null ? num.intValue() : requestedPage;
                if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("has_more")) {
                    bool = toBool(jSONObjectOptJSONObject.opt("has_more"));
                } else {
                    if (jSONObjectOptJSONObject == null || !jSONObjectOptJSONObject.has("hasMore")) {
                        if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("total_pages")) {
                            Integer num2 = toInt(jSONObjectOptJSONObject.opt("total_pages"));
                            if (iIntValue < (num2 != null ? num2.intValue() : 1)) {
                            }
                        } else if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("totalPages")) {
                            Integer num3 = toInt(jSONObjectOptJSONObject.opt("totalPages"));
                            if (iIntValue < (num3 != null ? num3.intValue() : 1)) {
                            }
                        } else {
                            z = arrayList.size() >= perPage;
                        }
                        if (z2 && arrayList.isEmpty()) {
                            if (str2 == null) {
                                str2 = "خطا در دریافت اطلاعات";
                            }
                            return new ParseResult(false, str2, CollectionsKt.emptyList(), iIntValue, false);
                        }
                        return new ParseResult(true, str2, arrayList, iIntValue, z);
                    }
                    bool = toBool(jSONObjectOptJSONObject.opt("hasMore"));
                }
                z = bool;
                if (z2) {
                }
                return new ParseResult(true, str2, arrayList, iIntValue, z);
            } catch (Throwable unused) {
                return new ParseResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
        }

        private final String normalizeCareer(String raw) {
            if (StringsKt.isBlank(raw)) {
                return "";
            }
            String strReplace$default = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(raw, "Actress", "بازیگر", false, 4, (Object) null), "Actor", "بازیگر", false, 4, (Object) null), "Director", "کارگردان", false, 4, (Object) null), "Writer", "نویسنده", false, 4, (Object) null), "Producer", "تهیه\u200cکننده", false, 4, (Object) null), "Music Department", "موسیقی", false, 4, (Object) null), "Composer", "آهنگساز", false, 4, (Object) null), "Editor", "تدوین", false, 4, (Object) null);
            List listSplit$default = StringsKt.split$default((CharSequence) strReplace$default, new String[]{",", "،", "|", "/", "\\", ";"}, false, 0, 6, (Object) null);
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listSplit$default, 10));
            Iterator it = listSplit$default.iterator();
            while (it.hasNext()) {
                arrayList.add(StringsKt.trim((CharSequence) it.next()).toString());
            }
            ArrayList arrayList2 = new ArrayList();
            for (Object obj : arrayList) {
                if (true ^ StringsKt.isBlank((String) obj)) {
                    arrayList2.add(obj);
                }
            }
            ArrayList arrayList3 = arrayList2;
            if (arrayList3.isEmpty()) {
                return StringsKt.trim((CharSequence) strReplace$default).toString();
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it2 = arrayList3.iterator();
            while (it2.hasNext()) {
                linkedHashMap.put((String) it2.next(), true);
            }
            Set setKeySet = linkedHashMap.keySet();
            Intrinsics.checkNotNullExpressionValue(setKeySet, "<get-keys>(...)");
            return CollectionsKt.joinToString$default(setKeySet, " • ", null, null, 0, null, null, 62, null);
        }

        private final String pickString(JSONObject obj, String... keys) {
            if (obj == null) {
                return null;
            }
            for (String str : keys) {
                Object objOpt = obj.opt(str);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                    if (!StringsKt.isBlank(string)) {
                        return string;
                    }
                }
            }
            return null;
        }

        private final JSONArray numericObjectToArray(JSONObject obj) {
            boolean z;
            Iterator<String> itKeys = obj.keys();
            JSONArray jSONArray = new JSONArray();
            boolean z2 = false;
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                Intrinsics.checkNotNull(next);
                String str = next;
                int i = 0;
                while (true) {
                    if (i >= str.length()) {
                        z = true;
                        break;
                    }
                    if (!Character.isDigit(str.charAt(i))) {
                        z = false;
                        break;
                    }
                    i++;
                }
                if (z) {
                    Object objOpt = obj.opt(next);
                    if (objOpt instanceof JSONObject) {
                        jSONArray.put(objOpt);
                        z2 = true;
                    }
                }
            }
            if (z2) {
                return jSONArray;
            }
            return null;
        }

        private final Integer toInt(Object v) {
            if (v instanceof Number) {
                return Integer.valueOf(((Number) v).intValue());
            }
            if (v instanceof String) {
                return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
            }
            return null;
        }

        private final Long toLong(Object v) {
            if (v instanceof Number) {
                return Long.valueOf(((Number) v).longValue());
            }
            if (v instanceof String) {
                return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) v).toString());
            }
            return null;
        }

        private final boolean toBool(Object v) {
            if (v instanceof Boolean) {
                return ((Boolean) v).booleanValue();
            }
            if (v instanceof Number) {
                if (((Number) v).intValue() == 0) {
                    return false;
                }
            } else {
                if (!(v instanceof String)) {
                    return false;
                }
                if (!Intrinsics.areEqual(v, "1")) {
                    String str = (String) v;
                    if (!StringsKt.equals(str, "true", true) && !StringsKt.equals(str, "yes", true) && !StringsKt.equals(str, "ok", true)) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m378dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }
}
