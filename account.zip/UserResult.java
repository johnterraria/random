package com.filmkio.nativescreen.account;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0007HÆ\u0003J+\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00032\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0005HÖ\u0001R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0018"}, m780d2 = {"Lcom/filmkio/nativescreen/account/UserResult;", "", "ok", "", "message", "", "data", "Lcom/filmkio/nativescreen/account/UserData;", "(ZLjava/lang/String;Lcom/filmkio/nativescreen/account/UserData;)V", "getData", "()Lcom/filmkio/nativescreen/account/UserData;", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class UserResult {
    public static final int $stable = 8;
    private final UserData data;
    private final String message;
    private final boolean ok;

    public static /* synthetic */ UserResult copy$default(UserResult userResult, boolean z, String str, UserData userData, int i, Object obj) {
        if ((i & 1) != 0) {
            z = userResult.ok;
        }
        if ((i & 2) != 0) {
            str = userResult.message;
        }
        if ((i & 4) != 0) {
            userData = userResult.data;
        }
        return userResult.copy(z, str, userData);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final boolean getOk() {
        return this.ok;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final UserData getData() {
        return this.data;
    }

    public final UserResult copy(boolean ok, String message, UserData data) {
        return new UserResult(ok, message, data);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UserResult)) {
            return false;
        }
        UserResult userResult = (UserResult) other;
        return this.ok == userResult.ok && Intrinsics.areEqual(this.message, userResult.message) && Intrinsics.areEqual(this.data, userResult.data);
    }

    public int hashCode() {
        int iHashCode = Boolean.hashCode(this.ok) * 31;
        String str = this.message;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        UserData userData = this.data;
        return iHashCode2 + (userData != null ? userData.hashCode() : 0);
    }

    public String toString() {
        return "UserResult(ok=" + this.ok + ", message=" + this.message + ", data=" + this.data + ")";
    }

    public UserResult(boolean z, String str, UserData userData) {
        this.ok = z;
        this.message = str;
        this.data = userData;
    }

    public final boolean getOk() {
        return this.ok;
    }

    public final String getMessage() {
        return this.message;
    }

    public final UserData getData() {
        return this.data;
    }
}
