package com.filmkio.nativescreen.account;

import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.AbsoluteSizeSpan;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.autofill.HintConstants;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.core.view.ViewCompat;
import androidx.media3.extractor.p003ts.TsExtractor;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import com.filmkio.AccountPanelPageActivity;
import com.filmkio.AppState;
import com.filmkio.BuildConfig;
import com.filmkio.C2629R;
import com.filmkio.MainActivity;
import com.filmkio.PurchaseActivity;
import com.filmkio.ScreenMotionKt;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.account.AccountScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.internal.ImagesContract;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.Constants;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import com.google.zxing.qrcode.encoder.Encoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: AccountScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000à\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u0003\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b1\n\u0002\u0010\r\n\u0002\b\u001f\b\u0007\u0018\u00002\u00020\u0001:\u001a\u0092\u0003\u0093\u0003\u0094\u0003\u0095\u0003\u0096\u0003\u0097\u0003\u0098\u0003\u0099\u0003\u009a\u0003\u009b\u0003\u009c\u0003\u009d\u0003\u009e\u0003B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u001b\u0010¦\u0001\u001a\u00020\f2\u0007\u0010§\u0001\u001a\u00020\b2\u0007\u0010¨\u0001\u001a\u00020\bH\u0002J\u001c\u0010©\u0001\u001a\u00030ª\u00012\u0007\u0010«\u0001\u001a\u00020\u00192\u0007\u0010¬\u0001\u001a\u00020\u0019H\u0002J%\u0010\u00ad\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\n2\u0007\u0010¯\u0001\u001a\u00020\f2\u0007\u0010°\u0001\u001a\u00020\fH\u0002J/\u0010±\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\n2\b\u0010²\u0001\u001a\u00030³\u00012\u0007\u0010°\u0001\u001a\u00020\f2\u0007\u0010´\u0001\u001a\u00020\fH\u0002J%\u0010µ\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\n2\u0007\u0010¶\u0001\u001a\u00020\f2\u0007\u0010·\u0001\u001a\u00020\fH\u0002J\u001c\u0010¸\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\u001c2\u0007\u0010¹\u0001\u001a\u00020\fH\u0002J\n\u0010º\u0001\u001a\u00030ª\u0001H\u0002J'\u0010»\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\n2\u0007\u0010¯\u0001\u001a\u00020\f2\t\b\u0002\u0010°\u0001\u001a\u00020\fH\u0002J\u0013\u0010¼\u0001\u001a\u00030ª\u00012\u0007\u0010½\u0001\u001a\u00020=H\u0002J\u001f\u0010¾\u0001\u001a\u00030ª\u00012\b\u0010¿\u0001\u001a\u00030 \u00012\t\u0010À\u0001\u001a\u0004\u0018\u00010\bH\u0002J\u0013\u0010Á\u0001\u001a\u00030ª\u00012\u0007\u0010®\u0001\u001a\u00020\u001cH\u0002J\n\u0010Â\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010Ã\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010Ä\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010Å\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010Æ\u0001\u001a\u00030ª\u0001H\u0002J\t\u0010Ç\u0001\u001a\u00020\u0016H\u0002J\"\u0010È\u0001\u001a\n\u0012\u0005\u0012\u00030Ê\u00010É\u00012\u000f\u0010Ë\u0001\u001a\n\u0012\u0005\u0012\u00030Ì\u00010É\u0001H\u0002J\u0013\u0010Í\u0001\u001a\u00030ª\u00012\u0007\u0010Î\u0001\u001a\u00020\u0016H\u0002J\n\u0010Ï\u0001\u001a\u00030ª\u0001H\u0002J\u0013\u0010Ð\u0001\u001a\u00030ª\u00012\u0007\u0010Î\u0001\u001a\u00020\u0016H\u0002J\t\u0010Ñ\u0001\u001a\u00020\u0016H\u0002J\u0015\u0010Ò\u0001\u001a\u00030Ó\u00012\t\b\u0002\u0010Ô\u0001\u001a\u00020\u0006H\u0002J\n\u0010Õ\u0001\u001a\u00030ª\u0001H\u0002J\u001c\u0010Ö\u0001\u001a\u00030ª\u00012\u0007\u0010×\u0001\u001a\u00020\b2\u0007\u0010§\u0001\u001a\u00020\bH\u0002J\u0012\u0010Ø\u0001\u001a\u00020\b2\u0007\u0010Ù\u0001\u001a\u00020\bH\u0002J\u0015\u0010Ú\u0001\u001a\u00030Û\u00012\t\u0010Ü\u0001\u001a\u0004\u0018\u00010\bH\u0002J\n\u0010Ý\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010Þ\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010ß\u0001\u001a\u00030ª\u0001H\u0002J\u0012\u0010à\u0001\u001a\u00020\u00062\u0007\u0010á\u0001\u001a\u00020\u0006H\u0002J\u0013\u0010â\u0001\u001a\u00030ã\u00012\u0007\u0010á\u0001\u001a\u00020\u0006H\u0002JN\u0010ä\u0001\u001a\u00030ª\u00012\b\u0010å\u0001\u001a\u00030æ\u00012\u0007\u0010ç\u0001\u001a\u00020\u00062\u0007\u0010è\u0001\u001a\u00020\u00062\b\u0010é\u0001\u001a\u00030ã\u00012\b\u0010ê\u0001\u001a\u00030ã\u00012\b\u0010ë\u0001\u001a\u00030ì\u00012\b\u0010í\u0001\u001a\u00030ì\u0001H\u0002J'\u0010î\u0001\u001a\u0005\u0018\u00010Ì\u00012\u000f\u0010ï\u0001\u001a\n\u0012\u0005\u0012\u00030Ì\u00010É\u00012\b\u0010ð\u0001\u001a\u00030ñ\u0001H\u0002J\n\u0010ò\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010ó\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010ô\u0001\u001a\u00030ª\u0001H\u0002J\n\u0010õ\u0001\u001a\u00030ª\u0001H\u0002J\u001c\u0010ö\u0001\u001a\u00030ª\u00012\u0010\u0010÷\u0001\u001a\u000b\u0012\u0006\u0012\u0004\u0018\u00010\u001c0ø\u0001H\u0002J)\u0010ù\u0001\u001a\u0005\u0018\u00010ú\u00012\u0007\u0010Ü\u0001\u001a\u00020\b2\u0007\u0010û\u0001\u001a\u00020\u00062\t\b\u0002\u0010ü\u0001\u001a\u00020\fH\u0002J\u0007\u0010ý\u0001\u001a\u00020\fJ\u0014\u0010þ\u0001\u001a\u00030ª\u00012\b\u0010ÿ\u0001\u001a\u00030Ì\u0001H\u0002J\u0015\u0010\u0080\u0002\u001a\u00030ª\u00012\t\u0010À\u0001\u001a\u0004\u0018\u00010\bH\u0002J\n\u0010\u0081\u0002\u001a\u00030ª\u0001H\u0002J$\u0010\u0082\u0002\u001a\u00020\f2\u0007\u0010\u0083\u0002\u001a\u00020\u00062\u0007\u0010\u0084\u0002\u001a\u00020\u00062\u0007\u0010\u0085\u0002\u001a\u00020\u0006H\u0002J\u0013\u0010\u0086\u0002\u001a\u00020\f2\b\u0010ÿ\u0001\u001a\u00030Ì\u0001H\u0002J\u0012\u0010\u0087\u0002\u001a\u00020\f2\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\u0012\u0010\u0088\u0002\u001a\u00020\f2\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\n\u0010\u0089\u0002\u001a\u00030ª\u0001H\u0002J\u0013\u0010\u008a\u0002\u001a\u00030ª\u00012\u0007\u0010\u008b\u0002\u001a\u00020\fH\u0002J\t\u0010\u008c\u0002\u001a\u00020\u0016H\u0002J\u0012\u0010\u008d\u0002\u001a\u00020\n2\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\u001c\u0010\u008e\u0002\u001a\u00020\n2\u0007\u0010Ü\u0001\u001a\u00020\b2\b\u0010²\u0001\u001a\u00030³\u0001H\u0002J\u001c\u0010\u008f\u0002\u001a\u00030\u0090\u00022\u0007\u0010\u0091\u0002\u001a\u00020\b2\u0007\u0010\u0092\u0002\u001a\u00020\u0006H\u0002J\u001f\u0010\u0093\u0002\u001a\u000f\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00160\u0094\u00022\u0007\u0010×\u0001\u001a\u00020\bH\u0002J\t\u0010\u0095\u0002\u001a\u00020\nH\u0002J<\u0010\u0096\u0002\u001a\u00020=2\u0007\u0010Ù\u0001\u001a\u00020\b2\u0007\u0010\u0097\u0002\u001a\u00020\u00062\t\b\u0002\u0010\u0098\u0002\u001a\u00020\f2\t\b\u0002\u0010\u0099\u0002\u001a\u00020\u00062\t\b\u0002\u0010\u009a\u0002\u001a\u00020\u0006H\u0002J\u0012\u0010\u009b\u0002\u001a\u00020\n2\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\t\u0010\u009c\u0002\u001a\u00020\u001cH\u0002J\t\u0010\u009d\u0002\u001a\u00020\nH\u0002J\u0012\u0010\u009e\u0002\u001a\u00020\u00162\u0007\u0010\u009f\u0002\u001a\u00020\bH\u0002J%\u0010 \u0002\u001a\u00020\n2\u0007\u0010\u0091\u0002\u001a\u00020\b2\u0007\u0010¡\u0002\u001a\u00020\b2\b\u0010¢\u0002\u001a\u00030£\u0002H\u0002J\u001c\u0010¤\u0002\u001a\u00020\u00162\b\u0010ÿ\u0001\u001a\u00030Ì\u00012\u0007\u0010\u0092\u0002\u001a\u00020\u0006H\u0002J\u001b\u0010¥\u0002\u001a\u00020\n2\u0007\u0010×\u0001\u001a\u00020\b2\u0007\u0010¦\u0002\u001a\u00020%H\u0002J$\u0010§\u0002\u001a\u00020\u00162\u0007\u0010\u0091\u0002\u001a\u00020\b2\u0007\u0010¡\u0002\u001a\u00020\b2\u0007\u0010\u0092\u0002\u001a\u00020\u0006H\u0002J\u001b\u0010¨\u0002\u001a\u00020\u00162\u0007\u0010\u0092\u0002\u001a\u00020\u00062\u0007\u0010\u0091\u0002\u001a\u00020\bH\u0002J\u0012\u0010©\u0002\u001a\u00020\u00062\u0007\u0010ª\u0002\u001a\u00020\u001cH\u0002J\u0012\u0010«\u0002\u001a\u00020\b2\u0007\u0010¬\u0002\u001a\u00020\bH\u0002J\u0014\u0010\u00ad\u0002\u001a\u00020\b2\t\u0010¬\u0002\u001a\u0004\u0018\u00010\bH\u0002J\n\u0010®\u0002\u001a\u00030ª\u0001H\u0014J\n\u0010¯\u0002\u001a\u00030ª\u0001H\u0014J\u001c\u0010°\u0002\u001a\u00030ª\u00012\u0007\u0010\u0091\u0002\u001a\u00020\b2\u0007\u0010±\u0002\u001a\u00020\bH\u0002J\u0013\u0010²\u0002\u001a\u00030ª\u00012\u0007\u0010³\u0002\u001a\u00020\bH\u0002J\n\u0010´\u0002\u001a\u00030ª\u0001H\u0002J\u0015\u0010µ\u0002\u001a\u00030Ó\u00012\t\b\u0002\u0010Ô\u0001\u001a\u00020\u0006H\u0002J\u001c\u0010¶\u0002\u001a\u0004\u0018\u00010U2\t\u0010§\u0001\u001a\u0004\u0018\u00010\bH\u0002¢\u0006\u0003\u0010·\u0002J\u001c\u0010¸\u0002\u001a\u00020\b2\b\u0010¹\u0002\u001a\u00030º\u00022\u0007\u0010»\u0002\u001a\u00020\bH\u0002J\n\u0010¼\u0002\u001a\u00030ª\u0001H\u0002J\u0013\u0010½\u0002\u001a\u00030ª\u00012\u0007\u0010¾\u0002\u001a\u00020WH\u0002J.\u0010¿\u0002\u001a\u00030ª\u00012\u0007\u0010À\u0002\u001a\u00020\u00162\u000f\u0010ï\u0001\u001a\n\u0012\u0005\u0012\u00030Ì\u00010É\u00012\b\u0010¢\u0002\u001a\u00030£\u0002H\u0002J\u001b\u0010Á\u0002\u001a\u00030ª\u00012\u000f\u0010ï\u0001\u001a\n\u0012\u0005\u0012\u00030Â\u00020É\u0001H\u0002J\u001b\u0010Ã\u0002\u001a\u00030ª\u00012\u000f\u0010Ë\u0001\u001a\n\u0012\u0005\u0012\u00030Ì\u00010É\u0001H\u0002J\b\u0010Ä\u0002\u001a\u00030ª\u0001J\u0015\u0010Å\u0002\u001a\u00030ª\u00012\t\b\u0002\u0010Æ\u0002\u001a\u00020\fH\u0002J\u001d\u0010Ç\u0002\u001a\u00020U2\t\u0010È\u0002\u001a\u0004\u0018\u00010\b2\u0007\u0010É\u0002\u001a\u00020\u0006H\u0002J4\u0010Ê\u0002\u001a\u00020\b2\u0007\u0010¾\u0002\u001a\u00020W2\u0007\u0010Ë\u0002\u001a\u00020\b2\u000e\u0010Ì\u0002\u001a\t\u0012\u0004\u0012\u00020\b0É\u00012\u0007\u0010»\u0002\u001a\u00020\bH\u0002J/\u0010Í\u0002\u001a\u00030Î\u00022\u0007\u0010Ï\u0002\u001a\u00020\u00062\u0007\u0010Ð\u0002\u001a\u00020\u00062\u0007\u0010Ñ\u0002\u001a\u00020\u00062\b\u0010Ò\u0002\u001a\u00030ã\u0001H\u0002J\u0013\u0010Ó\u0002\u001a\u00030ª\u00012\u0007\u0010á\u0001\u001a\u00020\u001cH\u0002J\u0013\u0010Ô\u0002\u001a\u00030ª\u00012\u0007\u0010Õ\u0002\u001a\u00020\fH\u0002J\u0013\u0010Ö\u0002\u001a\u00030ª\u00012\u0007\u0010×\u0002\u001a\u00020\fH\u0002J'\u0010Ø\u0002\u001a\u00030ª\u00012\u0007\u0010Ù\u0002\u001a\u00020\u00062\u0007\u0010Ú\u0002\u001a\u00020\f2\t\b\u0002\u0010Û\u0002\u001a\u00020UH\u0002J\u0013\u0010Ü\u0002\u001a\u00030ª\u00012\u0007\u0010Ý\u0002\u001a\u000200H\u0002J\u0013\u0010Þ\u0002\u001a\u00030ª\u00012\u0007\u0010ß\u0002\u001a\u000206H\u0002J*\u0010à\u0002\u001a\u00030ª\u00012\t\u0010®\u0001\u001a\u0004\u0018\u00010\n2\t\u0010Ü\u0001\u001a\u0004\u0018\u00010\b2\b\u0010á\u0002\u001a\u00030Û\u0001H\u0002J\u0013\u0010â\u0002\u001a\u00030ª\u00012\u0007\u0010×\u0002\u001a\u00020\fH\u0002J\u0015\u0010ã\u0002\u001a\u00030ª\u00012\t\u0010Ü\u0001\u001a\u0004\u0018\u00010\bH\u0002J\u001d\u0010ä\u0002\u001a\u00030ª\u00012\u0007\u0010×\u0002\u001a\u00020\f2\b\u0010å\u0002\u001a\u00030\u008c\u0001H\u0002J\u0013\u0010æ\u0002\u001a\u00030ª\u00012\u0007\u0010×\u0002\u001a\u00020\fH\u0002J\u001c\u0010ç\u0002\u001a\u00030ª\u00012\u0007\u0010è\u0002\u001a\u00020\u00062\u0007\u0010Ú\u0002\u001a\u00020\fH\u0002J\u0013\u0010é\u0002\u001a\u00030ª\u00012\u0007\u0010×\u0002\u001a\u00020\fH\u0002J\u0013\u0010ê\u0002\u001a\u00030ª\u00012\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\n\u0010ë\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ì\u0002\u001a\u00030ª\u0001H\u0002J\u0013\u0010í\u0002\u001a\u00030ª\u00012\u0007\u0010î\u0002\u001a\u00020UH\u0002J\n\u0010ï\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ð\u0002\u001a\u00030ª\u0001H\u0002J\u0014\u0010ñ\u0002\u001a\u00030ª\u00012\b\u0010å\u0002\u001a\u00030\u008c\u0001H\u0002J\u0013\u0010ò\u0002\u001a\u00030ª\u00012\u0007\u0010ó\u0002\u001a\u00020\u0006H\u0002J\n\u0010ô\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010õ\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ö\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010÷\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ø\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ù\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ú\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010û\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ü\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010ý\u0002\u001a\u00030ª\u0001H\u0002J\n\u0010þ\u0002\u001a\u00030ª\u0001H\u0002J\u0013\u0010ÿ\u0002\u001a\u00030\u0080\u00032\u0007\u0010Ü\u0001\u001a\u00020\bH\u0002J\u001c\u0010\u0081\u0003\u001a\u00030ª\u00012\u0007\u0010å\u0002\u001a\u00020\u00192\u0007\u0010Ú\u0002\u001a\u00020\fH\u0002J\u0013\u0010\u0082\u0003\u001a\u00030ª\u00012\u0007\u0010¦\u0002\u001a\u00020%H\u0002J\u0013\u0010\u0083\u0003\u001a\u00030ª\u00012\u0007\u0010Ú\u0002\u001a\u00020\fH\u0002J\u0013\u0010\u0084\u0003\u001a\u00030ª\u00012\u0007\u0010½\u0001\u001a\u00020=H\u0002J\u0013\u0010\u0085\u0003\u001a\u00030ª\u00012\u0007\u0010Ú\u0002\u001a\u00020\fH\u0002J\n\u0010\u0086\u0003\u001a\u00030ª\u0001H\u0002J\u001c\u0010\u0087\u0003\u001a\u00030ª\u00012\u0007\u0010½\u0001\u001a\u00020=2\u0007\u0010Ú\u0002\u001a\u00020\fH\u0002J\n\u0010\u0088\u0003\u001a\u00030ª\u0001H\u0002J\n\u0010\u0089\u0003\u001a\u00030ª\u0001H\u0002J\n\u0010\u008a\u0003\u001a\u00030ª\u0001H\u0002J.\u0010\u008b\u0003\u001a\u00030ª\u00012\u0007\u0010\u008c\u0003\u001a\u00020\u00062\u0007\u0010\u008d\u0003\u001a\u00020\u00062\u0007\u0010\u008e\u0003\u001a\u00020\u00062\u0007\u0010ó\u0002\u001a\u00020\u0006H\u0002J\n\u0010\u008f\u0003\u001a\u00030ª\u0001H\u0002J\n\u0010\u0090\u0003\u001a\u00030ª\u0001H\u0002J\n\u0010\u0091\u0003\u001a\u00030ª\u0001H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010&\u001a\n (*\u0004\u0018\u00010'0'X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0006X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u000206X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010B\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020FX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010G\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010H\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010O\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010P\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010Q\u001a\u00020RX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010S\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010T\u001a\u00020UX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010V\u001a\u0004\u0018\u00010WX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010X\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010Y\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010Z\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010[\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\\\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010]\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010^\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010_\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010`\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010a\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010b\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010c\u001a\u0004\u0018\u00010dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010e\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010g\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010h\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010i\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010j\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010k\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010l\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010m\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010n\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010o\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010p\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010q\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010r\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010s\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010t\u001a\u00020uX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010v\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010w\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010x\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010y\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010z\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010{\u001a\u00020|X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010}\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010~\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u007f\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0080\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0081\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0082\u0001\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0083\u0001\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0084\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0085\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0086\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0087\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0088\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0089\u0001\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u008a\u0001\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u008b\u0001\u001a\u00030\u008c\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u008d\u0001\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u008e\u0001\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u008f\u0001\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0090\u0001\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0091\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0092\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0093\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0094\u0001\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0095\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u0096\u0001\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0097\u0001\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0098\u0001\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u0099\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u009a\u0001\u001a\u00020=X\u0082.¢\u0006\u0002\n\u0000R\u000f\u0010\u009b\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u009c\u0001\u001a\u00030\u009d\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000f\u0010\u009e\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000R\u0012\u0010\u009f\u0001\u001a\u0005\u0018\u00010 \u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010¡\u0001\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010¢\u0001\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010£\u0001\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010¤\u0001\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010¥\u0001\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u009f\u0003"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "accent", "", "apiBase", "", "applyNewPasswordBtn", "Landroid/widget/TextView;", "applyNewPasswordRequestInFlight", "", "applyNewPasswordSpinnerFrame", "applyNewPasswordSpinnerRunnable", "Ljava/lang/Runnable;", "authFormsHost", "authHeightAnimator", "Landroid/animation/ValueAnimator;", "authInlineErrorView", "authModeHint", "authScreenRoot", "Landroid/widget/LinearLayout;", "authSwitchAnimating", "authTab", "Lcom/filmkio/nativescreen/account/AccountScreenView$AuthTab;", "authTabIndicatorAnimator", "authTabsIndicator", "Landroid/view/View;", "authTabsWrap", "backFromForgotBtn", "backFromQrBtn", "bgColor", "cardFill", "cardStroke", FirebaseAnalytics.Param.CONTENT, "currentPanelTab", "Lcom/filmkio/nativescreen/account/AccountScreenView$PanelTab;", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "fieldFill", "fieldStroke", "forgotInlineErrorView", "forgotLineOne", "forgotLineTwo", "forgotScreenRoot", "forgotStep", "Lcom/filmkio/nativescreen/account/AccountScreenView$ForgotStep;", "forgotStepOne", "forgotStepThree", "forgotStepTwo", "guestRoot", "guestScreen", "Lcom/filmkio/nativescreen/account/AccountScreenView$GuestScreen;", "initialFocusDone", "isLoggedIn", "isTouchDevice", "loggedSection", "loginBtn", "loginIdentityInput", "Lcom/filmkio/nativescreen/account/AccountScreenView$FloatingInput;", "loginPanel", "loginPasswordInput", "loginRequestInFlight", "loginSpinnerFrame", "loginSpinnerRunnable", "loginTabBtn", "logoutBtn", "mainHandler", "Landroid/os/Handler;", "messageText", "messageView", "openForgotBtn", "openQrBtn", "panelAvatarText", "panelCountdownDaysText", "panelCountdownHoursText", "panelCountdownMinutesText", "panelCountdownRow", "panelCountdownRunnable", "panelCountdownScroll", "Landroid/widget/HorizontalScrollView;", "panelCountdownSecondsText", "panelCountdownTargetMillis", "", "panelData", "Lcom/filmkio/nativescreen/account/UserPanelData;", "panelEmailText", "panelImportantLinksWrap", "panelInstagramCard", "panelInstagramUrl", "panelLoading", "panelLoadingText", "panelNameText", "panelNotificationsWrap", "panelRegularLinksWrap", "panelShortcutGridWrap", "panelSocialLinksWrap", "panelSubArcView", "Lcom/filmkio/nativescreen/account/AccountScreenView$SubscriptionGaugeView;", "panelSubMetaText", "panelSubPercentText", "panelSubStatusChip", "panelTabImportantBtn", "panelTabImportantContent", "panelTabRegularBtn", "panelTabRegularContent", "panelTabSubscriptionBtn", "panelTabSubscriptionContent", "panelTabsRow", "panelTelegramCard", "panelTelegramUrl", "qrCode", "qrCodeValue", "qrCountdownRunnable", "qrImage", "Landroid/widget/ImageView;", "qrInlineMessageView", "qrLoading", "qrMetaWrap", "qrPollInFlight", "qrPollRunnable", "qrProgress", "Landroid/widget/ProgressBar;", "qrReloadBtn", "qrScreenRoot", "qrSecondsLeft", "qrStatus", "qrTimer", "qrToken", "qrUrl", "qrUrlValue", "recoverCodeInput", "recoverEmailInput", "recoverPasswordInput", "recoverRepeatPasswordInput", "recoveryCodeSent", "recoveryEmailRequestInFlight", "recoveryLoadingTarget", "Lcom/filmkio/nativescreen/account/AccountScreenView$RecoveryLoadingTarget;", "recoveryRunnable", "recoverySecondsLeft", "recoverySendSpinnerFrame", "recoverySendSpinnerRunnable", "registerBtn", "registerEmailInput", "registerMobileInput", "registerPanel", "registerPasswordInput", "registerRequestInFlight", "registerSpinnerFrame", "registerSpinnerRunnable", "registerTabBtn", "registerUsernameInput", "resendRecoverMailBtn", "scrollView", "Landroid/widget/ScrollView;", "sendRecoverMailBtn", "session", "Lcom/filmkio/Session;", "verifiedRecoveryCode", "verifyCodeRequestInFlight", "verifyCodeSpinnerFrame", "verifyCodeSpinnerRunnable", "verifyRecoverCodeBtn", "aliasMatches", "value", "alias", "animateAuthTabSwitch", "", "fromTab", "toTab", "applyAuthTabStyle", "view", "selected", "focused", "applyButtonStyle", TtmlNode.TAG_STYLE, "Lcom/filmkio/nativescreen/account/AccountScreenView$ButtonStyle;", "enabled", "applyForgotStepBadge", "isActive", "isDone", "applyForgotStepLine", "isFilled", "applyNewPassword", "applyPanelTabButtonStyle", "applyPasswordVisibility", "field", "applySession", "newSession", "successMessage", "attachMenuShortcut", "buildAuthScreen", "buildForgotScreen", "buildGuestScreens", "buildLayout", "buildLoggedSection", "buildLoginPanel", "buildPanelShortcutEntries", "", "Lcom/filmkio/nativescreen/account/AccountScreenView$PanelShortcutEntry;", "menuItems", "Lcom/filmkio/nativescreen/account/PanelMenuItem;", "buildQrContent", TtmlNode.RUBY_CONTAINER, "buildQrScreen", "buildRecoverContent", "buildRegisterPanel", "centeredContentParams", "Landroid/widget/LinearLayout$LayoutParams;", "topMargin", "clearAuthInlineMessage", "copyToClipboard", Constants.ScionAnalytics.PARAM_LABEL, "defaultInputHint", "labelText", "detectMessageTone", "Lcom/filmkio/nativescreen/account/AccountScreenView$MessageTone;", "text", "doLogin", "doLogout", "doRegister", "dp", "v", "dpF", "", "drawCircularFinder", "canvas", "Landroid/graphics/Canvas;", "startX", "startY", "moduleSize", TypedValues.CycleType.S_WAVE_OFFSET, "onPaint", "Landroid/graphics/Paint;", "offPaint", "findPanelShortcutItem", FirebaseAnalytics.Param.ITEMS, "spec", "Lcom/filmkio/nativescreen/account/AccountScreenView$PanelShortcutSpec;", "focusAuthTab", "focusForgot", "focusLogout", "focusQr", "focusWithRetries", "getView", "Lkotlin/Function0;", "generateQr", "Landroid/graphics/Bitmap;", "size", "darkMode", "handleBackPressed", "handlePanelAction", "item", "hardLogout", "hideKeyboard", "isFinderRegionModule", "x", "y", "modules", "isPanelInternalRoute", "isRecoveryExpiryMessage", "isValidEmail", "loadQr", "loadUserPanelData", "force", "makeAuthSectionPanel", "makeAuthTabButton", "makeButton", "makeCard", "Lcom/filmkio/nativescreen/account/AccountScreenView$CardParts;", "title", "iconRes", "makeCountdownCell", "Lkotlin/Pair;", "makeCountdownSeparator", "makeFloatingInput", "leadingIconRes", "isPassword", "inputType", "imeAction", "makeForgotStepBadge", "makeForgotStepLine", "makeInlineErrorView", "makeNotificationRow", "message", "makePanelLinkRow", "subtitle", "emphasis", "Lcom/filmkio/nativescreen/account/AccountScreenView$LinkEmphasis;", "makePanelShortcutCard", "makePanelTabButton", "tab", "makeSectionHeader", "makeSocialHalfCard", "measureAuthPanelHeight", "panel", "normalizeExternalUrl", "raw", "normalizePanelAlias", "onAttachedToWindow", "onDetachedFromWindow", "openAccountPanelPage", "key", "openExternalUrl", ImagesContract.URL, "openPurchaseScreen", "panelContentParams", "parseExpireDateMillis", "(Ljava/lang/String;)Ljava/lang/Long;", "readableError", Constants.IPC_BUNDLE_KEY_SEND_ERROR, "", "fallback", "refreshUiByAuthState", "renderPanelData", "data", "renderPanelLinks", "wrap", "renderPanelNotifications", "Lcom/filmkio/nativescreen/account/NotifItem;", "renderPanelShortcutGrid", "requestInitialFocus", "resetForgotFlow", "keepEmail", "resolveCountdownTargetMillis", "expireDate", "dayLeft", "resolveSocialUrl", "keyNeedle", "labelNeedles", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "scrollToView", "sendRecoveryEmail", "isResend", "setApplyNewPasswordLoading", "loading", "setAuthFormsHostHeight", "targetHeight", "animate", "durationMs", "setForgotStep", "step", "setGuestScreen", "screen", "setInlineMessage", "tone", "setLoginLoading", "setMessage", "setRecoveryEmailLoading", TypedValues.AttributesType.S_TARGET, "setRegisterLoading", "setSubscriptionGaugeProgress", "percent", "setVerifyCodeLoading", "showShortMessage", "startApplyNewPasswordSpinner", "startLoginSpinner", "startPanelCountdown", "targetMillis", "startQrCountdown", "startQrPolling", "startRecoverySendSpinner", "startRecoveryTimer", "seconds", "startRegisterSpinner", "startVerifyCodeSpinner", "stopApplyNewPasswordSpinner", "stopLoginSpinner", "stopPanelCountdown", "stopQrCountdown", "stopQrPolling", "stopRecoverySendSpinner", "stopRecoveryTimer", "stopRegisterSpinner", "stopVerifyCodeSpinner", "styledHint", "", "switchAuthTab", "switchPanelTab", "syncAuthFormsHostHeight", "togglePasswordVisibility", "updateAuthTabIndicator", "updateAuthTabUi", "updateFloatingLabel", "updateForgotStepUi", "updateGuestScreenUi", "updateMessage", "updatePanelCountdownViews", "days", "hours", "minutes", "updateQrUi", "updateRecoveryResendUi", "verifyRecoveryCode", "AuthTab", "ButtonStyle", "CardParts", "FloatingInput", "ForgotStep", "GuestScreen", "LinkEmphasis", "MessageTone", "PanelShortcutEntry", "PanelShortcutSpec", "PanelTab", "RecoveryLoadingTarget", "SubscriptionGaugeView", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AccountScreenView extends FrameLayout {
    public static final int $stable = 8;
    private final int accent;
    private final String apiBase;
    private TextView applyNewPasswordBtn;
    private boolean applyNewPasswordRequestInFlight;
    private int applyNewPasswordSpinnerFrame;
    private Runnable applyNewPasswordSpinnerRunnable;
    private FrameLayout authFormsHost;
    private ValueAnimator authHeightAnimator;
    private TextView authInlineErrorView;
    private TextView authModeHint;
    private LinearLayout authScreenRoot;
    private boolean authSwitchAnimating;
    private AuthTab authTab;
    private ValueAnimator authTabIndicatorAnimator;
    private View authTabsIndicator;
    private FrameLayout authTabsWrap;
    private TextView backFromForgotBtn;
    private TextView backFromQrBtn;
    private final int bgColor;
    private final int cardFill;
    private final int cardStroke;
    private final LinearLayout content;
    private final Context ctx;
    private PanelTab currentPanelTab;
    private final ExecutorService executor;
    private final int fieldFill;
    private final int fieldStroke;
    private TextView forgotInlineErrorView;
    private View forgotLineOne;
    private View forgotLineTwo;
    private LinearLayout forgotScreenRoot;
    private ForgotStep forgotStep;
    private TextView forgotStepOne;
    private TextView forgotStepThree;
    private TextView forgotStepTwo;
    private LinearLayout guestRoot;
    private GuestScreen guestScreen;
    private boolean initialFocusDone;
    private boolean isLoggedIn;
    private final boolean isTouchDevice;
    private LinearLayout loggedSection;
    private TextView loginBtn;
    private FloatingInput loginIdentityInput;
    private LinearLayout loginPanel;
    private FloatingInput loginPasswordInput;
    private boolean loginRequestInFlight;
    private int loginSpinnerFrame;
    private Runnable loginSpinnerRunnable;
    private TextView loginTabBtn;
    private TextView logoutBtn;
    private final Handler mainHandler;
    private String messageText;
    private final TextView messageView;
    private TextView openForgotBtn;
    private TextView openQrBtn;
    private TextView panelAvatarText;
    private TextView panelCountdownDaysText;
    private TextView panelCountdownHoursText;
    private TextView panelCountdownMinutesText;
    private LinearLayout panelCountdownRow;
    private Runnable panelCountdownRunnable;
    private HorizontalScrollView panelCountdownScroll;
    private TextView panelCountdownSecondsText;
    private long panelCountdownTargetMillis;
    private UserPanelData panelData;
    private TextView panelEmailText;
    private LinearLayout panelImportantLinksWrap;
    private LinearLayout panelInstagramCard;
    private String panelInstagramUrl;
    private boolean panelLoading;
    private TextView panelLoadingText;
    private TextView panelNameText;
    private LinearLayout panelNotificationsWrap;
    private LinearLayout panelRegularLinksWrap;
    private LinearLayout panelShortcutGridWrap;
    private LinearLayout panelSocialLinksWrap;
    private SubscriptionGaugeView panelSubArcView;
    private TextView panelSubMetaText;
    private TextView panelSubPercentText;
    private TextView panelSubStatusChip;
    private TextView panelTabImportantBtn;
    private LinearLayout panelTabImportantContent;
    private TextView panelTabRegularBtn;
    private LinearLayout panelTabRegularContent;
    private TextView panelTabSubscriptionBtn;
    private LinearLayout panelTabSubscriptionContent;
    private LinearLayout panelTabsRow;
    private LinearLayout panelTelegramCard;
    private String panelTelegramUrl;
    private String qrCode;
    private TextView qrCodeValue;
    private Runnable qrCountdownRunnable;
    private ImageView qrImage;
    private TextView qrInlineMessageView;
    private boolean qrLoading;
    private LinearLayout qrMetaWrap;
    private boolean qrPollInFlight;
    private Runnable qrPollRunnable;
    private ProgressBar qrProgress;
    private TextView qrReloadBtn;
    private LinearLayout qrScreenRoot;
    private int qrSecondsLeft;
    private TextView qrStatus;
    private TextView qrTimer;
    private String qrToken;
    private String qrUrl;
    private TextView qrUrlValue;
    private FloatingInput recoverCodeInput;
    private FloatingInput recoverEmailInput;
    private FloatingInput recoverPasswordInput;
    private FloatingInput recoverRepeatPasswordInput;
    private boolean recoveryCodeSent;
    private boolean recoveryEmailRequestInFlight;
    private RecoveryLoadingTarget recoveryLoadingTarget;
    private Runnable recoveryRunnable;
    private int recoverySecondsLeft;
    private int recoverySendSpinnerFrame;
    private Runnable recoverySendSpinnerRunnable;
    private TextView registerBtn;
    private FloatingInput registerEmailInput;
    private FloatingInput registerMobileInput;
    private LinearLayout registerPanel;
    private FloatingInput registerPasswordInput;
    private boolean registerRequestInFlight;
    private int registerSpinnerFrame;
    private Runnable registerSpinnerRunnable;
    private TextView registerTabBtn;
    private FloatingInput registerUsernameInput;
    private TextView resendRecoverMailBtn;
    private final ScrollView scrollView;
    private TextView sendRecoverMailBtn;
    private Session session;
    private String verifiedRecoveryCode;
    private boolean verifyCodeRequestInFlight;
    private int verifyCodeSpinnerFrame;
    private Runnable verifyCodeSpinnerRunnable;
    private TextView verifyRecoverCodeBtn;

    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;
        public static final /* synthetic */ int[] $EnumSwitchMapping$2;
        public static final /* synthetic */ int[] $EnumSwitchMapping$3;
        public static final /* synthetic */ int[] $EnumSwitchMapping$4;
        public static final /* synthetic */ int[] $EnumSwitchMapping$5;

        static {
            int[] iArr = new int[GuestScreen.values().length];
            try {
                iArr[GuestScreen.AUTH.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[GuestScreen.FORGOT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[GuestScreen.f342QR.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[LinkEmphasis.values().length];
            try {
                iArr2[LinkEmphasis.SOCIAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr2[LinkEmphasis.IMPORTANT.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr2[LinkEmphasis.REGULAR.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr2[LinkEmphasis.DANGER.ordinal()] = 4;
            } catch (NoSuchFieldError unused7) {
            }
            $EnumSwitchMapping$1 = iArr2;
            int[] iArr3 = new int[MessageTone.values().length];
            try {
                iArr3[MessageTone.ERROR.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr3[MessageTone.SUCCESS.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr3[MessageTone.INFO.ordinal()] = 3;
            } catch (NoSuchFieldError unused10) {
            }
            $EnumSwitchMapping$2 = iArr3;
            int[] iArr4 = new int[ButtonStyle.values().length];
            try {
                iArr4[ButtonStyle.PRIMARY.ordinal()] = 1;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr4[ButtonStyle.SECONDARY.ordinal()] = 2;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr4[ButtonStyle.DOWNLOAD_BOX.ordinal()] = 3;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                iArr4[ButtonStyle.DANGER.ordinal()] = 4;
            } catch (NoSuchFieldError unused14) {
            }
            $EnumSwitchMapping$3 = iArr4;
            int[] iArr5 = new int[AuthTab.values().length];
            try {
                iArr5[AuthTab.LOGIN.ordinal()] = 1;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                iArr5[AuthTab.REGISTER.ordinal()] = 2;
            } catch (NoSuchFieldError unused16) {
            }
            $EnumSwitchMapping$4 = iArr5;
            int[] iArr6 = new int[ForgotStep.values().length];
            try {
                iArr6[ForgotStep.ENTER_EMAIL.ordinal()] = 1;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                iArr6[ForgotStep.VERIFY_CODE.ordinal()] = 2;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                iArr6[ForgotStep.SET_PASSWORD.ordinal()] = 3;
            } catch (NoSuchFieldError unused19) {
            }
            $EnumSwitchMapping$5 = iArr6;
        }
    }

    private final boolean isFinderRegionModule(int x, int y, int modules) {
        int i = modules - 7;
        if (x >= 0 && x < 7) {
            if (y >= 0 && y < 7) {
                return true;
            }
        }
        if (i <= x && x < modules) {
            if (y >= 0 && y < 7) {
                return true;
            }
        }
        if (x >= 0 && x < 7) {
            if (i <= y && y < modules) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AccountScreenView(Context ctx) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        this.ctx = ctx;
        this.accent = -676591;
        this.bgColor = -16052721;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.fieldFill = -16447475;
        this.fieldStroke = -13946310;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        String apiBase = AppState.INSTANCE.getApiBase();
        this.apiBase = apiBase == null ? "" : apiBase;
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.guestScreen = GuestScreen.AUTH;
        this.authTab = AuthTab.LOGIN;
        this.recoveryLoadingTarget = RecoveryLoadingTarget.NONE;
        this.forgotStep = ForgotStep.ENTER_EMAIL;
        this.verifiedRecoveryCode = "";
        this.qrUrl = "";
        this.qrCode = "";
        this.qrToken = "";
        this.scrollView = new ScrollView(ctx);
        this.content = new LinearLayout(ctx);
        this.messageView = new TextView(ctx);
        this.currentPanelTab = PanelTab.SUBSCRIPTION;
        this.panelTelegramUrl = "https://t.me/FilmKio";
        this.panelInstagramUrl = "https://instagram.com/FilmKio";
        setLayoutDirection(1);
        setBackgroundColor(-16052721);
        buildLayout();
        Session sessionLoad = SessionStore.INSTANCE.load(ctx);
        AppState.INSTANCE.setSession(sessionLoad);
        this.session = sessionLoad;
        this.isLoggedIn = sessionLoad != null;
        refreshUiByAuthState();
        updateMessage();
        if (zHasSystemFeature) {
            return;
        }
        if (this.isLoggedIn) {
            focusLogout();
        } else {
            focusAuthTab();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        FrameLayout frameLayout = this.authTabsWrap;
        FrameLayout frameLayout2 = null;
        if (frameLayout != null) {
            if (frameLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
                frameLayout = null;
            }
            frameLayout.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.onAttachedToWindow$lambda$1(this.f$0);
                }
            });
        }
        FrameLayout frameLayout3 = this.authFormsHost;
        if (frameLayout3 != null) {
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            } else {
                frameLayout2 = frameLayout3;
            }
            frameLayout2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.onAttachedToWindow$lambda$2(this.f$0);
                }
            });
        }
        if (this.isTouchDevice || this.initialFocusDone) {
            return;
        }
        this.initialFocusDone = true;
        requestInitialFocus();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onAttachedToWindow$lambda$1(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateAuthTabIndicator(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onAttachedToWindow$lambda$2(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncAuthFormsHostHeight(false);
    }

    public final void requestInitialFocus() {
        if (this.isTouchDevice) {
            return;
        }
        if (this.isLoggedIn) {
            focusLogout();
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this.guestScreen.ordinal()];
        if (i == 1) {
            focusAuthTab();
        } else if (i == 2) {
            focusForgot();
        } else {
            if (i != 3) {
                return;
            }
            focusQr();
        }
    }

    public final boolean handleBackPressed() {
        if (this.isLoggedIn) {
            return false;
        }
        if (this.guestScreen != GuestScreen.FORGOT && this.guestScreen != GuestScreen.f342QR) {
            return false;
        }
        setGuestScreen(GuestScreen.AUTH);
        return true;
    }

    private final void buildLayout() {
        int iM377dp = this.isTouchDevice ? 0 : m377dp(22);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        linearLayout.setPadding(m377dp(10), iM377dp, m377dp(10), m377dp(14));
        addView(linearLayout);
        ScrollView scrollView = this.scrollView;
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setOverScrollMode(2);
        scrollView.setFillViewport(true);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.addView(this.scrollView);
        LinearLayout linearLayout2 = this.content;
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        linearLayout2.setPadding(0, 0, 0, m377dp(24));
        this.scrollView.addView(this.content);
        TextView textView = this.messageView;
        textView.setTextColor(-2627846);
        textView.setTextSize(14.0f);
        textView.setGravity(17);
        textView.setVisibility(8);
        textView.setPadding(m377dp(12), m377dp(8), m377dp(12), m377dp(8));
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setBackground(roundedBg(588784689, 810314378, m377dp(1), dpF(14)));
        LinearLayout linearLayout3 = this.content;
        TextView textView2 = this.messageView;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = m377dp(12);
        Unit unit = Unit.INSTANCE;
        linearLayout3.addView(textView2, layoutParams);
        buildGuestScreens();
        buildLoggedSection();
    }

    private final void buildGuestScreens() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        this.guestRoot = linearLayout;
        buildAuthScreen();
        buildForgotScreen();
        buildQrScreen();
        LinearLayout linearLayout2 = this.guestRoot;
        LinearLayout linearLayout3 = null;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guestRoot");
            linearLayout2 = null;
        }
        LinearLayout linearLayout4 = this.authScreenRoot;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout4 = null;
        }
        linearLayout2.addView(linearLayout4);
        LinearLayout linearLayout5 = this.guestRoot;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guestRoot");
            linearLayout5 = null;
        }
        LinearLayout linearLayout6 = this.forgotScreenRoot;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotScreenRoot");
            linearLayout6 = null;
        }
        linearLayout5.addView(linearLayout6);
        LinearLayout linearLayout7 = this.guestRoot;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guestRoot");
            linearLayout7 = null;
        }
        LinearLayout linearLayout8 = this.qrScreenRoot;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScreenRoot");
            linearLayout8 = null;
        }
        linearLayout7.addView(linearLayout8);
        LinearLayout linearLayout9 = this.content;
        LinearLayout linearLayout10 = this.guestRoot;
        if (linearLayout10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guestRoot");
        } else {
            linearLayout3 = linearLayout10;
        }
        linearLayout9.addView(linearLayout3);
    }

    private final void buildAuthScreen() {
        FrameLayout frameLayout;
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setLayoutParams(centeredContentParams$default(this, 0, 1, null));
        this.authScreenRoot = linearLayout;
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        frameLayout2.setLayoutDirection(1);
        frameLayout2.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(1), dpF(16)));
        frameLayout2.setPadding(m377dp(5), m377dp(5), m377dp(5), m377dp(5));
        frameLayout2.setClipChildren(true);
        frameLayout2.setClipToPadding(true);
        this.authTabsWrap = frameLayout2;
        View view = new View(this.ctx);
        view.setBackground(roundedBg(this.accent, ViewCompat.MEASURED_SIZE_MASK, 0, dpF(10)));
        view.setAlpha(1.0f);
        this.authTabsIndicator = view;
        FrameLayout frameLayout3 = this.authTabsWrap;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout3 = null;
        }
        View view2 = this.authTabsIndicator;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view2 = null;
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(1, 1);
        layoutParams.gravity = 51;
        Unit unit = Unit.INSTANCE;
        frameLayout3.addView(view2, layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
        this.loginTabBtn = makeAuthTabButton("ورود");
        this.registerTabBtn = makeAuthTabButton("عضویت");
        TextView textView = this.loginTabBtn;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
            textView = null;
        }
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda29
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildAuthScreen$lambda$14(this.f$0, view3);
            }
        });
        TextView textView2 = this.registerTabBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
            textView2 = null;
        }
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda30
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildAuthScreen$lambda$15(this.f$0, view3);
            }
        });
        TextView textView3 = this.loginTabBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
            textView3 = null;
        }
        linearLayout2.addView(textView3, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView4 = this.registerTabBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
            textView4 = null;
        }
        linearLayout2.addView(textView4, new LinearLayout.LayoutParams(0, -2, 1.0f));
        FrameLayout frameLayout4 = this.authTabsWrap;
        if (frameLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout4 = null;
        }
        frameLayout4.addView(linearLayout2);
        TextView textView5 = new TextView(this.ctx);
        textView5.setTextColor(-4666915);
        textView5.setTextSize(13.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView5.getTypeface();
        }
        textView5.setTypeface(typefaceMedium);
        textView5.setLineSpacing(m377dp(2), 1.0f);
        textView5.setPadding(m377dp(2), m377dp(10), m377dp(2), m377dp(0));
        textView5.setText("");
        textView5.setVisibility(8);
        this.authModeHint = textView5;
        LinearLayout linearLayout3 = new LinearLayout(this.ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(1), dpF(18)));
        linearLayout3.setPadding(m377dp(14), m377dp(14), m377dp(14), m377dp(14));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m377dp(12);
        linearLayout3.setLayoutParams(layoutParams2);
        this.loginPanel = buildLoginPanel();
        this.registerPanel = buildRegisterPanel();
        FrameLayout frameLayout5 = new FrameLayout(this.ctx);
        frameLayout5.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        frameLayout5.setClipChildren(false);
        frameLayout5.setClipToPadding(false);
        this.authFormsHost = frameLayout5;
        this.authInlineErrorView = makeInlineErrorView();
        FrameLayout frameLayout6 = this.authFormsHost;
        if (frameLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout6 = null;
        }
        LinearLayout linearLayout4 = this.loginPanel;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPanel");
            linearLayout4 = null;
        }
        frameLayout6.addView(linearLayout4, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout frameLayout7 = this.authFormsHost;
        if (frameLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout7 = null;
        }
        LinearLayout linearLayout5 = this.registerPanel;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerPanel");
            linearLayout5 = null;
        }
        frameLayout7.addView(linearLayout5, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout frameLayout8 = this.authFormsHost;
        if (frameLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout8 = null;
        }
        linearLayout3.addView(frameLayout8);
        TextView textViewMakeButton = makeButton("فراموشی رمز عبور", ButtonStyle.DOWNLOAD_BOX);
        this.openForgotBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
            textViewMakeButton = null;
        }
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            TextView textView6 = this.openForgotBtn;
            if (textView6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
                textView6 = null;
            }
            typefaceRegular = textView6.getTypeface();
        }
        textViewMakeButton.setTypeface(typefaceRegular);
        TextView textView7 = this.openForgotBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
            textView7 = null;
        }
        textView7.setTextSize(13.0f);
        TextView textView8 = this.openForgotBtn;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
            textView8 = null;
        }
        textView8.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda31
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildAuthScreen$lambda$20(this.f$0, view3);
            }
        });
        TextView textViewMakeButton2 = makeButton("ورود آسان (QR)", ButtonStyle.DOWNLOAD_BOX);
        this.openQrBtn = textViewMakeButton2;
        if (textViewMakeButton2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
            textViewMakeButton2 = null;
        }
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            TextView textView9 = this.openQrBtn;
            if (textView9 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
                textView9 = null;
            }
            typefaceRegular2 = textView9.getTypeface();
        }
        textViewMakeButton2.setTypeface(typefaceRegular2);
        TextView textView10 = this.openQrBtn;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
            textView10 = null;
        }
        textView10.setTextSize(13.0f);
        TextView textView11 = this.openQrBtn;
        if (textView11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
            textView11 = null;
        }
        textView11.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda32
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildAuthScreen$lambda$21(this.f$0, view3);
            }
        });
        LinearLayout linearLayout6 = new LinearLayout(this.ctx);
        linearLayout6.setOrientation(0);
        linearLayout6.setLayoutDirection(1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m377dp(10);
        linearLayout6.setLayoutParams(layoutParams3);
        TextView textView12 = this.openForgotBtn;
        if (textView12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
            textView12 = null;
        }
        ViewGroup.LayoutParams layoutParams4 = textView12.getLayoutParams();
        LinearLayout.LayoutParams layoutParams5 = layoutParams4 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams4 : null;
        if (layoutParams5 != null) {
            layoutParams5.topMargin = 0;
            TextView textView13 = this.openForgotBtn;
            if (textView13 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
                textView13 = null;
            }
            textView13.setLayoutParams(layoutParams5);
            Unit unit2 = Unit.INSTANCE;
            Unit unit3 = Unit.INSTANCE;
        }
        TextView textView14 = this.openQrBtn;
        if (textView14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
            textView14 = null;
        }
        ViewGroup.LayoutParams layoutParams6 = textView14.getLayoutParams();
        LinearLayout.LayoutParams layoutParams7 = layoutParams6 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams6 : null;
        if (layoutParams7 != null) {
            layoutParams7.topMargin = 0;
            TextView textView15 = this.openQrBtn;
            if (textView15 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
                textView15 = null;
            }
            textView15.setLayoutParams(layoutParams7);
            Unit unit4 = Unit.INSTANCE;
            Unit unit5 = Unit.INSTANCE;
        }
        TextView textView16 = this.openForgotBtn;
        if (textView16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openForgotBtn");
            textView16 = null;
        }
        linearLayout6.addView(textView16, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView17 = this.openQrBtn;
        if (textView17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("openQrBtn");
            textView17 = null;
        }
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams8.setMarginStart(m377dp(10));
        Unit unit6 = Unit.INSTANCE;
        linearLayout6.addView(textView17, layoutParams8);
        LinearLayout linearLayout7 = this.authScreenRoot;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout7 = null;
        }
        FrameLayout frameLayout9 = this.authTabsWrap;
        if (frameLayout9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout9 = null;
        }
        linearLayout7.addView(frameLayout9);
        LinearLayout linearLayout8 = this.authScreenRoot;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout8 = null;
        }
        TextView textView18 = this.authModeHint;
        if (textView18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authModeHint");
            textView18 = null;
        }
        linearLayout8.addView(textView18);
        LinearLayout linearLayout9 = this.authScreenRoot;
        if (linearLayout9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout9 = null;
        }
        TextView textView19 = this.authInlineErrorView;
        if (textView19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authInlineErrorView");
            textView19 = null;
        }
        LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams9.topMargin = m377dp(8);
        Unit unit7 = Unit.INSTANCE;
        linearLayout9.addView(textView19, layoutParams9);
        LinearLayout linearLayout10 = this.authScreenRoot;
        if (linearLayout10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout10 = null;
        }
        linearLayout10.addView(linearLayout3);
        LinearLayout linearLayout11 = this.authScreenRoot;
        if (linearLayout11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout11 = null;
        }
        linearLayout11.addView(linearLayout6);
        updateAuthTabUi();
        FrameLayout frameLayout10 = this.authTabsWrap;
        if (frameLayout10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout10 = null;
        }
        frameLayout10.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda34
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.buildAuthScreen$lambda$28(this.f$0);
            }
        });
        FrameLayout frameLayout11 = this.authFormsHost;
        if (frameLayout11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout = null;
        } else {
            frameLayout = frameLayout11;
        }
        frameLayout.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda35
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.buildAuthScreen$lambda$29(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$14(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchAuthTab(AuthTab.LOGIN, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$15(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchAuthTab(AuthTab.REGISTER, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$20(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        resetForgotFlow$default(this$0, false, 1, null);
        this$0.setGuestScreen(GuestScreen.FORGOT);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$21(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setGuestScreen(GuestScreen.f342QR);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$28(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateAuthTabIndicator(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildAuthScreen$lambda$29(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncAuthFormsHostHeight(false);
    }

    private final LinearLayout buildLoginPanel() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        int i = -m377dp(6);
        FloatingInput floatingInputMakeFloatingInput$default = makeFloatingInput$default(this, "نام کاربری / ایمیل / شماره تماس", C2629R.drawable.ic_account_username, false, 0, 5, 12, null);
        this.loginIdentityInput = floatingInputMakeFloatingInput$default;
        TextView textView = null;
        if (floatingInputMakeFloatingInput$default == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
            floatingInputMakeFloatingInput$default = null;
        }
        ViewGroup.LayoutParams layoutParams = floatingInputMakeFloatingInput$default.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 != null) {
            layoutParams2.topMargin = -m377dp(14);
            FloatingInput floatingInput = this.loginIdentityInput;
            if (floatingInput == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
                floatingInput = null;
            }
            floatingInput.getRoot().setLayoutParams(layoutParams2);
        }
        FloatingInput floatingInputMakeFloatingInput$default2 = makeFloatingInput$default(this, "رمز عبور", C2629R.drawable.ic_account_password, true, 0, 6, 8, null);
        this.loginPasswordInput = floatingInputMakeFloatingInput$default2;
        if (floatingInputMakeFloatingInput$default2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
            floatingInputMakeFloatingInput$default2 = null;
        }
        ViewGroup.LayoutParams layoutParams3 = floatingInputMakeFloatingInput$default2.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams4 = layoutParams3 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams3 : null;
        if (layoutParams4 != null) {
            layoutParams4.topMargin = i;
            FloatingInput floatingInput2 = this.loginPasswordInput;
            if (floatingInput2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
                floatingInput2 = null;
            }
            floatingInput2.getRoot().setLayoutParams(layoutParams4);
        }
        FloatingInput floatingInput3 = this.loginPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
            floatingInput3 = null;
        }
        floatingInput3.getEdit().setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda37
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView2, int i2, KeyEvent keyEvent) {
                return AccountScreenView.buildLoginPanel$lambda$33(this.f$0, textView2, i2, keyEvent);
            }
        });
        TextView textViewMakeButton = makeButton("ورود به حساب", ButtonStyle.PRIMARY);
        this.loginBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textViewMakeButton = null;
        }
        textViewMakeButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda38
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildLoginPanel$lambda$34(this.f$0, view);
            }
        });
        TextView textView2 = this.loginBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView2 = null;
        }
        ViewGroup.LayoutParams layoutParams5 = textView2.getLayoutParams();
        LinearLayout.LayoutParams layoutParams6 = layoutParams5 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams5 : null;
        if (layoutParams6 != null) {
            layoutParams6.topMargin = m377dp(20);
            TextView textView3 = this.loginBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
                textView3 = null;
            }
            textView3.setLayoutParams(layoutParams6);
        }
        FloatingInput floatingInput4 = this.loginIdentityInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
            floatingInput4 = null;
        }
        linearLayout.addView(floatingInput4.getRoot());
        FloatingInput floatingInput5 = this.loginPasswordInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
            floatingInput5 = null;
        }
        linearLayout.addView(floatingInput5.getRoot());
        TextView textView4 = this.loginBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
        } else {
            textView = textView4;
        }
        linearLayout.addView(textView);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildLoginPanel$lambda$33(AccountScreenView this$0, TextView textView, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i != 6) {
            return false;
        }
        this$0.doLogin();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildLoginPanel$lambda$34(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.doLogin();
    }

    private final LinearLayout buildRegisterPanel() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        int i = -m377dp(6);
        FloatingInput floatingInputMakeFloatingInput$default = makeFloatingInput$default(this, "نام کاربری", C2629R.drawable.ic_account_username, false, 0, 0, 28, null);
        this.registerUsernameInput = floatingInputMakeFloatingInput$default;
        TextView textView = null;
        if (floatingInputMakeFloatingInput$default == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerUsernameInput");
            floatingInputMakeFloatingInput$default = null;
        }
        ViewGroup.LayoutParams layoutParams = floatingInputMakeFloatingInput$default.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 != null) {
            layoutParams2.topMargin = -m377dp(14);
            FloatingInput floatingInput = this.registerUsernameInput;
            if (floatingInput == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerUsernameInput");
                floatingInput = null;
            }
            floatingInput.getRoot().setLayoutParams(layoutParams2);
        }
        this.registerEmailInput = makeFloatingInput$default(this, "ایمیل", C2629R.drawable.ic_account_email, false, 33, 0, 20, null);
        this.registerPasswordInput = makeFloatingInput$default(this, "رمز عبور", C2629R.drawable.ic_account_password, true, 0, 0, 24, null);
        this.registerMobileInput = makeFloatingInput$default(this, "شماره موبایل (اختیاری)", C2629R.drawable.ic_account_mobile, false, 3, 0, 20, null);
        FloatingInput floatingInput2 = this.registerEmailInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerEmailInput");
            floatingInput2 = null;
        }
        ViewGroup.LayoutParams layoutParams3 = floatingInput2.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams4 = layoutParams3 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams3 : null;
        if (layoutParams4 != null) {
            layoutParams4.topMargin = i;
            FloatingInput floatingInput3 = this.registerEmailInput;
            if (floatingInput3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerEmailInput");
                floatingInput3 = null;
            }
            floatingInput3.getRoot().setLayoutParams(layoutParams4);
        }
        FloatingInput floatingInput4 = this.registerPasswordInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerPasswordInput");
            floatingInput4 = null;
        }
        ViewGroup.LayoutParams layoutParams5 = floatingInput4.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams6 = layoutParams5 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams5 : null;
        if (layoutParams6 != null) {
            layoutParams6.topMargin = i;
            FloatingInput floatingInput5 = this.registerPasswordInput;
            if (floatingInput5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerPasswordInput");
                floatingInput5 = null;
            }
            floatingInput5.getRoot().setLayoutParams(layoutParams6);
        }
        FloatingInput floatingInput6 = this.registerMobileInput;
        if (floatingInput6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerMobileInput");
            floatingInput6 = null;
        }
        ViewGroup.LayoutParams layoutParams7 = floatingInput6.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams8 = layoutParams7 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams7 : null;
        if (layoutParams8 != null) {
            layoutParams8.topMargin = i;
            FloatingInput floatingInput7 = this.registerMobileInput;
            if (floatingInput7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerMobileInput");
                floatingInput7 = null;
            }
            floatingInput7.getRoot().setLayoutParams(layoutParams8);
        }
        TextView textViewMakeButton = makeButton("ساخت حساب", ButtonStyle.PRIMARY);
        this.registerBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textViewMakeButton = null;
        }
        textViewMakeButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda41
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildRegisterPanel$lambda$41(this.f$0, view);
            }
        });
        TextView textView2 = this.registerBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView2 = null;
        }
        ViewGroup.LayoutParams layoutParams9 = textView2.getLayoutParams();
        LinearLayout.LayoutParams layoutParams10 = layoutParams9 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams9 : null;
        if (layoutParams10 != null) {
            layoutParams10.topMargin = m377dp(20);
            TextView textView3 = this.registerBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
                textView3 = null;
            }
            textView3.setLayoutParams(layoutParams10);
        }
        FloatingInput floatingInput8 = this.registerUsernameInput;
        if (floatingInput8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerUsernameInput");
            floatingInput8 = null;
        }
        linearLayout.addView(floatingInput8.getRoot());
        FloatingInput floatingInput9 = this.registerEmailInput;
        if (floatingInput9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerEmailInput");
            floatingInput9 = null;
        }
        linearLayout.addView(floatingInput9.getRoot());
        FloatingInput floatingInput10 = this.registerPasswordInput;
        if (floatingInput10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerPasswordInput");
            floatingInput10 = null;
        }
        linearLayout.addView(floatingInput10.getRoot());
        FloatingInput floatingInput11 = this.registerMobileInput;
        if (floatingInput11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerMobileInput");
            floatingInput11 = null;
        }
        linearLayout.addView(floatingInput11.getRoot());
        TextView textView4 = this.registerBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
        } else {
            textView = textView4;
        }
        linearLayout.addView(textView);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRegisterPanel$lambda$41(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.doRegister();
    }

    private final void buildForgotScreen() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        LinearLayout linearLayout2 = null;
        linearLayout.setLayoutParams(centeredContentParams$default(this, 0, 1, null));
        this.forgotScreenRoot = linearLayout;
        TextView textViewMakeButton = makeButton("بازگشت به ورود/عضویت", ButtonStyle.DOWNLOAD_BOX);
        this.backFromForgotBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromForgotBtn");
            textViewMakeButton = null;
        }
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            TextView textView = this.backFromForgotBtn;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("backFromForgotBtn");
                textView = null;
            }
            typefaceRegular = textView.getTypeface();
        }
        textViewMakeButton.setTypeface(typefaceRegular);
        TextView textView2 = this.backFromForgotBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromForgotBtn");
            textView2 = null;
        }
        textView2.setTextSize(13.0f);
        TextView textView3 = this.backFromForgotBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromForgotBtn");
            textView3 = null;
        }
        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildForgotScreen$lambda$44(this.f$0, view);
            }
        });
        this.forgotInlineErrorView = makeInlineErrorView();
        LinearLayout linearLayoutMakeAuthSectionPanel = makeAuthSectionPanel();
        linearLayoutMakeAuthSectionPanel.addView(makeSectionHeader("فراموشی رمز عبور", "بازیابی مرحله\u200cای: ایمیل، تایید کد، رمز جدید", C2629R.drawable.ic_account_forgot));
        buildRecoverContent(linearLayoutMakeAuthSectionPanel);
        LinearLayout linearLayout3 = this.forgotScreenRoot;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotScreenRoot");
            linearLayout3 = null;
        }
        TextView textView4 = this.backFromForgotBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromForgotBtn");
            textView4 = null;
        }
        linearLayout3.addView(textView4);
        LinearLayout linearLayout4 = this.forgotScreenRoot;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotScreenRoot");
            linearLayout4 = null;
        }
        TextView textView5 = this.forgotInlineErrorView;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotInlineErrorView");
            textView5 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(8);
        Unit unit = Unit.INSTANCE;
        linearLayout4.addView(textView5, layoutParams);
        LinearLayout linearLayout5 = this.forgotScreenRoot;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotScreenRoot");
        } else {
            linearLayout2 = linearLayout5;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m377dp(10);
        Unit unit2 = Unit.INSTANCE;
        linearLayout2.addView(linearLayoutMakeAuthSectionPanel, layoutParams2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildForgotScreen$lambda$44(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setGuestScreen(GuestScreen.AUTH);
    }

    private final void buildQrScreen() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        LinearLayout linearLayout2 = null;
        linearLayout.setLayoutParams(centeredContentParams$default(this, 0, 1, null));
        this.qrScreenRoot = linearLayout;
        TextView textViewMakeButton = makeButton("بازگشت به ورود/عضویت", ButtonStyle.DOWNLOAD_BOX);
        this.backFromQrBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromQrBtn");
            textViewMakeButton = null;
        }
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            TextView textView = this.backFromQrBtn;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("backFromQrBtn");
                textView = null;
            }
            typefaceRegular = textView.getTypeface();
        }
        textViewMakeButton.setTypeface(typefaceRegular);
        TextView textView2 = this.backFromQrBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromQrBtn");
            textView2 = null;
        }
        textView2.setTextSize(13.0f);
        TextView textView3 = this.backFromQrBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromQrBtn");
            textView3 = null;
        }
        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildQrScreen$lambda$48(this.f$0, view);
            }
        });
        this.qrInlineMessageView = makeInlineErrorView();
        LinearLayout linearLayoutMakeAuthSectionPanel = makeAuthSectionPanel();
        linearLayoutMakeAuthSectionPanel.addView(makeSectionHeader("ورود آسان", "با اسکن QR روی دستگاه دیگر وارد شوید", C2629R.drawable.ic_account_easy_login));
        buildQrContent(linearLayoutMakeAuthSectionPanel);
        LinearLayout linearLayout3 = this.qrScreenRoot;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScreenRoot");
            linearLayout3 = null;
        }
        TextView textView4 = this.backFromQrBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("backFromQrBtn");
            textView4 = null;
        }
        linearLayout3.addView(textView4);
        LinearLayout linearLayout4 = this.qrScreenRoot;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScreenRoot");
            linearLayout4 = null;
        }
        TextView textView5 = this.qrInlineMessageView;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrInlineMessageView");
            textView5 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(8);
        Unit unit = Unit.INSTANCE;
        linearLayout4.addView(textView5, layoutParams);
        LinearLayout linearLayout5 = this.qrScreenRoot;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScreenRoot");
        } else {
            linearLayout2 = linearLayout5;
        }
        LinearLayout linearLayout6 = linearLayoutMakeAuthSectionPanel;
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m377dp(10);
        layoutParams2.bottomMargin = this.isTouchDevice ? m377dp(58) : 0;
        Unit unit2 = Unit.INSTANCE;
        linearLayout2.addView(linearLayout6, layoutParams2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildQrScreen$lambda$48(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setGuestScreen(GuestScreen.AUTH);
    }

    private final void buildRecoverContent(LinearLayout container) {
        TextView textView;
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("مرحله\u200cها را به\u200cترتیب انجام دهید.");
        textView2.setTextColor(-6771259);
        textView2.setTextSize(12.0f);
        textView2.setLineSpacing(m377dp(2), 1.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceRegular);
        textView2.setBackground(roundedBg(354034736, 822083583, m377dp(1), dpF(10)));
        textView2.setPadding(m377dp(10), m377dp(7), m377dp(10), m377dp(7));
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(10);
        layoutParams.bottomMargin = m377dp(4);
        linearLayout.setLayoutParams(layoutParams);
        this.forgotStepOne = makeForgotStepBadge("ایمیل");
        this.forgotStepTwo = makeForgotStepBadge("تایید کد");
        this.forgotStepThree = makeForgotStepBadge("رمز جدید");
        this.forgotLineOne = makeForgotStepLine();
        this.forgotLineTwo = makeForgotStepLine();
        TextView textView3 = this.forgotStepOne;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepOne");
            textView3 = null;
        }
        linearLayout.addView(textView3);
        View view = this.forgotLineOne;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotLineOne");
            view = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, m377dp(2), 1.0f);
        layoutParams2.setMarginStart(m377dp(8));
        layoutParams2.setMarginEnd(m377dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(view, layoutParams2);
        TextView textView4 = this.forgotStepTwo;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepTwo");
            textView4 = null;
        }
        linearLayout.addView(textView4);
        View view2 = this.forgotLineTwo;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotLineTwo");
            view2 = null;
        }
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, m377dp(2), 1.0f);
        layoutParams3.setMarginStart(m377dp(8));
        layoutParams3.setMarginEnd(m377dp(8));
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(view2, layoutParams3);
        TextView textView5 = this.forgotStepThree;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepThree");
            textView5 = null;
        }
        linearLayout.addView(textView5);
        this.recoverEmailInput = makeFloatingInput$default(this, "ایمیل", C2629R.drawable.ic_account_email, false, 33, 0, 20, null);
        this.recoverCodeInput = makeFloatingInput$default(this, "کد تایید", C2629R.drawable.ic_account_forgot, false, 2, 0, 20, null);
        this.recoverPasswordInput = makeFloatingInput$default(this, "رمز عبور جدید", C2629R.drawable.ic_account_password, true, 0, 0, 24, null);
        this.recoverRepeatPasswordInput = makeFloatingInput$default(this, "تکرار رمز عبور", C2629R.drawable.ic_account_password, true, 0, 6, 8, null);
        FloatingInput floatingInput = this.recoverEmailInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput = null;
        }
        ViewGroup.LayoutParams layoutParams4 = floatingInput.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams5 = layoutParams4 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams4 : null;
        if (layoutParams5 != null) {
            layoutParams5.topMargin = -m377dp(14);
            FloatingInput floatingInput2 = this.recoverEmailInput;
            if (floatingInput2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
                floatingInput2 = null;
            }
            floatingInput2.getRoot().setLayoutParams(layoutParams5);
            Unit unit3 = Unit.INSTANCE;
            Unit unit4 = Unit.INSTANCE;
        }
        FloatingInput floatingInput3 = this.recoverCodeInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput3 = null;
        }
        ViewGroup.LayoutParams layoutParams6 = floatingInput3.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams7 = layoutParams6 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams6 : null;
        if (layoutParams7 != null) {
            layoutParams7.topMargin = -m377dp(6);
            FloatingInput floatingInput4 = this.recoverCodeInput;
            if (floatingInput4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
                floatingInput4 = null;
            }
            floatingInput4.getRoot().setLayoutParams(layoutParams7);
            Unit unit5 = Unit.INSTANCE;
            Unit unit6 = Unit.INSTANCE;
        }
        FloatingInput floatingInput5 = this.recoverPasswordInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput5 = null;
        }
        ViewGroup.LayoutParams layoutParams8 = floatingInput5.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams9 = layoutParams8 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams8 : null;
        if (layoutParams9 != null) {
            layoutParams9.topMargin = -m377dp(6);
            FloatingInput floatingInput6 = this.recoverPasswordInput;
            if (floatingInput6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
                floatingInput6 = null;
            }
            floatingInput6.getRoot().setLayoutParams(layoutParams9);
            Unit unit7 = Unit.INSTANCE;
            Unit unit8 = Unit.INSTANCE;
        }
        FloatingInput floatingInput7 = this.recoverRepeatPasswordInput;
        if (floatingInput7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput7 = null;
        }
        ViewGroup.LayoutParams layoutParams10 = floatingInput7.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams11 = layoutParams10 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams10 : null;
        if (layoutParams11 != null) {
            layoutParams11.topMargin = -m377dp(6);
            FloatingInput floatingInput8 = this.recoverRepeatPasswordInput;
            if (floatingInput8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
                floatingInput8 = null;
            }
            floatingInput8.getRoot().setLayoutParams(layoutParams11);
            Unit unit9 = Unit.INSTANCE;
            Unit unit10 = Unit.INSTANCE;
        }
        FloatingInput floatingInput9 = this.recoverRepeatPasswordInput;
        if (floatingInput9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput9 = null;
        }
        floatingInput9.getEdit().setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda50
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView6, int i, KeyEvent keyEvent) {
                return AccountScreenView.buildRecoverContent$lambda$60(this.f$0, textView6, i, keyEvent);
            }
        });
        TextView textViewMakeButton = makeButton("ارسال ایمیل بازیابی", ButtonStyle.PRIMARY);
        this.sendRecoverMailBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
            textViewMakeButton = null;
        }
        textViewMakeButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda51
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildRecoverContent$lambda$61(this.f$0, view3);
            }
        });
        TextView textView6 = this.sendRecoverMailBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
            textView6 = null;
        }
        ViewGroup.LayoutParams layoutParams12 = textView6.getLayoutParams();
        LinearLayout.LayoutParams layoutParams13 = layoutParams12 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams12 : null;
        if (layoutParams13 != null) {
            layoutParams13.topMargin = m377dp(16);
            TextView textView7 = this.sendRecoverMailBtn;
            if (textView7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView7 = null;
            }
            textView7.setLayoutParams(layoutParams13);
            Unit unit11 = Unit.INSTANCE;
            Unit unit12 = Unit.INSTANCE;
        }
        TextView textViewMakeButton2 = makeButton("ارسال مجدد", ButtonStyle.DOWNLOAD_BOX);
        this.resendRecoverMailBtn = textViewMakeButton2;
        if (textViewMakeButton2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textViewMakeButton2 = null;
        }
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            TextView textView8 = this.resendRecoverMailBtn;
            if (textView8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
                textView8 = null;
            }
            typefaceRegular2 = textView8.getTypeface();
        }
        textViewMakeButton2.setTypeface(typefaceRegular2);
        TextView textView9 = this.resendRecoverMailBtn;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView9 = null;
        }
        textView9.setTextSize(13.0f);
        TextView textView10 = this.resendRecoverMailBtn;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView10 = null;
        }
        textView10.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda52
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildRecoverContent$lambda$63(this.f$0, view3);
            }
        });
        TextView textView11 = this.resendRecoverMailBtn;
        if (textView11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView11 = null;
        }
        ViewGroup.LayoutParams layoutParams14 = textView11.getLayoutParams();
        LinearLayout.LayoutParams layoutParams15 = layoutParams14 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams14 : null;
        if (layoutParams15 != null) {
            layoutParams15.topMargin = m377dp(10);
            TextView textView12 = this.resendRecoverMailBtn;
            if (textView12 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
                textView12 = null;
            }
            textView12.setLayoutParams(layoutParams15);
            Unit unit13 = Unit.INSTANCE;
            Unit unit14 = Unit.INSTANCE;
        }
        TextView textViewMakeButton3 = makeButton("تایید کد", ButtonStyle.PRIMARY);
        this.verifyRecoverCodeBtn = textViewMakeButton3;
        if (textViewMakeButton3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textViewMakeButton3 = null;
        }
        textViewMakeButton3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda53
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildRecoverContent$lambda$65(this.f$0, view3);
            }
        });
        TextView textView13 = this.verifyRecoverCodeBtn;
        if (textView13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView13 = null;
        }
        ViewGroup.LayoutParams layoutParams16 = textView13.getLayoutParams();
        LinearLayout.LayoutParams layoutParams17 = layoutParams16 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams16 : null;
        if (layoutParams17 != null) {
            layoutParams17.topMargin = m377dp(12);
            TextView textView14 = this.verifyRecoverCodeBtn;
            if (textView14 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
                textView14 = null;
            }
            textView14.setLayoutParams(layoutParams17);
            Unit unit15 = Unit.INSTANCE;
            Unit unit16 = Unit.INSTANCE;
        }
        TextView textViewMakeButton4 = makeButton("تغییر رمز عبور", ButtonStyle.PRIMARY);
        this.applyNewPasswordBtn = textViewMakeButton4;
        if (textViewMakeButton4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textViewMakeButton4 = null;
        }
        textViewMakeButton4.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda54
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                AccountScreenView.buildRecoverContent$lambda$67(this.f$0, view3);
            }
        });
        TextView textView15 = this.applyNewPasswordBtn;
        if (textView15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView15 = null;
        }
        ViewGroup.LayoutParams layoutParams18 = textView15.getLayoutParams();
        LinearLayout.LayoutParams layoutParams19 = layoutParams18 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams18 : null;
        if (layoutParams19 != null) {
            layoutParams19.topMargin = m377dp(16);
            TextView textView16 = this.applyNewPasswordBtn;
            if (textView16 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
                textView16 = null;
            }
            textView16.setLayoutParams(layoutParams19);
            Unit unit17 = Unit.INSTANCE;
            Unit unit18 = Unit.INSTANCE;
        }
        container.addView(textView2);
        container.addView(linearLayout);
        FloatingInput floatingInput10 = this.recoverEmailInput;
        if (floatingInput10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput10 = null;
        }
        container.addView(floatingInput10.getRoot());
        TextView textView17 = this.sendRecoverMailBtn;
        if (textView17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
            textView17 = null;
        }
        container.addView(textView17);
        FloatingInput floatingInput11 = this.recoverCodeInput;
        if (floatingInput11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput11 = null;
        }
        container.addView(floatingInput11.getRoot());
        TextView textView18 = this.resendRecoverMailBtn;
        if (textView18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView18 = null;
        }
        container.addView(textView18);
        TextView textView19 = this.verifyRecoverCodeBtn;
        if (textView19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView19 = null;
        }
        container.addView(textView19);
        FloatingInput floatingInput12 = this.recoverPasswordInput;
        if (floatingInput12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput12 = null;
        }
        container.addView(floatingInput12.getRoot());
        FloatingInput floatingInput13 = this.recoverRepeatPasswordInput;
        if (floatingInput13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput13 = null;
        }
        container.addView(floatingInput13.getRoot());
        TextView textView20 = this.applyNewPasswordBtn;
        if (textView20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView = null;
        } else {
            textView = textView20;
        }
        container.addView(textView);
        this.forgotStep = ForgotStep.ENTER_EMAIL;
        this.verifiedRecoveryCode = "";
        updateRecoveryResendUi();
        updateForgotStepUi();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildRecoverContent$lambda$60(AccountScreenView this$0, TextView textView, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i != 6) {
            return false;
        }
        this$0.applyNewPassword();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRecoverContent$lambda$61(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.sendRecoveryEmail(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRecoverContent$lambda$63(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.recoverySecondsLeft <= 0) {
            this$0.sendRecoveryEmail(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRecoverContent$lambda$65(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.verifyRecoveryCode();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRecoverContent$lambda$67(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyNewPassword();
    }

    private final void buildQrContent(LinearLayout container) {
        TextView textView;
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setBackground(roundedBg(-16117737, this.fieldStroke, m377dp(1), dpF(16)));
        frameLayout.setPadding(m377dp(12), m377dp(12), m377dp(12), m377dp(12));
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        frameLayout2.setBackground(roundedBg(-16117737, 0, 0, dpF(14)));
        frameLayout2.setLayoutParams(new FrameLayout.LayoutParams(-1, m377dp(220)));
        frameLayout2.setPadding(m377dp(10), m377dp(10), m377dp(10), m377dp(10));
        ImageView imageView = new ImageView(this.ctx);
        imageView.setVisibility(4);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        this.qrImage = imageView;
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setVisibility(0);
        this.qrProgress = progressBar;
        ImageView imageView2 = this.qrImage;
        if (imageView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrImage");
            imageView2 = null;
        }
        frameLayout2.addView(imageView2, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar2 = this.qrProgress;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrProgress");
            progressBar2 = null;
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        Unit unit = Unit.INSTANCE;
        frameLayout2.addView(progressBar2, layoutParams);
        frameLayout.addView(frameLayout2);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("در حال دریافت QR...");
        textView2.setTextColor(-3811864);
        textView2.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceMedium);
        textView2.setGravity(17);
        textView2.setBackground(roundedBg(404235313, 822083583, m377dp(1), dpF(10)));
        textView2.setPadding(m377dp(10), m377dp(8), m377dp(10), m377dp(8));
        this.qrStatus = textView2;
        TextView textView3 = new TextView(this.ctx);
        textView3.setText("");
        textView3.setTextColor(this.accent);
        textView3.setTextSize(12.0f);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium2 == null) {
            typefaceMedium2 = textView3.getTypeface();
        }
        textView3.setTypeface(typefaceMedium2);
        textView3.setGravity(17);
        textView3.setBackground(roundedBg(286794801, 821406993, m377dp(1), dpF(10)));
        textView3.setPadding(m377dp(10), m377dp(7), m377dp(10), m377dp(7));
        this.qrTimer = textView3;
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setBackground(roundedBg(-16117737, this.fieldStroke, m377dp(1), dpF(12)));
        linearLayout.setPadding(m377dp(10), m377dp(10), m377dp(10), m377dp(10));
        linearLayout.setVisibility(this.isTouchDevice ? 0 : 8);
        this.qrMetaWrap = linearLayout;
        TextView textView4 = new TextView(this.ctx);
        textView4.setText("در موبایل، با لمس هر مورد آن را کپی کنید.");
        textView4.setTextColor(-7429190);
        textView4.setTextSize(11.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView4.getTypeface();
        }
        textView4.setTypeface(typefaceRegular);
        textView4.setLineSpacing(m377dp(1), 1.0f);
        TextView textView5 = new TextView(this.ctx);
        textView5.setText("آدرس ورود آسان");
        textView5.setTextColor(-6376503);
        textView5.setTextSize(11.0f);
        Typeface typefaceMedium3 = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium3 == null) {
            typefaceMedium3 = textView5.getTypeface();
        }
        textView5.setTypeface(typefaceMedium3);
        textView5.setPadding(0, 0, 0, m377dp(4));
        TextView textView6 = new TextView(this.ctx);
        textView6.setText("-");
        textView6.setTextColor(-1);
        textView6.setTextSize(12.0f);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = textView6.getTypeface();
        }
        textView6.setTypeface(typefaceRegular2);
        textView6.setTextIsSelectable(true);
        textView6.setTextDirection(3);
        textView6.setGravity(8388627);
        textView6.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(1), dpF(10)));
        textView6.setPadding(m377dp(10), m377dp(9), m377dp(10), m377dp(9));
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda70
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildQrContent$lambda$80$lambda$79(this.f$0, view);
            }
        });
        this.qrUrlValue = textView6;
        TextView textView7 = new TextView(this.ctx);
        textView7.setText("کد ورود آسان");
        textView7.setTextColor(-6376503);
        textView7.setTextSize(11.0f);
        Typeface typefaceMedium4 = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium4 == null) {
            typefaceMedium4 = textView7.getTypeface();
        }
        textView7.setTypeface(typefaceMedium4);
        textView7.setPadding(0, 0, 0, m377dp(4));
        TextView textView8 = new TextView(this.ctx);
        textView8.setText("-");
        textView8.setTextColor(this.accent);
        textView8.setTextSize(15.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView8.getTypeface();
        }
        textView8.setTypeface(typefaceBold);
        textView8.setTextIsSelectable(true);
        textView8.setTextDirection(3);
        textView8.setGravity(8388627);
        textView8.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(1), dpF(10)));
        textView8.setPadding(m377dp(10), m377dp(9), m377dp(10), m377dp(9));
        textView8.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda71
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildQrContent$lambda$83$lambda$82(this.f$0, view);
            }
        });
        this.qrCodeValue = textView8;
        LinearLayout linearLayout2 = this.qrMetaWrap;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout2 = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.bottomMargin = m377dp(8);
        Unit unit2 = Unit.INSTANCE;
        linearLayout2.addView(textView4, layoutParams2);
        LinearLayout linearLayout3 = this.qrMetaWrap;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout3 = null;
        }
        linearLayout3.addView(textView5);
        LinearLayout linearLayout4 = this.qrMetaWrap;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout4 = null;
        }
        TextView textView9 = this.qrUrlValue;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrUrlValue");
            textView9 = null;
        }
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.bottomMargin = m377dp(8);
        Unit unit3 = Unit.INSTANCE;
        linearLayout4.addView(textView9, layoutParams3);
        LinearLayout linearLayout5 = this.qrMetaWrap;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout5 = null;
        }
        linearLayout5.addView(textView7);
        LinearLayout linearLayout6 = this.qrMetaWrap;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout6 = null;
        }
        TextView textView10 = this.qrCodeValue;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrCodeValue");
            textView10 = null;
        }
        linearLayout6.addView(textView10);
        TextView textViewMakeButton = makeButton("دریافت مجدد QR", ButtonStyle.DOWNLOAD_BOX);
        this.qrReloadBtn = textViewMakeButton;
        if (textViewMakeButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
            textViewMakeButton = null;
        }
        Typeface typefaceRegular3 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular3 == null) {
            TextView textView11 = this.qrReloadBtn;
            if (textView11 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
                textView11 = null;
            }
            typefaceRegular3 = textView11.getTypeface();
        }
        textViewMakeButton.setTypeface(typefaceRegular3);
        TextView textView12 = this.qrReloadBtn;
        if (textView12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
            textView12 = null;
        }
        textView12.setTextSize(13.0f);
        TextView textView13 = this.qrReloadBtn;
        if (textView13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
            textView13 = null;
        }
        textView13.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda72
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildQrContent$lambda$86(this.f$0, view);
            }
        });
        TextView textView14 = this.qrReloadBtn;
        if (textView14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
            textView14 = null;
        }
        ViewGroup.LayoutParams layoutParams4 = textView14.getLayoutParams();
        LinearLayout.LayoutParams layoutParams5 = layoutParams4 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams4 : null;
        if (layoutParams5 != null) {
            layoutParams5.topMargin = m377dp(12);
            layoutParams5.bottomMargin = 0;
            TextView textView15 = this.qrReloadBtn;
            if (textView15 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
                textView15 = null;
            }
            textView15.setLayoutParams(layoutParams5);
        }
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = m377dp(0);
        Unit unit4 = Unit.INSTANCE;
        container.addView(frameLayout, layoutParams6);
        TextView textView16 = this.qrTimer;
        if (textView16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrTimer");
            textView16 = null;
        }
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.topMargin = m377dp(10);
        Unit unit5 = Unit.INSTANCE;
        container.addView(textView16, layoutParams7);
        LinearLayout linearLayout7 = this.qrMetaWrap;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrMetaWrap");
            linearLayout7 = null;
        }
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams8.topMargin = m377dp(10);
        Unit unit6 = Unit.INSTANCE;
        container.addView(linearLayout7, layoutParams8);
        TextView textView17 = this.qrReloadBtn;
        if (textView17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
            textView = null;
        } else {
            textView = textView17;
        }
        container.addView(textView);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildQrContent$lambda$80$lambda$79(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (!StringsKt.isBlank(this$0.qrUrl)) {
            this$0.copyToClipboard("qr_url", this$0.qrUrl);
            this$0.setMessage("آدرس QR کپی شد");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildQrContent$lambda$83$lambda$82(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (!StringsKt.isBlank(this$0.qrCode)) {
            this$0.copyToClipboard("qr_code", this$0.qrCode);
            this$0.setMessage("کد ورود کپی شد");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildQrContent$lambda$86(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loadQr();
    }

    private final void buildLoggedSection() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(8);
        linearLayout.setGravity(1);
        this.loggedSection = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(1);
        linearLayout2.setPadding(0, m377dp(6), 0, m377dp(4));
        TextView textView = new TextView(this.ctx);
        textView.setText("?");
        textView.setTextColor(-1);
        textView.setTextSize(33.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setGravity(1);
        textView.setBackground(roundedBg(-15260621, 1224060177, m377dp(1), dpF(999)));
        textView.setGravity(17);
        textView.setMinWidth(m377dp(88));
        textView.setMinHeight(m377dp(88));
        textView.setPadding(0, 0, 0, 0);
        this.panelAvatarText = textView;
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("");
        textView2.setTextColor(-4666915);
        textView2.setTextSize(15.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceRegular);
        textView2.setTextDirection(3);
        textView2.setGravity(1);
        textView2.setPadding(0, m377dp(8), 0, 0);
        this.panelEmailText = textView2;
        TextView textView3 = new TextView(this.ctx);
        textView3.setText("کاربر");
        textView3.setTextColor(-1);
        textView3.setTextSize(24.0f);
        Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold2 == null) {
            typefaceBold2 = textView3.getTypeface();
        }
        textView3.setTypeface(typefaceBold2);
        textView3.setGravity(1);
        textView3.setPadding(0, m377dp(12), 0, 0);
        this.panelNameText = textView3;
        TextView textView4 = new TextView(this.ctx);
        textView4.setText("");
        textView4.setTextColor(-7429190);
        textView4.setTextSize(13.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView4.getTypeface();
        }
        textView4.setTypeface(typefaceMedium);
        textView4.setVisibility(8);
        textView4.setPadding(0, m377dp(8), 0, 0);
        textView4.setGravity(1);
        this.panelLoadingText = textView4;
        TextView textView5 = this.panelAvatarText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelAvatarText");
            textView5 = null;
        }
        linearLayout2.addView(textView5, new LinearLayout.LayoutParams(m377dp(88), m377dp(88)));
        TextView textView6 = this.panelNameText;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelNameText");
            textView6 = null;
        }
        linearLayout2.addView(textView6);
        TextView textView7 = this.panelEmailText;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelEmailText");
            textView7 = null;
        }
        linearLayout2.addView(textView7);
        TextView textView8 = this.panelLoadingText;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
            textView8 = null;
        }
        linearLayout2.addView(textView8);
        LinearLayout linearLayout3 = this.loggedSection;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout3 = null;
        }
        linearLayout3.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout4 = new LinearLayout(this.ctx);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setClipChildren(false);
        linearLayout4.setClipToPadding(false);
        linearLayout4.setPadding(0, m377dp(8), 0, m377dp(10));
        linearLayout4.setBackground(null);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setLayoutDirection(1);
        SubscriptionGaugeView subscriptionGaugeView = new SubscriptionGaugeView(this.ctx);
        subscriptionGaugeView.setProgress(0, false);
        this.panelSubArcView = subscriptionGaugeView;
        TextView textView9 = new TextView(this.ctx);
        textView9.setText("0%");
        textView9.setTextColor(-1);
        textView9.setTextSize(34.0f);
        Typeface typefaceBold3 = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold3 == null) {
            typefaceBold3 = textView9.getTypeface();
        }
        textView9.setTypeface(typefaceBold3);
        textView9.setGravity(17);
        textView9.setTextDirection(3);
        textView9.setTextAlignment(4);
        textView9.setIncludeFontPadding(false);
        this.panelSubPercentText = textView9;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, m377dp(194));
        layoutParams.gravity = 1;
        Unit unit = Unit.INSTANCE;
        frameLayout.addView(subscriptionGaugeView, layoutParams);
        TextView textView10 = this.panelSubPercentText;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
            textView10 = null;
        }
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, -2);
        layoutParams2.gravity = 49;
        Unit unit2 = Unit.INSTANCE;
        frameLayout.addView(textView10, layoutParams2);
        subscriptionGaugeView.setOnLabelCenterChanged(new C26379());
        TextView textView11 = new TextView(this.ctx);
        textView11.setText("اشتراک شما غیرفعال است");
        textView11.setTextColor(-15935);
        textView11.setTextSize(14.0f);
        Typeface typefaceBold4 = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold4 == null) {
            typefaceBold4 = textView11.getTypeface();
        }
        textView11.setTypeface(typefaceBold4);
        textView11.setGravity(17);
        textView11.setPadding(m377dp(16), m377dp(6), m377dp(16), m377dp(6));
        textView11.setBackground(roundedBg(857608465, 1442802282, m377dp(1), dpF(999)));
        this.panelSubStatusChip = textView11;
        TextView textView12 = new TextView(this.ctx);
        textView12.setText("");
        textView12.setTextColor(-4996138);
        textView12.setTextSize(12.0f);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = textView12.getTypeface();
        }
        textView12.setTypeface(typefaceRegular2);
        textView12.setGravity(17);
        textView12.setVisibility(8);
        textView12.setPadding(0, m377dp(8), 0, 0);
        this.panelSubMetaText = textView12;
        HorizontalScrollView horizontalScrollView = new HorizontalScrollView(this.ctx);
        horizontalScrollView.setLayoutDirection(0);
        horizontalScrollView.setTextDirection(3);
        horizontalScrollView.setFillViewport(true);
        horizontalScrollView.setHorizontalScrollBarEnabled(false);
        horizontalScrollView.setOverScrollMode(2);
        horizontalScrollView.setClipChildren(false);
        horizontalScrollView.setClipToPadding(false);
        horizontalScrollView.setPadding(m377dp(12), m377dp(10), m377dp(12), 0);
        horizontalScrollView.setVisibility(8);
        this.panelCountdownScroll = horizontalScrollView;
        LinearLayout linearLayout5 = new LinearLayout(this.ctx);
        linearLayout5.setOrientation(0);
        linearLayout5.setGravity(16);
        linearLayout5.setLayoutDirection(0);
        linearLayout5.setClipChildren(false);
        linearLayout5.setClipToPadding(false);
        linearLayout5.setPadding(0, 0, 0, 0);
        this.panelCountdownRow = linearLayout5;
        HorizontalScrollView horizontalScrollView2 = this.panelCountdownScroll;
        if (horizontalScrollView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownScroll");
            horizontalScrollView2 = null;
        }
        LinearLayout linearLayout6 = this.panelCountdownRow;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout6 = null;
        }
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-1, -2);
        layoutParams3.gravity = 1;
        Unit unit3 = Unit.INSTANCE;
        horizontalScrollView2.addView(linearLayout6, layoutParams3);
        Pair<TextView, LinearLayout> pairMakeCountdownCell = makeCountdownCell("روز");
        this.panelCountdownDaysText = pairMakeCountdownCell.getFirst();
        LinearLayout linearLayout7 = this.panelCountdownRow;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout7 = null;
        }
        linearLayout7.addView(pairMakeCountdownCell.getSecond(), new LinearLayout.LayoutParams(0, -2, 1.0f));
        LinearLayout linearLayout8 = this.panelCountdownRow;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout8 = null;
        }
        TextView textViewMakeCountdownSeparator = makeCountdownSeparator();
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.setMarginStart(m377dp(1));
        layoutParams4.setMarginEnd(m377dp(1));
        Unit unit4 = Unit.INSTANCE;
        linearLayout8.addView(textViewMakeCountdownSeparator, layoutParams4);
        Pair<TextView, LinearLayout> pairMakeCountdownCell2 = makeCountdownCell("ساعت");
        this.panelCountdownHoursText = pairMakeCountdownCell2.getFirst();
        LinearLayout linearLayout9 = this.panelCountdownRow;
        if (linearLayout9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout9 = null;
        }
        linearLayout9.addView(pairMakeCountdownCell2.getSecond(), new LinearLayout.LayoutParams(0, -2, 1.0f));
        LinearLayout linearLayout10 = this.panelCountdownRow;
        if (linearLayout10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout10 = null;
        }
        TextView textViewMakeCountdownSeparator2 = makeCountdownSeparator();
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams5.setMarginStart(m377dp(1));
        layoutParams5.setMarginEnd(m377dp(1));
        Unit unit5 = Unit.INSTANCE;
        linearLayout10.addView(textViewMakeCountdownSeparator2, layoutParams5);
        Pair<TextView, LinearLayout> pairMakeCountdownCell3 = makeCountdownCell("دقیقه");
        this.panelCountdownMinutesText = pairMakeCountdownCell3.getFirst();
        LinearLayout linearLayout11 = this.panelCountdownRow;
        if (linearLayout11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout11 = null;
        }
        linearLayout11.addView(pairMakeCountdownCell3.getSecond(), new LinearLayout.LayoutParams(0, -2, 1.0f));
        LinearLayout linearLayout12 = this.panelCountdownRow;
        if (linearLayout12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout12 = null;
        }
        TextView textViewMakeCountdownSeparator3 = makeCountdownSeparator();
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams6.setMarginStart(m377dp(1));
        layoutParams6.setMarginEnd(m377dp(1));
        Unit unit6 = Unit.INSTANCE;
        linearLayout12.addView(textViewMakeCountdownSeparator3, layoutParams6);
        Pair<TextView, LinearLayout> pairMakeCountdownCell4 = makeCountdownCell("ثانیه");
        this.panelCountdownSecondsText = pairMakeCountdownCell4.getFirst();
        LinearLayout linearLayout13 = this.panelCountdownRow;
        if (linearLayout13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownRow");
            linearLayout13 = null;
        }
        linearLayout13.addView(pairMakeCountdownCell4.getSecond(), new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout4.addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
        TextView textView13 = this.panelSubStatusChip;
        if (textView13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubStatusChip");
            textView13 = null;
        }
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams7.gravity = 1;
        layoutParams7.topMargin = m377dp(4);
        Unit unit7 = Unit.INSTANCE;
        linearLayout4.addView(textView13, layoutParams7);
        TextView textView14 = this.panelSubMetaText;
        if (textView14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubMetaText");
            textView14 = null;
        }
        linearLayout4.addView(textView14, new LinearLayout.LayoutParams(-1, -2));
        HorizontalScrollView horizontalScrollView3 = this.panelCountdownScroll;
        if (horizontalScrollView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownScroll");
            horizontalScrollView3 = null;
        }
        linearLayout4.addView(horizontalScrollView3, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout14 = this.loggedSection;
        if (linearLayout14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout14 = null;
        }
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams8.topMargin = m377dp(14);
        Unit unit8 = Unit.INSTANCE;
        linearLayout14.addView(linearLayout4, layoutParams8);
        LinearLayout linearLayout15 = new LinearLayout(this.ctx);
        linearLayout15.setOrientation(1);
        linearLayout15.setLayoutDirection(1);
        linearLayout15.setVisibility(8);
        this.panelNotificationsWrap = linearLayout15;
        LinearLayout linearLayout16 = this.loggedSection;
        if (linearLayout16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout16 = null;
        }
        LinearLayout linearLayout17 = this.panelNotificationsWrap;
        if (linearLayout17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelNotificationsWrap");
            linearLayout17 = null;
        }
        LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams9.topMargin = m377dp(10);
        layoutParams9.bottomMargin = m377dp(16);
        Unit unit9 = Unit.INSTANCE;
        linearLayout16.addView(linearLayout17, layoutParams9);
        LinearLayout linearLayout18 = new LinearLayout(this.ctx);
        linearLayout18.setOrientation(0);
        linearLayout18.setLayoutDirection(1);
        linearLayout18.setGravity(16);
        linearLayout18.setPadding(0, 0, 0, 0);
        LinearLayout linearLayoutMakeSocialHalfCard = makeSocialHalfCard(C2629R.drawable.ic_social_telegram, "فیلمکیو در تلگرام");
        linearLayoutMakeSocialHalfCard.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildLoggedSection$lambda$117$lambda$116(this.f$0, view);
            }
        });
        this.panelTelegramCard = linearLayoutMakeSocialHalfCard;
        LinearLayout linearLayoutMakeSocialHalfCard2 = makeSocialHalfCard(C2629R.drawable.ic_social_instagram, "فیلمکیو در اینستاگرام");
        linearLayoutMakeSocialHalfCard2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildLoggedSection$lambda$119$lambda$118(this.f$0, view);
            }
        });
        this.panelInstagramCard = linearLayoutMakeSocialHalfCard2;
        LinearLayout linearLayout19 = this.panelTelegramCard;
        if (linearLayout19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTelegramCard");
            linearLayout19 = null;
        }
        LinearLayout.LayoutParams layoutParams10 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams10.setMarginStart(m377dp(4));
        layoutParams10.setMarginEnd(m377dp(4));
        Unit unit10 = Unit.INSTANCE;
        linearLayout18.addView(linearLayout19, layoutParams10);
        LinearLayout linearLayout20 = this.panelInstagramCard;
        if (linearLayout20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelInstagramCard");
            linearLayout20 = null;
        }
        LinearLayout.LayoutParams layoutParams11 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams11.setMarginStart(m377dp(4));
        layoutParams11.setMarginEnd(m377dp(4));
        Unit unit11 = Unit.INSTANCE;
        linearLayout18.addView(linearLayout20, layoutParams11);
        LinearLayout linearLayout21 = this.loggedSection;
        if (linearLayout21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout21 = null;
        }
        LinearLayout.LayoutParams layoutParams12 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams12.topMargin = 0;
        Unit unit12 = Unit.INSTANCE;
        linearLayout21.addView(linearLayout18, layoutParams12);
        LinearLayout linearLayout22 = new LinearLayout(this.ctx);
        linearLayout22.setOrientation(1);
        linearLayout22.setLayoutDirection(1);
        this.panelShortcutGridWrap = linearLayout22;
        LinearLayout linearLayout23 = this.loggedSection;
        if (linearLayout23 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout23 = null;
        }
        LinearLayout linearLayout24 = this.panelShortcutGridWrap;
        if (linearLayout24 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelShortcutGridWrap");
            linearLayout24 = null;
        }
        LinearLayout.LayoutParams layoutParams13 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams13.topMargin = m377dp(16);
        Unit unit13 = Unit.INSTANCE;
        linearLayout23.addView(linearLayout24, layoutParams13);
        renderPanelShortcutGrid(CollectionsKt.emptyList());
        TextView textViewMakeButton = makeButton("خروج از حساب کاربری", ButtonStyle.DANGER);
        textViewMakeButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.buildLoggedSection$lambda$126$lambda$125(this.f$0, view);
            }
        });
        this.logoutBtn = textViewMakeButton;
        LinearLayout linearLayout25 = this.loggedSection;
        if (linearLayout25 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout25 = null;
        }
        TextView textView15 = this.logoutBtn;
        if (textView15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoutBtn");
            textView15 = null;
        }
        TextView textView16 = textView15;
        LinearLayout.LayoutParams layoutParams14 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams14.topMargin = m377dp(20);
        layoutParams14.bottomMargin = m377dp(this.isTouchDevice ? 74 : 18);
        Unit unit14 = Unit.INSTANCE;
        linearLayout25.addView(textView16, layoutParams14);
        LinearLayout linearLayout26 = this.content;
        LinearLayout linearLayout27 = this.loggedSection;
        if (linearLayout27 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
            linearLayout27 = null;
        }
        linearLayout26.addView(linearLayout27, panelContentParams$default(this, 0, 1, null));
    }

    /* JADX INFO: renamed from: com.filmkio.nativescreen.account.AccountScreenView$buildLoggedSection$9 */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, m780d2 = {"<anonymous>", "", "centerY", "", "invoke"}, m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    static final class C26379 extends Lambda implements Function1<Float, Unit> {
        C26379() {
            super(1);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Float f) {
            invoke(f.floatValue());
            return Unit.INSTANCE;
        }

        public final void invoke(final float f) {
            TextView textView = AccountScreenView.this.panelSubPercentText;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
                textView = null;
            }
            final AccountScreenView accountScreenView = AccountScreenView.this;
            textView.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$buildLoggedSection$9$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.C26379.invoke$lambda$0(accountScreenView, f);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(AccountScreenView this$0, float f) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            TextView textView = this$0.panelSubPercentText;
            TextView textView2 = null;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
                textView = null;
            }
            ViewGroup.LayoutParams layoutParams = textView.getLayoutParams();
            FrameLayout.LayoutParams layoutParams2 = layoutParams instanceof FrameLayout.LayoutParams ? (FrameLayout.LayoutParams) layoutParams : null;
            if (layoutParams2 == null) {
                return;
            }
            TextView textView3 = this$0.panelSubPercentText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
                textView3 = null;
            }
            int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (f - (textView3.getHeight() / 2.0f)), 0);
            if (layoutParams2.topMargin != iCoerceAtLeast) {
                layoutParams2.topMargin = iCoerceAtLeast;
                TextView textView4 = this$0.panelSubPercentText;
                if (textView4 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
                } else {
                    textView2 = textView4;
                }
                textView2.setLayoutParams(layoutParams2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildLoggedSection$lambda$117$lambda$116(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (StringsKt.isBlank(this$0.panelTelegramUrl)) {
            this$0.showShortMessage("لینک معتبر نیست");
        } else {
            this$0.openExternalUrl(this$0.panelTelegramUrl);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildLoggedSection$lambda$119$lambda$118(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (StringsKt.isBlank(this$0.panelInstagramUrl)) {
            this$0.showShortMessage("لینک معتبر نیست");
        } else {
            this$0.openExternalUrl(this$0.panelInstagramUrl);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildLoggedSection$lambda$126$lambda$125(AccountScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.doLogout();
    }

    private final void setGuestScreen(GuestScreen screen) {
        if (this.guestScreen == screen) {
            return;
        }
        this.guestScreen = screen;
        updateGuestScreenUi();
        int i = WhenMappings.$EnumSwitchMapping$0[screen.ordinal()];
        if (i == 1) {
            stopQrPolling();
            stopQrCountdown();
            stopRecoveryTimer();
            if (this.isTouchDevice) {
                return;
            }
            focusAuthTab();
            return;
        }
        if (i == 2) {
            stopQrPolling();
            stopQrCountdown();
            if (this.isTouchDevice) {
                return;
            }
            focusForgot();
            return;
        }
        if (i != 3) {
            return;
        }
        stopRecoveryTimer();
        loadQr();
        if (this.isTouchDevice) {
            return;
        }
        focusQr();
    }

    private final void updateGuestScreenUi() {
        LinearLayout linearLayout = this.authScreenRoot;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
            linearLayout = null;
        }
        linearLayout.setVisibility(this.guestScreen == GuestScreen.AUTH ? 0 : 8);
        LinearLayout linearLayout3 = this.forgotScreenRoot;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotScreenRoot");
            linearLayout3 = null;
        }
        linearLayout3.setVisibility(this.guestScreen == GuestScreen.FORGOT ? 0 : 8);
        LinearLayout linearLayout4 = this.qrScreenRoot;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrScreenRoot");
        } else {
            linearLayout2 = linearLayout4;
        }
        linearLayout2.setVisibility(this.guestScreen != GuestScreen.f342QR ? 8 : 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x002c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void switchAuthTab(AuthTab target, boolean animate) {
        boolean z;
        AuthTab authTab = this.authTab;
        if (authTab == target) {
            updateAuthTabUi();
            return;
        }
        if (this.authSwitchAnimating) {
            return;
        }
        this.authTab = target;
        clearAuthInlineMessage();
        if (animate && this.guestScreen == GuestScreen.AUTH) {
            LinearLayout linearLayout = this.authScreenRoot;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authScreenRoot");
                linearLayout = null;
            }
            if (linearLayout.getVisibility() == 0) {
                z = true;
            }
        } else {
            z = false;
        }
        updateAuthTabIndicator(z);
        if (z) {
            animateAuthTabSwitch(authTab, target);
            return;
        }
        updateAuthTabUi();
        if (this.isTouchDevice || this.guestScreen != GuestScreen.AUTH) {
            return;
        }
        focusAuthTab();
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x002d A[PHI: r0
  0x002d: PHI (r0v3 android.widget.LinearLayout) = (r0v2 android.widget.LinearLayout), (r0v11 android.widget.LinearLayout) binds: [B:17:0x0027, B:14:0x001f] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void animateAuthTabSwitch(AuthTab fromTab, AuthTab toTab) {
        final LinearLayout linearLayout;
        LinearLayout linearLayout2;
        final LinearLayout linearLayout3 = null;
        if (fromTab == AuthTab.LOGIN) {
            linearLayout = this.loginPanel;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginPanel");
                linearLayout = null;
            }
        } else {
            linearLayout = this.registerPanel;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerPanel");
                linearLayout = null;
            }
        }
        if (toTab == AuthTab.LOGIN) {
            linearLayout2 = this.loginPanel;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginPanel");
            } else {
                linearLayout3 = linearLayout2;
            }
        } else {
            linearLayout2 = this.registerPanel;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerPanel");
            }
        }
        float fM377dp = m377dp(24);
        if (toTab != AuthTab.REGISTER) {
            fM377dp = -fM377dp;
        }
        float f = (-fM377dp) * 0.6f;
        AccelerateDecelerateInterpolator accelerateDecelerateInterpolator = new AccelerateDecelerateInterpolator();
        this.authSwitchAnimating = true;
        int iMeasureAuthPanelHeight = measureAuthPanelHeight(linearLayout);
        final int iMeasureAuthPanelHeight2 = measureAuthPanelHeight(linearLayout3);
        if (iMeasureAuthPanelHeight > 0) {
            setAuthFormsHostHeight$default(this, iMeasureAuthPanelHeight, false, 0L, 4, null);
        }
        updateAuthTabUi();
        linearLayout3.setVisibility(0);
        linearLayout3.setAlpha(0.0f);
        linearLayout3.setTranslationX(fM377dp);
        linearLayout3.setScaleX(0.986f);
        linearLayout3.setScaleY(0.986f);
        linearLayout.animate().cancel();
        linearLayout3.animate().cancel();
        if (iMeasureAuthPanelHeight > 0 && iMeasureAuthPanelHeight2 > 0 && iMeasureAuthPanelHeight != iMeasureAuthPanelHeight2) {
            setAuthFormsHostHeight(iMeasureAuthPanelHeight2, true, 220L);
        }
        AccelerateDecelerateInterpolator accelerateDecelerateInterpolator2 = accelerateDecelerateInterpolator;
        linearLayout.animate().alpha(0.0f).translationX(f).scaleX(0.986f).scaleY(0.986f).setDuration(170L).setInterpolator(accelerateDecelerateInterpolator2).withEndAction(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda57
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.animateAuthTabSwitch$lambda$128(linearLayout);
            }
        }).start();
        linearLayout3.animate().alpha(1.0f).translationX(0.0f).scaleX(1.0f).scaleY(1.0f).setDuration(220L).setStartDelay(20L).setInterpolator(accelerateDecelerateInterpolator2).withEndAction(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda58
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.animateAuthTabSwitch$lambda$129(linearLayout3, iMeasureAuthPanelHeight2, this);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void animateAuthTabSwitch$lambda$128(LinearLayout fromPanel) {
        Intrinsics.checkNotNullParameter(fromPanel, "$fromPanel");
        fromPanel.setVisibility(8);
        fromPanel.setAlpha(1.0f);
        fromPanel.setTranslationX(0.0f);
        fromPanel.setScaleX(1.0f);
        fromPanel.setScaleY(1.0f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void animateAuthTabSwitch$lambda$129(LinearLayout toPanel, int i, AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(toPanel, "$toPanel");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        toPanel.setAlpha(1.0f);
        toPanel.setTranslationX(0.0f);
        toPanel.setScaleX(1.0f);
        toPanel.setScaleY(1.0f);
        if (i > 0) {
            setAuthFormsHostHeight$default(this$0, i, false, 0L, 4, null);
        } else {
            this$0.syncAuthFormsHostHeight(false);
        }
        this$0.authSwitchAnimating = false;
        if (this$0.isTouchDevice || this$0.guestScreen != GuestScreen.AUTH) {
            return;
        }
        this$0.focusAuthTab();
    }

    private final void syncAuthFormsHostHeight(boolean animate) {
        LinearLayout linearLayout;
        String str;
        if (this.authFormsHost == null) {
            return;
        }
        LinearLayout linearLayout2 = null;
        if (this.authTab == AuthTab.LOGIN) {
            linearLayout = this.loginPanel;
            if (linearLayout == null) {
                str = "loginPanel";
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            linearLayout2 = linearLayout;
        } else {
            linearLayout = this.registerPanel;
            if (linearLayout == null) {
                str = "registerPanel";
                Intrinsics.throwUninitializedPropertyAccessException(str);
            }
            linearLayout2 = linearLayout;
        }
        int iMeasureAuthPanelHeight = measureAuthPanelHeight(linearLayout2);
        if (iMeasureAuthPanelHeight > 0) {
            setAuthFormsHostHeight(iMeasureAuthPanelHeight, animate, 180L);
        }
    }

    private final int measureAuthPanelHeight(View panel) {
        int measuredWidth;
        FrameLayout frameLayout = this.authFormsHost;
        if (frameLayout == null) {
            return panel.getHeight();
        }
        FrameLayout frameLayout2 = null;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout = null;
        }
        Integer numValueOf = Integer.valueOf(frameLayout.getWidth());
        if (!(numValueOf.intValue() > 0)) {
            numValueOf = null;
        }
        if (numValueOf != null) {
            measuredWidth = numValueOf.intValue();
        } else {
            FrameLayout frameLayout3 = this.authFormsHost;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
                frameLayout3 = null;
            }
            measuredWidth = frameLayout3.getMeasuredWidth();
        }
        if (measuredWidth <= 0) {
            return panel.getHeight();
        }
        FrameLayout frameLayout4 = this.authFormsHost;
        if (frameLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout4 = null;
        }
        int paddingLeft = measuredWidth - frameLayout4.getPaddingLeft();
        FrameLayout frameLayout5 = this.authFormsHost;
        if (frameLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
        } else {
            frameLayout2 = frameLayout5;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(RangesKt.coerceAtLeast(paddingLeft - frameLayout2.getPaddingRight(), 0), 1073741824);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        int visibility = panel.getVisibility();
        if (visibility == 8) {
            panel.setVisibility(4);
        }
        panel.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredHeight = panel.getMeasuredHeight();
        panel.setVisibility(visibility);
        return measuredHeight;
    }

    static /* synthetic */ void setAuthFormsHostHeight$default(AccountScreenView accountScreenView, int i, boolean z, long j, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            j = 180;
        }
        accountScreenView.setAuthFormsHostHeight(i, z, j);
    }

    private final void setAuthFormsHostHeight(int targetHeight, boolean animate, long durationMs) {
        int height;
        FrameLayout frameLayout = this.authFormsHost;
        if (frameLayout == null || targetHeight <= 0) {
            return;
        }
        FrameLayout frameLayout2 = null;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout = null;
        }
        ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
        if (layoutParams == null) {
            return;
        }
        FrameLayout frameLayout3 = this.authFormsHost;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout3 = null;
        }
        if (frameLayout3.getHeight() > 0) {
            FrameLayout frameLayout4 = this.authFormsHost;
            if (frameLayout4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
                frameLayout4 = null;
            }
            height = frameLayout4.getHeight();
        } else {
            height = layoutParams.height > 0 ? layoutParams.height : targetHeight;
        }
        ValueAnimator valueAnimator = this.authHeightAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.authHeightAnimator = null;
        if (!animate || height == targetHeight) {
            layoutParams.height = targetHeight;
            FrameLayout frameLayout5 = this.authFormsHost;
            if (frameLayout5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            } else {
                frameLayout2 = frameLayout5;
            }
            frameLayout2.setLayoutParams(layoutParams);
            return;
        }
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(height, targetHeight);
        valueAnimatorOfInt.setDuration(durationMs);
        valueAnimatorOfInt.setInterpolator(new AccelerateDecelerateInterpolator());
        valueAnimatorOfInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda26
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                AccountScreenView.setAuthFormsHostHeight$lambda$132$lambda$131(this.f$0, valueAnimator2);
            }
        });
        valueAnimatorOfInt.start();
        this.authHeightAnimator = valueAnimatorOfInt;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setAuthFormsHostHeight$lambda$132$lambda$131(AccountScreenView this$0, ValueAnimator va) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(va, "va");
        Object animatedValue = va.getAnimatedValue();
        Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Int");
        int iIntValue = ((Integer) animatedValue).intValue();
        FrameLayout frameLayout = this$0.authFormsHost;
        FrameLayout frameLayout2 = null;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
            frameLayout = null;
        }
        ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
        layoutParams.height = iIntValue;
        FrameLayout frameLayout3 = this$0.authFormsHost;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authFormsHost");
        } else {
            frameLayout2 = frameLayout3;
        }
        frameLayout2.setLayoutParams(layoutParams);
    }

    private final void updateAuthTabIndicator(boolean animate) {
        TextView textView;
        String str;
        if (this.authTabsWrap == null || this.authTabsIndicator == null) {
            return;
        }
        FrameLayout frameLayout = null;
        View view = null;
        if (this.authTab == AuthTab.LOGIN) {
            textView = this.loginTabBtn;
            if (textView == null) {
                str = "loginTabBtn";
                Intrinsics.throwUninitializedPropertyAccessException(str);
                textView = null;
            }
        } else {
            textView = this.registerTabBtn;
            if (textView == null) {
                str = "registerTabBtn";
                Intrinsics.throwUninitializedPropertyAccessException(str);
                textView = null;
            }
        }
        int width = textView.getWidth();
        int height = textView.getHeight();
        if (width <= 0 || height <= 0) {
            FrameLayout frameLayout2 = this.authTabsWrap;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            } else {
                frameLayout = frameLayout2;
            }
            frameLayout.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda39
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.updateAuthTabIndicator$lambda$133(this.f$0);
                }
            });
            return;
        }
        Rect rect = new Rect(0, 0, width, height);
        FrameLayout frameLayout3 = this.authTabsWrap;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout3 = null;
        }
        frameLayout3.offsetDescendantRectToMyCoords(textView, rect);
        FrameLayout frameLayout4 = this.authTabsWrap;
        if (frameLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout4 = null;
        }
        int paddingLeft = frameLayout4.getPaddingLeft();
        FrameLayout frameLayout5 = this.authTabsWrap;
        if (frameLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout5 = null;
        }
        int paddingTop = frameLayout5.getPaddingTop();
        FrameLayout frameLayout6 = this.authTabsWrap;
        if (frameLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout6 = null;
        }
        int width2 = frameLayout6.getWidth();
        FrameLayout frameLayout7 = this.authTabsWrap;
        if (frameLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout7 = null;
        }
        int paddingRight = width2 - frameLayout7.getPaddingRight();
        FrameLayout frameLayout8 = this.authTabsWrap;
        if (frameLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout8 = null;
        }
        int height2 = frameLayout8.getHeight();
        FrameLayout frameLayout9 = this.authTabsWrap;
        if (frameLayout9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsWrap");
            frameLayout9 = null;
        }
        int paddingBottom = height2 - frameLayout9.getPaddingBottom();
        final float f = rect.left - paddingLeft;
        final float f2 = rect.top - paddingTop;
        int iCoerceAtLeast = RangesKt.coerceAtLeast(paddingRight - paddingLeft, 1);
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast(paddingBottom - paddingTop, 1);
        final int iCoerceAtLeast3 = RangesKt.coerceAtLeast(Math.min(width, iCoerceAtLeast), 1);
        final int iCoerceAtLeast4 = RangesKt.coerceAtLeast(Math.min(height, Math.min(m377dp(56), iCoerceAtLeast2)), 1);
        View view2 = this.authTabsIndicator;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view2 = null;
        }
        ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
        int i = layoutParams2.width > 0 ? layoutParams2.width : iCoerceAtLeast3;
        int i2 = layoutParams2.height > 0 ? layoutParams2.height : iCoerceAtLeast4;
        View view3 = this.authTabsIndicator;
        if (view3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view3 = null;
        }
        final float translationX = view3.getTranslationX();
        View view4 = this.authTabsIndicator;
        if (view4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view4 = null;
        }
        final float translationY = view4.getTranslationY();
        ValueAnimator valueAnimator = this.authTabIndicatorAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.authTabIndicatorAnimator = null;
        if (!animate) {
            layoutParams2.width = iCoerceAtLeast3;
            layoutParams2.height = iCoerceAtLeast4;
            View view5 = this.authTabsIndicator;
            if (view5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
                view5 = null;
            }
            view5.setLayoutParams(layoutParams2);
            View view6 = this.authTabsIndicator;
            if (view6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
                view6 = null;
            }
            view6.setTranslationX(f);
            View view7 = this.authTabsIndicator;
            if (view7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            } else {
                view = view7;
            }
            view.setTranslationY(f2);
            return;
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.setDuration(240L);
        valueAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
        final int i3 = i;
        final int i4 = i2;
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda40
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                AccountScreenView.updateAuthTabIndicator$lambda$135$lambda$134(i3, iCoerceAtLeast3, i4, iCoerceAtLeast4, translationX, f, translationY, f2, this, valueAnimator2);
            }
        });
        valueAnimatorOfFloat.start();
        this.authTabIndicatorAnimator = valueAnimatorOfFloat;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void updateAuthTabIndicator$lambda$133(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateAuthTabIndicator(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void updateAuthTabIndicator$lambda$135$lambda$134(int i, int i2, int i3, int i4, float f, float f2, float f3, float f4, AccountScreenView this$0, ValueAnimator va) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(va, "va");
        float animatedFraction = va.getAnimatedFraction();
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (i + ((i2 - i) * animatedFraction)), 1);
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast((int) (i3 + ((i4 - i3) * animatedFraction)), 1);
        float f5 = f + ((f2 - f) * animatedFraction);
        float f6 = f3 + ((f4 - f3) * animatedFraction);
        View view = this$0.authTabsIndicator;
        View view2 = null;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view = null;
        }
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
        layoutParams2.width = iCoerceAtLeast;
        layoutParams2.height = iCoerceAtLeast2;
        View view3 = this$0.authTabsIndicator;
        if (view3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view3 = null;
        }
        view3.setLayoutParams(layoutParams2);
        View view4 = this$0.authTabsIndicator;
        if (view4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
            view4 = null;
        }
        view4.setTranslationX(f5);
        View view5 = this$0.authTabsIndicator;
        if (view5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authTabsIndicator");
        } else {
            view2 = view5;
        }
        view2.setTranslationY(f6);
    }

    private final void updateAuthTabUi() {
        boolean z;
        TextView textView = null;
        if (this.authSwitchAnimating) {
            TextView textView2 = this.loginTabBtn;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
                textView2 = null;
            }
            boolean z2 = this.authTab == AuthTab.LOGIN;
            TextView textView3 = this.loginTabBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
                textView3 = null;
            }
            applyAuthTabStyle(textView2, z2, textView3.isFocused());
            TextView textView4 = this.registerTabBtn;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
                textView4 = null;
            }
            z = this.authTab == AuthTab.REGISTER;
            TextView textView5 = this.registerTabBtn;
            if (textView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
                textView5 = null;
            }
            applyAuthTabStyle(textView4, z, textView5.isFocused());
            TextView textView6 = this.authModeHint;
            if (textView6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authModeHint");
            } else {
                textView = textView6;
            }
            textView.setText("");
            return;
        }
        LinearLayout linearLayout = this.loginPanel;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPanel");
            linearLayout = null;
        }
        linearLayout.setVisibility(this.authTab == AuthTab.LOGIN ? 0 : 8);
        LinearLayout linearLayout2 = this.registerPanel;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerPanel");
            linearLayout2 = null;
        }
        linearLayout2.setVisibility(this.authTab == AuthTab.REGISTER ? 0 : 8);
        TextView textView7 = this.loginTabBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
            textView7 = null;
        }
        boolean z3 = this.authTab == AuthTab.LOGIN;
        TextView textView8 = this.loginTabBtn;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
            textView8 = null;
        }
        applyAuthTabStyle(textView7, z3, textView8.isFocused());
        TextView textView9 = this.registerTabBtn;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
            textView9 = null;
        }
        z = this.authTab == AuthTab.REGISTER;
        TextView textView10 = this.registerTabBtn;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
            textView10 = null;
        }
        applyAuthTabStyle(textView9, z, textView10.isFocused());
        TextView textView11 = this.authModeHint;
        if (textView11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("authModeHint");
        } else {
            textView = textView11;
        }
        textView.setText("");
        updateAuthTabIndicator(false);
        syncAuthFormsHostHeight(false);
    }

    private final void refreshUiByAuthState() {
        LinearLayout linearLayout = this.guestRoot;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guestRoot");
            linearLayout = null;
        }
        linearLayout.setVisibility(this.isLoggedIn ? 8 : 0);
        LinearLayout linearLayout3 = this.loggedSection;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loggedSection");
        } else {
            linearLayout2 = linearLayout3;
        }
        linearLayout2.setVisibility(this.isLoggedIn ? 0 : 8);
        if (!this.isLoggedIn) {
            stopPanelCountdown();
            updateGuestScreenUi();
            updateAuthTabUi();
            if (this.guestScreen == GuestScreen.f342QR) {
                loadQr();
                return;
            }
            return;
        }
        stopQrPolling();
        stopQrCountdown();
        loadUserPanelData(false);
    }

    private final void loadUserPanelData(boolean force) {
        UserPanelData userPanelData;
        final Session session = this.session;
        if (!this.isLoggedIn || session == null || this.panelLoading) {
            return;
        }
        if (!force && (userPanelData = this.panelData) != null) {
            Intrinsics.checkNotNull(userPanelData);
            renderPanelData(userPanelData);
            return;
        }
        TextView textView = null;
        if (StringsKt.isBlank(this.apiBase)) {
            TextView textView2 = this.panelLoadingText;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
                textView2 = null;
            }
            textView2.setText("آدرس سرور در دسترس نیست.");
            TextView textView3 = this.panelLoadingText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
            } else {
                textView = textView3;
            }
            textView.setVisibility(0);
            return;
        }
        this.panelLoading = true;
        TextView textView4 = this.panelLoadingText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
            textView4 = null;
        }
        textView4.setText("در حال دریافت اطلاعات حساب...");
        TextView textView5 = this.panelLoadingText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
        } else {
            textView = textView5;
        }
        textView.setVisibility(0);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.loadUserPanelData$lambda$138(session, this);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadUserPanelData$lambda$138(Session session, final AccountScreenView this$0) {
        String strSignedRequest$default;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            Map mapMapOf = MapsKt.mapOf(TuplesKt.m787to("x-fk-user-id", String.valueOf(session.getUserId())), TuplesKt.m787to("x-fk-session", session.getSessionToken()));
            Map mapMapOf2 = MapsKt.mapOf(TuplesKt.m787to("userID", String.valueOf(session.getUserId())), TuplesKt.m787to("userId", String.valueOf(session.getUserId())));
            try {
                strSignedRequest$default = FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/userPanelData", "GET", mapMapOf2, mapMapOf, null, false, 96, null);
            } catch (Throwable unused) {
                strSignedRequest$default = FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/userData", "GET", mapMapOf2, mapMapOf, null, false, 96, null);
            }
            final UserPanelResult userPanel = AccountParser.INSTANCE.parseUserPanel(strSignedRequest$default);
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda22
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.loadUserPanelData$lambda$138$lambda$136(this.f$0, userPanel);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda33
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.loadUserPanelData$lambda$138$lambda$137(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadUserPanelData$lambda$138$lambda$136(AccountScreenView this$0, UserPanelResult parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.panelLoading = false;
        if (!parsed.getOk() || parsed.getData() == null) {
            TextView textView = this$0.panelLoadingText;
            TextView textView2 = null;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
                textView = null;
            }
            textView.setText(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "دریافت اطلاعات حساب ناموفق بود"));
            TextView textView3 = this$0.panelLoadingText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
            } else {
                textView2 = textView3;
            }
            textView2.setVisibility(0);
            return;
        }
        this$0.panelData = parsed.getData();
        this$0.renderPanelData(parsed.getData());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadUserPanelData$lambda$138$lambda$137(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.panelLoading = false;
        TextView textView = this$0.panelLoadingText;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
            textView = null;
        }
        textView.setText(this$0.readableError(e, "خطا در دریافت اطلاعات حساب"));
        TextView textView3 = this$0.panelLoadingText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
        } else {
            textView2 = textView3;
        }
        textView2.setVisibility(0);
    }

    private final void renderPanelData(UserPanelData data) {
        String string;
        GradientDrawable gradientDrawableRoundedBg;
        String userName = data.getUserName();
        TextView textView = null;
        String string2 = userName != null ? StringsKt.trim((CharSequence) userName).toString() : null;
        String str = string2;
        if (str == null || StringsKt.isBlank(str)) {
            string2 = null;
        }
        if (string2 == null) {
            String displayName = data.getDisplayName();
            string2 = displayName != null ? StringsKt.trim((CharSequence) displayName).toString() : null;
            String str2 = string2;
            if (str2 == null || StringsKt.isBlank(str2)) {
                string2 = null;
            }
            if (string2 == null) {
                string2 = "کاربر";
            }
        }
        TextView textView2 = this.panelNameText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelNameText");
            textView2 = null;
        }
        String str3 = string2;
        textView2.setText(str3);
        TextView textView3 = this.panelAvatarText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelAvatarText");
            textView3 = null;
        }
        Character chFirstOrNull = StringsKt.firstOrNull(StringsKt.trim((CharSequence) str3).toString());
        if (chFirstOrNull == null || (string = Character.valueOf(Character.toUpperCase(chFirstOrNull.charValue())).toString()) == null) {
            string = "?";
        }
        textView3.setText(string);
        String email = data.getEmail();
        String string3 = email != null ? StringsKt.trim((CharSequence) email).toString() : null;
        if (string3 == null) {
            string3 = "";
        }
        TextView textView4 = this.panelEmailText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelEmailText");
            textView4 = null;
        }
        String str4 = string3;
        if (StringsKt.isBlank(str4)) {
        }
        textView4.setText(str4);
        this.panelTelegramUrl = resolveSocialUrl(data, "telegram", CollectionsKt.listOf((Object[]) new String[]{"تلگرام", "telegram"}), "https://t.me/FilmKio");
        this.panelInstagramUrl = resolveSocialUrl(data, "instagram", CollectionsKt.listOf((Object[]) new String[]{"اینستاگرام", "instagram", "insta"}), "https://instagram.com/FilmKio");
        renderPanelNotifications(data.getNotifications());
        renderPanelShortcutGrid(data.getMenu());
        int iCoerceIn = RangesKt.coerceIn(data.getProgressPercent(), 0, 100);
        TextView textView5 = this.panelSubPercentText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubPercentText");
            textView5 = null;
        }
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String str5 = String.format(Locale.US, "%d%%", Arrays.copyOf(new Object[]{Integer.valueOf(iCoerceIn)}, 1));
        Intrinsics.checkNotNullExpressionValue(str5, "format(...)");
        textView5.setText(str5);
        setSubscriptionGaugeProgress(iCoerceIn, true);
        boolean subscriberStatus = data.getSubscriberStatus();
        TextView textView6 = this.panelSubStatusChip;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubStatusChip");
            textView6 = null;
        }
        textView6.setText(subscriberStatus ? "اشتراک شما فعال است" : "اشتراک شما غیرفعال است");
        TextView textView7 = this.panelSubStatusChip;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubStatusChip");
            textView7 = null;
        }
        textView7.setTextColor(subscriberStatus ? -14756000 : -29556);
        TextView textView8 = this.panelSubStatusChip;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubStatusChip");
            textView8 = null;
        }
        if (subscriberStatus) {
            gradientDrawableRoundedBg = roundedBg(521282584, 1430184070, m377dp(1), dpF(999));
        } else {
            gradientDrawableRoundedBg = roundedBg(857673487, 1442802282, m377dp(1), dpF(999));
        }
        textView8.setBackground(gradientDrawableRoundedBg);
        String expireDate = data.getExpireDate();
        String string4 = expireDate != null ? StringsKt.trim((CharSequence) expireDate).toString() : null;
        if (string4 == null) {
            string4 = "";
        }
        TextView textView9 = this.panelSubMetaText;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubMetaText");
            textView9 = null;
        }
        String str6 = string4;
        textView9.setVisibility(StringsKt.isBlank(str6) ? 8 : 0);
        TextView textView10 = this.panelSubMetaText;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelSubMetaText");
            textView10 = null;
        }
        textView10.setText(StringsKt.isBlank(str6) ? "" : "تاریخ انقضا: " + string4);
        long jResolveCountdownTargetMillis = resolveCountdownTargetMillis(data.getExpireDate(), data.getDayLeft());
        if (jResolveCountdownTargetMillis > System.currentTimeMillis() && subscriberStatus) {
            HorizontalScrollView horizontalScrollView = this.panelCountdownScroll;
            if (horizontalScrollView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelCountdownScroll");
                horizontalScrollView = null;
            }
            horizontalScrollView.setVisibility(0);
            startPanelCountdown(jResolveCountdownTargetMillis);
        } else {
            HorizontalScrollView horizontalScrollView2 = this.panelCountdownScroll;
            if (horizontalScrollView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelCountdownScroll");
                horizontalScrollView2 = null;
            }
            horizontalScrollView2.setVisibility(8);
            stopPanelCountdown();
            updatePanelCountdownViews(0, 0, 0, 0);
        }
        TextView textView11 = this.panelLoadingText;
        if (textView11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelLoadingText");
        } else {
            textView = textView11;
        }
        textView.setVisibility(8);
    }

    private final void setSubscriptionGaugeProgress(int percent, boolean animate) {
        SubscriptionGaugeView subscriptionGaugeView = this.panelSubArcView;
        if (subscriptionGaugeView != null) {
            subscriptionGaugeView.setProgress(percent, animate);
        }
    }

    private final Pair<TextView, LinearLayout> makeCountdownCell(String label) {
        TextView textView = new TextView(this.ctx);
        textView.setText("00");
        textView.setTextColor(-1);
        textView.setTextSize(23.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setGravity(17);
        textView.setLayoutDirection(0);
        textView.setTextDirection(3);
        textView.setTextAlignment(4);
        textView.setIncludeFontPadding(true);
        textView.setSingleLine(true);
        textView.setEllipsize(null);
        textView.setMaxLines(1);
        textView.setMinWidth(0);
        textView.setMinimumWidth(0);
        textView.setPadding(m377dp(4), 0, m377dp(4), 0);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText(label);
        textView2.setTextColor(-1379847);
        textView2.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceMedium);
        textView2.setGravity(17);
        textView2.setSingleLine(true);
        textView2.setPadding(m377dp(10), m377dp(5), m377dp(10), m377dp(5));
        textView2.setBackground(roundedBg(287454020, DefaultTimeBar.DEFAULT_UNPLAYED_COLOR, m377dp(1), dpF(999)));
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutDirection(1);
        linearLayout.setClipChildren(false);
        linearLayout.setClipToPadding(false);
        linearLayout.addView(textView);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = m377dp(4);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView2, layoutParams);
        return TuplesKt.m787to(textView, linearLayout);
    }

    private final TextView makeCountdownSeparator() {
        TextView textView = new TextView(this.ctx);
        textView.setText(":");
        textView.setTextColor(-3023640);
        textView.setTextSize(24.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setGravity(17);
        textView.setPadding(m377dp(4), m377dp(6), m377dp(4), 0);
        return textView;
    }

    private final LinearLayout makeSocialHalfCard(int iconRes, String title) {
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(-1);
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-1);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setGravity(17);
        textView.setTextAlignment(4);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(17);
        linearLayout.setPadding(m377dp(8), m377dp(12), m377dp(8), m377dp(12));
        linearLayout.setBackground(roundedBg(0, 989855743, m377dp(1), dpF(12)));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(!this.isTouchDevice);
        linearLayout.setFocusableInTouchMode(true ^ this.isTouchDevice);
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(m377dp(20), m377dp(20)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(8);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        linearLayout.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda43
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makeSocialHalfCard$lambda$150$lambda$149(this.f$0, view, z);
            }
        });
        attachMenuShortcut(linearLayout);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeSocialHalfCard$lambda$150$lambda$149(AccountScreenView this$0, View view, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.setBackground(this$0.roundedBg(z ? 303703861 : 0, z ? 1728053247 : 989855743, this$0.m377dp(1), this$0.dpF(12)));
        if (z) {
            Intrinsics.checkNotNull(view);
            this$0.scrollToView(view);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0067  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void renderPanelNotifications(List<NotifItem> items) {
        Pair pairM787to;
        String string;
        LinearLayout linearLayout = this.panelNotificationsWrap;
        if (linearLayout == null) {
            return;
        }
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelNotificationsWrap");
            linearLayout = null;
        }
        linearLayout.removeAllViews();
        ArrayList arrayList = new ArrayList();
        for (NotifItem notifItem : items) {
            String value = notifItem.getValue();
            if (value == null || (string = StringsKt.trim((CharSequence) value).toString()) == null) {
                pairM787to = null;
            } else {
                if (!(true ^ StringsKt.isBlank(string))) {
                    string = null;
                }
                if (string != null) {
                    String label = notifItem.getLabel();
                    String string2 = label != null ? StringsKt.trim((CharSequence) label).toString() : null;
                    if (string2 == null) {
                        string2 = "";
                    }
                    pairM787to = TuplesKt.m787to(string, string2);
                }
            }
            if (pairM787to != null) {
                arrayList.add(pairM787to);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (true) {
            boolean z = false;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            String str = (String) ((Pair) next).component2();
            if (!StringsKt.contains((CharSequence) str, (CharSequence) "تلویزیون", true) && !StringsKt.contains((CharSequence) str, (CharSequence) "tv", true)) {
                z = true;
            }
            if (z) {
                arrayList2.add(next);
            }
        }
        ArrayList arrayList3 = arrayList2;
        ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
        Iterator it2 = arrayList3.iterator();
        while (it2.hasNext()) {
            arrayList4.add((String) ((Pair) it2.next()).getFirst());
        }
        List listTake = CollectionsKt.take(arrayList4, 3);
        if (listTake.isEmpty()) {
            LinearLayout linearLayout3 = this.panelNotificationsWrap;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelNotificationsWrap");
            } else {
                linearLayout2 = linearLayout3;
            }
            linearLayout2.setVisibility(8);
            return;
        }
        int i = 0;
        for (Object obj : listTake) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            String str2 = (String) obj;
            LinearLayout linearLayout4 = this.panelNotificationsWrap;
            if (linearLayout4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelNotificationsWrap");
                linearLayout4 = null;
            }
            LinearLayout linearLayoutMakeNotificationRow = makeNotificationRow(str2);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) {
                layoutParams.topMargin = m377dp(8);
            }
            Unit unit = Unit.INSTANCE;
            linearLayout4.addView(linearLayoutMakeNotificationRow, layoutParams);
            i = i2;
        }
        LinearLayout linearLayout5 = this.panelNotificationsWrap;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelNotificationsWrap");
        } else {
            linearLayout2 = linearLayout5;
        }
        linearLayout2.setVisibility(0);
    }

    private final LinearLayout makeNotificationRow(String message) {
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(C2629R.drawable.ic_panel_notification);
        imageView.setColorFilter(-675054);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        TextView textView = new TextView(this.ctx);
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "پیام جدید"));
        textView.setTextColor(-468598);
        textView.setTextSize(13.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setGravity(21);
        textView.setTextAlignment(5);
        textView.setMaxLines(2);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m377dp(10), m377dp(10), m377dp(10), m377dp(10));
        linearLayout.setBackground(roundedBg(337516296, 1173730066, m377dp(1), dpF(12)));
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(m377dp(20), m377dp(20)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginStart(m377dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        return linearLayout;
    }

    private final void renderPanelShortcutGrid(List<PanelMenuItem> menuItems) {
        LinearLayout linearLayout = this.panelShortcutGridWrap;
        if (linearLayout == null) {
            return;
        }
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelShortcutGridWrap");
            linearLayout = null;
        }
        linearLayout.removeAllViews();
        int i = 0;
        for (Object obj : CollectionsKt.chunked(buildPanelShortcutEntries(menuItems), 3)) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            List list = (List) obj;
            LinearLayout linearLayout2 = new LinearLayout(this.ctx);
            linearLayout2.setOrientation(0);
            linearLayout2.setLayoutDirection(1);
            linearLayout2.setGravity(16);
            for (int i3 = 0; i3 < 3; i3++) {
                if (i3 < list.size()) {
                    PanelShortcutEntry panelShortcutEntry = (PanelShortcutEntry) list.get(i3);
                    LinearLayout linearLayoutMakePanelShortcutCard = makePanelShortcutCard(panelShortcutEntry.getItem(), panelShortcutEntry.getIconRes());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    layoutParams.setMarginStart(m377dp(4));
                    layoutParams.setMarginEnd(m377dp(4));
                    Unit unit = Unit.INSTANCE;
                    linearLayout2.addView(linearLayoutMakePanelShortcutCard, layoutParams);
                } else {
                    View view = new View(this.ctx);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    layoutParams2.setMarginStart(m377dp(4));
                    layoutParams2.setMarginEnd(m377dp(4));
                    Unit unit2 = Unit.INSTANCE;
                    linearLayout2.addView(view, layoutParams2);
                }
            }
            LinearLayout linearLayout3 = this.panelShortcutGridWrap;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("panelShortcutGridWrap");
                linearLayout3 = null;
            }
            LinearLayout linearLayout4 = linearLayout2;
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            if (i > 0) {
                layoutParams3.topMargin = m377dp(8);
            }
            Unit unit3 = Unit.INSTANCE;
            linearLayout3.addView(linearLayout4, layoutParams3);
            i = i2;
        }
    }

    private final List<PanelShortcutEntry> buildPanelShortcutEntries(List<PanelMenuItem> menuItems) {
        PanelMenuItem panelMenuItem;
        ArrayList arrayList = new ArrayList();
        for (Object obj : menuItems) {
            if (((PanelMenuItem) obj).getStatus()) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = arrayList;
        List<PanelShortcutSpec> listListOf = CollectionsKt.listOf((Object[]) new PanelShortcutSpec[]{new PanelShortcutSpec("buy_subscription", "خرید اشتراک", C2629R.drawable.ic_panel_buy_subscription, CollectionsKt.listOf((Object[]) new String[]{"buy_subscription", "purchase_subscription", FirebaseAnalytics.Event.PURCHASE, "buy", "renew"}), CollectionsKt.listOf((Object[]) new String[]{FirebaseAnalytics.Event.PURCHASE, "buy_subscription"}), CollectionsKt.listOf((Object[]) new String[]{"خرید اشتراک", "تمدید اشتراک"})), new PanelShortcutSpec("purchase_history", "سوابق پرداخت", C2629R.drawable.ic_panel_purchase_history, CollectionsKt.listOf((Object[]) new String[]{"purchase_history", "payment_history", "orders", "order_history"}), CollectionsKt.listOf((Object[]) new String[]{"purchase_history", "orders"}), CollectionsKt.listOf((Object[]) new String[]{"سوابق پرداخت", "سوابق خرید", "پرداخت"})), new PanelShortcutSpec("support", "پشتیبانی", C2629R.drawable.ic_panel_support, CollectionsKt.listOf((Object[]) new String[]{"support", "ticket", "tickets"}), CollectionsKt.listOf((Object[]) new String[]{"support", "ticket", "tickets"}), CollectionsKt.listOf((Object[]) new String[]{"پشتیبانی", "تیکت"})), new PanelShortcutSpec("watch_history", "سابقه تماشا", C2629R.drawable.ic_history, CollectionsKt.listOf((Object[]) new String[]{"watch_history", "seen", "watched"}), CollectionsKt.listOf((Object[]) new String[]{"watch_history", "history"}), CollectionsKt.listOf((Object[]) new String[]{"سابقه تماشا", "مشاهده", "تماشا کرده"})), new PanelShortcutSpec("marked_items", "نشان شده ها", C2629R.drawable.ic_watchlist_off, CollectionsKt.listOf((Object[]) new String[]{"watchlist", "bookmark", "bookmarks", "marked", "favorites"}), CollectionsKt.listOf((Object[]) new String[]{"watchlist", "bookmark", "favorites"}), CollectionsKt.listOf((Object[]) new String[]{"نشان شده", "لیست تماشا", "علاقه"})), new PanelShortcutSpec("requests", "درخواست ها", C2629R.drawable.ic_panel_requests, CollectionsKt.listOf((Object[]) new String[]{"requests", "request", "requests_movie"}), CollectionsKt.listOf((Object[]) new String[]{"requests", "request"}), CollectionsKt.listOf("درخواست")), new PanelShortcutSpec("lists", "لیست ها", C2629R.drawable.ic_panel_lists, CollectionsKt.listOf((Object[]) new String[]{"lists", "user_lists", "collections"}), CollectionsKt.listOf((Object[]) new String[]{"lists", "collections"}), CollectionsKt.listOf((Object[]) new String[]{"لیست ها", "لیست\u200cها", "لیست های کاربری", "لیست\u200cهای کاربری"})), new PanelShortcutSpec("play_settings", "تنظیمات پخش", C2629R.drawable.ic_panel_playset, CollectionsKt.listOf((Object[]) new String[]{"play_settings", "playset", "player_settings"}), CollectionsKt.listOf((Object[]) new String[]{"play_settings", "playset"}), CollectionsKt.listOf((Object[]) new String[]{"تنظیمات پخش", "پخش آنلاین"})), new PanelShortcutSpec("edit_profile", "ویرایش اطلاعات", C2629R.drawable.ic_panel_edit_profile, CollectionsKt.listOf((Object[]) new String[]{"edit_profile", "profile_edit", "settings", "account_edit"}), CollectionsKt.listOf((Object[]) new String[]{"edit_profile", Scopes.PROFILE}), CollectionsKt.listOf((Object[]) new String[]{"ویرایش اطلاعات", "ویرایش پروفایل", "پروفایل"}))});
        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(listListOf, 10));
        for (PanelShortcutSpec panelShortcutSpec : listListOf) {
            PanelMenuItem panelMenuItemFindPanelShortcutItem = findPanelShortcutItem(arrayList2, panelShortcutSpec);
            if (panelMenuItemFindPanelShortcutItem != null) {
                panelMenuItem = panelMenuItemFindPanelShortcutItem.copy((253 & 1) != 0 ? panelMenuItemFindPanelShortcutItem.key : null, (253 & 2) != 0 ? panelMenuItemFindPanelShortcutItem.label : panelShortcutSpec.getLabel(), (253 & 4) != 0 ? panelMenuItemFindPanelShortcutItem.icon : null, (253 & 8) != 0 ? panelMenuItemFindPanelShortcutItem.style : null, (253 & 16) != 0 ? panelMenuItemFindPanelShortcutItem.badge : null, (253 & 32) != 0 ? panelMenuItemFindPanelShortcutItem.screen : null, (253 & 64) != 0 ? panelMenuItemFindPanelShortcutItem.url : null, (253 & 128) != 0 ? panelMenuItemFindPanelShortcutItem.status : false);
            } else {
                panelMenuItem = new PanelMenuItem(panelShortcutSpec.getKey(), panelShortcutSpec.getLabel(), null, "default", null, panelShortcutSpec.getKey(), null, true);
            }
            arrayList3.add(new PanelShortcutEntry(panelMenuItem, panelShortcutSpec.getIconRes()));
        }
        return arrayList3;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0053  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00bd A[EDGE_INSN: B:49:0x00bd->B:46:0x00bd BREAK  A[LOOP:0: B:3:0x0006->B:54:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b9 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00b9 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00b9 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:54:? A[LOOP:0: B:3:0x0006->B:54:?, LOOP_END, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final PanelMenuItem findPanelShortcutItem(List<PanelMenuItem> items, PanelShortcutSpec spec) {
        Object next;
        boolean z;
        boolean z2;
        boolean z3;
        Iterator<T> it = items.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            PanelMenuItem panelMenuItem = (PanelMenuItem) next;
            String strNormalizePanelAlias = normalizePanelAlias(panelMenuItem.getKey());
            String strNormalizePanelAlias2 = normalizePanelAlias(panelMenuItem.getScreen());
            List<String> keyAliases = spec.getKeyAliases();
            boolean z4 = true;
            if ((keyAliases instanceof Collection) && keyAliases.isEmpty()) {
                z = false;
                if (z) {
                }
                if (!z4) {
                }
            } else {
                Iterator<T> it2 = keyAliases.iterator();
                while (it2.hasNext()) {
                    if (aliasMatches(strNormalizePanelAlias, (String) it2.next())) {
                        z = true;
                        break;
                    }
                }
                z = false;
                if (z) {
                    List<String> screenAliases = spec.getScreenAliases();
                    if ((screenAliases instanceof Collection) && screenAliases.isEmpty()) {
                        z2 = false;
                        if (z2) {
                        }
                    } else {
                        Iterator<T> it3 = screenAliases.iterator();
                        while (it3.hasNext()) {
                            if (aliasMatches(strNormalizePanelAlias2, (String) it3.next())) {
                                z2 = true;
                                break;
                            }
                        }
                        z2 = false;
                        if (z2) {
                            List<String> labelAliases = spec.getLabelAliases();
                            if ((labelAliases instanceof Collection) && labelAliases.isEmpty()) {
                                z3 = false;
                                if (z3) {
                                }
                            } else {
                                Iterator<T> it4 = labelAliases.iterator();
                                while (it4.hasNext()) {
                                    if (StringsKt.contains((CharSequence) panelMenuItem.getLabel(), (CharSequence) it4.next(), true)) {
                                        z3 = true;
                                        break;
                                    }
                                }
                                z3 = false;
                                if (z3) {
                                    z4 = false;
                                }
                            }
                        }
                    }
                }
                if (!z4) {
                    break;
                }
            }
        }
        return (PanelMenuItem) next;
    }

    private final boolean aliasMatches(String value, String alias) {
        String strNormalizePanelAlias = normalizePanelAlias(alias);
        if (StringsKt.isBlank(value)) {
            return false;
        }
        String str = strNormalizePanelAlias;
        if (StringsKt.isBlank(str)) {
            return false;
        }
        if (Intrinsics.areEqual(value, strNormalizePanelAlias)) {
            return true;
        }
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "_", false, 2, (Object) null) && StringsKt.endsWith$default(value, new StringBuilder().append("_").append(strNormalizePanelAlias).toString(), false, 2, (Object) null);
    }

    private final String normalizePanelAlias(String raw) {
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return "";
        }
        String string = StringsKt.trim((CharSequence) str).toString();
        Locale US = Locale.US;
        Intrinsics.checkNotNullExpressionValue(US, "US");
        String lowerCase = string.toLowerCase(US);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return StringsKt.replace$default(StringsKt.replace$default(lowerCase, '-', '_', false, 4, (Object) null), ' ', '_', false, 4, (Object) null);
    }

    private final LinearLayout makePanelShortcutCard(final PanelMenuItem item, int iconRes) {
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(-1);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        TextView textView = new TextView(this.ctx);
        textView.setText(item.getLabel());
        textView.setTextColor(-1);
        textView.setTextSize(13.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setGravity(17);
        textView.setTextAlignment(4);
        textView.setMaxLines(2);
        textView.setLineSpacing(m377dp(2), 1.0f);
        textView.setIncludeFontPadding(false);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(17);
        linearLayout.setMinimumHeight(m377dp(112));
        linearLayout.setPadding(m377dp(8), m377dp(10), m377dp(8), m377dp(10));
        linearLayout.setBackground(roundedBg(-15920358, 536870911, m377dp(1), dpF(14)));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(!this.isTouchDevice);
        linearLayout.setFocusableInTouchMode(true ^ this.isTouchDevice);
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(m377dp(22), m377dp(22)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(8);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda27
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountScreenView.makePanelShortcutCard$lambda$177$lambda$175(this.f$0, item, view);
            }
        });
        linearLayout.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda28
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makePanelShortcutCard$lambda$177$lambda$176(this.f$0, view, z);
            }
        });
        attachMenuShortcut(linearLayout);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makePanelShortcutCard$lambda$177$lambda$175(AccountScreenView this$0, PanelMenuItem item, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        this$0.handlePanelAction(item);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makePanelShortcutCard$lambda$177$lambda$176(AccountScreenView this$0, View view, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        view.setBackground(this$0.roundedBg(z ? -15458774 : -15920358, z ? 1728053247 : 536870911, this$0.m377dp(1), this$0.dpF(14)));
        if (z) {
            Intrinsics.checkNotNull(view);
            this$0.scrollToView(view);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00cf A[EDGE_INSN: B:76:0x00cf->B:62:0x00cf BREAK  A[LOOP:1: B:35:0x0074->B:79:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:79:? A[LOOP:1: B:35:0x0074->B:79:?, LOOP_END, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final String resolveSocialUrl(UserPanelData data, String keyNeedle, List<String> labelNeedles, String fallback) {
        Object next;
        Object next2;
        boolean z;
        boolean z2;
        List listPlus = CollectionsKt.plus((Collection) data.getSocial(), (Iterable) data.getMenu());
        Iterator it = listPlus.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            PanelMenuItem panelMenuItem = (PanelMenuItem) next;
            String url = panelMenuItem.getUrl();
            if (!(url == null || StringsKt.isBlank(url)) && StringsKt.contains((CharSequence) panelMenuItem.getKey(), (CharSequence) keyNeedle, true)) {
                break;
            }
        }
        PanelMenuItem panelMenuItem2 = (PanelMenuItem) next;
        String url2 = panelMenuItem2 != null ? panelMenuItem2.getUrl() : null;
        String str = url2;
        if (!(str == null || StringsKt.isBlank(str))) {
            return normalizeExternalUrl(url2);
        }
        Iterator it2 = listPlus.iterator();
        while (true) {
            if (!it2.hasNext()) {
                next2 = null;
                break;
            }
            next2 = it2.next();
            PanelMenuItem panelMenuItem3 = (PanelMenuItem) next2;
            String url3 = panelMenuItem3.getUrl();
            if (!(url3 == null || StringsKt.isBlank(url3))) {
                List<String> list = labelNeedles;
                if ((list instanceof Collection) && list.isEmpty()) {
                    z2 = false;
                    if (!z2) {
                    }
                    if (!z) {
                    }
                } else {
                    Iterator<T> it3 = list.iterator();
                    while (it3.hasNext()) {
                        if (StringsKt.contains((CharSequence) panelMenuItem3.getLabel(), (CharSequence) it3.next(), true)) {
                            z2 = true;
                            break;
                        }
                    }
                    z2 = false;
                    z = !z2;
                    if (!z) {
                        break;
                    }
                }
            }
        }
        PanelMenuItem panelMenuItem4 = (PanelMenuItem) next2;
        String url4 = panelMenuItem4 != null ? panelMenuItem4.getUrl() : null;
        if (url4 != null) {
            fallback = url4;
        }
        return normalizeExternalUrl(fallback);
    }

    private final String normalizeExternalUrl(String raw) {
        String string = StringsKt.trim((CharSequence) raw).toString();
        return StringsKt.isBlank(string) ? "" : (StringsKt.startsWith(string, "http://", true) || StringsKt.startsWith(string, "https://", true)) ? string : "https://" + string;
    }

    private final long resolveCountdownTargetMillis(String expireDate, int dayLeft) {
        Long expireDateMillis = parseExpireDateMillis(expireDate);
        if (expireDateMillis != null && expireDateMillis.longValue() > 0) {
            return expireDateMillis.longValue();
        }
        if (dayLeft <= 0) {
            return 0L;
        }
        return System.currentTimeMillis() + (((long) dayLeft) * 24 * 60 * 60 * 1000);
    }

    private final Long parseExpireDateMillis(String value) {
        String string = value != null ? StringsKt.trim((CharSequence) value).toString() : null;
        if (string == null) {
            string = "";
        }
        String str = string;
        if (StringsKt.isBlank(str)) {
            return null;
        }
        List<String> listListOf = CollectionsKt.listOf((Object[]) new String[]{"yyyy/MM/dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy/MM/dd", "yyyy-MM-dd"});
        boolean zContains$default = StringsKt.contains$default((CharSequence) str, ':', false, 2, (Object) null);
        for (String str2 : listListOf) {
            if (zContains$default == StringsKt.contains$default((CharSequence) str2, ':', false, 2, (Object) null)) {
                try {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str2, Locale.US);
                    simpleDateFormat.setLenient(false);
                    Date date = simpleDateFormat.parse(string);
                    if (date != null) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        if (!zContains$default) {
                            calendar.set(11, 23);
                            calendar.set(12, 59);
                            calendar.set(13, 59);
                            calendar.set(14, 0);
                        }
                        return Long.valueOf(calendar.getTimeInMillis());
                    }
                } catch (Throwable unused) {
                    continue;
                }
            }
        }
        return null;
    }

    private final void startPanelCountdown(long targetMillis) {
        this.panelCountdownTargetMillis = targetMillis;
        if (this.panelCountdownRunnable == null) {
            this.panelCountdownRunnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView.startPanelCountdown.1
                @Override // java.lang.Runnable
                public void run() {
                    long jCoerceAtLeast = RangesKt.coerceAtLeast(AccountScreenView.this.panelCountdownTargetMillis - System.currentTimeMillis(), 0L);
                    long j = jCoerceAtLeast / 1000;
                    AccountScreenView.this.updatePanelCountdownViews(RangesKt.coerceAtLeast((int) (j / 86400), 0), RangesKt.coerceAtLeast((int) ((j % 86400) / 3600), 0), RangesKt.coerceAtLeast((int) ((j % 3600) / 60), 0), RangesKt.coerceAtLeast((int) (j % 60), 0));
                    if (jCoerceAtLeast > 0) {
                        AccountScreenView.this.mainHandler.postDelayed(this, 1000L);
                    }
                }
            };
        }
        Runnable runnable = this.panelCountdownRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
            this.mainHandler.post(runnable);
        }
    }

    private final void stopPanelCountdown() {
        this.panelCountdownTargetMillis = 0L;
        Runnable runnable = this.panelCountdownRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updatePanelCountdownViews(int days, int hours, int minutes, int seconds) {
        float f;
        String strPadStart = StringsKt.padStart(String.valueOf(days), 2, '0');
        TextView textView = this.panelCountdownDaysText;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownDaysText");
            textView = null;
        }
        textView.setText(strPadStart);
        TextView textView3 = this.panelCountdownDaysText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownDaysText");
            textView3 = null;
        }
        if (strPadStart.length() >= 5) {
            f = 18.0f;
        } else {
            f = strPadStart.length() == 4 ? 20.0f : 23.0f;
        }
        textView3.setTextSize(2, f);
        TextView textView4 = this.panelCountdownHoursText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownHoursText");
            textView4 = null;
        }
        textView4.setText(StringsKt.padStart(String.valueOf(hours), 2, '0'));
        TextView textView5 = this.panelCountdownMinutesText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownMinutesText");
            textView5 = null;
        }
        textView5.setText(StringsKt.padStart(String.valueOf(minutes), 2, '0'));
        TextView textView6 = this.panelCountdownSecondsText;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelCountdownSecondsText");
        } else {
            textView2 = textView6;
        }
        textView2.setText(StringsKt.padStart(String.valueOf(seconds), 2, '0'));
    }

    private final void switchPanelTab(PanelTab tab) {
        TextView textView;
        TextView textView2;
        TextView textView3;
        this.currentPanelTab = tab;
        LinearLayout linearLayout = this.panelTabSubscriptionContent;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabSubscriptionContent");
            linearLayout = null;
        }
        linearLayout.setVisibility(tab == PanelTab.SUBSCRIPTION ? 0 : 8);
        LinearLayout linearLayout2 = this.panelTabImportantContent;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabImportantContent");
            linearLayout2 = null;
        }
        linearLayout2.setVisibility(tab == PanelTab.IMPORTANT ? 0 : 8);
        LinearLayout linearLayout3 = this.panelTabRegularContent;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabRegularContent");
            linearLayout3 = null;
        }
        linearLayout3.setVisibility(tab == PanelTab.REGULAR ? 0 : 8);
        TextView textView4 = this.panelTabSubscriptionBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabSubscriptionBtn");
            textView = null;
        } else {
            textView = textView4;
        }
        applyPanelTabButtonStyle$default(this, textView, tab == PanelTab.SUBSCRIPTION, false, 4, null);
        TextView textView5 = this.panelTabImportantBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabImportantBtn");
            textView2 = null;
        } else {
            textView2 = textView5;
        }
        applyPanelTabButtonStyle$default(this, textView2, tab == PanelTab.IMPORTANT, false, 4, null);
        TextView textView6 = this.panelTabRegularBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("panelTabRegularBtn");
            textView3 = null;
        } else {
            textView3 = textView6;
        }
        applyPanelTabButtonStyle$default(this, textView3, tab == PanelTab.REGULAR, false, 4, null);
    }

    private final TextView makePanelTabButton(String label, final PanelTab tab) {
        final TextView textView = new TextView(this.ctx);
        textView.setText(label);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setPadding(m377dp(10), m377dp(9), m377dp(10), m377dp(9));
        textView.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda66
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makePanelTabButton$lambda$186(this.f$0, tab, textView, view, z);
            }
        });
        attachMenuShortcut(textView);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makePanelTabButton$lambda$186(AccountScreenView this$0, PanelTab tab, TextView view, View view2, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(tab, "$tab");
        Intrinsics.checkNotNullParameter(view, "$view");
        this$0.applyPanelTabButtonStyle(view, this$0.currentPanelTab == tab, z);
        if (z) {
            this$0.scrollToView(view);
        }
    }

    static /* synthetic */ void applyPanelTabButtonStyle$default(AccountScreenView accountScreenView, TextView textView, boolean z, boolean z2, int i, Object obj) {
        if ((i & 4) != 0) {
            z2 = textView.isFocused();
        }
        accountScreenView.applyPanelTabButtonStyle(textView, z, z2);
    }

    private final void applyPanelTabButtonStyle(TextView view, boolean selected, boolean focused) {
        int i = selected ? -676591 : focused ? 404235570 : 0;
        int i2 = -1;
        int i3 = ViewCompat.MEASURED_SIZE_MASK;
        if (selected && focused) {
            i3 = -1;
        } else if (!selected && focused) {
            i3 = 1157627903;
        }
        if (selected) {
            i2 = -16052459;
        } else if (!focused) {
            i2 = -5258536;
        }
        view.setBackground(roundedBg(i, i3, m377dp(1), dpF(999)));
        view.setTextColor(i2);
    }

    private final void renderPanelLinks(LinearLayout wrap, List<PanelMenuItem> items, LinkEmphasis emphasis) {
        String url;
        String str;
        wrap.removeAllViews();
        if (items.isEmpty()) {
            TextView textView = new TextView(this.ctx);
            int i = WhenMappings.$EnumSwitchMapping$1[emphasis.ordinal()];
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i != 4) {
                            throw new NoWhenBranchMatchedException();
                        }
                    }
                }
            }
            textView.setText(str);
            textView.setTextColor(-7429190);
            textView.setTextSize(13.0f);
            Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
            if (typefaceRegular == null) {
                typefaceRegular = textView.getTypeface();
            }
            textView.setTypeface(typefaceRegular);
            wrap.addView(textView);
            return;
        }
        int i2 = 0;
        for (Object obj : items) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            final PanelMenuItem panelMenuItem = (PanelMenuItem) obj;
            int i4 = WhenMappings.$EnumSwitchMapping$1[emphasis.ordinal()];
            if (i4 == 1) {
                url = panelMenuItem.getUrl();
                if (url == null) {
                    url = "شبکه اجتماعی";
                }
            } else if (i4 == 2) {
                String badge = panelMenuItem.getBadge();
                url = ((badge == null || StringsKt.isBlank(badge)) || Intrinsics.areEqual(panelMenuItem.getBadge(), "0")) ? "دسترسی سریع" : "تعداد: " + panelMenuItem.getBadge();
            } else if (i4 == 3) {
                String badge2 = panelMenuItem.getBadge();
                url = ((badge2 == null || StringsKt.isBlank(badge2)) || Intrinsics.areEqual(panelMenuItem.getBadge(), "0")) ? "بخش کاربری" : "تعداد: " + panelMenuItem.getBadge();
            } else {
                if (i4 != 4) {
                    throw new NoWhenBranchMatchedException();
                }
                url = "";
            }
            TextView textViewMakePanelLinkRow = makePanelLinkRow(panelMenuItem.getLabel(), url, emphasis);
            textViewMakePanelLinkRow.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda56
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    AccountScreenView.renderPanelLinks$lambda$190$lambda$188(this.f$0, panelMenuItem, view);
                }
            });
            TextView textView2 = textViewMakePanelLinkRow;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            if (i2 > 0) {
                layoutParams.topMargin = m377dp(10);
            }
            Unit unit = Unit.INSTANCE;
            wrap.addView(textView2, layoutParams);
            i2 = i3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void renderPanelLinks$lambda$190$lambda$188(AccountScreenView this$0, PanelMenuItem item, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        this$0.handlePanelAction(item);
    }

    private final TextView makePanelLinkRow(String title, String subtitle, final LinkEmphasis emphasis) {
        int i;
        GradientDrawable gradientDrawableRoundedBg;
        TextView textView = new TextView(this.ctx);
        textView.setText(title + "\n" + subtitle);
        int i2 = WhenMappings.$EnumSwitchMapping$1[emphasis.ordinal()];
        if (i2 == 1) {
            i = -2693902;
        } else if (i2 == 2) {
            i = -919812;
        } else if (i2 == 3) {
            i = -3614488;
        } else {
            if (i2 != 4) {
                throw new NoWhenBranchMatchedException();
            }
            i = -15935;
        }
        textView.setTextColor(i);
        textView.setTextSize(14.0f);
        textView.setLineSpacing(m377dp(2), 1.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setGravity(21);
        textView.setPadding(m377dp(10), m377dp(10), m377dp(10), m377dp(10));
        int i3 = WhenMappings.$EnumSwitchMapping$1[emphasis.ordinal()];
        if (i3 == 1) {
            gradientDrawableRoundedBg = roundedBg(252977196, 788529151, m377dp(1), dpF(12));
        } else if (i3 == 2) {
            gradientDrawableRoundedBg = roundedBg(337126449, 1156951313, m377dp(1), dpF(12));
        } else if (i3 == 3) {
            gradientDrawableRoundedBg = roundedBg(252646684, 721420287, m377dp(1), dpF(12));
        } else {
            if (i3 != 4) {
                throw new NoWhenBranchMatchedException();
            }
            gradientDrawableRoundedBg = roundedBg(672795403, 1442802282, m377dp(1), dpF(12));
        }
        textView.setBackground(gradientDrawableRoundedBg);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setClickable(true);
        textView.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda10
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makePanelLinkRow$lambda$192$lambda$191(emphasis, this, view, z);
            }
        });
        attachMenuShortcut(textView);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makePanelLinkRow$lambda$192$lambda$191(LinkEmphasis emphasis, AccountScreenView this$0, View view, boolean z) {
        GradientDrawable gradientDrawableRoundedBg;
        Intrinsics.checkNotNullParameter(emphasis, "$emphasis");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        int i = WhenMappings.$EnumSwitchMapping$1[emphasis.ordinal()];
        if (i == 1) {
            gradientDrawableRoundedBg = this$0.roundedBg(z ? 404960583 : 252977196, z ? 1728053247 : 788529151, this$0.m377dp(1), this$0.dpF(12));
        } else if (i == 2) {
            gradientDrawableRoundedBg = this$0.roundedBg(z ? 455028290 : 337126449, z ? -1711952623 : 1156951313, this$0.m377dp(1), this$0.dpF(12));
        } else if (i == 3) {
            gradientDrawableRoundedBg = this$0.roundedBg(z ? 371010105 : 252646684, z ? 1442840575 : 721420287, this$0.m377dp(1), this$0.dpF(12));
        } else {
            if (i != 4) {
                throw new NoWhenBranchMatchedException();
            }
            gradientDrawableRoundedBg = this$0.roundedBg(z ? 824053519 : 672795403, z ? -1996526998 : 1442802282, this$0.m377dp(1), this$0.dpF(12));
        }
        view.setBackground(gradientDrawableRoundedBg);
        if (z) {
            Intrinsics.checkNotNull(view);
            this$0.scrollToView(view);
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0033, code lost:
    
        if (r0.equals("purchase_subscription") == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x003c, code lost:
    
        if (r0.equals("instagram") == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0045, code lost:
    
        if (r0.equals("buy_subscription") != false) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0047, code lost:
    
        openPurchaseScreen();
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0052, code lost:
    
        if (r0.equals("logout") == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x005c, code lost:
    
        if (r0.equals("telegram") == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x005f, code lost:
    
        r4 = r4.getUrl();
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0063, code lost:
    
        if (r4 != null) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0065, code lost:
    
        r4 = "";
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x006f, code lost:
    
        if ((!kotlin.text.StringsKt.isBlank(r4)) == false) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0071, code lost:
    
        openExternalUrl(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0075, code lost:
    
        showShortMessage("لینک معتبر نیست");
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0082, code lost:
    
        if (r0.equals("logout_tv") == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0085, code lost:
    
        doLogout();
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0020, code lost:
    
        if (r0.equals(com.google.firebase.analytics.FirebaseAnalytics.Event.PURCHASE) == false) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x002a, code lost:
    
        if (r0.equals("logout_user") == false) goto L37;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void handlePanelAction(PanelMenuItem item) {
        String lowerCase = item.getKey().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        boolean z = true;
        switch (lowerCase.hashCode()) {
            case -1540097705:
                break;
            case -1360467711:
                break;
            case -1097329270:
                break;
            case -1008169418:
                break;
            case 28903346:
                break;
            case 1215997851:
                break;
            case 1729852768:
                break;
            case 1743324417:
                break;
            default:
                if (isPanelInternalRoute(item)) {
                    openAccountPanelPage(item.getLabel(), item.getKey());
                } else {
                    String url = item.getUrl();
                    if (url != null && !StringsKt.isBlank(url)) {
                        z = false;
                    }
                    if (!z) {
                        openExternalUrl(item.getUrl());
                    } else {
                        openAccountPanelPage(item.getLabel(), item.getKey());
                    }
                }
                break;
        }
    }

    private final boolean isPanelInternalRoute(PanelMenuItem item) {
        String lowerCase;
        String key = item.getKey();
        Locale US = Locale.US;
        Intrinsics.checkNotNullExpressionValue(US, "US");
        String lowerCase2 = key.toLowerCase(US);
        Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
        String screen = item.getScreen();
        if (screen != null) {
            Locale US2 = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US2, "US");
            lowerCase = screen.toLowerCase(US2);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        } else {
            lowerCase = null;
        }
        if (lowerCase == null) {
            lowerCase = "";
        }
        List<String> listListOf = CollectionsKt.listOf((Object[]) new String[]{"purchase_history", "payment_history", "support", "ticket", "watch_history", "history", "watchlist", "marked", "bookmark", "request", "lists", "play_settings", "playset", "edit_profile", Scopes.PROFILE, "comment"});
        if (!(listListOf instanceof Collection) || !listListOf.isEmpty()) {
            for (String str : listListOf) {
                if (StringsKt.contains$default((CharSequence) lowerCase2, (CharSequence) str, false, 2, (Object) null) || StringsKt.contains$default((CharSequence) lowerCase, (CharSequence) str, false, 2, (Object) null)) {
                    return true;
                }
            }
        }
        return false;
    }

    private final void openAccountPanelPage(String title, String key) {
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) AccountPanelPageActivity.class);
            intent.putExtra(AccountPanelPageActivity.EXTRA_TITLE, title);
            intent.putExtra(AccountPanelPageActivity.EXTRA_KEY, key);
            if (!(this.ctx instanceof MainActivity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
            showShortMessage("باز کردن صفحه «" + title + "» ممکن نشد.");
        }
    }

    private final void openPurchaseScreen() {
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) PurchaseActivity.class);
            if (!(this.ctx instanceof MainActivity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
            showShortMessage("باز کردن صفحه خرید اشتراک ممکن نشد.");
        }
    }

    private final void openExternalUrl(String url) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(StringsKt.trim((CharSequence) url).toString()));
            if (!(this.ctx instanceof MainActivity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
            showShortMessage("باز کردن لینک ممکن نشد.");
        }
    }

    private final void showShortMessage(String text) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(text, "عملیات انجام نشد"), 0).show();
    }

    private final void doLogin() {
        String string;
        String string2;
        hideKeyboard();
        if (this.loginRequestInFlight || this.registerRequestInFlight) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        FloatingInput floatingInput = this.loginIdentityInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        final String string3 = (text == null || (string2 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string3 == null) {
            string3 = "";
        }
        FloatingInput floatingInput2 = this.loginPasswordInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        String string4 = (text2 == null || (string = text2.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
        final String str = string4 != null ? string4 : "";
        if (StringsKt.isBlank(string3) || StringsKt.isBlank(str)) {
            setMessage("نام کاربری/ایمیل/شماره تماس و رمز عبور را وارد کنید");
            return;
        }
        setMessage(null);
        setLoginLoading(true);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda25
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.doLogin$lambda$198(this.f$0, string3, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doLogin$lambda$198(final AccountScreenView this$0, String identity, String password) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(identity, "$identity");
        Intrinsics.checkNotNullParameter(password, "$password");
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(HintConstants.AUTOFILL_HINT_USERNAME, identity);
            jSONObject.put(HintConstants.AUTOFILL_HINT_PASSWORD, password);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final LoginResult login = AccountParser.INSTANCE.parseLogin(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/login", "POST", null, null, string, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda60
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doLogin$lambda$198$lambda$196(this.f$0, login);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda61
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doLogin$lambda$198$lambda$197(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doLogin$lambda$198$lambda$196(AccountScreenView this$0, LoginResult parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.setLoginLoading(false);
        if (!parsed.getOk() || parsed.getSession() == null) {
            String message = parsed.getMessage();
            if (message == null) {
                message = "ورود ناموفق بود";
            }
            this$0.setMessage(message);
            return;
        }
        this$0.applySession(parsed.getSession(), "✅ با موفقیت وارد شدید");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doLogin$lambda$198$lambda$197(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.setLoginLoading(false);
        this$0.setMessage(this$0.readableError(e, "خطا در ورود"));
    }

    private final void doRegister() {
        String string;
        String string2;
        String string3;
        String string4;
        hideKeyboard();
        if (this.loginRequestInFlight || this.registerRequestInFlight) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        FloatingInput floatingInput = this.registerUsernameInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerUsernameInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        String string5 = (text == null || (string4 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string4).toString();
        final String str = string5 == null ? "" : string5;
        FloatingInput floatingInput2 = this.registerEmailInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerEmailInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        String string6 = (text2 == null || (string3 = text2.toString()) == null) ? null : StringsKt.trim((CharSequence) string3).toString();
        final String str2 = string6 == null ? "" : string6;
        FloatingInput floatingInput3 = this.registerPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerPasswordInput");
            floatingInput3 = null;
        }
        Editable text3 = floatingInput3.getEdit().getText();
        String string7 = (text3 == null || (string2 = text3.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        final String str3 = string7 == null ? "" : string7;
        FloatingInput floatingInput4 = this.registerMobileInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerMobileInput");
            floatingInput4 = null;
        }
        Editable text4 = floatingInput4.getEdit().getText();
        String string8 = (text4 == null || (string = text4.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
        final String str4 = string8 == null ? "" : string8;
        if (StringsKt.isBlank(str)) {
            setMessage("نام کاربری الزامی است");
            return;
        }
        if (!isValidEmail(str2)) {
            setMessage("ایمیل معتبر وارد کنید");
        } else {
            if (str3.length() < 6) {
                setMessage("رمز عبور باید حداقل ۶ کاراکتر باشد");
                return;
            }
            setMessage(null);
            setRegisterLoading(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda45
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doRegister$lambda$205(this.f$0, str, str2, str3, str4);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doRegister$lambda$205(final AccountScreenView this$0, final String username, String email, final String password, String mobile) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(username, "$username");
        Intrinsics.checkNotNullParameter(email, "$email");
        Intrinsics.checkNotNullParameter(password, "$password");
        Intrinsics.checkNotNullParameter(mobile, "$mobile");
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(HintConstants.AUTOFILL_HINT_USERNAME, username);
            jSONObject.put("email", email);
            jSONObject.put(HintConstants.AUTOFILL_HINT_PASSWORD, password);
            if (!StringsKt.isBlank(mobile)) {
                jSONObject.put(BuildConfig.FLAVOR, mobile);
                jSONObject.put(HintConstants.AUTOFILL_HINT_PHONE, mobile);
            }
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            String strSignedRequest$default = FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/register", "POST", null, null, string, false, 88, null);
            final LoginResult login = AccountParser.INSTANCE.parseLogin(strSignedRequest$default);
            if (login.getOk() && login.getSession() != null) {
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        AccountScreenView.doRegister$lambda$205$lambda$200(this.f$0, login);
                    }
                });
                return;
            }
            final SimpleResult simple = AccountParser.INSTANCE.parseSimple(strSignedRequest$default);
            if (!simple.getOk()) {
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        AccountScreenView.doRegister$lambda$205$lambda$201(this.f$0, simple);
                    }
                });
                return;
            }
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put(HintConstants.AUTOFILL_HINT_USERNAME, username);
            jSONObject2.put(HintConstants.AUTOFILL_HINT_PASSWORD, password);
            String string2 = jSONObject2.toString();
            Intrinsics.checkNotNullExpressionValue(string2, "toString(...)");
            final LoginResult login2 = AccountParser.INSTANCE.parseLogin(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/login", "POST", null, null, string2, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doRegister$lambda$205$lambda$203(this.f$0, login2, username, password, simple);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doRegister$lambda$205$lambda$204(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doRegister$lambda$205$lambda$200(AccountScreenView this$0, LoginResult asLogin) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(asLogin, "$asLogin");
        this$0.setRegisterLoading(false);
        Session session = asLogin.getSession();
        String message = asLogin.getMessage();
        if (message == null) {
            message = "✅ عضویت انجام شد";
        }
        this$0.applySession(session, message);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doRegister$lambda$205$lambda$201(AccountScreenView this$0, SimpleResult simple) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(simple, "$simple");
        this$0.setRegisterLoading(false);
        String message = simple.getMessage();
        if (message == null) {
            message = "ثبت نام ناموفق بود";
        }
        this$0.setMessage(message);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doRegister$lambda$205$lambda$203(AccountScreenView this$0, LoginResult loginParsed, String username, String password, SimpleResult simple) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(loginParsed, "$loginParsed");
        Intrinsics.checkNotNullParameter(username, "$username");
        Intrinsics.checkNotNullParameter(password, "$password");
        Intrinsics.checkNotNullParameter(simple, "$simple");
        this$0.setRegisterLoading(false);
        if (loginParsed.getOk() && loginParsed.getSession() != null) {
            Session session = loginParsed.getSession();
            String message = loginParsed.getMessage();
            if (message == null) {
                message = "✅ عضویت انجام شد";
            }
            this$0.applySession(session, message);
            return;
        }
        FloatingInput floatingInput = this$0.loginIdentityInput;
        FloatingInput floatingInput2 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
            floatingInput = null;
        }
        floatingInput.getEdit().setText(username);
        FloatingInput floatingInput3 = this$0.loginPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
        } else {
            floatingInput2 = floatingInput3;
        }
        floatingInput2.getEdit().setText(password);
        this$0.authTab = AuthTab.LOGIN;
        this$0.updateAuthTabUi();
        String message2 = simple.getMessage();
        if (message2 == null) {
            message2 = "عضویت انجام شد، حالا وارد شوید";
        }
        this$0.setMessage(message2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doRegister$lambda$205$lambda$204(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.setRegisterLoading(false);
        this$0.setMessage(this$0.readableError(e, "خطا در ثبت نام"));
    }

    private final void sendRecoveryEmail(boolean isResend) {
        String string;
        hideKeyboard();
        if (this.recoveryEmailRequestInFlight || this.verifyCodeRequestInFlight) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        FloatingInput floatingInput = this.recoverEmailInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        final String string2 = (text == null || (string = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
        if (string2 == null) {
            string2 = "";
        }
        if (!isValidEmail(string2)) {
            setMessage("ایمیل معتبر وارد کنید");
            return;
        }
        setMessage(null);
        setRecoveryEmailLoading(true, isResend ? RecoveryLoadingTarget.RESEND : RecoveryLoadingTarget.SEND);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda46
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.sendRecoveryEmail$lambda$209(this.f$0, string2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void sendRecoveryEmail$lambda$209(final AccountScreenView this$0, String email) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(email, "$email");
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("email", email);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final SimpleResult simple = AccountParser.INSTANCE.parseSimple(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/forgetPass", "POST", null, null, string, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda44
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.sendRecoveryEmail$lambda$209$lambda$207(this.f$0, simple);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda55
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.sendRecoveryEmail$lambda$209$lambda$208(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void sendRecoveryEmail$lambda$209$lambda$207(AccountScreenView this$0, SimpleResult parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.setRecoveryEmailLoading(false, RecoveryLoadingTarget.NONE);
        if (!parsed.getOk()) {
            String message = parsed.getMessage();
            if (message == null) {
                message = "ارسال ایمیل بازیابی ناموفق بود";
            }
            this$0.setMessage(message);
            return;
        }
        this$0.recoveryCodeSent = true;
        this$0.startRecoveryTimer(120);
        if (this$0.forgotStep == ForgotStep.ENTER_EMAIL) {
            FloatingInput floatingInput = this$0.recoverCodeInput;
            if (floatingInput == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
                floatingInput = null;
            }
            floatingInput.getEdit().setText("");
            this$0.setForgotStep(ForgotStep.VERIFY_CODE);
            if (!this$0.isTouchDevice && this$0.guestScreen == GuestScreen.FORGOT) {
                this$0.focusForgot();
            }
        }
        this$0.setMessage(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void sendRecoveryEmail$lambda$209$lambda$208(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.setRecoveryEmailLoading(false, RecoveryLoadingTarget.NONE);
        this$0.setMessage(this$0.readableError(e, "خطا در ارسال کد"));
    }

    private final void verifyRecoveryCode() {
        String string;
        String string2;
        hideKeyboard();
        if (this.verifyCodeRequestInFlight || this.recoveryEmailRequestInFlight) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        FloatingInput floatingInput = this.recoverEmailInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        final String string3 = (text == null || (string2 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string3 == null) {
            string3 = "";
        }
        FloatingInput floatingInput2 = this.recoverCodeInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        String string4 = (text2 == null || (string = text2.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
        final String str = string4 != null ? string4 : "";
        if (!isValidEmail(string3)) {
            setMessage("ایمیل معتبر وارد کنید");
        } else {
            if (!new Regex("^[0-9]{5}$").matches(str)) {
                setMessage("کد تایید باید ۵ رقمی باشد");
                return;
            }
            setMessage(null);
            setVerifyCodeLoading(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.verifyRecoveryCode$lambda$213(this.f$0, string3, str);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void verifyRecoveryCode$lambda$213(final AccountScreenView this$0, String email, final String code) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(email, "$email");
        Intrinsics.checkNotNullParameter(code, "$code");
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("email", email);
            Integer intOrNull = StringsKt.toIntOrNull(code);
            jSONObject.put("code", intOrNull != null ? intOrNull.intValue() : 0);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final SimpleResult simple = AccountParser.INSTANCE.parseSimple(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/confrimCode", "POST", null, null, string, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda68
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.verifyRecoveryCode$lambda$213$lambda$211(this.f$0, simple, code);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda69
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.verifyRecoveryCode$lambda$213$lambda$212(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void verifyRecoveryCode$lambda$213$lambda$211(AccountScreenView this$0, SimpleResult parsed, String code) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        Intrinsics.checkNotNullParameter(code, "$code");
        this$0.setVerifyCodeLoading(false);
        if (!parsed.getOk()) {
            String message = parsed.getMessage();
            if (message == null) {
                message = "کد تایید نامعتبر است";
            }
            this$0.setMessage(message);
            return;
        }
        this$0.verifiedRecoveryCode = code;
        this$0.stopRecoveryTimer();
        this$0.recoveryCodeSent = false;
        this$0.recoverySecondsLeft = 0;
        FloatingInput floatingInput = this$0.recoverPasswordInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput = null;
        }
        floatingInput.getEdit().setText("");
        FloatingInput floatingInput2 = this$0.recoverRepeatPasswordInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput2 = null;
        }
        floatingInput2.getEdit().setText("");
        this$0.setForgotStep(ForgotStep.SET_PASSWORD);
        if (!this$0.isTouchDevice && this$0.guestScreen == GuestScreen.FORGOT) {
            this$0.focusForgot();
        }
        this$0.setMessage(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void verifyRecoveryCode$lambda$213$lambda$212(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.setVerifyCodeLoading(false);
        this$0.setMessage(this$0.readableError(e, "خطا در تایید کد"));
    }

    private final void applyNewPassword() {
        String string;
        String string2;
        String string3;
        hideKeyboard();
        if (this.applyNewPasswordRequestInFlight || this.recoveryEmailRequestInFlight || this.verifyCodeRequestInFlight) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        FloatingInput floatingInput = this.recoverEmailInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        final String string4 = (text == null || (string3 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string3).toString();
        if (string4 == null) {
            string4 = "";
        }
        FloatingInput floatingInput2 = this.recoverPasswordInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        final String string5 = (text2 == null || (string2 = text2.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string5 == null) {
            string5 = "";
        }
        FloatingInput floatingInput3 = this.recoverRepeatPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput3 = null;
        }
        Editable text3 = floatingInput3.getEdit().getText();
        String string6 = (text3 == null || (string = text3.toString()) == null) ? null : StringsKt.trim((CharSequence) string).toString();
        String str = string6 != null ? string6 : "";
        final String string7 = StringsKt.trim((CharSequence) this.verifiedRecoveryCode).toString();
        if (this.forgotStep != ForgotStep.SET_PASSWORD) {
            setMessage("ابتدا کد بازیابی را تایید کنید");
            return;
        }
        if (!isValidEmail(string4)) {
            setMessage("ایمیل معتبر وارد کنید");
            return;
        }
        if (!new Regex("^[0-9]{5}$").matches(string7)) {
            setMessage("کد تایید معتبر نیست؛ دوباره تایید کنید");
            return;
        }
        if (string5.length() < 6) {
            setMessage("رمز عبور جدید باید حداقل ۶ کاراکتر باشد");
        } else {
            if (!Intrinsics.areEqual(string5, str)) {
                setMessage("رمز عبور و تکرار آن یکسان نیست");
                return;
            }
            setMessage(null);
            setApplyNewPasswordLoading(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda59
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.applyNewPassword$lambda$217(string7, this, string4, string5);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyNewPassword$lambda$217(String code, final AccountScreenView this$0, final String email, final String password) {
        Intrinsics.checkNotNullParameter(code, "$code");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(email, "$email");
        Intrinsics.checkNotNullParameter(password, "$password");
        try {
            Integer intOrNull = StringsKt.toIntOrNull(code);
            int iIntValue = intOrNull != null ? intOrNull.intValue() : 0;
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("email", email);
            jSONObject.put("code", iIntValue);
            jSONObject.put(HintConstants.AUTOFILL_HINT_PASSWORD, password);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final SimpleResult simple = AccountParser.INSTANCE.parseSimple(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/changePass", "POST", null, null, string, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda23
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.applyNewPassword$lambda$217$lambda$215(this.f$0, simple, email, password);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda24
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.applyNewPassword$lambda$217$lambda$216(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyNewPassword$lambda$217$lambda$215(AccountScreenView this$0, SimpleResult changeParsed, String email, String password) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(changeParsed, "$changeParsed");
        Intrinsics.checkNotNullParameter(email, "$email");
        Intrinsics.checkNotNullParameter(password, "$password");
        this$0.setApplyNewPasswordLoading(false);
        if (!changeParsed.getOk()) {
            String message = changeParsed.getMessage();
            if (message == null) {
                message = "تغییر رمز ناموفق بود";
            }
            this$0.setMessage(message);
            return;
        }
        this$0.resetForgotFlow(true);
        FloatingInput floatingInput = this$0.recoverCodeInput;
        FloatingInput floatingInput2 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput = null;
        }
        floatingInput.getEdit().setText("");
        FloatingInput floatingInput3 = this$0.recoverPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput3 = null;
        }
        floatingInput3.getEdit().setText("");
        FloatingInput floatingInput4 = this$0.recoverRepeatPasswordInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput4 = null;
        }
        floatingInput4.getEdit().setText("");
        FloatingInput floatingInput5 = this$0.loginIdentityInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
            floatingInput5 = null;
        }
        floatingInput5.getEdit().setText(email);
        FloatingInput floatingInput6 = this$0.loginPasswordInput;
        if (floatingInput6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginPasswordInput");
        } else {
            floatingInput2 = floatingInput6;
        }
        floatingInput2.getEdit().setText(password);
        this$0.setGuestScreen(GuestScreen.AUTH);
        this$0.authTab = AuthTab.LOGIN;
        this$0.updateAuthTabUi();
        String message2 = changeParsed.getMessage();
        if (message2 == null) {
            message2 = "رمز عبور با موفقیت تغییر کرد";
        }
        this$0.setMessage(message2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyNewPassword$lambda$217$lambda$216(AccountScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.setApplyNewPasswordLoading(false);
        this$0.setMessage(this$0.readableError(e, "خطا در تغییر رمز عبور"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void loadQr() {
        if (this.isLoggedIn || this.guestScreen != GuestScreen.f342QR) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            setMessage("آدرس سرور در دسترس نیست");
            return;
        }
        this.qrLoading = true;
        TextView textView = this.qrStatus;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
            textView = null;
        }
        textView.setText("در حال دریافت QR...");
        updateQrUi();
        stopQrPolling();
        stopQrCountdown();
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda48
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.loadQr$lambda$220(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadQr$lambda$220(final AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final QrData qr = AccountParser.INSTANCE.parseQr(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/Qrdata", "GET", null, null, null, false, 120, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.loadQr$lambda$220$lambda$218(this.f$0, qr);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.loadQr$lambda$220$lambda$219(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadQr$lambda$220$lambda$218(AccountScreenView this$0, QrData qrData) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.qrLoading = false;
        TextView textView = null;
        if (qrData == null || StringsKt.isBlank(qrData.getUrl())) {
            this$0.qrUrl = "";
            this$0.qrCode = "";
            this$0.qrToken = "";
            this$0.qrSecondsLeft = 0;
            TextView textView2 = this$0.qrStatus;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
            } else {
                textView = textView2;
            }
            textView.setText("دریافت QR انجام نشد");
            this$0.updateQrUi();
            return;
        }
        this$0.qrUrl = qrData.getUrl();
        this$0.qrCode = qrData.getCode();
        this$0.qrToken = qrData.getToken();
        this$0.qrSecondsLeft = Math.max(1, qrData.getExpiresIn());
        TextView textView3 = this$0.qrStatus;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
        } else {
            textView = textView3;
        }
        textView.setText("");
        this$0.updateQrUi();
        if (this$0.guestScreen != GuestScreen.f342QR || this$0.isLoggedIn) {
            return;
        }
        this$0.startQrCountdown();
        this$0.startQrPolling();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadQr$lambda$220$lambda$219(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.qrLoading = false;
        this$0.qrUrl = "";
        this$0.qrCode = "";
        this$0.qrToken = "";
        this$0.qrSecondsLeft = 0;
        TextView textView = this$0.qrStatus;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
            textView = null;
        }
        textView.setText("خطا در دریافت QR");
        this$0.updateQrUi();
    }

    private final void startQrCountdown() {
        if (this.guestScreen != GuestScreen.f342QR || this.isLoggedIn) {
            return;
        }
        stopQrCountdown();
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startQrCountdown$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.isLoggedIn || this.this$0.guestScreen != AccountScreenView.GuestScreen.f342QR) {
                    this.this$0.stopQrCountdown();
                    return;
                }
                TextView textView = null;
                if (this.this$0.qrSecondsLeft <= 0) {
                    TextView textView2 = this.this$0.qrTimer;
                    if (textView2 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("qrTimer");
                    } else {
                        textView = textView2;
                    }
                    textView.setText("کد منقضی شد؛ دریافت کد جدید...");
                    this.this$0.stopQrCountdown();
                    this.this$0.loadQr();
                    return;
                }
                TextView textView3 = this.this$0.qrTimer;
                if (textView3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrTimer");
                } else {
                    textView = textView3;
                }
                textView.setText("اعتبار QR: " + this.this$0.qrSecondsLeft + " ثانیه");
                AccountScreenView accountScreenView = this.this$0;
                accountScreenView.qrSecondsLeft--;
                this.this$0.mainHandler.postDelayed(this, 1000L);
            }
        };
        this.qrCountdownRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void stopQrCountdown() {
        Runnable runnable = this.qrCountdownRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.qrCountdownRunnable = null;
    }

    private final void startQrPolling() {
        if (this.guestScreen == GuestScreen.f342QR && !this.isLoggedIn && this.qrPollRunnable == null) {
            AccountScreenView$startQrPolling$runnable$1 accountScreenView$startQrPolling$runnable$1 = new AccountScreenView$startQrPolling$runnable$1(this);
            this.qrPollRunnable = accountScreenView$startQrPolling$runnable$1;
            this.mainHandler.post(accountScreenView$startQrPolling$runnable$1);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void stopQrPolling() {
        Runnable runnable = this.qrPollRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.qrPollRunnable = null;
        this.qrPollInFlight = false;
    }

    private final void updateQrUi() {
        TextView textView = null;
        if (this.qrLoading) {
            ProgressBar progressBar = this.qrProgress;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrProgress");
                progressBar = null;
            }
            progressBar.setVisibility(0);
            ImageView imageView = this.qrImage;
            if (imageView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrImage");
                imageView = null;
            }
            imageView.setVisibility(4);
            TextView textView2 = this.qrTimer;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrTimer");
                textView2 = null;
            }
            textView2.setText("");
            TextView textView3 = this.qrUrlValue;
            if (textView3 != null) {
                if (textView3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrUrlValue");
                    textView3 = null;
                }
                textView3.setText("-");
            }
            TextView textView4 = this.qrCodeValue;
            if (textView4 != null) {
                if (textView4 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrCodeValue");
                } else {
                    textView = textView4;
                }
                textView.setText("-");
                return;
            }
            return;
        }
        ProgressBar progressBar2 = this.qrProgress;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrProgress");
            progressBar2 = null;
        }
        progressBar2.setVisibility(8);
        if (StringsKt.isBlank(this.qrUrl)) {
            ImageView imageView2 = this.qrImage;
            if (imageView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrImage");
                imageView2 = null;
            }
            imageView2.setVisibility(4);
            TextView textView5 = this.qrTimer;
            if (textView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrTimer");
                textView5 = null;
            }
            textView5.setText("");
            TextView textView6 = this.qrUrlValue;
            if (textView6 != null) {
                if (textView6 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrUrlValue");
                    textView6 = null;
                }
                textView6.setText("-");
            }
            TextView textView7 = this.qrCodeValue;
            if (textView7 != null) {
                if (textView7 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrCodeValue");
                } else {
                    textView = textView7;
                }
                textView.setText("-");
                return;
            }
            return;
        }
        ImageView imageView3 = this.qrImage;
        if (imageView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrImage");
            imageView3 = null;
        }
        imageView3.setVisibility(0);
        Bitmap bitmapGenerateQr = generateQr(this.qrUrl, m377dp(182), true);
        if (bitmapGenerateQr != null) {
            ImageView imageView4 = this.qrImage;
            if (imageView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrImage");
                imageView4 = null;
            }
            imageView4.setImageBitmap(bitmapGenerateQr);
        }
        TextView textView8 = this.qrUrlValue;
        if (textView8 != null) {
            if (textView8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrUrlValue");
                textView8 = null;
            }
            textView8.setText(this.qrUrl);
        }
        TextView textView9 = this.qrCodeValue;
        if (textView9 != null) {
            if (textView9 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrCodeValue");
            } else {
                textView = textView9;
            }
            String str = this.qrCode;
            textView.setText(StringsKt.isBlank(str) ? "-" : str);
        }
    }

    private final void startRecoveryTimer(int seconds) {
        stopRecoveryTimer();
        this.recoverySecondsLeft = Math.max(0, seconds);
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startRecoveryTimer$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                this.this$0.updateRecoveryResendUi();
                if (this.this$0.recoverySecondsLeft <= 0) {
                    return;
                }
                AccountScreenView accountScreenView = this.this$0;
                accountScreenView.recoverySecondsLeft--;
                this.this$0.mainHandler.postDelayed(this, 1000L);
            }
        };
        this.recoveryRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopRecoveryTimer() {
        Runnable runnable = this.recoveryRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.recoveryRunnable = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateRecoveryResendUi() {
        String str;
        boolean z = this.recoveryCodeSent && this.recoverySecondsLeft <= 0 && !this.recoveryEmailRequestInFlight && !this.verifyCodeRequestInFlight;
        TextView textView = this.resendRecoverMailBtn;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView = null;
        }
        textView.setEnabled(z);
        TextView textView3 = this.resendRecoverMailBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView3 = null;
        }
        textView3.setFocusable(z && !this.isTouchDevice);
        TextView textView4 = this.resendRecoverMailBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView4 = null;
        }
        textView4.setFocusableInTouchMode(z && !this.isTouchDevice);
        TextView textView5 = this.resendRecoverMailBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView5 = null;
        }
        textView5.setAlpha(z ? 1.0f : 0.55f);
        if (!this.recoveryEmailRequestInFlight || this.recoveryLoadingTarget != RecoveryLoadingTarget.RESEND) {
            TextView textView6 = this.resendRecoverMailBtn;
            if (textView6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
                textView6 = null;
            }
            int i = this.recoverySecondsLeft;
            if (i > 0) {
                str = "ارسال مجدد (" + i + ")";
            }
            textView6.setText(str);
        }
        TextView textView7 = this.resendRecoverMailBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView7 = null;
        }
        ButtonStyle buttonStyle = ButtonStyle.DOWNLOAD_BOX;
        TextView textView8 = this.resendRecoverMailBtn;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
        } else {
            textView2 = textView8;
        }
        applyButtonStyle(textView7, buttonStyle, textView2.isFocused(), z);
    }

    static /* synthetic */ void resetForgotFlow$default(AccountScreenView accountScreenView, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = false;
        }
        accountScreenView.resetForgotFlow(z);
    }

    private final void resetForgotFlow(boolean keepEmail) {
        setRecoveryEmailLoading(false, RecoveryLoadingTarget.NONE);
        setVerifyCodeLoading(false);
        setApplyNewPasswordLoading(false);
        stopRecoveryTimer();
        this.recoveryCodeSent = false;
        this.recoverySecondsLeft = 0;
        this.verifiedRecoveryCode = "";
        FloatingInput floatingInput = null;
        if (!keepEmail) {
            FloatingInput floatingInput2 = this.recoverEmailInput;
            if (floatingInput2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
                floatingInput2 = null;
            }
            floatingInput2.getEdit().setText("");
        }
        FloatingInput floatingInput3 = this.recoverCodeInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput3 = null;
        }
        floatingInput3.getEdit().setText("");
        FloatingInput floatingInput4 = this.recoverPasswordInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput4 = null;
        }
        floatingInput4.getEdit().setText("");
        FloatingInput floatingInput5 = this.recoverRepeatPasswordInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
        } else {
            floatingInput = floatingInput5;
        }
        floatingInput.getEdit().setText("");
        setForgotStep(ForgotStep.ENTER_EMAIL);
        updateRecoveryResendUi();
    }

    private final void setRecoveryEmailLoading(boolean loading, RecoveryLoadingTarget target) {
        this.recoveryEmailRequestInFlight = loading;
        this.recoveryLoadingTarget = loading ? target : RecoveryLoadingTarget.NONE;
        TextView textView = this.sendRecoverMailBtn;
        if (textView != null) {
            TextView textView2 = null;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView = null;
            }
            textView.setEnabled(!loading);
            TextView textView3 = this.sendRecoverMailBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView3 = null;
            }
            textView3.setClickable(!loading);
            TextView textView4 = this.sendRecoverMailBtn;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView4 = null;
            }
            boolean z = false;
            textView4.setFocusable((loading || this.isTouchDevice) ? false : true);
            TextView textView5 = this.sendRecoverMailBtn;
            if (textView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView5 = null;
            }
            if (!loading && !this.isTouchDevice) {
                z = true;
            }
            textView5.setFocusableInTouchMode(z);
            TextView textView6 = this.sendRecoverMailBtn;
            if (textView6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView6 = null;
            }
            ButtonStyle buttonStyle = ButtonStyle.PRIMARY;
            TextView textView7 = this.sendRecoverMailBtn;
            if (textView7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
            } else {
                textView2 = textView7;
            }
            applyButtonStyle(textView6, buttonStyle, textView2.isFocused(), !loading);
        }
        if (loading && target != RecoveryLoadingTarget.NONE) {
            startRecoverySendSpinner(target);
        } else {
            stopRecoverySendSpinner();
        }
        if (this.resendRecoverMailBtn != null) {
            updateRecoveryResendUi();
        }
    }

    private final void setLoginLoading(boolean loading) {
        this.loginRequestInFlight = loading;
        TextView textView = this.loginBtn;
        if (textView == null) {
            return;
        }
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.loginBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView3 = null;
        }
        textView3.setClickable(!loading);
        TextView textView4 = this.loginBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView4 = null;
        }
        boolean z = false;
        textView4.setFocusable((loading || this.isTouchDevice) ? false : true);
        TextView textView5 = this.loginBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView5 = null;
        }
        if (!loading && !this.isTouchDevice) {
            z = true;
        }
        textView5.setFocusableInTouchMode(z);
        TextView textView6 = this.loginBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            textView6 = null;
        }
        ButtonStyle buttonStyle = ButtonStyle.PRIMARY;
        TextView textView7 = this.loginBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
        } else {
            textView2 = textView7;
        }
        applyButtonStyle(textView6, buttonStyle, textView2.isFocused(), !loading);
        if (loading) {
            startLoginSpinner();
        } else {
            stopLoginSpinner();
        }
    }

    private final void startLoginSpinner() {
        stopLoginSpinner();
        this.loginSpinnerFrame = 0;
        final String[] strArr = {"◐", "◓", "◑", "◒"};
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startLoginSpinner$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                if (!this.this$0.loginRequestInFlight || this.this$0.loginBtn == null) {
                    return;
                }
                TextView textView = this.this$0.loginBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
                    textView = null;
                }
                textView.setText(strArr[this.this$0.loginSpinnerFrame % strArr.length]);
                this.this$0.loginSpinnerFrame++;
                this.this$0.mainHandler.postDelayed(this, 120L);
            }
        };
        this.loginSpinnerRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopLoginSpinner() {
        Runnable runnable = this.loginSpinnerRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        TextView textView = null;
        this.loginSpinnerRunnable = null;
        TextView textView2 = this.loginBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("loginBtn");
            } else {
                textView = textView2;
            }
            textView.setText("ورود به حساب");
        }
    }

    private final void setRegisterLoading(boolean loading) {
        this.registerRequestInFlight = loading;
        TextView textView = this.registerBtn;
        if (textView == null) {
            return;
        }
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.registerBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView3 = null;
        }
        textView3.setClickable(!loading);
        TextView textView4 = this.registerBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView4 = null;
        }
        boolean z = false;
        textView4.setFocusable((loading || this.isTouchDevice) ? false : true);
        TextView textView5 = this.registerBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView5 = null;
        }
        if (!loading && !this.isTouchDevice) {
            z = true;
        }
        textView5.setFocusableInTouchMode(z);
        TextView textView6 = this.registerBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            textView6 = null;
        }
        ButtonStyle buttonStyle = ButtonStyle.PRIMARY;
        TextView textView7 = this.registerBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
        } else {
            textView2 = textView7;
        }
        applyButtonStyle(textView6, buttonStyle, textView2.isFocused(), !loading);
        if (loading) {
            startRegisterSpinner();
        } else {
            stopRegisterSpinner();
        }
    }

    private final void startRegisterSpinner() {
        stopRegisterSpinner();
        this.registerSpinnerFrame = 0;
        final String[] strArr = {"◐", "◓", "◑", "◒"};
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startRegisterSpinner$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                if (!this.this$0.registerRequestInFlight || this.this$0.registerBtn == null) {
                    return;
                }
                TextView textView = this.this$0.registerBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
                    textView = null;
                }
                textView.setText(strArr[this.this$0.registerSpinnerFrame % strArr.length]);
                this.this$0.registerSpinnerFrame++;
                this.this$0.mainHandler.postDelayed(this, 120L);
            }
        };
        this.registerSpinnerRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopRegisterSpinner() {
        Runnable runnable = this.registerSpinnerRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        TextView textView = null;
        this.registerSpinnerRunnable = null;
        TextView textView2 = this.registerBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerBtn");
            } else {
                textView = textView2;
            }
            textView.setText("ساخت حساب");
        }
    }

    private final void setVerifyCodeLoading(boolean loading) {
        this.verifyCodeRequestInFlight = loading;
        TextView textView = this.verifyRecoverCodeBtn;
        if (textView == null) {
            return;
        }
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.verifyRecoverCodeBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView3 = null;
        }
        textView3.setClickable(!loading);
        TextView textView4 = this.verifyRecoverCodeBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView4 = null;
        }
        boolean z = false;
        textView4.setFocusable((loading || this.isTouchDevice) ? false : true);
        TextView textView5 = this.verifyRecoverCodeBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView5 = null;
        }
        if (!loading && !this.isTouchDevice) {
            z = true;
        }
        textView5.setFocusableInTouchMode(z);
        TextView textView6 = this.verifyRecoverCodeBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView6 = null;
        }
        ButtonStyle buttonStyle = ButtonStyle.PRIMARY;
        TextView textView7 = this.verifyRecoverCodeBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
        } else {
            textView2 = textView7;
        }
        applyButtonStyle(textView6, buttonStyle, textView2.isFocused(), !loading);
        if (loading) {
            startVerifyCodeSpinner();
        } else {
            stopVerifyCodeSpinner();
        }
        updateRecoveryResendUi();
    }

    private final void setApplyNewPasswordLoading(boolean loading) {
        this.applyNewPasswordRequestInFlight = loading;
        TextView textView = this.applyNewPasswordBtn;
        if (textView == null) {
            return;
        }
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.applyNewPasswordBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView3 = null;
        }
        textView3.setClickable(!loading);
        TextView textView4 = this.applyNewPasswordBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView4 = null;
        }
        boolean z = false;
        textView4.setFocusable((loading || this.isTouchDevice) ? false : true);
        TextView textView5 = this.applyNewPasswordBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView5 = null;
        }
        if (!loading && !this.isTouchDevice) {
            z = true;
        }
        textView5.setFocusableInTouchMode(z);
        TextView textView6 = this.applyNewPasswordBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView6 = null;
        }
        ButtonStyle buttonStyle = ButtonStyle.PRIMARY;
        TextView textView7 = this.applyNewPasswordBtn;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
        } else {
            textView2 = textView7;
        }
        applyButtonStyle(textView6, buttonStyle, textView2.isFocused(), !loading);
        if (loading) {
            startApplyNewPasswordSpinner();
        } else {
            stopApplyNewPasswordSpinner();
        }
    }

    private final void startRecoverySendSpinner(final RecoveryLoadingTarget target) {
        stopRecoverySendSpinner();
        this.recoverySendSpinnerFrame = 0;
        final String[] strArr = {"◐", "◓", "◑", "◒"};
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startRecoverySendSpinner$runnable$1

            /* JADX INFO: compiled from: AccountScreenView.kt */
            @Metadata(m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
            public /* synthetic */ class WhenMappings {
                public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                static {
                    int[] iArr = new int[AccountScreenView.RecoveryLoadingTarget.values().length];
                    try {
                        iArr[AccountScreenView.RecoveryLoadingTarget.SEND.ordinal()] = 1;
                    } catch (NoSuchFieldError unused) {
                    }
                    try {
                        iArr[AccountScreenView.RecoveryLoadingTarget.RESEND.ordinal()] = 2;
                    } catch (NoSuchFieldError unused2) {
                    }
                    try {
                        iArr[AccountScreenView.RecoveryLoadingTarget.NONE.ordinal()] = 3;
                    } catch (NoSuchFieldError unused3) {
                    }
                    $EnumSwitchMapping$0 = iArr;
                }
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.recoveryEmailRequestInFlight) {
                    String str = strArr[this.this$0.recoverySendSpinnerFrame % strArr.length];
                    int i = WhenMappings.$EnumSwitchMapping$0[target.ordinal()];
                    TextView textView = null;
                    if (i != 1) {
                        if (i == 2 && this.this$0.resendRecoverMailBtn != null) {
                            TextView textView2 = this.this$0.resendRecoverMailBtn;
                            if (textView2 == null) {
                                Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
                            } else {
                                textView = textView2;
                            }
                            textView.setText(str + " در حال ارسال کد جدید...");
                        }
                    } else if (this.this$0.sendRecoverMailBtn != null) {
                        TextView textView3 = this.this$0.sendRecoverMailBtn;
                        if (textView3 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                        } else {
                            textView = textView3;
                        }
                        textView.setText(str + " در حال ارسال کد...");
                    }
                    this.this$0.recoverySendSpinnerFrame++;
                    this.this$0.mainHandler.postDelayed(this, 120L);
                }
            }
        };
        this.recoverySendSpinnerRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopRecoverySendSpinner() {
        Runnable runnable = this.recoverySendSpinnerRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        TextView textView = null;
        this.recoverySendSpinnerRunnable = null;
        TextView textView2 = this.sendRecoverMailBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
                textView2 = null;
            }
            textView2.setText("ارسال ایمیل بازیابی");
        }
        TextView textView3 = this.resendRecoverMailBtn;
        if (textView3 != null) {
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            } else {
                textView = textView3;
            }
            textView.setText("ارسال مجدد");
        }
    }

    private final void startVerifyCodeSpinner() {
        stopVerifyCodeSpinner();
        this.verifyCodeSpinnerFrame = 0;
        final String[] strArr = {"◐", "◓", "◑", "◒"};
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startVerifyCodeSpinner$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                if (!this.this$0.verifyCodeRequestInFlight || this.this$0.verifyRecoverCodeBtn == null) {
                    return;
                }
                TextView textView = this.this$0.verifyRecoverCodeBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
                    textView = null;
                }
                textView.setText(strArr[this.this$0.verifyCodeSpinnerFrame % strArr.length] + " در حال تایید کد...");
                this.this$0.verifyCodeSpinnerFrame++;
                this.this$0.mainHandler.postDelayed(this, 120L);
            }
        };
        this.verifyCodeSpinnerRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopVerifyCodeSpinner() {
        Runnable runnable = this.verifyCodeSpinnerRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        TextView textView = null;
        this.verifyCodeSpinnerRunnable = null;
        TextView textView2 = this.verifyRecoverCodeBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            } else {
                textView = textView2;
            }
            textView.setText("تایید کد");
        }
    }

    private final void startApplyNewPasswordSpinner() {
        stopApplyNewPasswordSpinner();
        this.applyNewPasswordSpinnerFrame = 0;
        final String[] strArr = {"◐", "◓", "◑", "◒"};
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startApplyNewPasswordSpinner$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                if (!this.this$0.applyNewPasswordRequestInFlight || this.this$0.applyNewPasswordBtn == null) {
                    return;
                }
                TextView textView = this.this$0.applyNewPasswordBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
                    textView = null;
                }
                textView.setText(strArr[this.this$0.applyNewPasswordSpinnerFrame % strArr.length] + " در حال تغییر رمز...");
                this.this$0.applyNewPasswordSpinnerFrame++;
                this.this$0.mainHandler.postDelayed(this, 120L);
            }
        };
        this.applyNewPasswordSpinnerRunnable = runnable;
        this.mainHandler.post(runnable);
    }

    private final void stopApplyNewPasswordSpinner() {
        Runnable runnable = this.applyNewPasswordSpinnerRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        TextView textView = null;
        this.applyNewPasswordSpinnerRunnable = null;
        TextView textView2 = this.applyNewPasswordBtn;
        if (textView2 != null) {
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            } else {
                textView = textView2;
            }
            textView.setText("تغییر رمز عبور");
        }
    }

    private final void setForgotStep(ForgotStep step) {
        this.forgotStep = step;
        updateForgotStepUi();
    }

    private final void updateForgotStepUi() {
        boolean z = true;
        boolean z2 = this.forgotStep == ForgotStep.ENTER_EMAIL;
        boolean z3 = this.forgotStep == ForgotStep.VERIFY_CODE;
        boolean z4 = this.forgotStep == ForgotStep.SET_PASSWORD;
        FloatingInput floatingInput = this.recoverEmailInput;
        TextView textView = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput = null;
        }
        floatingInput.getRoot().setVisibility(0);
        FloatingInput floatingInput2 = this.recoverEmailInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput2 = null;
        }
        floatingInput2.getEdit().setEnabled(!z4);
        FloatingInput floatingInput3 = this.recoverEmailInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput3 = null;
        }
        floatingInput3.getEdit().setAlpha(z4 ? 0.75f : 1.0f);
        FloatingInput floatingInput4 = this.recoverEmailInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
            floatingInput4 = null;
        }
        floatingInput4.getLeadingIcon().setAlpha(z4 ? 0.7f : 0.92f);
        TextView textView2 = this.sendRecoverMailBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sendRecoverMailBtn");
            textView2 = null;
        }
        textView2.setVisibility(z2 ? 0 : 8);
        FloatingInput floatingInput5 = this.recoverCodeInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
            floatingInput5 = null;
        }
        floatingInput5.getRoot().setVisibility(z3 ? 0 : 8);
        TextView textView3 = this.resendRecoverMailBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
            textView3 = null;
        }
        textView3.setVisibility(z3 ? 0 : 8);
        TextView textView4 = this.verifyRecoverCodeBtn;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("verifyRecoverCodeBtn");
            textView4 = null;
        }
        textView4.setVisibility(z3 ? 0 : 8);
        FloatingInput floatingInput6 = this.recoverPasswordInput;
        if (floatingInput6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
            floatingInput6 = null;
        }
        floatingInput6.getRoot().setVisibility(z4 ? 0 : 8);
        FloatingInput floatingInput7 = this.recoverRepeatPasswordInput;
        if (floatingInput7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recoverRepeatPasswordInput");
            floatingInput7 = null;
        }
        floatingInput7.getRoot().setVisibility(z4 ? 0 : 8);
        TextView textView5 = this.applyNewPasswordBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("applyNewPasswordBtn");
            textView5 = null;
        }
        textView5.setVisibility(z4 ? 0 : 8);
        TextView textView6 = this.forgotStepOne;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepOne");
            textView6 = null;
        }
        applyForgotStepBadge(textView6, z2, z3 || z4);
        TextView textView7 = this.forgotStepTwo;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepTwo");
            textView7 = null;
        }
        applyForgotStepBadge(textView7, z3, z4);
        TextView textView8 = this.forgotStepThree;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotStepThree");
            textView8 = null;
        }
        applyForgotStepBadge(textView8, z4, false);
        View view = this.forgotLineOne;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotLineOne");
            view = null;
        }
        if (!z3 && !z4) {
            z = false;
        }
        applyForgotStepLine(view, z);
        View view2 = this.forgotLineTwo;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("forgotLineTwo");
            view2 = null;
        }
        applyForgotStepLine(view2, z4);
        if (z3) {
            updateRecoveryResendUi();
            return;
        }
        TextView textView9 = this.resendRecoverMailBtn;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("resendRecoverMailBtn");
        } else {
            textView = textView9;
        }
        textView.setEnabled(false);
    }

    private final void doLogout() {
        hideKeyboard();
        setMessage("در حال خروج...");
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda47
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.doLogout$lambda$233(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doLogout$lambda$233(final AccountScreenView this$0) {
        Handler handler;
        Runnable runnable;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            Session session = this$0.session;
            if (session != null && (!StringsKt.isBlank(this$0.apiBase))) {
                String clientPlatform = AppState.INSTANCE.getClientPlatform();
                if (StringsKt.isBlank(clientPlatform)) {
                    clientPlatform = this$0.isTouchDevice ? "android" : "tv";
                }
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("scope", "current");
                jSONObject.put("platform", clientPlatform);
                String string = jSONObject.toString();
                Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/logout", "POST", null, MapsKt.mapOf(TuplesKt.m787to("x-fk-user-id", String.valueOf(session.getUserId())), TuplesKt.m787to("x-fk-session", session.getSessionToken())), string, false, 72, null);
            }
            handler = this$0.mainHandler;
            runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doLogout$lambda$233$lambda$232(this.f$0);
                }
            };
        } catch (Throwable unused) {
            handler = this$0.mainHandler;
            runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView.doLogout$lambda$233$lambda$232(this.f$0);
                }
            };
        }
        handler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void doLogout$lambda$233$lambda$232(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.hardLogout("از حساب خارج شدید");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void applySession(Session newSession, String successMessage) {
        this.session = newSession;
        AppState.INSTANCE.setSession(newSession);
        SessionStore.INSTANCE.save(this.ctx, newSession);
        this.isLoggedIn = true;
        this.panelData = null;
        this.panelLoading = false;
        stopQrPolling();
        stopQrCountdown();
        refreshUiByAuthState();
        setMessage(successMessage);
        if (this.isTouchDevice) {
            return;
        }
        focusLogout();
    }

    private final void hardLogout(String successMessage) {
        setLoginLoading(false);
        setRegisterLoading(false);
        this.session = null;
        AppState.INSTANCE.setSession(null);
        SessionStore.INSTANCE.clear(this.ctx);
        this.isLoggedIn = false;
        this.panelData = null;
        this.panelLoading = false;
        stopQrPolling();
        stopQrCountdown();
        this.guestScreen = GuestScreen.AUTH;
        this.authTab = AuthTab.LOGIN;
        if (this.recoverEmailInput != null) {
            resetForgotFlow$default(this, false, 1, null);
        }
        refreshUiByAuthState();
        updateAuthTabUi();
        setMessage(successMessage);
        if (this.isTouchDevice) {
            return;
        }
        focusAuthTab();
    }

    private final void setMessage(String text) {
        TextView textView;
        String string = StringsKt.trim((CharSequence) SafeUserMessage.INSTANCE.fromRaw(text, "")).toString();
        String str = string;
        if (!(str == null || StringsKt.isBlank(str)) && this.guestScreen == GuestScreen.FORGOT && this.forgotStep == ForgotStep.SET_PASSWORD && isRecoveryExpiryMessage(string)) {
            return;
        }
        MessageTone messageToneDetectMessageTone = detectMessageTone(string);
        TextView textView2 = null;
        this.messageText = null;
        updateMessage();
        TextView textView3 = this.authInlineErrorView;
        if (textView3 != null) {
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authInlineErrorView");
                textView3 = null;
            }
            setInlineMessage(textView3, null, MessageTone.INFO);
        }
        TextView textView4 = this.forgotInlineErrorView;
        if (textView4 != null) {
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("forgotInlineErrorView");
                textView4 = null;
            }
            setInlineMessage(textView4, null, MessageTone.INFO);
        }
        TextView textView5 = this.qrInlineMessageView;
        if (textView5 != null) {
            if (textView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrInlineMessageView");
                textView5 = null;
            }
            setInlineMessage(textView5, null, MessageTone.INFO);
        }
        if ((str == null || StringsKt.isBlank(str)) || this.isLoggedIn) {
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this.guestScreen.ordinal()];
        if (i != 1) {
            if (i == 2) {
                TextView textView6 = this.forgotInlineErrorView;
                if (textView6 != null) {
                    if (textView6 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("forgotInlineErrorView");
                    } else {
                        textView2 = textView6;
                    }
                    setInlineMessage(textView2, string, messageToneDetectMessageTone);
                }
            } else if (i == 3 && (textView = this.qrInlineMessageView) != null) {
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrInlineMessageView");
                } else {
                    textView2 = textView;
                }
                setInlineMessage(textView2, string, messageToneDetectMessageTone);
            }
        } else if (this.authInlineErrorView != null) {
            if (this.authTab == AuthTab.REGISTER) {
                messageToneDetectMessageTone = MessageTone.ERROR;
            }
            TextView textView7 = this.authInlineErrorView;
            if (textView7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authInlineErrorView");
            } else {
                textView2 = textView7;
            }
            setInlineMessage(textView2, string, messageToneDetectMessageTone);
        }
        this.scrollView.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda67
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.setMessage$lambda$234(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setMessage$lambda$234(AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.scrollView.smoothScrollTo(0, 0);
    }

    private final boolean isRecoveryExpiryMessage(String text) {
        String lowerCase = text.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        String str = lowerCase;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "منقضی", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "اعتبار", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "زمان", false, 2, (Object) null);
    }

    private final void clearAuthInlineMessage() {
        TextView textView = this.authInlineErrorView;
        if (textView != null) {
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("authInlineErrorView");
                textView = null;
            }
            setInlineMessage(textView, null, MessageTone.INFO);
        }
    }

    private final void updateMessage() {
        this.messageView.setText("");
        this.messageView.setVisibility(8);
    }

    private final void setInlineMessage(TextView view, String text, MessageTone tone) {
        Triple triple;
        if (view == null) {
            return;
        }
        String str = text;
        if (str == null || StringsKt.isBlank(str)) {
            view.setText("");
            view.setVisibility(8);
            return;
        }
        int i = WhenMappings.$EnumSwitchMapping$2[tone.ordinal()];
        if (i == 1) {
            triple = new Triple(572132107, 1157589610, -17477);
        } else if (i == 2) {
            triple = new Triple(571678744, 1146674831, -3934252);
        } else {
            if (i != 3) {
                throw new NoWhenBranchMatchedException();
            }
            triple = new Triple(588784689, 810314378, -2627846);
        }
        int iIntValue = ((Number) triple.component1()).intValue();
        int iIntValue2 = ((Number) triple.component2()).intValue();
        view.setTextColor(((Number) triple.component3()).intValue());
        view.setBackground(roundedBg(iIntValue, iIntValue2, m377dp(1), dpF(10)));
        view.setText(str);
        view.setVisibility(0);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final MessageTone detectMessageTone(String text) {
        String string;
        if (text != null) {
            String lowerCase = text.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            string = lowerCase != null ? StringsKt.trim((CharSequence) lowerCase).toString() : null;
        }
        if (string == null) {
            string = "";
        }
        String str = string;
        if (StringsKt.isBlank(str)) {
            return MessageTone.INFO;
        }
        if (StringsKt.contains$default((CharSequence) str, (CharSequence) "خطا", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "نامعتبر", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "منقضی", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "نیست", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "لطفا", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "وارد کنید", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "الزامی", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "حداقل", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "یکسان نیست", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "ناموفق", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "یافت نشد", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "پیدا نشد", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "وجود ندارد", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "نشد", false, 2, (Object) null)) {
            return MessageTone.ERROR;
        }
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "✅", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "موفق", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "وارد شدید", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "خارج شدید", false, 2, (Object) null) ? MessageTone.SUCCESS : MessageTone.INFO;
    }

    private final String readableError(Throwable error, String fallback) {
        if (error instanceof FkApiClient.ApiException) {
            try {
                SimpleResult simple = AccountParser.INSTANCE.parseSimple(((FkApiClient.ApiException) error).getBody());
                String message = simple.getMessage();
                if (!(message == null || StringsKt.isBlank(message)) && !Intrinsics.areEqual(simple.getMessage(), "پاسخ نامعتبر است")) {
                    return SafeUserMessage.INSTANCE.fromRaw(simple.getMessage(), fallback);
                }
                String strOptString = new JSONObject(((FkApiClient.ApiException) error).getBody()).optString("message");
                Intrinsics.checkNotNull(strOptString);
                if (!StringsKt.isBlank(strOptString)) {
                    return SafeUserMessage.INSTANCE.fromRaw(strOptString, fallback);
                }
            } catch (Throwable unused) {
            }
        }
        return SafeUserMessage.INSTANCE.fromThrowable(error, fallback);
    }

    private final LinearLayout makeAuthSectionPanel() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(1), dpF(18)));
        linearLayout.setPadding(m377dp(16), m377dp(16), m377dp(16), m377dp(16));
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return linearLayout;
    }

    private final TextView makeInlineErrorView() {
        TextView textView = new TextView(this.ctx);
        textView.setVisibility(8);
        textView.setTextColor(-17477);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular);
        textView.setLineSpacing(m377dp(1), 1.0f);
        textView.setGravity(21);
        textView.setBackground(roundedBg(572132107, 1157589610, m377dp(1), dpF(10)));
        textView.setPadding(m377dp(10), m377dp(8), m377dp(10), m377dp(8));
        return textView;
    }

    private final LinearLayout makeSectionHeader(String title, String subtitle, int iconRes) {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = m377dp(6);
        linearLayout.setLayoutParams(layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(this.accent);
        imageView.setAlpha(0.95f);
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText(subtitle);
        textView2.setTextColor(-5324327);
        textView2.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceRegular);
        textView2.setLineSpacing(m377dp(1), 1.0f);
        textView2.setPadding(0, m377dp(5), 0, 0);
        View view = new View(this.ctx);
        view.setBackgroundColor(553648127);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(m377dp(18), m377dp(18));
        layoutParams2.setMarginEnd(m377dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout2.addView(imageView, layoutParams2);
        linearLayout2.addView(textView);
        linearLayout.addView(linearLayout2);
        linearLayout.addView(textView2);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, m377dp(1));
        layoutParams3.topMargin = m377dp(8);
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(view, layoutParams3);
        return linearLayout;
    }

    private final CardParts makeCard(String title, int iconRes) {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setBackground(roundedBg(this.cardFill, this.cardStroke, m377dp(1), dpF(18)));
        linearLayout.setPadding(m377dp(14), m377dp(12), m377dp(14), m377dp(14));
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(-1);
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-1);
        textView.setTextSize(2, 17.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setPadding(m377dp(8), 0, 0, 0);
        View view = new View(this.ctx);
        view.setBackgroundColor(553648127);
        LinearLayout linearLayout3 = new LinearLayout(this.ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setPadding(0, m377dp(8), 0, 0);
        linearLayout2.addView(imageView, new LinearLayout.LayoutParams(m377dp(21), m377dp(21)));
        linearLayout2.addView(textView);
        linearLayout.addView(linearLayout2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, m377dp(1));
        layoutParams.topMargin = m377dp(10);
        layoutParams.bottomMargin = m377dp(4);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(view, layoutParams);
        linearLayout.addView(linearLayout3);
        return new CardParts(linearLayout, linearLayout3);
    }

    static /* synthetic */ FloatingInput makeFloatingInput$default(AccountScreenView accountScreenView, String str, int i, boolean z, int i2, int i3, int i4, Object obj) {
        if ((i4 & 4) != 0) {
            z = false;
        }
        boolean z2 = z;
        if ((i4 & 8) != 0) {
            i2 = 1;
        }
        int i5 = i2;
        if ((i4 & 16) != 0) {
            i3 = 5;
        }
        return accountScreenView.makeFloatingInput(str, i, z2, i5, i3);
    }

    private final FloatingInput makeFloatingInput(String labelText, int leadingIconRes, boolean isPassword, int inputType, int imeAction) {
        int iM377dp = m377dp(4);
        final FrameLayout frameLayout = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, m377dp(88));
        layoutParams.topMargin = m377dp(4);
        frameLayout.setLayoutParams(layoutParams);
        frameLayout.setLayoutDirection(1);
        final LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m377dp(2), dpF(16)));
        linearLayout.setPadding(m377dp(12), m377dp(12), m377dp(12), m377dp(12));
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, m377dp(64));
        layoutParams2.gravity = 80;
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(leadingIconRes);
        imageView.setColorFilter(-1);
        imageView.setAlpha(0.92f);
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint(styledHint(defaultInputHint(labelText)));
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(-9800576);
        appCompatEditText.setTextSize(14.0f);
        appCompatEditText.setGravity(21);
        appCompatEditText.setSingleLine();
        ImageView imageView2 = null;
        appCompatEditText.setBackground(null);
        appCompatEditText.setInputType(inputType);
        appCompatEditText.setImeOptions(imeAction);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setFocusable(true);
        appCompatEditText.setFocusableInTouchMode(true);
        appCompatEditText.setPadding(m377dp(6), 0, m377dp(5), 0);
        if (isPassword) {
            imageView2 = new ImageView(this.ctx);
            imageView2.setId(View.generateViewId());
            imageView2.setImageResource(C2629R.drawable.ic_password_eye_off);
            imageView2.setColorFilter(-1);
            imageView2.setAlpha(0.92f);
            imageView2.setFocusable(!this.isTouchDevice);
            imageView2.setFocusableInTouchMode(!this.isTouchDevice);
            imageView2.setPadding(m377dp(4), m377dp(4), m377dp(4), m377dp(4));
        }
        ImageView imageView3 = imageView2;
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(m377dp(22), m377dp(22));
        layoutParams3.setMarginStart(iM377dp);
        layoutParams3.setMarginEnd(m377dp(5));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(imageView, layoutParams3);
        AppCompatEditText appCompatEditText2 = appCompatEditText;
        linearLayout.addView(appCompatEditText2, new LinearLayout.LayoutParams(0, -2, 1.0f));
        if (imageView3 != null) {
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(m377dp(24), m377dp(24));
            layoutParams4.setMarginEnd(iM377dp);
            Unit unit2 = Unit.INSTANCE;
            linearLayout.addView(imageView3, layoutParams4);
        }
        TextView textView = new TextView(this.ctx);
        textView.setText(labelText);
        textView.setTextColor(-4666400);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular2);
        textView.setPadding(m377dp(7), m377dp(1), m377dp(7), 0);
        textView.setBackground(roundedBg(this.fieldFill, 0, 0, dpF(8)));
        textView.setTranslationY(0.0f);
        FrameLayout.LayoutParams layoutParams5 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams5.gravity = 53;
        layoutParams5.rightMargin = m377dp(40);
        layoutParams5.topMargin = m377dp(14);
        frameLayout.addView(linearLayout, layoutParams2);
        frameLayout.addView(textView, layoutParams5);
        final FloatingInput floatingInput = new FloatingInput(frameLayout, linearLayout, textView, appCompatEditText, imageView, imageView3, isPassword, false);
        if (isPassword) {
            applyPasswordVisibility(floatingInput);
            if (imageView3 != null) {
                imageView3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda6
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        AccountScreenView.makeFloatingInput$lambda$264(this.f$0, floatingInput, view);
                    }
                });
            }
            if (imageView3 != null) {
                imageView3.setOnKeyListener(new View.OnKeyListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda7
                    @Override // android.view.View.OnKeyListener
                    public final boolean onKey(View view, int i, KeyEvent keyEvent) {
                        return AccountScreenView.makeFloatingInput$lambda$265(this.f$0, floatingInput, view, i, keyEvent);
                    }
                });
            }
            if (imageView3 != null) {
                imageView3.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda8
                    @Override // android.view.View.OnFocusChangeListener
                    public final void onFocusChange(View view, boolean z) {
                        AccountScreenView.makeFloatingInput$lambda$266(this.f$0, frameLayout, view, z);
                    }
                });
            }
            if (imageView3 != null) {
                attachMenuShortcut(imageView3);
            }
            if (imageView3 != null) {
                appCompatEditText.setNextFocusLeftId(imageView3.getId());
                imageView3.setNextFocusRightId(appCompatEditText.getId());
            }
        }
        appCompatEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda9
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makeFloatingInput$lambda$268(linearLayout, this, floatingInput, frameLayout, view, z);
            }
        });
        appCompatEditText.addTextChangedListener(new TextWatcher() { // from class: com.filmkio.nativescreen.account.AccountScreenView.makeFloatingInput.8
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                AccountScreenView.this.updateFloatingLabel(floatingInput, true);
            }
        });
        updateFloatingLabel(floatingInput, false);
        attachMenuShortcut(appCompatEditText2);
        return floatingInput;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeFloatingInput$lambda$264(AccountScreenView this$0, FloatingInput field, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(field, "$field");
        this$0.togglePasswordVisibility(field);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean makeFloatingInput$lambda$265(AccountScreenView this$0, FloatingInput field, View view, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(field, "$field");
        if (keyEvent.getAction() != 0 || (i != 23 && i != 66)) {
            return false;
        }
        this$0.togglePasswordVisibility(field);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeFloatingInput$lambda$266(AccountScreenView this$0, FrameLayout root, View view, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(root, "$root");
        view.setAlpha(z ? 1.0f : 0.92f);
        if (z) {
            this$0.scrollToView(root);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeFloatingInput$lambda$268(LinearLayout shell, AccountScreenView this$0, FloatingInput field, FrameLayout root, View view, boolean z) {
        Intrinsics.checkNotNullParameter(shell, "$shell");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(field, "$field");
        Intrinsics.checkNotNullParameter(root, "$root");
        shell.setBackground(this$0.roundedBg(this$0.fieldFill, z ? this$0.accent : this$0.fieldStroke, this$0.m377dp(2), this$0.dpF(16)));
        this$0.updateFloatingLabel(field, true);
        if (z) {
            this$0.scrollToView(root);
        }
    }

    private final void togglePasswordVisibility(FloatingInput field) {
        if (field.isPassword()) {
            field.setPasswordVisible(!field.getPasswordVisible());
            applyPasswordVisibility(field);
        }
    }

    private final void applyPasswordVisibility(FloatingInput field) {
        if (field.isPassword()) {
            int iCoerceAtLeast = RangesKt.coerceAtLeast(field.getEdit().getSelectionStart(), 0);
            field.getEdit().setInputType(field.getPasswordVisible() ? 145 : TsExtractor.TS_STREAM_TYPE_AC3);
            AppCompatEditText edit = field.getEdit();
            Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
            if (typefaceRegular == null) {
                typefaceRegular = field.getEdit().getTypeface();
            }
            edit.setTypeface(typefaceRegular);
            AppCompatEditText edit2 = field.getEdit();
            Editable text = field.getEdit().getText();
            edit2.setSelection(Math.min(iCoerceAtLeast, text != null ? text.length() : 0));
            ImageView toggleIcon = field.getToggleIcon();
            if (toggleIcon != null) {
                toggleIcon.setImageResource(field.getPasswordVisible() ? C2629R.drawable.ic_password_eye_on : C2629R.drawable.ic_password_eye_off);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateFloatingLabel(FloatingInput field, boolean animate) {
        ViewGroup.LayoutParams layoutParams = field.getLabel().getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
        layoutParams2.rightMargin = m377dp(40);
        field.getLabel().setLayoutParams(layoutParams2);
        field.getLabel().setTextColor(-4666400);
        if (animate) {
            field.getLabel().animate().translationY(0.0f).scaleX(1.0f).scaleY(1.0f).setDuration(90L).start();
            return;
        }
        field.getLabel().setTranslationY(0.0f);
        field.getLabel().setScaleX(1.0f);
        field.getLabel().setScaleY(1.0f);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0079 A[ORIG_RETURN, RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final String defaultInputHint(String labelText) {
        switch (labelText.hashCode()) {
            case -2034596264:
                return !labelText.equals("کد تایید") ? "" : "کد تایید را وارد کنید";
            case -940664135:
                if (labelText.equals("نام کاربری / ایمیل / شماره تماس")) {
                    return "نام کاربری یا ایمیل یا شماره تماس را وارد کنید";
                }
                break;
            case -526625922:
                if (labelText.equals("تکرار رمز عبور")) {
                    return "تکرار رمز عبور را وارد کنید";
                }
                break;
            case -342345364:
                if (labelText.equals("رمز عبور جدید")) {
                    return "رمز عبور جدید را وارد کنید";
                }
                break;
            case 1041602022:
                if (labelText.equals("شماره موبایل (اختیاری)")) {
                    return "شماره موبایل را وارد کنید";
                }
                break;
            case 1348078220:
                if (labelText.equals("نام کاربری")) {
                    return "نام کاربری را وارد کنید";
                }
                break;
            case 1507979864:
                if (labelText.equals("ایمیل")) {
                    return "ایمیل را وارد کنید";
                }
                break;
            case 1739411610:
                if (labelText.equals("رمز عبور")) {
                    return "رمز عبور را وارد کنید";
                }
                break;
        }
    }

    private final CharSequence styledHint(String text) {
        String str = text;
        if (StringsKt.isBlank(str)) {
            return str;
        }
        SpannableString spannableString = new SpannableString(str);
        spannableString.setSpan(new AbsoluteSizeSpan(12, true), 0, spannableString.length(), 33);
        return spannableString;
    }

    private final TextView makeForgotStepBadge(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setPadding(m377dp(12), m377dp(7), m377dp(12), m377dp(7));
        textView.setBackground(roundedBg(-15590876, 637534207, m377dp(1), dpF(999)));
        textView.setTextColor(-6442551);
        return textView;
    }

    private final void applyForgotStepBadge(TextView view, boolean isActive, boolean isDone) {
        int i;
        int i2;
        int i3 = isActive ? -676591 : isDone ? -14865864 : -15590876;
        if (isActive) {
            i = -1;
        } else {
            i = isDone ? this.accent : 637534207;
        }
        if (isActive) {
            i2 = -16118254;
        } else {
            i2 = isDone ? this.accent : -6442551;
        }
        view.setBackground(roundedBg(i3, i, m377dp(1), dpF(999)));
        view.setTextColor(i2);
    }

    private final View makeForgotStepLine() {
        View view = new View(this.ctx);
        view.setBackgroundColor(805306367);
        view.setAlpha(0.9f);
        return view;
    }

    private final void applyForgotStepLine(View view, boolean isFilled) {
        view.setBackgroundColor(isFilled ? this.accent : 805306367);
        view.setAlpha(isFilled ? 1.0f : 0.9f);
    }

    private final TextView makeAuthTabButton(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(15.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setClickable(true);
        textView.setPadding(m377dp(12), m377dp(10), m377dp(12), m377dp(10));
        textView.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda36
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makeAuthTabButton$lambda$273(this.f$0, view, z);
            }
        });
        attachMenuShortcut(textView);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:15:0x002c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void makeAuthTabButton$lambda$273(AccountScreenView this$0, View view, boolean z) {
        boolean z2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        TextView textView = this$0.loginTabBtn;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loginTabBtn");
            textView = null;
        }
        if (view != textView || this$0.authTab != AuthTab.LOGIN) {
            TextView textView3 = this$0.registerTabBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("registerTabBtn");
            } else {
                textView2 = textView3;
            }
            z2 = view == textView2 && this$0.authTab == AuthTab.REGISTER;
        }
        Intrinsics.checkNotNull(view, "null cannot be cast to non-null type android.widget.TextView");
        this$0.applyAuthTabStyle((TextView) view, z2, z);
        if (z) {
            this$0.scrollToView(view);
        }
    }

    private final void applyAuthTabStyle(TextView view, boolean selected, boolean focused) {
        int i = (!focused || selected) ? 1319213 : 571941165;
        int i2 = (focused && selected) ? 1090519039 : focused ? 1174405119 : 0;
        int i3 = selected ? -16052459 : focused ? -1 : -5324327;
        view.setBackground(roundedBg(i, i2, m377dp(1), dpF(10)));
        view.setTextColor(i3);
    }

    private final TextView makeButton(String text, final ButtonStyle style) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(style == ButtonStyle.DANGER ? 15.0f : 16.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setClickable(true);
        textView.setPadding(m377dp(14), m377dp(11), m377dp(14), m377dp(11));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m377dp(10);
        textView.setLayoutParams(layoutParams);
        applyButtonStyle(textView, style, false, true);
        textView.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda13
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                AccountScreenView.makeButton$lambda$276(this.f$0, style, view, z);
            }
        });
        attachMenuShortcut(textView);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeButton$lambda$276(AccountScreenView this$0, ButtonStyle style, View view, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(style, "$style");
        Intrinsics.checkNotNull(view, "null cannot be cast to non-null type android.widget.TextView");
        TextView textView = (TextView) view;
        this$0.applyButtonStyle(textView, style, z, textView.isEnabled());
        if (z) {
            this$0.scrollToView(view);
        }
    }

    private final void applyButtonStyle(TextView view, ButtonStyle style, boolean focused, boolean enabled) {
        Triple triple;
        int i = WhenMappings.$EnumSwitchMapping$3[style.ordinal()];
        if (i == 1) {
            triple = new Triple(Integer.valueOf(enabled ? -676591 : -9412555), Integer.valueOf((enabled && focused) ? -1 : 0), Integer.valueOf(enabled ? -16052459 : -13817052));
        } else if (i == 2) {
            triple = new Triple(Integer.valueOf((focused && enabled) ? -14865864 : -15195603), Integer.valueOf((focused && enabled) ? this.accent : 822083583), Integer.valueOf(enabled ? -1 : -7494726));
        } else if (i == 3) {
            triple = new Triple(-15986670, Integer.valueOf((focused && enabled) ? 905969663 : 452984831), Integer.valueOf(enabled ? -4931894 : -8418922));
        } else {
            if (i != 4) {
                throw new NoWhenBranchMatchedException();
            }
            triple = new Triple(Integer.valueOf((focused && enabled) ? -12507353 : -13492706), Integer.valueOf((focused && enabled) ? -1 : 1275068415), Integer.valueOf(enabled ? -1 : -5925740));
        }
        int iIntValue = ((Number) triple.component1()).intValue();
        int iIntValue2 = ((Number) triple.component2()).intValue();
        int iIntValue3 = ((Number) triple.component3()).intValue();
        view.setBackground(roundedBg(iIntValue, iIntValue2, m377dp(1), dpF(12)));
        view.setTextColor(iIntValue3);
    }

    private final void attachMenuShortcut(View view) {
        view.setOnKeyListener(new View.OnKeyListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda49
            @Override // android.view.View.OnKeyListener
            public final boolean onKey(View view2, int i, KeyEvent keyEvent) {
                return AccountScreenView.attachMenuShortcut$lambda$277(this.f$0, view2, i, keyEvent);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean attachMenuShortcut$lambda$277(AccountScreenView this$0, View view, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (keyEvent.getAction() != 0 || i != 22) {
            return false;
        }
        Context context = this$0.ctx;
        MainActivity mainActivity = context instanceof MainActivity ? (MainActivity) context : null;
        if (mainActivity != null) {
            mainActivity.openMenuFromContent();
        }
        return true;
    }

    private final void scrollToView(View v) {
        final int iMax = Math.max(0, v.getTop() - m377dp(16));
        this.scrollView.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda42
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.scrollToView$lambda$278(this.f$0, iMax);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scrollToView$lambda$278(AccountScreenView this$0, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.scrollView.smoothScrollTo(0, i);
    }

    private final void focusAuthTab() {
        int i = WhenMappings.$EnumSwitchMapping$4[this.authTab.ordinal()];
        if (i == 1) {
            focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusAuthTab.1
                {
                    super(0);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // kotlin.jvm.functions.Function0
                public final View invoke() {
                    FloatingInput floatingInput = AccountScreenView.this.loginIdentityInput;
                    if (floatingInput == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("loginIdentityInput");
                        floatingInput = null;
                    }
                    return floatingInput.getEdit();
                }
            });
        } else {
            if (i != 2) {
                return;
            }
            focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusAuthTab.2
                {
                    super(0);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // kotlin.jvm.functions.Function0
                public final View invoke() {
                    FloatingInput floatingInput = AccountScreenView.this.registerUsernameInput;
                    if (floatingInput == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("registerUsernameInput");
                        floatingInput = null;
                    }
                    return floatingInput.getEdit();
                }
            });
        }
    }

    private final void focusForgot() {
        int i = WhenMappings.$EnumSwitchMapping$5[this.forgotStep.ordinal()];
        if (i == 1) {
            focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusForgot.1
                {
                    super(0);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // kotlin.jvm.functions.Function0
                public final View invoke() {
                    FloatingInput floatingInput = AccountScreenView.this.recoverEmailInput;
                    if (floatingInput == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("recoverEmailInput");
                        floatingInput = null;
                    }
                    return floatingInput.getEdit();
                }
            });
        } else if (i == 2) {
            focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusForgot.2
                {
                    super(0);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // kotlin.jvm.functions.Function0
                public final View invoke() {
                    FloatingInput floatingInput = AccountScreenView.this.recoverCodeInput;
                    if (floatingInput == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("recoverCodeInput");
                        floatingInput = null;
                    }
                    return floatingInput.getEdit();
                }
            });
        } else {
            if (i != 3) {
                return;
            }
            focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusForgot.3
                {
                    super(0);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // kotlin.jvm.functions.Function0
                public final View invoke() {
                    FloatingInput floatingInput = AccountScreenView.this.recoverPasswordInput;
                    if (floatingInput == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("recoverPasswordInput");
                        floatingInput = null;
                    }
                    return floatingInput.getEdit();
                }
            });
        }
    }

    private final void focusQr() {
        focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusQr.1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final View invoke() {
                TextView textView = AccountScreenView.this.qrReloadBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("qrReloadBtn");
                    textView = null;
                }
                return textView;
            }
        });
    }

    private final void focusLogout() {
        focusWithRetries(new Function0<View>() { // from class: com.filmkio.nativescreen.account.AccountScreenView.focusLogout.1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final View invoke() {
                TextView textView = AccountScreenView.this.logoutBtn;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("logoutBtn");
                    textView = null;
                }
                return textView;
            }
        });
    }

    private final void focusWithRetries(final Function0<? extends View> getView) {
        final Function0<Boolean> function0 = new Function0<Boolean>() { // from class: com.filmkio.nativescreen.account.AccountScreenView$focusWithRetries$request$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            public final Boolean invoke() {
                View viewInvoke = getView.invoke();
                if (viewInvoke != null) {
                    return Boolean.valueOf(viewInvoke.requestFocus());
                }
                return null;
            }
        };
        post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda62
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.focusWithRetries$lambda$279(function0);
            }
        });
        postDelayed(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda63
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.focusWithRetries$lambda$280(function0);
            }
        }, 60L);
        postDelayed(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda64
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.focusWithRetries$lambda$281(function0);
            }
        }, 140L);
        postDelayed(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$$ExternalSyntheticLambda65
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView.focusWithRetries$lambda$282(function0);
            }
        }, 240L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void focusWithRetries$lambda$279(Function0 request) {
        Intrinsics.checkNotNullParameter(request, "$request");
        request.invoke();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void focusWithRetries$lambda$280(Function0 request) {
        Intrinsics.checkNotNullParameter(request, "$request");
        request.invoke();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void focusWithRetries$lambda$281(Function0 request) {
        Intrinsics.checkNotNullParameter(request, "$request");
        request.invoke();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void focusWithRetries$lambda$282(Function0 request) {
        Intrinsics.checkNotNullParameter(request, "$request");
        request.invoke();
    }

    private final void hideKeyboard() {
        Object systemService = this.ctx.getSystemService("input_method");
        InputMethodManager inputMethodManager = systemService instanceof InputMethodManager ? (InputMethodManager) systemService : null;
        if (inputMethodManager == null) {
            return;
        }
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private final boolean isValidEmail(String text) {
        String str = text;
        if (StringsKt.isBlank(str)) {
            return false;
        }
        return Patterns.EMAIL_ADDRESS.matcher(str).matches();
    }

    static /* synthetic */ Bitmap generateQr$default(AccountScreenView accountScreenView, String str, int i, boolean z, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z = false;
        }
        return accountScreenView.generateQr(str, i, z);
    }

    private final Bitmap generateQr(String text, int size, boolean darkMode) {
        int width;
        int i;
        int i2;
        Paint paint;
        try {
            ByteMatrix matrix = Encoder.encode(text, ErrorCorrectionLevel.M).getMatrix();
            if (matrix == null || (width = matrix.getWidth()) <= 0) {
                return null;
            }
            byte b = 1;
            float f = (size - (r4 * r5)) / 2.0f;
            float fMax = Math.max(1, size / (width + 8));
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Intrinsics.checkNotNullExpressionValue(bitmapCreateBitmap, "createBitmap(...)");
            Canvas canvas = new Canvas(bitmapCreateBitmap);
            int i3 = darkMode ? -1 : ViewCompat.MEASURED_STATE_MASK;
            int i4 = darkMode ? -16117737 : -1;
            Paint paint2 = new Paint(1);
            paint2.setStyle(Paint.Style.FILL);
            paint2.setColor(i3);
            Paint paint3 = new Paint(1);
            paint3.setStyle(Paint.Style.FILL);
            paint3.setColor(i4);
            Paint paint4 = new Paint(1);
            paint4.setStyle(Paint.Style.FILL);
            paint4.setColor(this.accent);
            canvas.drawColor(i4);
            int i5 = 0;
            while (i5 < width) {
                int i6 = 0;
                while (i6 < width) {
                    if (matrix.get(i6, i5) != b || isFinderRegionModule(i6, i5, width)) {
                        i = i6;
                        i2 = i5;
                        paint = paint4;
                    } else {
                        float f2 = ((i6 + 4) * fMax) + f;
                        float f3 = ((i5 + 4) * fMax) + f;
                        i = i6;
                        i2 = i5;
                        paint = paint4;
                        canvas.drawRect(f2, f3, f2 + fMax, f3 + fMax, paint2);
                    }
                    i6 = i + 1;
                    i5 = i2;
                    paint4 = paint;
                    b = 1;
                }
                i5++;
                b = 1;
            }
            Paint paint5 = paint4;
            int i7 = (4 + width) - 7;
            drawCircularFinder(canvas, 4, 4, fMax, f, paint5, paint3);
            drawCircularFinder(canvas, i7, 4, fMax, f, paint5, paint3);
            drawCircularFinder(canvas, 4, i7, fMax, f, paint5, paint3);
            return bitmapCreateBitmap;
        } catch (Throwable unused) {
            return null;
        }
    }

    private final void drawCircularFinder(Canvas canvas, int startX, int startY, float moduleSize, float offset, Paint onPaint, Paint offPaint) {
        float f = ((startX + 3.5f) * moduleSize) + offset;
        float f2 = offset + ((startY + 3.5f) * moduleSize);
        canvas.drawCircle(f, f2, 3.5f * moduleSize, onPaint);
        canvas.drawCircle(f, f2, 2.5f * moduleSize, offPaint);
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(this.accent);
        canvas.drawCircle(f, f2, moduleSize * 1.5f, paint);
    }

    private final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(radius);
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        return gradientDrawable;
    }

    static /* synthetic */ LinearLayout.LayoutParams centeredContentParams$default(AccountScreenView accountScreenView, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = 0;
        }
        return accountScreenView.centeredContentParams(i);
    }

    private final LinearLayout.LayoutParams centeredContentParams(int topMargin) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(Math.min(m377dp(660), Math.max(m377dp(220), getResources().getDisplayMetrics().widthPixels - m377dp(44))), -2);
        layoutParams.gravity = 1;
        layoutParams.topMargin = topMargin;
        return layoutParams;
    }

    static /* synthetic */ LinearLayout.LayoutParams panelContentParams$default(AccountScreenView accountScreenView, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = 0;
        }
        return accountScreenView.panelContentParams(i);
    }

    private final LinearLayout.LayoutParams panelContentParams(int topMargin) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(Math.min(m377dp(TypedValues.TransitionType.TYPE_DURATION), Math.max(m377dp(220), getResources().getDisplayMetrics().widthPixels - m377dp(20))), -2);
        layoutParams.gravity = 1;
        layoutParams.topMargin = topMargin;
        return layoutParams;
    }

    private final void copyToClipboard(String label, String value) {
        Object systemService = this.ctx.getSystemService("clipboard");
        ClipboardManager clipboardManager = systemService instanceof ClipboardManager ? (ClipboardManager) systemService : null;
        if (clipboardManager == null) {
            return;
        }
        clipboardManager.setPrimaryClip(ClipData.newPlainText(label, value));
    }

    /* JADX INFO: renamed from: dp */
    private final int m377dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private final float dpF(int v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ValueAnimator valueAnimator = this.authHeightAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        this.authHeightAnimator = null;
        ValueAnimator valueAnimator2 = this.authTabIndicatorAnimator;
        if (valueAnimator2 != null) {
            valueAnimator2.cancel();
        }
        this.authTabIndicatorAnimator = null;
        stopLoginSpinner();
        stopRegisterSpinner();
        this.loginRequestInFlight = false;
        this.registerRequestInFlight = false;
        stopVerifyCodeSpinner();
        this.verifyCodeRequestInFlight = false;
        stopApplyNewPasswordSpinner();
        this.applyNewPasswordRequestInFlight = false;
        stopRecoverySendSpinner();
        this.recoveryEmailRequestInFlight = false;
        this.recoveryLoadingTarget = RecoveryLoadingTarget.NONE;
        stopRecoveryTimer();
        stopQrPolling();
        stopQrCountdown();
        stopPanelCountdown();
        SubscriptionGaugeView subscriptionGaugeView = this.panelSubArcView;
        if (subscriptionGaugeView != null) {
            subscriptionGaugeView.stop();
        }
        this.panelSubArcView = null;
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0018\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u0006H\u0002J(\u0010\u001a\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u00062\u0006\u0010\u001e\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020\u0006H\u0002J(\u0010 \u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020\u0006H\u0002J\u0010\u0010#\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u001cH\u0014J\u001c\u0010$\u001a\u00020\r2\u0014\u0010%\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r\u0018\u00010\fJ\u0016\u0010&\u001a\u00020\r2\u0006\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020*J\u0006\u0010+\u001a\u00020\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006,"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$SubscriptionGaugeView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "animatedProgress", "", "arcRect", "Landroid/graphics/RectF;", "dottedPaint", "Landroid/graphics/Paint;", "labelCenterListener", "Lkotlin/Function1;", "", "labelCenterY", "markerConnectorPaint", "markerFillPaint", "markerGlowPaint", "markerGlowSoftPaint", "markerRingPaint", "progressAnimator", "Landroid/animation/ValueAnimator;", "progressPaint", "trackPaint", "dpF", "value", "drawInnerDots", "canvas", "Landroid/graphics/Canvas;", "centerX", "centerY", "radius", "drawMarker", "startAngle", "progressValue", "onDraw", "setOnLabelCenterChanged", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "setProgress", "percent", "", "animate", "", "stop", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class SubscriptionGaugeView extends View {
        private float animatedProgress;
        private final RectF arcRect;
        private final Paint dottedPaint;
        private Function1<? super Float, Unit> labelCenterListener;
        private float labelCenterY;
        private final Paint markerConnectorPaint;
        private final Paint markerFillPaint;
        private final Paint markerGlowPaint;
        private final Paint markerGlowSoftPaint;
        private final Paint markerRingPaint;
        private ValueAnimator progressAnimator;
        private final Paint progressPaint;
        private final Paint trackPaint;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public SubscriptionGaugeView(Context context) {
            super(context);
            Intrinsics.checkNotNullParameter(context, "context");
            this.arcRect = new RectF();
            Paint paint = new Paint(1);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(-15063757);
            this.trackPaint = paint;
            Paint paint2 = new Paint(1);
            paint2.setStyle(Paint.Style.STROKE);
            paint2.setStrokeCap(Paint.Cap.ROUND);
            paint2.setColor(-675054);
            this.progressPaint = paint2;
            Paint paint3 = new Paint(1);
            paint3.setStyle(Paint.Style.FILL);
            paint3.setColor(1728053247);
            this.dottedPaint = paint3;
            Paint paint4 = new Paint(1);
            paint4.setStyle(Paint.Style.FILL);
            paint4.setColor(-856313070);
            this.markerGlowPaint = paint4;
            Paint paint5 = new Paint(1);
            paint5.setStyle(Paint.Style.FILL);
            paint5.setColor(1727378194);
            this.markerGlowSoftPaint = paint5;
            Paint paint6 = new Paint(1);
            paint6.setStyle(Paint.Style.STROKE);
            paint6.setStrokeCap(Paint.Cap.ROUND);
            paint6.setColor(-675054);
            this.markerConnectorPaint = paint6;
            Paint paint7 = new Paint(1);
            paint7.setStyle(Paint.Style.STROKE);
            paint7.setColor(-675054);
            paint7.setStrokeCap(Paint.Cap.ROUND);
            paint7.setStrokeJoin(Paint.Join.ROUND);
            this.markerRingPaint = paint7;
            Paint paint8 = new Paint(1);
            paint8.setStyle(Paint.Style.FILL);
            paint8.setColor(-1);
            this.markerFillPaint = paint8;
        }

        public final void setOnLabelCenterChanged(Function1<? super Float, Unit> listener) {
            this.labelCenterListener = listener;
            float f = this.labelCenterY;
            if (f <= 0.0f || listener == null) {
                return;
            }
            listener.invoke(Float.valueOf(f));
        }

        public final void setProgress(int percent, boolean animate) {
            float fCoerceIn = RangesKt.coerceIn(percent, 0, 100) / 100.0f;
            ValueAnimator valueAnimator = this.progressAnimator;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            if (!animate) {
                this.animatedProgress = fCoerceIn;
                invalidate();
                return;
            }
            ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.animatedProgress, fCoerceIn);
            valueAnimatorOfFloat.setDuration(1000L);
            valueAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
            valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.filmkio.nativescreen.account.AccountScreenView$SubscriptionGaugeView$$ExternalSyntheticLambda0
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                    AccountScreenView.SubscriptionGaugeView.setProgress$lambda$9$lambda$8(this.f$0, valueAnimator2);
                }
            });
            valueAnimatorOfFloat.start();
            this.progressAnimator = valueAnimatorOfFloat;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void setProgress$lambda$9$lambda$8(SubscriptionGaugeView this$0, ValueAnimator valueAnimator) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(valueAnimator, "valueAnimator");
            Object animatedValue = valueAnimator.getAnimatedValue();
            Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
            this$0.animatedProgress = RangesKt.coerceIn(((Float) animatedValue).floatValue(), 0.0f, 1.0f);
            this$0.invalidate();
        }

        public final void stop() {
            ValueAnimator valueAnimator = this.progressAnimator;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            this.progressAnimator = null;
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            Intrinsics.checkNotNullParameter(canvas, "canvas");
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            if (width <= 0.0f || height <= 0.0f) {
                return;
            }
            float fMax = Math.max(dpF(9.0f), Math.min(width, height) * 0.082f);
            this.trackPaint.setStrokeWidth(fMax);
            this.progressPaint.setStrokeWidth(fMax);
            float f = height * 0.83f;
            float fMin = Math.min(RangesKt.coerceAtLeast((width - (Math.max((fMax * 0.95f) + dpF(4.0f), dpF(24.0f)) * 2.0f)) / 2.0f, dpF(24.0f)), RangesKt.coerceAtLeast(f - dpF(10.0f), dpF(24.0f)));
            float f2 = width / 2.0f;
            this.arcRect.set(f2 - fMin, f - fMin, f2 + fMin, f + fMin);
            float f3 = f - (0.06f * fMin);
            this.labelCenterY = f3;
            Function1<? super Float, Unit> function1 = this.labelCenterListener;
            if (function1 != null) {
                function1.invoke(Float.valueOf(f3));
            }
            float fCoerceIn = RangesKt.coerceIn(this.animatedProgress, 0.0f, 1.0f);
            float fCoerceIn2 = fCoerceIn >= 0.9995f ? 180.0f : RangesKt.coerceIn(fCoerceIn * 180.0f, 0.0f, 180.0f);
            drawInnerDots(canvas, f2, f, 0.62f * fMin);
            canvas.drawArc(this.arcRect, 180.0f, 180.0f, false, this.trackPaint);
            if (fCoerceIn2 > 0.0f) {
                canvas.drawArc(this.arcRect, 180.0f, fCoerceIn2, false, this.progressPaint);
            }
            drawMarker(canvas, 180.0f, fCoerceIn, fMin);
        }

        private final void drawInnerDots(Canvas canvas, float centerX, float centerY, float radius) {
            int i = 0;
            while (true) {
                float f = i / 18;
                double d = ((double) (1.0f - f)) * 3.141592653589793d;
                double d2 = radius;
                float fCos = ((float) (Math.cos(d) * d2)) + centerX;
                float fSin = centerY - ((float) (d2 * Math.sin(d)));
                this.dottedPaint.setAlpha(f <= this.animatedProgress ? 210 : 108);
                canvas.drawCircle(fCos, fSin, i % 2 == 0 ? dpF(1.35f) : dpF(1.0f), this.dottedPaint);
                if (i == 18) {
                    return;
                } else {
                    i++;
                }
            }
        }

        private final void drawMarker(Canvas canvas, float startAngle, float progressValue, float radius) {
            double radians = Math.toRadians(startAngle + (RangesKt.coerceIn(progressValue, 0.0f, 1.0f) * 180.0f));
            float fCenterX = this.arcRect.centerX();
            float fCenterY = this.arcRect.centerY();
            double d = radius;
            float fCos = ((float) (Math.cos(radians) * d)) + fCenterX;
            float fSin = ((float) (d * Math.sin(radians))) + fCenterY;
            float f = fCos - fCenterX;
            float f2 = fSin - fCenterY;
            float fCoerceAtLeast = RangesKt.coerceAtLeast((float) Math.sqrt((f * f) + (f2 * f2)), 0.001f);
            float f3 = fCos + ((f / fCoerceAtLeast) * 0.0f);
            float f4 = fSin + ((f2 / fCoerceAtLeast) * 0.0f);
            float strokeWidth = this.progressPaint.getStrokeWidth();
            float fCoerceAtLeast2 = RangesKt.coerceAtLeast(0.6f * strokeWidth, dpF(5.0f));
            float fCoerceAtLeast3 = RangesKt.coerceAtLeast(0.34f * strokeWidth, dpF(2.4f));
            float fCoerceAtLeast4 = RangesKt.coerceAtLeast(fCoerceAtLeast2 - (fCoerceAtLeast3 / 2.0f), dpF(3.0f));
            this.markerRingPaint.setStrokeWidth(fCoerceAtLeast3);
            this.markerConnectorPaint.setStrokeWidth(strokeWidth);
            this.markerConnectorPaint.setColor(this.progressPaint.getColor());
            canvas.drawCircle(f3, f4, dpF(6.4f) + fCoerceAtLeast2, this.markerGlowSoftPaint);
            canvas.drawCircle(f3, f4, fCoerceAtLeast2 + dpF(3.0f), this.markerGlowPaint);
            canvas.drawCircle(f3, f4, fCoerceAtLeast4, this.markerFillPaint);
            canvas.drawCircle(f3, f4, fCoerceAtLeast4, this.markerRingPaint);
        }

        private final float dpF(float value) {
            return value * getResources().getDisplayMetrics().density;
        }
    }

    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\t\u001a\u00020\u0003HÆ\u0003J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\u000b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\u0013"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$CardParts;", "", "root", "Landroid/widget/LinearLayout;", TtmlNode.TAG_BODY, "(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V", "getBody", "()Landroid/widget/LinearLayout;", "getRoot", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class CardParts {
        private final LinearLayout body;
        private final LinearLayout root;

        public static /* synthetic */ CardParts copy$default(CardParts cardParts, LinearLayout linearLayout, LinearLayout linearLayout2, int i, Object obj) {
            if ((i & 1) != 0) {
                linearLayout = cardParts.root;
            }
            if ((i & 2) != 0) {
                linearLayout2 = cardParts.body;
            }
            return cardParts.copy(linearLayout, linearLayout2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final LinearLayout getRoot() {
            return this.root;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final LinearLayout getBody() {
            return this.body;
        }

        public final CardParts copy(LinearLayout root, LinearLayout body) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(body, "body");
            return new CardParts(root, body);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof CardParts)) {
                return false;
            }
            CardParts cardParts = (CardParts) other;
            return Intrinsics.areEqual(this.root, cardParts.root) && Intrinsics.areEqual(this.body, cardParts.body);
        }

        public int hashCode() {
            return (this.root.hashCode() * 31) + this.body.hashCode();
        }

        public String toString() {
            return "CardParts(root=" + this.root + ", body=" + this.body + ")";
        }

        public CardParts(LinearLayout root, LinearLayout body) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(body, "body");
            this.root = root;
            this.body = body;
        }

        public final LinearLayout getRoot() {
            return this.root;
        }

        public final LinearLayout getBody() {
            return this.body;
        }
    }

    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00030\b\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00030\b\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\b¢\u0006\u0002\u0010\u000bJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0006HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\bHÆ\u0003J\u000f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00030\bHÆ\u0003J\u000f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00030\bHÆ\u0003JW\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00030\b2\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00030\b2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\bHÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001f\u001a\u00020\u0006HÖ\u0001J\t\u0010 \u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00030\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00030\b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011¨\u0006!"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$PanelShortcutSpec;", "", "key", "", Constants.ScionAnalytics.PARAM_LABEL, "iconRes", "", "keyAliases", "", "screenAliases", "labelAliases", "(Ljava/lang/String;Ljava/lang/String;ILjava/util/List;Ljava/util/List;Ljava/util/List;)V", "getIconRes", "()I", "getKey", "()Ljava/lang/String;", "getKeyAliases", "()Ljava/util/List;", "getLabel", "getLabelAliases", "getScreenAliases", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class PanelShortcutSpec {
        private final int iconRes;
        private final String key;
        private final List<String> keyAliases;
        private final String label;
        private final List<String> labelAliases;
        private final List<String> screenAliases;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ PanelShortcutSpec copy$default(PanelShortcutSpec panelShortcutSpec, String str, String str2, int i, List list, List list2, List list3, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                str = panelShortcutSpec.key;
            }
            if ((i2 & 2) != 0) {
                str2 = panelShortcutSpec.label;
            }
            String str3 = str2;
            if ((i2 & 4) != 0) {
                i = panelShortcutSpec.iconRes;
            }
            int i3 = i;
            if ((i2 & 8) != 0) {
                list = panelShortcutSpec.keyAliases;
            }
            List list4 = list;
            if ((i2 & 16) != 0) {
                list2 = panelShortcutSpec.screenAliases;
            }
            List list5 = list2;
            if ((i2 & 32) != 0) {
                list3 = panelShortcutSpec.labelAliases;
            }
            return panelShortcutSpec.copy(str, str3, i3, list4, list5, list3);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getKey() {
            return this.key;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getLabel() {
            return this.label;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getIconRes() {
            return this.iconRes;
        }

        public final List<String> component4() {
            return this.keyAliases;
        }

        public final List<String> component5() {
            return this.screenAliases;
        }

        public final List<String> component6() {
            return this.labelAliases;
        }

        public final PanelShortcutSpec copy(String key, String label, int iconRes, List<String> keyAliases, List<String> screenAliases, List<String> labelAliases) {
            Intrinsics.checkNotNullParameter(key, "key");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(keyAliases, "keyAliases");
            Intrinsics.checkNotNullParameter(screenAliases, "screenAliases");
            Intrinsics.checkNotNullParameter(labelAliases, "labelAliases");
            return new PanelShortcutSpec(key, label, iconRes, keyAliases, screenAliases, labelAliases);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PanelShortcutSpec)) {
                return false;
            }
            PanelShortcutSpec panelShortcutSpec = (PanelShortcutSpec) other;
            return Intrinsics.areEqual(this.key, panelShortcutSpec.key) && Intrinsics.areEqual(this.label, panelShortcutSpec.label) && this.iconRes == panelShortcutSpec.iconRes && Intrinsics.areEqual(this.keyAliases, panelShortcutSpec.keyAliases) && Intrinsics.areEqual(this.screenAliases, panelShortcutSpec.screenAliases) && Intrinsics.areEqual(this.labelAliases, panelShortcutSpec.labelAliases);
        }

        public int hashCode() {
            return (((((((((this.key.hashCode() * 31) + this.label.hashCode()) * 31) + Integer.hashCode(this.iconRes)) * 31) + this.keyAliases.hashCode()) * 31) + this.screenAliases.hashCode()) * 31) + this.labelAliases.hashCode();
        }

        public String toString() {
            return "PanelShortcutSpec(key=" + this.key + ", label=" + this.label + ", iconRes=" + this.iconRes + ", keyAliases=" + this.keyAliases + ", screenAliases=" + this.screenAliases + ", labelAliases=" + this.labelAliases + ")";
        }

        public PanelShortcutSpec(String key, String label, int i, List<String> keyAliases, List<String> screenAliases, List<String> labelAliases) {
            Intrinsics.checkNotNullParameter(key, "key");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(keyAliases, "keyAliases");
            Intrinsics.checkNotNullParameter(screenAliases, "screenAliases");
            Intrinsics.checkNotNullParameter(labelAliases, "labelAliases");
            this.key = key;
            this.label = label;
            this.iconRes = i;
            this.keyAliases = keyAliases;
            this.screenAliases = screenAliases;
            this.labelAliases = labelAliases;
        }

        public final String getKey() {
            return this.key;
        }

        public final String getLabel() {
            return this.label;
        }

        public final int getIconRes() {
            return this.iconRes;
        }

        public final List<String> getKeyAliases() {
            return this.keyAliases;
        }

        public final List<String> getScreenAliases() {
            return this.screenAliases;
        }

        public final List<String> getLabelAliases() {
            return this.labelAliases;
        }
    }

    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0014"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$PanelShortcutEntry;", "", "item", "Lcom/filmkio/nativescreen/account/PanelMenuItem;", "iconRes", "", "(Lcom/filmkio/nativescreen/account/PanelMenuItem;I)V", "getIconRes", "()I", "getItem", "()Lcom/filmkio/nativescreen/account/PanelMenuItem;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class PanelShortcutEntry {
        private final int iconRes;
        private final PanelMenuItem item;

        public static /* synthetic */ PanelShortcutEntry copy$default(PanelShortcutEntry panelShortcutEntry, PanelMenuItem panelMenuItem, int i, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                panelMenuItem = panelShortcutEntry.item;
            }
            if ((i2 & 2) != 0) {
                i = panelShortcutEntry.iconRes;
            }
            return panelShortcutEntry.copy(panelMenuItem, i);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final PanelMenuItem getItem() {
            return this.item;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final int getIconRes() {
            return this.iconRes;
        }

        public final PanelShortcutEntry copy(PanelMenuItem item, int iconRes) {
            Intrinsics.checkNotNullParameter(item, "item");
            return new PanelShortcutEntry(item, iconRes);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PanelShortcutEntry)) {
                return false;
            }
            PanelShortcutEntry panelShortcutEntry = (PanelShortcutEntry) other;
            return Intrinsics.areEqual(this.item, panelShortcutEntry.item) && this.iconRes == panelShortcutEntry.iconRes;
        }

        public int hashCode() {
            return (this.item.hashCode() * 31) + Integer.hashCode(this.iconRes);
        }

        public String toString() {
            return "PanelShortcutEntry(item=" + this.item + ", iconRes=" + this.iconRes + ")";
        }

        public PanelShortcutEntry(PanelMenuItem item, int i) {
            Intrinsics.checkNotNullParameter(item, "item");
            this.item = item;
            this.iconRes = i;
        }

        public final PanelMenuItem getItem() {
            return this.item;
        }

        public final int getIconRes() {
            return this.iconRes;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u001d\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u000b\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0002\u0010\u0010J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\tHÆ\u0003J\t\u0010$\u001a\u00020\u000bHÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u000bHÆ\u0003J\t\u0010&\u001a\u00020\u000eHÆ\u0003J\t\u0010'\u001a\u00020\u000eHÆ\u0003J[\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000b2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u000b2\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u000eHÆ\u0001J\u0013\u0010)\u001a\u00020\u000e2\b\u0010*\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010+\u001a\u00020,HÖ\u0001J\t\u0010-\u001a\u00020.HÖ\u0001R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u000f\u001a\u00020\u000eX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0013\"\u0004\b\u0019\u0010\u001aR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0013\u0010\f\u001a\u0004\u0018\u00010\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0017¨\u0006/"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$FloatingInput;", "", "root", "Landroid/widget/FrameLayout;", "shell", "Landroid/widget/LinearLayout;", Constants.ScionAnalytics.PARAM_LABEL, "Landroid/widget/TextView;", "edit", "Landroidx/appcompat/widget/AppCompatEditText;", "leadingIcon", "Landroid/widget/ImageView;", "toggleIcon", "isPassword", "", "passwordVisible", "(Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatEditText;Landroid/widget/ImageView;Landroid/widget/ImageView;ZZ)V", "getEdit", "()Landroidx/appcompat/widget/AppCompatEditText;", "()Z", "getLabel", "()Landroid/widget/TextView;", "getLeadingIcon", "()Landroid/widget/ImageView;", "getPasswordVisible", "setPasswordVisible", "(Z)V", "getRoot", "()Landroid/widget/FrameLayout;", "getShell", "()Landroid/widget/LinearLayout;", "getToggleIcon", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "", "toString", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class FloatingInput {
        private final AppCompatEditText edit;
        private final boolean isPassword;
        private final TextView label;
        private final ImageView leadingIcon;
        private boolean passwordVisible;
        private final FrameLayout root;
        private final LinearLayout shell;
        private final ImageView toggleIcon;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final FrameLayout getRoot() {
            return this.root;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final LinearLayout getShell() {
            return this.shell;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final TextView getLabel() {
            return this.label;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final AppCompatEditText getEdit() {
            return this.edit;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final ImageView getLeadingIcon() {
            return this.leadingIcon;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final ImageView getToggleIcon() {
            return this.toggleIcon;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final boolean getIsPassword() {
            return this.isPassword;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final boolean getPasswordVisible() {
            return this.passwordVisible;
        }

        public final FloatingInput copy(FrameLayout root, LinearLayout shell, TextView label, AppCompatEditText edit, ImageView leadingIcon, ImageView toggleIcon, boolean isPassword, boolean passwordVisible) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(shell, "shell");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(edit, "edit");
            Intrinsics.checkNotNullParameter(leadingIcon, "leadingIcon");
            return new FloatingInput(root, shell, label, edit, leadingIcon, toggleIcon, isPassword, passwordVisible);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof FloatingInput)) {
                return false;
            }
            FloatingInput floatingInput = (FloatingInput) other;
            return Intrinsics.areEqual(this.root, floatingInput.root) && Intrinsics.areEqual(this.shell, floatingInput.shell) && Intrinsics.areEqual(this.label, floatingInput.label) && Intrinsics.areEqual(this.edit, floatingInput.edit) && Intrinsics.areEqual(this.leadingIcon, floatingInput.leadingIcon) && Intrinsics.areEqual(this.toggleIcon, floatingInput.toggleIcon) && this.isPassword == floatingInput.isPassword && this.passwordVisible == floatingInput.passwordVisible;
        }

        public int hashCode() {
            int iHashCode = ((((((((this.root.hashCode() * 31) + this.shell.hashCode()) * 31) + this.label.hashCode()) * 31) + this.edit.hashCode()) * 31) + this.leadingIcon.hashCode()) * 31;
            ImageView imageView = this.toggleIcon;
            return ((((iHashCode + (imageView == null ? 0 : imageView.hashCode())) * 31) + Boolean.hashCode(this.isPassword)) * 31) + Boolean.hashCode(this.passwordVisible);
        }

        public String toString() {
            return "FloatingInput(root=" + this.root + ", shell=" + this.shell + ", label=" + this.label + ", edit=" + this.edit + ", leadingIcon=" + this.leadingIcon + ", toggleIcon=" + this.toggleIcon + ", isPassword=" + this.isPassword + ", passwordVisible=" + this.passwordVisible + ")";
        }

        public FloatingInput(FrameLayout root, LinearLayout shell, TextView label, AppCompatEditText edit, ImageView leadingIcon, ImageView imageView, boolean z, boolean z2) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(shell, "shell");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(edit, "edit");
            Intrinsics.checkNotNullParameter(leadingIcon, "leadingIcon");
            this.root = root;
            this.shell = shell;
            this.label = label;
            this.edit = edit;
            this.leadingIcon = leadingIcon;
            this.toggleIcon = imageView;
            this.isPassword = z;
            this.passwordVisible = z2;
        }

        public final FrameLayout getRoot() {
            return this.root;
        }

        public final LinearLayout getShell() {
            return this.shell;
        }

        public final TextView getLabel() {
            return this.label;
        }

        public final AppCompatEditText getEdit() {
            return this.edit;
        }

        public final ImageView getLeadingIcon() {
            return this.leadingIcon;
        }

        public final ImageView getToggleIcon() {
            return this.toggleIcon;
        }

        public final boolean isPassword() {
            return this.isPassword;
        }

        public final boolean getPasswordVisible() {
            return this.passwordVisible;
        }

        public final void setPasswordVisible(boolean z) {
            this.passwordVisible = z;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$ButtonStyle;", "", "(Ljava/lang/String;I)V", "PRIMARY", "SECONDARY", "DOWNLOAD_BOX", "DANGER", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class ButtonStyle {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ ButtonStyle[] $VALUES;
        public static final ButtonStyle PRIMARY = new ButtonStyle("PRIMARY", 0);
        public static final ButtonStyle SECONDARY = new ButtonStyle("SECONDARY", 1);
        public static final ButtonStyle DOWNLOAD_BOX = new ButtonStyle("DOWNLOAD_BOX", 2);
        public static final ButtonStyle DANGER = new ButtonStyle("DANGER", 3);

        private static final /* synthetic */ ButtonStyle[] $values() {
            return new ButtonStyle[]{PRIMARY, SECONDARY, DOWNLOAD_BOX, DANGER};
        }

        public static EnumEntries<ButtonStyle> getEntries() {
            return $ENTRIES;
        }

        public static ButtonStyle valueOf(String str) {
            return (ButtonStyle) Enum.valueOf(ButtonStyle.class, str);
        }

        public static ButtonStyle[] values() {
            return (ButtonStyle[]) $VALUES.clone();
        }

        private ButtonStyle(String str, int i) {
        }

        static {
            ButtonStyle[] buttonStyleArr$values = $values();
            $VALUES = buttonStyleArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(buttonStyleArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$GuestScreen;", "", "(Ljava/lang/String;I)V", "AUTH", "FORGOT", "QR", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class GuestScreen {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ GuestScreen[] $VALUES;
        public static final GuestScreen AUTH = new GuestScreen("AUTH", 0);
        public static final GuestScreen FORGOT = new GuestScreen("FORGOT", 1);

        /* JADX INFO: renamed from: QR */
        public static final GuestScreen f342QR = new GuestScreen("QR", 2);

        private static final /* synthetic */ GuestScreen[] $values() {
            return new GuestScreen[]{AUTH, FORGOT, f342QR};
        }

        public static EnumEntries<GuestScreen> getEntries() {
            return $ENTRIES;
        }

        public static GuestScreen valueOf(String str) {
            return (GuestScreen) Enum.valueOf(GuestScreen.class, str);
        }

        public static GuestScreen[] values() {
            return (GuestScreen[]) $VALUES.clone();
        }

        private GuestScreen(String str, int i) {
        }

        static {
            GuestScreen[] guestScreenArr$values = $values();
            $VALUES = guestScreenArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(guestScreenArr$values);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$AuthTab;", "", "(Ljava/lang/String;I)V", "LOGIN", "REGISTER", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class AuthTab {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ AuthTab[] $VALUES;
        public static final AuthTab LOGIN = new AuthTab("LOGIN", 0);
        public static final AuthTab REGISTER = new AuthTab("REGISTER", 1);

        private static final /* synthetic */ AuthTab[] $values() {
            return new AuthTab[]{LOGIN, REGISTER};
        }

        public static EnumEntries<AuthTab> getEntries() {
            return $ENTRIES;
        }

        public static AuthTab valueOf(String str) {
            return (AuthTab) Enum.valueOf(AuthTab.class, str);
        }

        public static AuthTab[] values() {
            return (AuthTab[]) $VALUES.clone();
        }

        private AuthTab(String str, int i) {
        }

        static {
            AuthTab[] authTabArr$values = $values();
            $VALUES = authTabArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(authTabArr$values);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$ForgotStep;", "", "(Ljava/lang/String;I)V", "ENTER_EMAIL", "VERIFY_CODE", "SET_PASSWORD", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class ForgotStep {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ ForgotStep[] $VALUES;
        public static final ForgotStep ENTER_EMAIL = new ForgotStep("ENTER_EMAIL", 0);
        public static final ForgotStep VERIFY_CODE = new ForgotStep("VERIFY_CODE", 1);
        public static final ForgotStep SET_PASSWORD = new ForgotStep("SET_PASSWORD", 2);

        private static final /* synthetic */ ForgotStep[] $values() {
            return new ForgotStep[]{ENTER_EMAIL, VERIFY_CODE, SET_PASSWORD};
        }

        public static EnumEntries<ForgotStep> getEntries() {
            return $ENTRIES;
        }

        public static ForgotStep valueOf(String str) {
            return (ForgotStep) Enum.valueOf(ForgotStep.class, str);
        }

        public static ForgotStep[] values() {
            return (ForgotStep[]) $VALUES.clone();
        }

        private ForgotStep(String str, int i) {
        }

        static {
            ForgotStep[] forgotStepArr$values = $values();
            $VALUES = forgotStepArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(forgotStepArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$RecoveryLoadingTarget;", "", "(Ljava/lang/String;I)V", "NONE", "SEND", "RESEND", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class RecoveryLoadingTarget {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ RecoveryLoadingTarget[] $VALUES;
        public static final RecoveryLoadingTarget NONE = new RecoveryLoadingTarget("NONE", 0);
        public static final RecoveryLoadingTarget SEND = new RecoveryLoadingTarget("SEND", 1);
        public static final RecoveryLoadingTarget RESEND = new RecoveryLoadingTarget("RESEND", 2);

        private static final /* synthetic */ RecoveryLoadingTarget[] $values() {
            return new RecoveryLoadingTarget[]{NONE, SEND, RESEND};
        }

        public static EnumEntries<RecoveryLoadingTarget> getEntries() {
            return $ENTRIES;
        }

        public static RecoveryLoadingTarget valueOf(String str) {
            return (RecoveryLoadingTarget) Enum.valueOf(RecoveryLoadingTarget.class, str);
        }

        public static RecoveryLoadingTarget[] values() {
            return (RecoveryLoadingTarget[]) $VALUES.clone();
        }

        private RecoveryLoadingTarget(String str, int i) {
        }

        static {
            RecoveryLoadingTarget[] recoveryLoadingTargetArr$values = $values();
            $VALUES = recoveryLoadingTargetArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(recoveryLoadingTargetArr$values);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$MessageTone;", "", "(Ljava/lang/String;I)V", "ERROR", "SUCCESS", "INFO", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class MessageTone {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ MessageTone[] $VALUES;
        public static final MessageTone ERROR = new MessageTone("ERROR", 0);
        public static final MessageTone SUCCESS = new MessageTone("SUCCESS", 1);
        public static final MessageTone INFO = new MessageTone("INFO", 2);

        private static final /* synthetic */ MessageTone[] $values() {
            return new MessageTone[]{ERROR, SUCCESS, INFO};
        }

        public static EnumEntries<MessageTone> getEntries() {
            return $ENTRIES;
        }

        public static MessageTone valueOf(String str) {
            return (MessageTone) Enum.valueOf(MessageTone.class, str);
        }

        public static MessageTone[] values() {
            return (MessageTone[]) $VALUES.clone();
        }

        private MessageTone(String str, int i) {
        }

        static {
            MessageTone[] messageToneArr$values = $values();
            $VALUES = messageToneArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(messageToneArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$PanelTab;", "", "(Ljava/lang/String;I)V", "SUBSCRIPTION", "IMPORTANT", "REGULAR", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class PanelTab {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ PanelTab[] $VALUES;
        public static final PanelTab SUBSCRIPTION = new PanelTab("SUBSCRIPTION", 0);
        public static final PanelTab IMPORTANT = new PanelTab("IMPORTANT", 1);
        public static final PanelTab REGULAR = new PanelTab("REGULAR", 2);

        private static final /* synthetic */ PanelTab[] $values() {
            return new PanelTab[]{SUBSCRIPTION, IMPORTANT, REGULAR};
        }

        public static EnumEntries<PanelTab> getEntries() {
            return $ENTRIES;
        }

        public static PanelTab valueOf(String str) {
            return (PanelTab) Enum.valueOf(PanelTab.class, str);
        }

        public static PanelTab[] values() {
            return (PanelTab[]) $VALUES.clone();
        }

        private PanelTab(String str, int i) {
        }

        static {
            PanelTab[] panelTabArr$values = $values();
            $VALUES = panelTabArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(panelTabArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: AccountScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountScreenView$LinkEmphasis;", "", "(Ljava/lang/String;I)V", "SOCIAL", "IMPORTANT", "REGULAR", "DANGER", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class LinkEmphasis {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ LinkEmphasis[] $VALUES;
        public static final LinkEmphasis SOCIAL = new LinkEmphasis("SOCIAL", 0);
        public static final LinkEmphasis IMPORTANT = new LinkEmphasis("IMPORTANT", 1);
        public static final LinkEmphasis REGULAR = new LinkEmphasis("REGULAR", 2);
        public static final LinkEmphasis DANGER = new LinkEmphasis("DANGER", 3);

        private static final /* synthetic */ LinkEmphasis[] $values() {
            return new LinkEmphasis[]{SOCIAL, IMPORTANT, REGULAR, DANGER};
        }

        public static EnumEntries<LinkEmphasis> getEntries() {
            return $ENTRIES;
        }

        public static LinkEmphasis valueOf(String str) {
            return (LinkEmphasis) Enum.valueOf(LinkEmphasis.class, str);
        }

        public static LinkEmphasis[] values() {
            return (LinkEmphasis[]) $VALUES.clone();
        }

        private LinkEmphasis(String str, int i) {
        }

        static {
            LinkEmphasis[] linkEmphasisArr$values = $values();
            $VALUES = linkEmphasisArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(linkEmphasisArr$values);
        }
    }
}
