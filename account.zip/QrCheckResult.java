package com.filmkio.nativescreen.account;

import androidx.core.app.NotificationCompat;
import com.filmkio.Session;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\u0002\u0010\tJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u0013\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u0014\u001a\u0004\u0018\u00010\bHÆ\u0003J7\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\bHÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00032\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u0005HÖ\u0001R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0013\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000b¨\u0006\u001b"}, m780d2 = {"Lcom/filmkio/nativescreen/account/QrCheckResult;", "", "ok", "", "message", "", NotificationCompat.CATEGORY_STATUS, "session", "Lcom/filmkio/Session;", "(ZLjava/lang/String;Ljava/lang/String;Lcom/filmkio/Session;)V", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "getSession", "()Lcom/filmkio/Session;", "getStatus", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class QrCheckResult {
    public static final int $stable = 0;
    private final String message;
    private final boolean ok;
    private final Session session;
    private final String status;

    public static /* synthetic */ QrCheckResult copy$default(QrCheckResult qrCheckResult, boolean z, String str, String str2, Session session, int i, Object obj) {
        if ((i & 1) != 0) {
            z = qrCheckResult.ok;
        }
        if ((i & 2) != 0) {
            str = qrCheckResult.message;
        }
        if ((i & 4) != 0) {
            str2 = qrCheckResult.status;
        }
        if ((i & 8) != 0) {
            session = qrCheckResult.session;
        }
        return qrCheckResult.copy(z, str, str2, session);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final boolean getOk() {
        return this.ok;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final Session getSession() {
        return this.session;
    }

    public final QrCheckResult copy(boolean ok, String message, String status, Session session) {
        return new QrCheckResult(ok, message, status, session);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QrCheckResult)) {
            return false;
        }
        QrCheckResult qrCheckResult = (QrCheckResult) other;
        return this.ok == qrCheckResult.ok && Intrinsics.areEqual(this.message, qrCheckResult.message) && Intrinsics.areEqual(this.status, qrCheckResult.status) && Intrinsics.areEqual(this.session, qrCheckResult.session);
    }

    public int hashCode() {
        int iHashCode = Boolean.hashCode(this.ok) * 31;
        String str = this.message;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.status;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        Session session = this.session;
        return iHashCode3 + (session != null ? session.hashCode() : 0);
    }

    public String toString() {
        return "QrCheckResult(ok=" + this.ok + ", message=" + this.message + ", status=" + this.status + ", session=" + this.session + ")";
    }

    public QrCheckResult(boolean z, String str, String str2, Session session) {
        this.ok = z;
        this.message = str;
        this.status = str2;
        this.session = session;
    }

    public final boolean getOk() {
        return this.ok;
    }

    public final String getMessage() {
        return this.message;
    }

    public final String getStatus() {
        return this.status;
    }

    public final Session getSession() {
        return this.session;
    }
}
