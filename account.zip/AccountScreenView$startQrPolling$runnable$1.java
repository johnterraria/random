package com.filmkio.nativescreen.account;

import android.os.Handler;
import android.widget.TextView;
import com.filmkio.Session;
import com.filmkio.nativescreen.account.AccountScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import java.util.concurrent.ExecutorService;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: AccountScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"}, m780d2 = {"com/filmkio/nativescreen/account/AccountScreenView$startQrPolling$runnable$1", "Ljava/lang/Runnable;", "run", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AccountScreenView$startQrPolling$runnable$1 implements Runnable {
    final /* synthetic */ AccountScreenView this$0;

    AccountScreenView$startQrPolling$runnable$1(AccountScreenView accountScreenView) {
        this.this$0 = accountScreenView;
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.this$0.isLoggedIn || this.this$0.guestScreen != AccountScreenView.GuestScreen.f342QR || (StringsKt.isBlank(this.this$0.qrToken) && StringsKt.isBlank(this.this$0.qrCode))) {
            this.this$0.stopQrPolling();
            return;
        }
        if (this.this$0.qrPollInFlight) {
            this.this$0.mainHandler.postDelayed(this, 5000L);
            return;
        }
        this.this$0.qrPollInFlight = true;
        ExecutorService executorService = this.this$0.executor;
        final AccountScreenView accountScreenView = this.this$0;
        executorService.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startQrPolling$runnable$1$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                AccountScreenView$startQrPolling$runnable$1.run$lambda$3(accountScreenView, this);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void run$lambda$3(final AccountScreenView this$0, final AccountScreenView$startQrPolling$runnable$1 self) {
        Handler handler;
        Runnable runnable;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(self, "$self");
        try {
            JSONObject jSONObject = new JSONObject();
            if (!StringsKt.isBlank(this$0.qrToken)) {
                jSONObject.put("token", this$0.qrToken);
            }
            if (!StringsKt.isBlank(this$0.qrCode)) {
                jSONObject.put("code", this$0.qrCode);
            }
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final QrCheckResult qrCheck = AccountParser.INSTANCE.parseQrCheck(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/qrLoginCheck", "POST", null, null, string, false, 88, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startQrPolling$runnable$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView$startQrPolling$runnable$1.run$lambda$3$lambda$1(qrCheck, this$0);
                }
            });
            handler = this$0.mainHandler;
            runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startQrPolling$runnable$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView$startQrPolling$runnable$1.run$lambda$3$lambda$2(this$0, self);
                }
            };
        } catch (Throwable unused) {
            handler = this$0.mainHandler;
            runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.AccountScreenView$startQrPolling$runnable$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    AccountScreenView$startQrPolling$runnable$1.run$lambda$3$lambda$2(this$0, self);
                }
            };
        }
        handler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void run$lambda$3$lambda$1(QrCheckResult check, AccountScreenView this$0) {
        Intrinsics.checkNotNullParameter(check, "$check");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (check.getOk() && check.getSession() != null) {
            Session session = check.getSession();
            String message = check.getMessage();
            if (message == null) {
                message = "✅ ورود با QR انجام شد";
            }
            this$0.applySession(session, message);
            return;
        }
        TextView textView = null;
        if (Intrinsics.areEqual(check.getStatus(), "expired")) {
            TextView textView2 = this$0.qrStatus;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
            } else {
                textView = textView2;
            }
            textView.setText("کد QR منقضی شد");
            this$0.loadQr();
            return;
        }
        if (Intrinsics.areEqual(check.getStatus(), "used")) {
            TextView textView3 = this$0.qrStatus;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
            } else {
                textView = textView3;
            }
            textView.setText("کد QR استفاده شد، دریافت مجدد...");
            this$0.loadQr();
            return;
        }
        if (Intrinsics.areEqual(check.getStatus(), "pending")) {
            return;
        }
        String message2 = check.getMessage();
        if (message2 == null || StringsKt.isBlank(message2)) {
            return;
        }
        TextView textView4 = this$0.qrStatus;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("qrStatus");
        } else {
            textView = textView4;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(check.getMessage(), "در انتظار تایید QR"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void run$lambda$3$lambda$2(AccountScreenView this$0, AccountScreenView$startQrPolling$runnable$1 self) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(self, "$self");
        this$0.qrPollInFlight = false;
        if (!this$0.isLoggedIn && this$0.guestScreen == AccountScreenView.GuestScreen.f342QR && this$0.qrPollRunnable == self) {
            this$0.mainHandler.postDelayed(self, 5000L);
        }
    }
}
