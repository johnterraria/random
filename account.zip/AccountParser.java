package com.filmkio.nativescreen.account;

import androidx.autofill.HintConstants;
import androidx.core.app.NotificationCompat;
import androidx.media3.extractor.text.ttml.TtmlNode;
import com.filmkio.Session;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.internal.ImagesContract;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.Constants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\u0090\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0002J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0002J\u0018\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u001f\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002¢\u0006\u0002\u0010\u0013J\u001f\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002¢\u0006\u0002\u0010\u0016J\u001a\u0010\u0017\u001a\u0004\u0018\u00010\u00102\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u001a\u0010\u0018\u001a\u0004\u0018\u00010\u00012\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u001a\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J\u000e\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u0010J\u0018\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001f0\u00042\b\u0010 \u001a\u0004\u0018\u00010\u000eH\u0002J\u0018\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\b\u0010\"\u001a\u0004\u0018\u00010#H\u0002J\u0010\u0010$\u001a\u0004\u0018\u00010%2\u0006\u0010\u001d\u001a\u00020\u0010J\u0010\u0010&\u001a\u0004\u0018\u00010'2\u0006\u0010\u001d\u001a\u00020\u0010J\u000e\u0010(\u001a\u00020)2\u0006\u0010\u001d\u001a\u00020\u0010J\u000e\u0010*\u001a\u00020+2\u0006\u0010\u001d\u001a\u00020\u0010J\u0012\u0010,\u001a\u00020\u00072\b\u0010-\u001a\u0004\u0018\u00010\u0001H\u0002J\u001e\u0010.\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00120/2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0002J\u000e\u00100\u001a\u0002012\u0006\u0010\u001d\u001a\u00020\u0010J\u000e\u00102\u001a\u0002032\u0006\u0010\u001d\u001a\u00020\u0010J&\u00104\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u000e2\f\u00105\u001a\b\u0012\u0004\u0012\u00020\u00100\u00042\u0006\u00106\u001a\u00020\u0001H\u0002J\u001a\u00107\u001a\u0004\u0018\u00010\u00102\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0002J \u00108\u001a\u0004\u0018\u00010\u00102\u0006\u0010\r\u001a\u00020\u000e2\f\u00105\u001a\b\u0012\u0004\u0012\u00020\u00100\u0004H\u0002J\u001a\u00109\u001a\u00020\u00072\b\u0010-\u001a\u0004\u0018\u00010\u00012\u0006\u00106\u001a\u00020\u0007H\u0002¨\u0006:"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountParser;", "", "()V", "defaultMenuItems", "", "Lcom/filmkio/nativescreen/account/PanelMenuItem;", "subscriberStatus", "", "mapLegacyPanelData", "Lcom/filmkio/nativescreen/account/UserPanelData;", "legacy", "Lcom/filmkio/nativescreen/account/UserData;", "optBoolAny", "obj", "Lorg/json/JSONObject;", "key", "", "optIntAny", "", "(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Integer;", "optLongAny", "", "(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;", "optStringAny", "optValue", "parseField", "Lcom/filmkio/nativescreen/account/FieldMeta;", "parseLogin", "Lcom/filmkio/nativescreen/account/LoginResult;", "json", "parseNotifications", "Lcom/filmkio/nativescreen/account/NotifItem;", "notifSection", "parsePanelItems", FirebaseAnalytics.Param.ITEMS, "Lorg/json/JSONArray;", "parsePlayset", "Lcom/filmkio/nativescreen/account/PlaySetState;", "parseQr", "Lcom/filmkio/nativescreen/account/QrData;", "parseQrCheck", "Lcom/filmkio/nativescreen/account/QrCheckResult;", "parseSimple", "Lcom/filmkio/nativescreen/account/SimpleResult;", "parseStatus", "raw", "parseSummaryMap", "", "parseUser", "Lcom/filmkio/nativescreen/account/UserResult;", "parseUserPanel", "Lcom/filmkio/nativescreen/account/UserPanelResult;", "pickAny", "keys", "fallback", "pickLabel", "pickString", "toBool", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AccountParser {
    public static final int $stable = 0;
    public static final AccountParser INSTANCE = new AccountParser();

    private AccountParser() {
    }

    public final QrData parseQr(String json) {
        Intrinsics.checkNotNullParameter(json, "json");
        try {
            JSONObject jSONObject = new JSONObject(json);
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            String strOptStringAny = optStringAny(jSONObject, ImagesContract.URL);
            if (strOptStringAny == null) {
                strOptStringAny = "";
            }
            String strOptStringAny2 = optStringAny(jSONObject, "code");
            if (strOptStringAny2 == null) {
                strOptStringAny2 = "";
            }
            String strOptStringAny3 = optStringAny(jSONObject, "token");
            String str = strOptStringAny3 != null ? strOptStringAny3 : "";
            Integer numOptIntAny = optIntAny(jSONObject, "expires_in");
            return new QrData(strOptStringAny, strOptStringAny2, str, numOptIntAny != null ? numOptIntAny.intValue() : 180);
        } catch (Throwable unused) {
            return null;
        }
    }

    public final LoginResult parseLogin(String json) {
        Intrinsics.checkNotNullParameter(json, "json");
        try {
            JSONObject jSONObject = new JSONObject(json);
            boolean zOptBoolAny = optBoolAny(jSONObject, "flag");
            String strOptStringAny = optStringAny(jSONObject, "message");
            if (!zOptBoolAny) {
                if (strOptStringAny == null) {
                    strOptStringAny = "خطا در ورود";
                }
                return new LoginResult(false, strOptStringAny, null);
            }
            Long lOptLongAny = optLongAny(jSONObject, "userID");
            long jLongValue = (lOptLongAny == null && (lOptLongAny = optLongAny(jSONObject, "user_id")) == null) ? 0L : lOptLongAny.longValue();
            String strOptStringAny2 = optStringAny(jSONObject, "session_token");
            if (strOptStringAny2 == null) {
                strOptStringAny2 = optStringAny(jSONObject, "sessionToken");
            }
            String strOptStringAny3 = optStringAny(jSONObject, "expires");
            if (jLongValue > 0) {
                String str = strOptStringAny2;
                if (!(str == null || StringsKt.isBlank(str))) {
                    return new LoginResult(true, strOptStringAny, new Session(jLongValue, strOptStringAny2, strOptStringAny3));
                }
            }
            return new LoginResult(false, "پاسخ لاگین ناقص است", null);
        } catch (Throwable unused) {
            return new LoginResult(false, "پاسخ نامعتبر است", null);
        }
    }

    public final SimpleResult parseSimple(String json) {
        Intrinsics.checkNotNullParameter(json, "json");
        try {
            JSONObject jSONObject = new JSONObject(json);
            boolean zOptBoolAny = optBoolAny(jSONObject, "flag");
            String strOptStringAny = optStringAny(jSONObject, "message");
            Long lOptLongAny = optLongAny(jSONObject, "userID");
            if (lOptLongAny == null) {
                lOptLongAny = optLongAny(jSONObject, "user_id");
            }
            return new SimpleResult(zOptBoolAny, strOptStringAny, lOptLongAny);
        } catch (Throwable unused) {
            return new SimpleResult(false, "پاسخ نامعتبر است", null);
        }
    }

    public final QrCheckResult parseQrCheck(String json) {
        String lowerCase;
        String string;
        Intrinsics.checkNotNullParameter(json, "json");
        try {
            JSONObject jSONObject = new JSONObject(json);
            boolean zOptBoolAny = optBoolAny(jSONObject, "flag");
            String strOptStringAny = optStringAny(jSONObject, "message");
            String strOptStringAny2 = optStringAny(jSONObject, NotificationCompat.CATEGORY_STATUS);
            if (strOptStringAny2 == null || (string = StringsKt.trim((CharSequence) strOptStringAny2).toString()) == null) {
                lowerCase = null;
            } else {
                lowerCase = string.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            }
            if (!zOptBoolAny) {
                return new QrCheckResult(false, strOptStringAny, lowerCase, null);
            }
            LoginResult login = parseLogin(json);
            if (login.getOk() && login.getSession() != null) {
                return new QrCheckResult(true, login.getMessage(), lowerCase, login.getSession());
            }
            return new QrCheckResult(false, strOptStringAny, lowerCase, null);
        } catch (Throwable unused) {
            return new QrCheckResult(false, "پاسخ نامعتبر است", null, null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:84:0x015a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final UserResult parseUser(String json) {
        Object value;
        Object value2;
        Object value3;
        Object value4;
        Object value5;
        Object value6;
        Boolean status;
        Intrinsics.checkNotNullParameter(json, "json");
        boolean zBooleanValue = false;
        try {
            JSONObject jSONObject = new JSONObject(json);
            if (jSONObject.has("flag") && !optBoolAny(jSONObject, "flag")) {
                String strOptStringAny = optStringAny(jSONObject, "message");
                if (strOptStringAny == null) {
                    strOptStringAny = "خطا در دریافت اطلاعات";
                }
                return new UserResult(false, strOptStringAny, null);
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            ArrayList arrayList = new ArrayList();
            List<NotifItem> listEmptyList = CollectionsKt.emptyList();
            Iterator<String> itKeys = jSONObject.keys();
            List<NotifItem> notifications = listEmptyList;
            while (true) {
                if (!itKeys.hasNext()) {
                    break;
                }
                String next = itKeys.next();
                if (Intrinsics.areEqual(next, "notifications")) {
                    Intrinsics.checkNotNull(next);
                    FieldMeta field = parseField(jSONObject, next);
                    if (field != null && (status = field.getStatus()) != null) {
                        zBooleanValue = status.booleanValue();
                    }
                    arrayList.add(new FieldItem(next, field != null ? field.getLabel() : null, null, zBooleanValue));
                    notifications = parseNotifications(jSONObject.optJSONObject("notifications"));
                } else {
                    Intrinsics.checkNotNull(next);
                    FieldMeta field2 = parseField(jSONObject, next);
                    if (field2 != null) {
                        Boolean status2 = field2.getStatus();
                        zBooleanValue = status2 != null ? status2.booleanValue() : true;
                        if (zBooleanValue) {
                            String label = field2.getLabel();
                            Object value7 = field2.getValue();
                            arrayList.add(new FieldItem(next, label, value7 != null ? value7.toString() : null, zBooleanValue));
                        }
                    }
                }
            }
            FieldMeta field3 = parseField(jSONObject, HintConstants.AUTOFILL_HINT_GENDER);
            FieldMeta field4 = parseField(jSONObject, "userName");
            if (field4 == null) {
                field4 = parseField(jSONObject, HintConstants.AUTOFILL_HINT_USERNAME);
            }
            FieldMeta field5 = parseField(jSONObject, "displayName");
            if (field5 == null) {
                field5 = parseField(jSONObject, "display_name");
            }
            FieldMeta field6 = parseField(jSONObject, "email");
            if (field6 == null) {
                field6 = parseField(jSONObject, "user_email");
            }
            FieldMeta field7 = parseField(jSONObject, "subscriberStatus");
            FieldMeta field8 = parseField(jSONObject, "expaireDayLeft");
            FieldMeta field9 = parseField(jSONObject, "expaireDate");
            String string = (field3 == null || (value6 = field3.getValue()) == null) ? null : value6.toString();
            String string2 = (field4 == null || (value5 = field4.getValue()) == null) ? null : value5.toString();
            String string3 = (field5 == null || (value4 = field5.getValue()) == null) ? null : value4.toString();
            String string4 = (field6 == null || (value3 = field6.getValue()) == null) ? null : value3.toString();
            Object value8 = field7 != null ? field7.getValue() : null;
            if (value8 instanceof Boolean) {
                zBooleanValue = ((Boolean) value8).booleanValue();
            } else if (value8 instanceof Number) {
                if (((Number) value8).intValue() != 0) {
                    zBooleanValue = true;
                }
            } else if (value8 instanceof String) {
                if (!Intrinsics.areEqual(value8, "1")) {
                    String str = (String) value8;
                    if (StringsKt.equals(str, "true", true) || StringsKt.equals(str, AppMeasurementSdk.ConditionalUserProperty.ACTIVE, true) || StringsKt.equals(str, "vip", true)) {
                    }
                }
            }
            return new UserResult(true, null, new UserData(notifications, arrayList, string, string2, string3, string4, zBooleanValue, (field8 == null || (value2 = field8.getValue()) == null) ? null : value2.toString(), (field9 == null || (value = field9.getValue()) == null) ? null : value.toString()));
        } catch (Throwable unused) {
            return new UserResult(false, "پاسخ نامعتبر است", null);
        }
    }

    public final UserPanelResult parseUserPanel(String json) {
        int iIntValue;
        Intrinsics.checkNotNullParameter(json, "json");
        int iCoerceIn = 0;
        try {
            JSONObject jSONObject = new JSONObject(json);
            if (jSONObject.has("flag") && !optBoolAny(jSONObject, "flag")) {
                String strOptStringAny = optStringAny(jSONObject, "message");
                return new UserPanelResult(false, strOptStringAny != null ? strOptStringAny : "خطا در دریافت اطلاعات پنل کاربری", null);
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            if (!(jSONObject.has("subscription") || jSONObject.has("menu") || jSONObject.has(NotificationCompat.CATEGORY_SOCIAL) || jSONObject.has("summary"))) {
                UserResult user = parseUser(json);
                if (!user.getOk() || user.getData() == null) {
                    String message = user.getMessage();
                    return new UserPanelResult(false, message != null ? message : "خطا در دریافت اطلاعات پنل کاربری", null);
                }
                return new UserPanelResult(true, null, mapLegacyPanelData(user.getData()));
            }
            JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject(Scopes.PROFILE);
            if (jSONObjectOptJSONObject2 == null) {
                jSONObjectOptJSONObject2 = jSONObject;
            }
            JSONObject jSONObjectOptJSONObject3 = jSONObject.optJSONObject("subscription");
            if (jSONObjectOptJSONObject3 == null) {
                jSONObjectOptJSONObject3 = jSONObject;
            }
            String strPickString = pickString(jSONObjectOptJSONObject2, CollectionsKt.listOf((Object[]) new String[]{"userName", HintConstants.AUTOFILL_HINT_USERNAME, "user_login"}));
            if (strPickString == null) {
                strPickString = pickString(jSONObject, CollectionsKt.listOf((Object[]) new String[]{"userName", HintConstants.AUTOFILL_HINT_USERNAME}));
            }
            String str = strPickString;
            String strPickString2 = pickString(jSONObjectOptJSONObject2, CollectionsKt.listOf((Object[]) new String[]{"displayName", "display_name", "name"}));
            String strPickString3 = strPickString2 == null ? pickString(jSONObject, CollectionsKt.listOf((Object[]) new String[]{"displayName", "display_name"})) : strPickString2;
            String strPickString4 = pickString(jSONObjectOptJSONObject2, CollectionsKt.listOf((Object[]) new String[]{"email", "user_email"}));
            if (strPickString4 == null) {
                strPickString4 = pickString(jSONObject, CollectionsKt.listOf((Object[]) new String[]{"email", "user_email"}));
            }
            String str2 = strPickString4;
            List<String> listListOf = CollectionsKt.listOf((Object[]) new String[]{"subscriberStatus", NotificationCompat.CATEGORY_STATUS});
            Object NULL = JSONObject.NULL;
            Intrinsics.checkNotNullExpressionValue(NULL, "NULL");
            boolean bool = toBool(pickAny(jSONObjectOptJSONObject3, listListOf, NULL), false);
            Integer numOptIntAny = optIntAny(jSONObjectOptJSONObject3, "dayLeft");
            if (numOptIntAny != null) {
                iIntValue = numOptIntAny.intValue();
            } else {
                Integer numOptIntAny2 = optIntAny(jSONObjectOptJSONObject3, "expaireDayLeft");
                if (numOptIntAny2 != null) {
                    iIntValue = numOptIntAny2.intValue();
                } else {
                    Integer numOptIntAny3 = optIntAny(jSONObject, "dayLeft");
                    iIntValue = (numOptIntAny3 == null && (numOptIntAny3 = optIntAny(jSONObject, "expaireDayLeft")) == null) ? 0 : numOptIntAny3.intValue();
                }
            }
            int iCoerceAtLeast = RangesKt.coerceAtLeast(iIntValue, 0);
            String strPickString5 = pickString(jSONObjectOptJSONObject3, CollectionsKt.listOf((Object[]) new String[]{"expireDate", "expaireDate"}));
            String strPickString6 = strPickString5 == null ? pickString(jSONObject, CollectionsKt.listOf((Object[]) new String[]{"expireDate", "expaireDate"})) : strPickString5;
            Integer numOptIntAny4 = optIntAny(jSONObjectOptJSONObject3, "progressPercent");
            if (numOptIntAny4 != null) {
                iCoerceIn = RangesKt.coerceIn(numOptIntAny4.intValue(), 0, 100);
            } else if (bool && iCoerceAtLeast > 0) {
                iCoerceIn = RangesKt.coerceIn((int) ((iCoerceAtLeast / 30.0f) * 100.0f), 1, 100);
            }
            int i = iCoerceIn;
            List<NotifItem> notifications = parseNotifications(jSONObject.optJSONObject("notifications"));
            Map<String, Integer> summaryMap = parseSummaryMap(jSONObject.optJSONObject("summary"));
            List<PanelMenuItem> panelItems = parsePanelItems(jSONObject.optJSONArray("menu"));
            if (panelItems.isEmpty()) {
                panelItems = INSTANCE.defaultMenuItems(bool);
            }
            return new UserPanelResult(true, null, new UserPanelData(str, strPickString3, str2, bool, iCoerceAtLeast, strPickString6, i, notifications, summaryMap, panelItems, parsePanelItems(jSONObject.optJSONArray(NotificationCompat.CATEGORY_SOCIAL))));
        } catch (Throwable unused) {
            return new UserPanelResult(false, "پاسخ نامعتبر است", null);
        }
    }

    public final PlaySetState parsePlayset(String json) {
        Intrinsics.checkNotNullParameter(json, "json");
        try {
            Object objNextValue = new JSONTokener(json).nextValue();
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject == null) {
                return null;
            }
            if (jSONObject.has("flag") && !optBoolAny(jSONObject, "flag")) {
                return null;
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("playset");
            if (jSONObjectOptJSONObject == null) {
                JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("data");
                JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optJSONObject("playset") : null;
                jSONObjectOptJSONObject = jSONObjectOptJSONObject3 == null ? jSONObject.optJSONObject("data") : jSONObjectOptJSONObject3;
            }
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            return AccountPlayset.INSTANCE.normalizePlayset(jSONObject);
        } catch (Throwable unused) {
            return null;
        }
    }

    private final String pickString(JSONObject obj, List<String> keys) {
        Iterator<String> it = keys.iterator();
        while (it.hasNext()) {
            Object objOptValue = optValue(obj, it.next());
            if (objOptValue != null && !Intrinsics.areEqual(objOptValue, JSONObject.NULL)) {
                String string = objOptValue.toString();
                if (!StringsKt.isBlank(string)) {
                    return string;
                }
            }
        }
        return null;
    }

    private final String pickLabel(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        if (!(objOpt instanceof JSONObject)) {
            return null;
        }
        String strOptString = ((JSONObject) objOpt).optString(Constants.ScionAnalytics.PARAM_LABEL);
        Intrinsics.checkNotNull(strOptString);
        if (!StringsKt.isBlank(strOptString)) {
            return strOptString;
        }
        return null;
    }

    private final FieldMeta parseField(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        Boolean boolValueOf = null;
        if (objOpt == null || Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
            return null;
        }
        if (objOpt instanceof JSONObject) {
            JSONObject jSONObject = (JSONObject) objOpt;
            String strOptString = jSONObject.optString(Constants.ScionAnalytics.PARAM_LABEL);
            Intrinsics.checkNotNull(strOptString);
            if (!(!StringsKt.isBlank(strOptString))) {
                strOptString = null;
            }
            Object objOpt2 = jSONObject.opt("value");
            Object objOpt3 = jSONObject.opt(NotificationCompat.CATEGORY_STATUS);
            if (objOpt3 instanceof Boolean) {
                boolValueOf = (Boolean) objOpt3;
            } else if (objOpt3 instanceof Number) {
                boolValueOf = Boolean.valueOf(((Number) objOpt3).intValue() != 0);
            } else if (objOpt3 instanceof String) {
                if (!Intrinsics.areEqual(objOpt3, "1")) {
                    Intrinsics.checkNotNull(objOpt3);
                    if (!StringsKt.equals((String) objOpt3, "true", true)) {
                        z = false;
                    }
                }
                boolValueOf = Boolean.valueOf(z);
            }
            return new FieldMeta(strOptString, objOpt2, boolValueOf);
        }
        return new FieldMeta(null, objOpt, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0099  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final List<NotifItem> parseNotifications(JSONObject notifSection) {
        String string;
        if (notifSection == null) {
            return CollectionsKt.emptyList();
        }
        if (!parseStatus(notifSection.opt(NotificationCompat.CATEGORY_STATUS))) {
            return CollectionsKt.emptyList();
        }
        JSONArray jSONArrayOptJSONArray = notifSection.optJSONArray(FirebaseAnalytics.Param.ITEMS);
        if (jSONArrayOptJSONArray == null) {
            return CollectionsKt.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        int length = jSONArrayOptJSONArray.length();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null && parseStatus(jSONObjectOptJSONObject.opt(NotificationCompat.CATEGORY_STATUS))) {
                String strOptString = jSONObjectOptJSONObject.optString(Constants.ScionAnalytics.PARAM_LABEL);
                Intrinsics.checkNotNull(strOptString);
                String string2 = null;
                if (!(!StringsKt.isBlank(strOptString))) {
                    strOptString = null;
                }
                Object objOpt = jSONObjectOptJSONObject.opt("value");
                if (objOpt != null && (string = objOpt.toString()) != null) {
                    string2 = StringsKt.trim((CharSequence) string).toString();
                }
                String str = strOptString;
                if (str == null || StringsKt.isBlank(str)) {
                    String str2 = string2;
                    if (!(str2 == null || StringsKt.isBlank(str2))) {
                    }
                } else {
                    arrayList.add(new NotifItem(strOptString, string2, true));
                }
            }
        }
        return arrayList;
    }

    private final Map<String, Integer> parseSummaryMap(JSONObject obj) {
        Integer numValueOf;
        if (obj == null) {
            return MapsKt.emptyMap();
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Iterator<String> itKeys = obj.keys();
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            Object objOpt = obj.opt(next);
            if (objOpt instanceof Number) {
                numValueOf = Integer.valueOf(((Number) objOpt).intValue());
            } else if (objOpt instanceof String) {
                Intrinsics.checkNotNull(objOpt);
                numValueOf = StringsKt.toIntOrNull((String) objOpt);
            } else if (objOpt instanceof Boolean) {
                Intrinsics.checkNotNull(objOpt);
                numValueOf = Integer.valueOf(((Boolean) objOpt).booleanValue() ? 1 : 0);
            } else {
                numValueOf = null;
            }
            if (numValueOf != null) {
                int iIntValue = numValueOf.intValue();
                Intrinsics.checkNotNull(next);
                linkedHashMap.put(next, Integer.valueOf(RangesKt.coerceAtLeast(iIntValue, 0)));
            }
        }
        return linkedHashMap;
    }

    private final List<PanelMenuItem> parsePanelItems(JSONArray items) {
        String str;
        String string;
        String string2;
        if (items == null) {
            return CollectionsKt.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        int length = items.length();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObjectOptJSONObject = items.optJSONObject(i);
            if (jSONObjectOptJSONObject != null && parseStatus(jSONObjectOptJSONObject.opt(NotificationCompat.CATEGORY_STATUS))) {
                String strOptString = jSONObjectOptJSONObject.optString("key");
                Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
                String string3 = StringsKt.trim((CharSequence) strOptString).toString();
                if (StringsKt.isBlank(string3)) {
                    String strOptString2 = jSONObjectOptJSONObject.optString("screen");
                    Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
                    String string4 = StringsKt.trim((CharSequence) strOptString2).toString();
                    if (StringsKt.isBlank(string4)) {
                        string4 = "item_" + i;
                    }
                    string3 = string4;
                }
                String str2 = string3;
                String strOptString3 = jSONObjectOptJSONObject.optString(Constants.ScionAnalytics.PARAM_LABEL);
                Intrinsics.checkNotNullExpressionValue(strOptString3, "optString(...)");
                String string5 = StringsKt.trim((CharSequence) strOptString3).toString();
                if (!StringsKt.isBlank(string5)) {
                    String strOptString4 = jSONObjectOptJSONObject.optString("icon");
                    Intrinsics.checkNotNullExpressionValue(strOptString4, "optString(...)");
                    String string6 = StringsKt.trim((CharSequence) strOptString4).toString();
                    if (StringsKt.isBlank(string6)) {
                        string6 = null;
                    }
                    String str3 = string6;
                    String strOptString5 = jSONObjectOptJSONObject.optString(TtmlNode.TAG_STYLE);
                    Intrinsics.checkNotNullExpressionValue(strOptString5, "optString(...)");
                    String string7 = StringsKt.trim((CharSequence) strOptString5).toString();
                    if (StringsKt.isBlank(string7)) {
                        string7 = null;
                    }
                    String str4 = string7;
                    Object objOpt = jSONObjectOptJSONObject.opt("badge");
                    if (objOpt == null || (string = objOpt.toString()) == null || (string2 = StringsKt.trim((CharSequence) string).toString()) == null) {
                        str = null;
                    } else {
                        String str5 = string2;
                        if (StringsKt.isBlank(str5)) {
                            str5 = null;
                        }
                        str = str5;
                    }
                    String strOptString6 = jSONObjectOptJSONObject.optString("screen");
                    Intrinsics.checkNotNullExpressionValue(strOptString6, "optString(...)");
                    String string8 = StringsKt.trim((CharSequence) strOptString6).toString();
                    if (StringsKt.isBlank(string8)) {
                        string8 = null;
                    }
                    String str6 = string8;
                    String strOptString7 = jSONObjectOptJSONObject.optString(ImagesContract.URL);
                    Intrinsics.checkNotNullExpressionValue(strOptString7, "optString(...)");
                    String string9 = StringsKt.trim((CharSequence) strOptString7).toString();
                    arrayList.add(new PanelMenuItem(str2, string5, str3, str4, str, str6, StringsKt.isBlank(string9) ? null : string9, true));
                }
            }
        }
        return arrayList;
    }

    private final UserPanelData mapLegacyPanelData(UserData legacy) {
        Integer intOrNull;
        String expaireDayLeft = legacy.getExpaireDayLeft();
        int iCoerceIn = 0;
        int iCoerceAtLeast = (expaireDayLeft == null || (intOrNull = StringsKt.toIntOrNull(expaireDayLeft)) == null) ? 0 : RangesKt.coerceAtLeast(intOrNull.intValue(), 0);
        if (legacy.getSubscriberStatus() && iCoerceAtLeast > 0) {
            iCoerceIn = RangesKt.coerceIn((int) ((iCoerceAtLeast / 30.0f) * 100.0f), 1, 100);
        }
        return new UserPanelData(legacy.getUserName(), legacy.getDisplayName(), legacy.getEmail(), legacy.getSubscriberStatus(), iCoerceAtLeast, legacy.getExpaireDate(), iCoerceIn, legacy.getNotifItems(), MapsKt.emptyMap(), defaultMenuItems(legacy.getSubscriberStatus()), CollectionsKt.emptyList());
    }

    private final List<PanelMenuItem> defaultMenuItems(boolean subscriberStatus) {
        PanelMenuItem[] panelMenuItemArr = new PanelMenuItem[11];
        panelMenuItemArr[0] = new PanelMenuItem("buy_subscription", subscriberStatus ? "تمدید اشتراک" : "خرید اشتراک", null, "primary", null, FirebaseAnalytics.Event.PURCHASE, null, true);
        panelMenuItemArr[1] = new PanelMenuItem("purchase_history", "سوابق خرید", null, "default", null, "purchase_history", null, true);
        panelMenuItemArr[2] = new PanelMenuItem("tickets", "تیکت ها", null, "default", null, "tickets", null, true);
        panelMenuItemArr[3] = new PanelMenuItem("watch_history", "سابقه تماشا", null, "default", null, "watch_history", null, true);
        panelMenuItemArr[4] = new PanelMenuItem("comments", "دیدگاه ها", null, "default", null, "comments", null, true);
        panelMenuItemArr[5] = new PanelMenuItem("watchlist", "لیست تماشا", null, "default", null, "watchlist", null, true);
        panelMenuItemArr[6] = new PanelMenuItem("requests", "درخواست ها", null, "default", null, "requests", null, true);
        panelMenuItemArr[7] = new PanelMenuItem("lists", "لیست ها", null, "default", null, "lists", null, true);
        panelMenuItemArr[8] = new PanelMenuItem("play_settings", "تنظیمات پخش آنلاین", null, "default", null, "play_settings", null, true);
        panelMenuItemArr[9] = new PanelMenuItem("edit_profile", "ویرایش اطلاعات", null, "default", null, "edit_profile", null, true);
        panelMenuItemArr[10] = new PanelMenuItem("logout", "خروج از حساب کاربری", null, "danger", null, "logout", null, true);
        return CollectionsKt.listOf((Object[]) panelMenuItemArr);
    }

    private final boolean parseStatus(Object raw) {
        if (raw instanceof Boolean) {
            return ((Boolean) raw).booleanValue();
        }
        if (raw instanceof Number) {
            if (((Number) raw).intValue() == 0) {
                return false;
            }
        } else if ((raw instanceof String) && !Intrinsics.areEqual(raw, "1") && !StringsKt.equals((String) raw, "true", true)) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x0043, code lost:
    
        if (kotlin.text.StringsKt.equals(r4, "vip", true) == false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:?, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0017, code lost:
    
        if (((java.lang.Number) r4).intValue() != 0) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final boolean toBool(Object raw, boolean fallback) {
        if (raw instanceof Boolean) {
            return ((Boolean) raw).booleanValue();
        }
        if (!(raw instanceof Number)) {
            if (!(raw instanceof String)) {
                return fallback;
            }
            if (!Intrinsics.areEqual(raw, "1")) {
                String str = (String) raw;
                if (!StringsKt.equals(str, "true", true)) {
                    if (!StringsKt.equals(str, AppMeasurementSdk.ConditionalUserProperty.ACTIVE, true)) {
                    }
                }
            }
            return true;
        }
    }

    private final Object pickAny(JSONObject obj, List<String> keys, Object fallback) {
        Iterator<String> it = keys.iterator();
        while (it.hasNext()) {
            Object objOptValue = optValue(obj, it.next());
            if (objOptValue != null && !Intrinsics.areEqual(objOptValue, JSONObject.NULL)) {
                return objOptValue;
            }
        }
        return fallback;
    }

    private final Object optValue(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        return objOpt instanceof JSONObject ? ((JSONObject) objOpt).opt("value") : objOpt;
    }

    private final String optStringAny(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        if (objOpt == null ? true : Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
            return null;
        }
        if (objOpt instanceof String) {
            return (String) objOpt;
        }
        if (objOpt instanceof Number) {
            return objOpt.toString();
        }
        if (!(objOpt instanceof Boolean)) {
            return objOpt.toString();
        }
        Intrinsics.checkNotNull(objOpt);
        return ((Boolean) objOpt).booleanValue() ? "1" : "0";
    }

    private final Long optLongAny(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        if (objOpt instanceof Number) {
            return Long.valueOf(((Number) objOpt).longValue());
        }
        if (objOpt instanceof String) {
            Intrinsics.checkNotNull(objOpt);
            return StringsKt.toLongOrNull((String) objOpt);
        }
        if (!(objOpt instanceof Boolean)) {
            return null;
        }
        Intrinsics.checkNotNull(objOpt);
        return Long.valueOf(((Boolean) objOpt).booleanValue() ? 1L : 0L);
    }

    private final Integer optIntAny(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        if (objOpt instanceof Number) {
            return Integer.valueOf(((Number) objOpt).intValue());
        }
        if (objOpt instanceof String) {
            Intrinsics.checkNotNull(objOpt);
            return StringsKt.toIntOrNull((String) objOpt);
        }
        if (!(objOpt instanceof Boolean)) {
            return null;
        }
        Intrinsics.checkNotNull(objOpt);
        return Integer.valueOf(((Boolean) objOpt).booleanValue() ? 1 : 0);
    }

    private final boolean optBoolAny(JSONObject obj, String key) {
        Object objOpt = obj.opt(key);
        if (objOpt instanceof Boolean) {
            Intrinsics.checkNotNull(objOpt);
            return ((Boolean) objOpt).booleanValue();
        }
        if (objOpt instanceof Number) {
            if (((Number) objOpt).intValue() == 0) {
                return false;
            }
        } else {
            if (!(objOpt instanceof String)) {
                return false;
            }
            if (!Intrinsics.areEqual(objOpt, "1")) {
                Intrinsics.checkNotNull(objOpt);
                String str = (String) objOpt;
                if (!StringsKt.equals(str, "true", true) && !StringsKt.equals(str, AppMeasurementSdk.ConditionalUserProperty.ACTIVE, true) && !StringsKt.equals(str, "vip", true)) {
                    return false;
                }
            }
        }
        return true;
    }
}
