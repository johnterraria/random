package com.filmkio.nativescreen.account;

import com.google.android.gms.common.internal.ImagesContract;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J1\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\n¨\u0006\u0019"}, m780d2 = {"Lcom/filmkio/nativescreen/account/QrData;", "", ImagesContract.URL, "", "code", "token", "expiresIn", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V", "getCode", "()Ljava/lang/String;", "getExpiresIn", "()I", "getToken", "getUrl", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class QrData {
    public static final int $stable = 0;
    private final String code;
    private final int expiresIn;
    private final String token;
    private final String url;

    public static /* synthetic */ QrData copy$default(QrData qrData, String str, String str2, String str3, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = qrData.url;
        }
        if ((i2 & 2) != 0) {
            str2 = qrData.code;
        }
        if ((i2 & 4) != 0) {
            str3 = qrData.token;
        }
        if ((i2 & 8) != 0) {
            i = qrData.expiresIn;
        }
        return qrData.copy(str, str2, str3, i);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getUrl() {
        return this.url;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getCode() {
        return this.code;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getToken() {
        return this.token;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getExpiresIn() {
        return this.expiresIn;
    }

    public final QrData copy(String url, String code, String token, int expiresIn) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(code, "code");
        Intrinsics.checkNotNullParameter(token, "token");
        return new QrData(url, code, token, expiresIn);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QrData)) {
            return false;
        }
        QrData qrData = (QrData) other;
        return Intrinsics.areEqual(this.url, qrData.url) && Intrinsics.areEqual(this.code, qrData.code) && Intrinsics.areEqual(this.token, qrData.token) && this.expiresIn == qrData.expiresIn;
    }

    public int hashCode() {
        return (((((this.url.hashCode() * 31) + this.code.hashCode()) * 31) + this.token.hashCode()) * 31) + Integer.hashCode(this.expiresIn);
    }

    public String toString() {
        return "QrData(url=" + this.url + ", code=" + this.code + ", token=" + this.token + ", expiresIn=" + this.expiresIn + ")";
    }

    public QrData(String url, String code, String token, int i) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(code, "code");
        Intrinsics.checkNotNullParameter(token, "token");
        this.url = url;
        this.code = code;
        this.token = token;
        this.expiresIn = i;
    }

    public final String getUrl() {
        return this.url;
    }

    public final String getCode() {
        return this.code;
    }

    public final String getToken() {
        return this.token;
    }

    public final int getExpiresIn() {
        return this.expiresIn;
    }
}
