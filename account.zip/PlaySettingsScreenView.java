package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.media3.extractor.text.ttml.TtmlNode;
import com.filmkio.AppState;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: PlaySettingsScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\u009c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0000\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\tJ\u0018\u00101\u001a\u00020/2\u0006\u00102\u001a\u00020/2\u0006\u00103\u001a\u00020\u0005H\u0002J\u0018\u00104\u001a\u00020\b2\u0006\u00105\u001a\u00020\u000e2\u0006\u00106\u001a\u00020\u001bH\u0002JZ\u00107\u001a\u00020\b2\u0006\u00108\u001a\u00020/2\u0006\u00109\u001a\u00020\u000b2\u0018\u0010:\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050<0;2\u0012\u0010=\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\b0>2\u0012\u0010?\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0@H\u0002J\u0010\u0010A\u001a\u00020\u000b2\u0006\u0010B\u001a\u00020\u000bH\u0002J\u0010\u0010C\u001a\u00020D2\u0006\u0010B\u001a\u00020\u000bH\u0002J\b\u0010E\u001a\u00020\bH\u0002J\b\u0010F\u001a\u00020\u001bH\u0002J\b\u0010G\u001a\u00020\bH\u0002J\u0010\u0010H\u001a\u00020\u000e2\u0006\u0010I\u001a\u00020\u0005H\u0002J\b\u0010J\u001a\u00020\bH\u0014J\u001a\u0010K\u001a\u00020\u000b2\b\u0010L\u001a\u0004\u0018\u00010\u00052\u0006\u0010M\u001a\u00020\u000bH\u0002J\u0012\u0010N\u001a\u00020\u001b2\b\u0010L\u001a\u0004\u0018\u00010\u0005H\u0002J\b\u0010O\u001a\u00020\bH\u0002J\b\u0010P\u001a\u00020\bH\u0002J(\u0010Q\u001a\u00020R2\u0006\u0010S\u001a\u00020\u000b2\u0006\u0010T\u001a\u00020\u000b2\u0006\u0010U\u001a\u00020\u000b2\u0006\u0010V\u001a\u00020DH\u0002J&\u0010W\u001a\u00020\b2\u0006\u0010X\u001a\u00020\u00052\u0006\u0010Y\u001a\u00020\u00052\f\u0010Z\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u0018\u0010[\u001a\u00020\b2\u0006\u0010I\u001a\u00020\u00052\u0006\u0010\\\u001a\u00020\u000bH\u0002J\u0010\u0010]\u001a\u00020\b2\u0006\u0010^\u001a\u00020\u0005H\u0002J(\u0010_\u001a\u00020\b2\u0006\u0010^\u001a\u00020\u00052\u0006\u0010`\u001a\u00020\u00052\u000e\u0010a\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\u0012\u0010b\u001a\u00020\u001b2\b\u0010B\u001a\u0004\u0018\u00010cH\u0002J0\u0010d\u001a\u00020R2\u0006\u0010e\u001a\u00020\u000b2\u0006\u0010f\u001a\u00020\u000b2\u0006\u0010T\u001a\u00020\u000b2\u0006\u0010U\u001a\u00020\u000b2\u0006\u0010V\u001a\u00020DH\u0002R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\f\u001a\u001e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\rj\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e`\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R*\u0010\u0014\u001a\u001e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\rj\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e`\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0015\u001a\n \u0017*\u0004\u0018\u00010\u00160\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000R*\u0010$\u001a\u001e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\rj\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e`\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010(\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010+\u001a\u001e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e0\rj\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000e`\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010,\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020/X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000¨\u0006g"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PlaySettingsScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "accent", "", "backgroundChips", "Ljava/util/LinkedHashMap;", "Landroid/widget/TextView;", "Lkotlin/collections/LinkedHashMap;", "cardFill", "cardStroke", "chipFill", "chipStroke", "colorChips", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "heroFill", "heroStroke", "isTouchDevice", "", "loading", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "playset", "Lcom/filmkio/nativescreen/account/PlaySetState;", "previewSample", "qualityChips", "saveRequestNonce", "saveStateText", "screenFill", "sessionToken", "sessionUserId", "", "sizeChips", "stateAction", "stateButton", "stateOverlay", "Landroid/widget/LinearLayout;", "stateText", "addSection", "parent", "title", "applyChipState", "chip", "selected", "buildChoiceGrid", TtmlNode.RUBY_CONTAINER, "columns", "choices", "", "Lkotlin/Pair;", "onClick", "Lkotlin/Function1;", "chipsStore", "", "dp", "v", "dpF", "", "hideState", "isLoggedIn", "loadPlayset", "makeChoiceChip", "text", "onDetachedFromWindow", "parseColorSafe", "raw", "fallback", "parseSaveOk", "renderPlayset", "renderPreview", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "savePlaysetChange", "key", "value", "rollback", "setSavingState", "color", "showShortMessage", "message", "showState", "buttonText", "action", "toBool", "", "verticalCardBg", "topColor", "bottomColor", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class PlaySettingsScreenView extends FrameLayout {
    public static final int $stable = 8;
    private final int accent;
    private final String apiBase;
    private final LinkedHashMap<String, TextView> backgroundChips;
    private final int cardFill;
    private final int cardStroke;
    private final int chipFill;
    private final int chipStroke;
    private final LinkedHashMap<String, TextView> colorChips;
    private final Context ctx;
    private final ExecutorService executor;
    private final int heroFill;
    private final int heroStroke;
    private final boolean isTouchDevice;
    private boolean loading;
    private ProgressBar loadingView;
    private final Handler mainHandler;
    private final Function0<Unit> onRequireLogin;
    private PlaySetState playset;
    private TextView previewSample;
    private final LinkedHashMap<String, TextView> qualityChips;
    private int saveRequestNonce;
    private TextView saveStateText;
    private final int screenFill;
    private String sessionToken;
    private long sessionUserId;
    private final LinkedHashMap<String, TextView> sizeChips;
    private Function0<Unit> stateAction;
    private TextView stateButton;
    private LinearLayout stateOverlay;
    private TextView stateText;

    public /* synthetic */ PlaySettingsScreenView(Context context, String str, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PlaySettingsScreenView(Context ctx, String apiBase, Function0<Unit> function0) {
        LinearLayout linearLayout;
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        this.isTouchDevice = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.accent = -676591;
        this.screenFill = -16315632;
        this.cardFill = -15920358;
        this.cardStroke = 536870911;
        this.chipFill = 252646684;
        this.chipStroke = 721420287;
        this.heroFill = 337126449;
        this.heroStroke = 1156951313;
        this.playset = AccountPlayset.INSTANCE.normalizePlayset(null);
        this.qualityChips = new LinkedHashMap<>();
        this.sizeChips = new LinkedHashMap<>();
        this.colorChips = new LinkedHashMap<>();
        this.backgroundChips = new LinkedHashMap<>();
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        ScrollView scrollView = new ScrollView(ctx);
        scrollView.setOverScrollMode(2);
        scrollView.setVerticalScrollBarEnabled(false);
        addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout2 = new LinearLayout(ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setPadding(m383dp(14), m383dp(12), m383dp(14), m383dp(96));
        scrollView.addView(linearLayout2, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout3 = new LinearLayout(ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setPadding(m383dp(12), m383dp(11), m383dp(12), m383dp(11));
        linearLayout3.setBackground(roundedBg(337126449, 1156951313, m383dp(1), dpF(14)));
        TextView textView = new TextView(ctx);
        textView.setText("تنظیمات پیش\u200cفرض پخش آنلاین");
        textView.setTextColor(-1);
        textView.setTextSize(15.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
        textView.setIncludeFontPadding(false);
        textView.setGravity(5);
        textView.setTextAlignment(5);
        TextView textView2 = new TextView(ctx);
        textView2.setText("این گزینه\u200cها هنگام باز شدن پلیر به\u200cصورت خودکار اعمال می\u200cشوند.");
        textView2.setTextColor(-4666915);
        textView2.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(ctx);
        textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
        textView2.setIncludeFontPadding(false);
        textView2.setGravity(5);
        textView2.setTextAlignment(5);
        TextView textView3 = new TextView(ctx);
        textView3.setText("هر تغییر به\u200cصورت خودکار ذخیره می\u200cشود.");
        textView3.setTextColor(-534899);
        textView3.setTextSize(11.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView3.setTypeface(typefaceMedium == null ? textView3.getTypeface() : typefaceMedium);
        textView3.setIncludeFontPadding(false);
        textView3.setGravity(5);
        textView3.setTextAlignment(5);
        textView3.setPadding(m383dp(8), m383dp(4), m383dp(8), m383dp(4));
        textView3.setBackground(roundedBg(437982216, 1173730066, m383dp(1), dpF(999)));
        this.saveStateText = textView3;
        linearLayout3.addView(textView);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m383dp(6);
        Unit unit = Unit.INSTANCE;
        linearLayout3.addView(textView2, layoutParams);
        TextView textView4 = this.saveStateText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveStateText");
            textView4 = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m383dp(6);
        Unit unit2 = Unit.INSTANCE;
        linearLayout3.addView(textView4, layoutParams2);
        linearLayout2.addView(linearLayout3);
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setPadding(m383dp(12), m383dp(12), m383dp(12), m383dp(12));
        linearLayout4.setBackground(verticalCardBg(-15656408, -15985891, 788529151, m383dp(1), dpF(14)));
        TextView textView5 = new TextView(ctx);
        textView5.setText("پیش\u200cنمایش زیرنویس");
        textView5.setTextColor(-2496779);
        textView5.setTextSize(13.0f);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(ctx);
        textView5.setTypeface(typefaceMedium2 == null ? textView5.getTypeface() : typefaceMedium2);
        textView5.setIncludeFontPadding(false);
        textView5.setGravity(5);
        textView5.setTextAlignment(5);
        FrameLayout frameLayout = new FrameLayout(ctx);
        frameLayout.setBackground(roundedBg(-16117478, 821406993, m383dp(1), dpF(10)));
        frameLayout.setPadding(m383dp(10), m383dp(10), m383dp(10), m383dp(10));
        frameLayout.setMinimumHeight(m383dp(104));
        TextView textView6 = new TextView(ctx);
        textView6.setText("این یک نمونه زیرنویس است");
        textView6.setTextColor(-1);
        textView6.setTextSize(18.0f);
        Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(ctx);
        textView6.setTypeface(typefaceBold2 == null ? textView6.getTypeface() : typefaceBold2);
        textView6.setGravity(17);
        textView6.setIncludeFontPadding(false);
        textView6.setPadding(m383dp(12), m383dp(7), m383dp(12), m383dp(7));
        textView6.setBackground(roundedBg(Integer.MIN_VALUE, 0, 0, dpF(9)));
        this.previewSample = textView6;
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        Unit unit3 = Unit.INSTANCE;
        frameLayout.addView(textView6, layoutParams3);
        linearLayout4.addView(textView5);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = m383dp(10);
        Unit unit4 = Unit.INSTANCE;
        linearLayout4.addView(frameLayout, layoutParams4);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = m383dp(10);
        Unit unit5 = Unit.INSTANCE;
        linearLayout2.addView(linearLayout4, layoutParams5);
        LinearLayout linearLayoutAddSection = addSection(linearLayout2, "کیفیت پیش\u200cفرض پخش");
        List<QualityOption> play_qualities = AccountPlayset.INSTANCE.getPLAY_QUALITIES();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(play_qualities, 10));
        for (QualityOption qualityOption : play_qualities) {
            arrayList.add(TuplesKt.m787to(String.valueOf(qualityOption.getValue()), qualityOption.getLabel()));
        }
        buildChoiceGrid(linearLayoutAddSection, 3, arrayList, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.9
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String value) {
                Intrinsics.checkNotNullParameter(value, "value");
                Integer intOrNull = StringsKt.toIntOrNull(value);
                int iIntValue = intOrNull != null ? intOrNull.intValue() : 0;
                if (PlaySettingsScreenView.this.playset.getQuality() == iIntValue) {
                    return;
                }
                final int quality = PlaySettingsScreenView.this.playset.getQuality();
                PlaySettingsScreenView playSettingsScreenView = PlaySettingsScreenView.this;
                playSettingsScreenView.playset = PlaySetState.copy$default(playSettingsScreenView.playset, iIntValue, null, null, null, 14, null);
                PlaySettingsScreenView.this.renderPlayset();
                PlaySettingsScreenView playSettingsScreenView2 = PlaySettingsScreenView.this;
                String strValueOf = String.valueOf(iIntValue);
                final PlaySettingsScreenView playSettingsScreenView3 = PlaySettingsScreenView.this;
                playSettingsScreenView2.savePlaysetChange("quality", strValueOf, new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.9.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        PlaySettingsScreenView playSettingsScreenView4 = playSettingsScreenView3;
                        playSettingsScreenView4.playset = PlaySetState.copy$default(playSettingsScreenView4.playset, quality, null, null, null, 14, null);
                        playSettingsScreenView3.renderPlayset();
                    }
                });
            }
        }, this.qualityChips);
        LinearLayout linearLayoutAddSection2 = addSection(linearLayout2, "اندازه زیرنویس");
        List<PlayOption> sub_sizes = AccountPlayset.INSTANCE.getSUB_SIZES();
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(sub_sizes, 10));
        for (PlayOption playOption : sub_sizes) {
            arrayList2.add(TuplesKt.m787to(playOption.getValue(), playOption.getLabel()));
        }
        buildChoiceGrid(linearLayoutAddSection2, 2, arrayList2, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.11
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String value) {
                Intrinsics.checkNotNullParameter(value, "value");
                if (Intrinsics.areEqual(PlaySettingsScreenView.this.playset.getSizeSubtitle(), value)) {
                    return;
                }
                final String sizeSubtitle = PlaySettingsScreenView.this.playset.getSizeSubtitle();
                PlaySettingsScreenView playSettingsScreenView = PlaySettingsScreenView.this;
                playSettingsScreenView.playset = PlaySetState.copy$default(playSettingsScreenView.playset, 0, value, null, null, 13, null);
                PlaySettingsScreenView.this.renderPlayset();
                PlaySettingsScreenView playSettingsScreenView2 = PlaySettingsScreenView.this;
                final PlaySettingsScreenView playSettingsScreenView3 = PlaySettingsScreenView.this;
                playSettingsScreenView2.savePlaysetChange("size_subtitle", value, new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.11.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        PlaySettingsScreenView playSettingsScreenView4 = playSettingsScreenView3;
                        playSettingsScreenView4.playset = PlaySetState.copy$default(playSettingsScreenView4.playset, 0, sizeSubtitle, null, null, 13, null);
                        playSettingsScreenView3.renderPlayset();
                    }
                });
            }
        }, this.sizeChips);
        LinearLayout linearLayoutAddSection3 = addSection(linearLayout2, "رنگ زیرنویس");
        List<PlayOption> sub_colors = AccountPlayset.INSTANCE.getSUB_COLORS();
        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(sub_colors, 10));
        for (PlayOption playOption2 : sub_colors) {
            arrayList3.add(TuplesKt.m787to(playOption2.getValue(), playOption2.getLabel()));
        }
        buildChoiceGrid(linearLayoutAddSection3, 2, arrayList3, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.13
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String value) {
                Intrinsics.checkNotNullParameter(value, "value");
                if (StringsKt.equals(PlaySettingsScreenView.this.playset.getColorSubtitle(), value, true)) {
                    return;
                }
                final String colorSubtitle = PlaySettingsScreenView.this.playset.getColorSubtitle();
                PlaySettingsScreenView playSettingsScreenView = PlaySettingsScreenView.this;
                playSettingsScreenView.playset = PlaySetState.copy$default(playSettingsScreenView.playset, 0, null, value, null, 11, null);
                PlaySettingsScreenView.this.renderPlayset();
                PlaySettingsScreenView playSettingsScreenView2 = PlaySettingsScreenView.this;
                final PlaySettingsScreenView playSettingsScreenView3 = PlaySettingsScreenView.this;
                playSettingsScreenView2.savePlaysetChange("color_subtitle", value, new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.13.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        PlaySettingsScreenView playSettingsScreenView4 = playSettingsScreenView3;
                        playSettingsScreenView4.playset = PlaySetState.copy$default(playSettingsScreenView4.playset, 0, null, colorSubtitle, null, 11, null);
                        playSettingsScreenView3.renderPlayset();
                    }
                });
            }
        }, this.colorChips);
        LinearLayout linearLayoutAddSection4 = addSection(linearLayout2, "پس\u200cزمینه زیرنویس");
        List<PlayOption> sub_backgrounds = AccountPlayset.INSTANCE.getSUB_BACKGROUNDS();
        ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(sub_backgrounds, 10));
        for (PlayOption playOption3 : sub_backgrounds) {
            arrayList4.add(TuplesKt.m787to(playOption3.getValue(), playOption3.getLabel()));
        }
        buildChoiceGrid(linearLayoutAddSection4, 2, arrayList4, new Function1<String, Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.15
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(String value) {
                Intrinsics.checkNotNullParameter(value, "value");
                if (Intrinsics.areEqual(PlaySettingsScreenView.this.playset.getBgSubtitle(), value)) {
                    return;
                }
                final String bgSubtitle = PlaySettingsScreenView.this.playset.getBgSubtitle();
                PlaySettingsScreenView playSettingsScreenView = PlaySettingsScreenView.this;
                playSettingsScreenView.playset = PlaySetState.copy$default(playSettingsScreenView.playset, 0, null, null, value, 7, null);
                PlaySettingsScreenView.this.renderPlayset();
                PlaySettingsScreenView playSettingsScreenView2 = PlaySettingsScreenView.this;
                final PlaySettingsScreenView playSettingsScreenView3 = PlaySettingsScreenView.this;
                playSettingsScreenView2.savePlaysetChange("bg_subtitle", value, new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.15.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        PlaySettingsScreenView playSettingsScreenView4 = playSettingsScreenView3;
                        playSettingsScreenView4.playset = PlaySetState.copy$default(playSettingsScreenView4.playset, 0, null, null, bgSubtitle, 7, null);
                        playSettingsScreenView3.renderPlayset();
                    }
                });
            }
        }, this.backgroundChips);
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
            Unit unit6 = Unit.INSTANCE;
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams6 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams6.gravity = 17;
        Unit unit7 = Unit.INSTANCE;
        addView(progressBar, layoutParams6);
        LinearLayout linearLayout5 = new LinearLayout(this.ctx);
        linearLayout5.setOrientation(1);
        linearLayout5.setLayoutDirection(1);
        linearLayout5.setGravity(17);
        linearLayout5.setVisibility(8);
        linearLayout5.setPadding(m383dp(24), m383dp(24), m383dp(24), m383dp(24));
        linearLayout5.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout5;
        TextView textView7 = new TextView(this.ctx);
        textView7.setTextColor(-419430401);
        textView7.setTextSize(15.0f);
        textView7.setGravity(17);
        Typeface typefaceMedium3 = NativeFonts.INSTANCE.medium(this.ctx);
        textView7.setTypeface(typefaceMedium3 == null ? textView7.getTypeface() : typefaceMedium3);
        textView7.setIncludeFontPadding(false);
        this.stateText = textView7;
        TextView textView8 = new TextView(this.ctx);
        textView8.setText("تلاش دوباره");
        textView8.setTextColor(-16052459);
        textView8.setTextSize(14.0f);
        textView8.setGravity(17);
        Typeface typefaceBold3 = NativeFonts.INSTANCE.bold(this.ctx);
        textView8.setTypeface(typefaceBold3 == null ? textView8.getTypeface() : typefaceBold3);
        textView8.setPadding(m383dp(16), m383dp(10), m383dp(16), m383dp(10));
        textView8.setBackground(roundedBg(this.accent, 0, 0, dpF(12)));
        textView8.setFocusable(!this.isTouchDevice);
        textView8.setFocusableInTouchMode(!this.isTouchDevice);
        textView8.setClickable(true);
        textView8.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                PlaySettingsScreenView.lambda$25$lambda$24(this.f$0, view);
            }
        });
        this.stateButton = textView8;
        LinearLayout linearLayout6 = this.stateOverlay;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout6 = null;
        }
        TextView textView9 = this.stateText;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView9 = null;
        }
        linearLayout6.addView(textView9);
        LinearLayout linearLayout7 = this.stateOverlay;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout7 = null;
        }
        TextView textView10 = this.stateButton;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView10 = null;
        }
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams7.topMargin = m383dp(12);
        Unit unit8 = Unit.INSTANCE;
        linearLayout7.addView(textView10, layoutParams7);
        LinearLayout linearLayout8 = this.stateOverlay;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        } else {
            linearLayout = linearLayout8;
        }
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        renderPlayset();
        if (!isLoggedIn()) {
            showState("برای دسترسی به تنظیمات پخش، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.22
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = PlaySettingsScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else if (StringsKt.isBlank(this.apiBase)) {
            showState("آدرس سرور در دسترس نیست.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView.23
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    PlaySettingsScreenView.this.loadPlayset();
                }
            });
        } else {
            loadPlayset();
        }
    }

    static final void lambda$25$lambda$24(PlaySettingsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.stateAction;
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final LinearLayout addSection(LinearLayout parent, String title) {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setPadding(m383dp(12), m383dp(12), m383dp(12), m383dp(12));
        linearLayout.setBackground(roundedBg(this.cardFill, this.cardStroke, m383dp(1), dpF(14)));
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-1);
        textView.setTextSize(13.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setIncludeFontPadding(false);
        textView.setGravity(5);
        textView.setTextAlignment(5);
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout.addView(textView);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m383dp(10);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(linearLayout2, layoutParams);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m383dp(10);
        Unit unit2 = Unit.INSTANCE;
        parent.addView(linearLayout, layoutParams2);
        return linearLayout2;
    }

    private final void buildChoiceGrid(LinearLayout container, int columns, List<Pair<String, String>> choices, final Function1<? super String, Unit> onClick, Map<String, TextView> chipsStore) {
        container.removeAllViews();
        chipsStore.clear();
        int i = 1;
        Iterator it = CollectionsKt.chunked(choices, Math.max(1, columns)).iterator();
        int i2 = 0;
        int i3 = 0;
        while (it.hasNext()) {
            Object next = it.next();
            int i4 = i3 + 1;
            if (i3 < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            List list = (List) next;
            LinearLayout linearLayout = new LinearLayout(this.ctx);
            linearLayout.setOrientation(i2);
            linearLayout.setLayoutDirection(i);
            linearLayout.setGravity(16);
            int i5 = i2;
            for (Object obj : list) {
                int i6 = i5 + 1;
                if (i5 < 0) {
                    CollectionsKt.throwIndexOverflow();
                }
                Pair pair = (Pair) obj;
                final String str = (String) pair.component1();
                TextView textViewMakeChoiceChip = makeChoiceChip((String) pair.component2());
                textViewMakeChoiceChip.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        PlaySettingsScreenView.buildChoiceGrid$lambda$40$lambda$36$lambda$34$lambda$33(onClick, str, view);
                    }
                });
                chipsStore.put(str, textViewMakeChoiceChip);
                TextView textView = textViewMakeChoiceChip;
                Iterator it2 = it;
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                if (i5 > 0) {
                    layoutParams.setMarginStart(m383dp(8));
                }
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(textView, layoutParams);
                i5 = i6;
                it = it2;
            }
            Iterator it3 = it;
            int iMax = Math.max(0, columns - list.size());
            int i7 = 0;
            while (i7 < iMax) {
                View view = new View(this.ctx);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, 0, 1.0f);
                layoutParams2.setMarginStart(((list.isEmpty() ^ true) || i7 > 0) ? m383dp(8) : 0);
                Unit unit2 = Unit.INSTANCE;
                linearLayout.addView(view, layoutParams2);
                i7++;
            }
            LinearLayout linearLayout2 = linearLayout;
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            if (i3 > 0) {
                layoutParams3.topMargin = m383dp(8);
            }
            Unit unit3 = Unit.INSTANCE;
            container.addView(linearLayout2, layoutParams3);
            i2 = 0;
            i3 = i4;
            i = 1;
            it = it3;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildChoiceGrid$lambda$40$lambda$36$lambda$34$lambda$33(Function1 onClick, String value, View view) {
        Intrinsics.checkNotNullParameter(onClick, "$onClick");
        Intrinsics.checkNotNullParameter(value, "$value");
        onClick.invoke(value);
    }

    private final TextView makeChoiceChip(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        textView.setMaxLines(1);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setPadding(m383dp(10), m383dp(9), m383dp(10), m383dp(9));
        textView.setBackground(roundedBg(this.chipFill, this.chipStroke, m383dp(1), dpF(11)));
        textView.setTextColor(-3614488);
        textView.setClickable(true);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(true ^ this.isTouchDevice);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void renderPlayset() {
        for (Map.Entry<String, TextView> entry : this.qualityChips.entrySet()) {
            applyChipState(entry.getValue(), Intrinsics.areEqual(entry.getKey(), String.valueOf(this.playset.getQuality())));
        }
        for (Map.Entry<String, TextView> entry2 : this.sizeChips.entrySet()) {
            applyChipState(entry2.getValue(), Intrinsics.areEqual(entry2.getKey(), this.playset.getSizeSubtitle()));
        }
        for (Map.Entry<String, TextView> entry3 : this.colorChips.entrySet()) {
            applyChipState(entry3.getValue(), StringsKt.equals(entry3.getKey(), this.playset.getColorSubtitle(), true));
        }
        for (Map.Entry<String, TextView> entry4 : this.backgroundChips.entrySet()) {
            applyChipState(entry4.getValue(), Intrinsics.areEqual(entry4.getKey(), this.playset.getBgSubtitle()));
        }
        renderPreview();
    }

    private final void renderPreview() {
        int colorSafe = parseColorSafe(this.playset.getColorSubtitle(), -1);
        int colorSafe2 = parseColorSafe(this.playset.getBgSubtitle(), 0);
        Float floatOrNull = StringsKt.toFloatOrNull(this.playset.getSizeSubtitle());
        float fMin = Math.min(30.0f, Math.max(14.0f, (floatOrNull != null ? floatOrNull.floatValue() : 28.96f) / 1.45f));
        TextView textView = this.previewSample;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("previewSample");
            textView = null;
        }
        textView.setTextColor(colorSafe);
        TextView textView3 = this.previewSample;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("previewSample");
            textView3 = null;
        }
        textView3.setTextSize(fMin);
        TextView textView4 = this.previewSample;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("previewSample");
        } else {
            textView2 = textView4;
        }
        textView2.setBackground(roundedBg(colorSafe2, 0, 0, dpF(9)));
    }

    private final void applyChipState(TextView chip, boolean selected) {
        int i = selected ? this.accent : this.chipFill;
        int i2 = selected ? ViewCompat.MEASURED_SIZE_MASK : this.chipStroke;
        int i3 = selected ? -16052459 : -3614488;
        chip.setBackground(roundedBg(i, i2, m383dp(1), dpF(11)));
        chip.setTextColor(i3);
        chip.setAlpha(selected ? 1.0f : 0.96f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void loadPlayset() {
        if (this.loading || !isLoggedIn() || StringsKt.isBlank(this.apiBase)) {
            return;
        }
        final String str = this.sessionToken;
        if (str == null) {
            str = "";
        }
        this.loading = true;
        ProgressBar progressBar = this.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(0);
        hideState();
        setSavingState("در حال دریافت تنظیمات...", -3614488);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                PlaySettingsScreenView.loadPlayset$lambda$48(str, this);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPlayset$lambda$48(String token, final PlaySettingsScreenView this$0) {
        Intrinsics.checkNotNullParameter(token, "$token");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            if (!StringsKt.isBlank(token)) {
                linkedHashMap.put("x-fk-user-id", String.valueOf(this$0.sessionUserId));
                linkedHashMap.put("x-fk-session", token);
            }
            final PlaySetState playset = AccountParser.INSTANCE.parsePlayset(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/getPlaySet", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("userId", String.valueOf(this$0.sessionUserId))), linkedHashMap, null, false, 96, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    PlaySettingsScreenView.loadPlayset$lambda$48$lambda$46(this.f$0, playset);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    PlaySettingsScreenView.loadPlayset$lambda$48$lambda$47(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPlayset$lambda$48$lambda$46(PlaySettingsScreenView this$0, PlaySetState playSetState) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loading = false;
        ProgressBar progressBar = this$0.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        if (playSetState == null) {
            this$0.setSavingState("تنظیمات پیش\u200cفرض بارگذاری شد.", -3614488);
            this$0.renderPlayset();
        } else {
            this$0.playset = playSetState;
            this$0.renderPlayset();
            this$0.setSavingState("هر تغییر به\u200cصورت خودکار ذخیره می\u200cشود.", -3614488);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPlayset$lambda$48$lambda$47(final PlaySettingsScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loading = false;
        ProgressBar progressBar = this$0.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        this$0.showState("دریافت تنظیمات پخش ناموفق بود.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$loadPlayset$1$2$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                this.this$0.loadPlayset();
            }
        });
        this$0.setSavingState("خطا در دریافت تنظیمات.", -29556);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void savePlaysetChange(final String key, final String value, final Function0<Unit> rollback) {
        if (!isLoggedIn() || StringsKt.isBlank(this.apiBase)) {
            rollback.invoke();
            showShortMessage("ذخیره تنظیمات ممکن نشد.");
            return;
        }
        String str = this.sessionToken;
        if (str == null) {
            str = "";
        }
        final String str2 = str;
        final int i = this.saveRequestNonce + 1;
        this.saveRequestNonce = i;
        setSavingState("در حال ذخیره...", -667526);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                PlaySettingsScreenView.savePlaysetChange$lambda$52(str2, this, key, value, i, rollback);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void savePlaysetChange$lambda$52(String token, final PlaySettingsScreenView this$0, String key, String value, final int i, final Function0 rollback) {
        Intrinsics.checkNotNullParameter(token, "$token");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(key, "$key");
        Intrinsics.checkNotNullParameter(value, "$value");
        Intrinsics.checkNotNullParameter(rollback, "$rollback");
        try {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            if (!StringsKt.isBlank(token)) {
                linkedHashMap.put("x-fk-user-id", String.valueOf(this$0.sessionUserId));
                linkedHashMap.put("x-fk-session", token);
            }
            LinkedHashMap linkedHashMapLinkedMapOf = MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("userId", String.valueOf(this$0.sessionUserId)));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userID", this$0.sessionUserId);
            jSONObject.put("key", key);
            jSONObject.put("value", value);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final boolean saveOk = this$0.parseSaveOk(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/SavePlaysetByKey", "POST", linkedHashMapLinkedMapOf, linkedHashMap, string, false, 64, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    PlaySettingsScreenView.savePlaysetChange$lambda$52$lambda$50(i, this$0, saveOk, rollback);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PlaySettingsScreenView$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    PlaySettingsScreenView.savePlaysetChange$lambda$52$lambda$51(i, this$0, rollback);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void savePlaysetChange$lambda$52$lambda$50(int i, PlaySettingsScreenView this$0, boolean z, Function0 rollback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(rollback, "$rollback");
        if (i != this$0.saveRequestNonce) {
            return;
        }
        if (!z) {
            rollback.invoke();
            this$0.showShortMessage("ذخیره تنظیمات ناموفق بود.");
            this$0.setSavingState("ذخیره ناموفق بود.", -29556);
            return;
        }
        this$0.setSavingState("تنظیمات ذخیره شد.", -8660834);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void savePlaysetChange$lambda$52$lambda$51(int i, PlaySettingsScreenView this$0, Function0 rollback) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(rollback, "$rollback");
        if (i != this$0.saveRequestNonce) {
            return;
        }
        rollback.invoke();
        this$0.showShortMessage("خطا در ذخیره تنظیمات.");
        this$0.setSavingState("خطا در ذخیره تنظیمات.", -29556);
    }

    private final boolean parseSaveOk(String raw) {
        String str = raw;
        boolean z = false;
        if (str == null || StringsKt.isBlank(str)) {
            return true;
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject == null) {
                return true;
            }
            List listListOf = CollectionsKt.listOf((Object[]) new String[]{"flag", NotificationCompat.CATEGORY_STATUS, FirebaseAnalytics.Param.SUCCESS});
            if (!(listListOf instanceof Collection) || !listListOf.isEmpty()) {
                Iterator it = listListOf.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    String str2 = (String) it.next();
                    if (jSONObject.has(str2) && !toBool(jSONObject.opt(str2))) {
                        z = true;
                        break;
                    }
                }
            }
            return !z;
        } catch (Throwable unused) {
            return true;
        }
    }

    private final boolean toBool(Object v) {
        if (v instanceof Boolean) {
            return ((Boolean) v).booleanValue();
        }
        if (v instanceof Number) {
            if (((Number) v).intValue() == 0) {
                return false;
            }
        } else {
            if (!(v instanceof String)) {
                return false;
            }
            if (!Intrinsics.areEqual(v, "1")) {
                String str = (String) v;
                if (!StringsKt.equals(str, "true", true) && !StringsKt.equals(str, "ok", true) && !StringsKt.equals(str, FirebaseAnalytics.Param.SUCCESS, true)) {
                    return false;
                }
            }
        }
        return true;
    }

    private final void setSavingState(String text, int color) {
        TextView textView = this.saveStateText;
        if (textView == null) {
            return;
        }
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveStateText");
            textView = null;
        }
        textView.setText(text);
        TextView textView3 = this.saveStateText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveStateText");
        } else {
            textView2 = textView3;
        }
        textView2.setTextColor(color);
    }

    private final int parseColorSafe(String raw, int fallback) {
        String string = raw != null ? StringsKt.trim((CharSequence) raw).toString() : null;
        if (string == null) {
            string = "";
        }
        if (string.length() == 0) {
            return fallback;
        }
        if (StringsKt.equals(string, "none", true)) {
            return 0;
        }
        if (StringsKt.startsWith(string, "rgba", true)) {
            List listSplit$default = StringsKt.split$default((CharSequence) StringsKt.substringBeforeLast$default(StringsKt.substringAfter$default(string, "(", (String) null, 2, (Object) null), ")", (String) null, 2, (Object) null), new String[]{","}, false, 0, 6, (Object) null);
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listSplit$default, 10));
            Iterator it = listSplit$default.iterator();
            while (it.hasNext()) {
                arrayList.add(StringsKt.trim((CharSequence) it.next()).toString());
            }
            ArrayList arrayList2 = arrayList;
            if (arrayList2.size() == 4) {
                Float floatOrNull = StringsKt.toFloatOrNull((String) arrayList2.get(0));
                float fFloatValue = floatOrNull != null ? floatOrNull.floatValue() : 0.0f;
                Float floatOrNull2 = StringsKt.toFloatOrNull((String) arrayList2.get(1));
                float fFloatValue2 = floatOrNull2 != null ? floatOrNull2.floatValue() : 0.0f;
                Float floatOrNull3 = StringsKt.toFloatOrNull((String) arrayList2.get(2));
                float fFloatValue3 = floatOrNull3 != null ? floatOrNull3.floatValue() : 0.0f;
                Float floatOrNull4 = StringsKt.toFloatOrNull((String) arrayList2.get(3));
                return Color.argb(RangesKt.coerceIn((int) ((floatOrNull4 != null ? floatOrNull4.floatValue() : 0.0f) * 255.0f), 0, 255), RangesKt.coerceIn((int) fFloatValue, 0, 255), RangesKt.coerceIn((int) fFloatValue2, 0, 255), RangesKt.coerceIn((int) fFloatValue3, 0, 255));
            }
        }
        try {
            return Color.parseColor(string);
        } catch (Throwable unused) {
            return fallback;
        }
    }

    private final void showState(String message, String buttonText, Function0<Unit> action) {
        TextView textView = this.stateText;
        LinearLayout linearLayout = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView = null;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت اطلاعات"));
        TextView textView2 = this.stateButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView2 = null;
        }
        textView2.setText(buttonText);
        this.stateAction = action;
        TextView textView3 = this.stateButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView3 = null;
        }
        textView3.setVisibility(action == null ? 8 : 0);
        LinearLayout linearLayout2 = this.stateOverlay;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
        } else {
            linearLayout = linearLayout2;
        }
        linearLayout.setVisibility(0);
    }

    private final void hideState() {
        LinearLayout linearLayout = this.stateOverlay;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        }
        linearLayout.setVisibility(8);
        this.stateAction = null;
    }

    private final boolean isLoggedIn() {
        return this.sessionUserId > 0;
    }

    private final void showShortMessage(String message) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(message, "عملیات انجام نشد"), 0).show();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }

    private final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        if (strokeWidth > 0) {
            gradientDrawable.setStroke(strokeWidth, stroke);
        }
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    private final GradientDrawable verticalCardBg(int topColor, int bottomColor, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{topColor, bottomColor});
        if (strokeWidth > 0) {
            gradientDrawable.setStroke(strokeWidth, stroke);
        }
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: renamed from: dp */
    private final int m383dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    private final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }
}
