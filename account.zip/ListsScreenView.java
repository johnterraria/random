package com.filmkio.nativescreen.account;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.app.NotificationCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import coil.ImageLoader;
import coil.request.ImageRequest;
import com.filmkio.AppState;
import com.filmkio.C2629R;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.NativeImageLoader;
import com.filmkio.nativescreen.account.ListsScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.nativescreen.querygrid.QueryItem;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.Constants;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: ListsScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000¦\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0011\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b&\b\u0007\u0018\u0000 Ý\u00012\u00020\u0001:\u0014Ý\u0001Þ\u0001ß\u0001à\u0001á\u0001â\u0001ã\u0001ä\u0001å\u0001æ\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007\u0012\u0016\b\u0002\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\b\u0018\u00010\n¢\u0006\u0002\u0010\fJ\u0010\u0010f\u001a\u00020\b2\u0006\u0010g\u001a\u00020CH\u0002J&\u0010h\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u00050i2\u0006\u0010j\u001a\u00020\u000b2\u0006\u0010k\u001a\u00020\u000bH\u0002J\u0010\u0010l\u001a\u00020\b2\u0006\u0010m\u001a\u00020,H\u0002J\b\u0010n\u001a\u00020\bH\u0002J\u0014\u0010o\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050pH\u0002J\b\u0010q\u001a\u00020\bH\u0002J\b\u0010r\u001a\u00020\bH\u0002J\b\u0010s\u001a\u00020\bH\u0002J\b\u0010t\u001a\u00020\bH\u0002J\u001e\u0010u\u001a\u0004\u0018\u00010\u00052\b\u0010v\u001a\u0004\u0018\u00010\u00052\b\u0010w\u001a\u0004\u0018\u00010\u0005H\u0002J\u0010\u0010x\u001a\u00020\b2\u0006\u0010y\u001a\u00020\u0005H\u0002J\u0010\u0010z\u001a\u00020\b2\u0006\u0010{\u001a\u00020\u0010H\u0002J\"\u0010|\u001a\u0004\u0018\u00010\u00102\u0006\u0010}\u001a\u00020\u00052\u0006\u0010~\u001a\u00020\u00052\u0006\u0010\u007f\u001a\u00020\\H\u0002J\u0011\u0010\u0080\u0001\u001a\u00020\b2\u0006\u0010{\u001a\u00020\u0010H\u0002J\u001f\u0010\u0081\u0001\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u00050i2\u0006\u0010j\u001a\u00020\u000bH\u0002J\u0012\u0010\u0082\u0001\u001a\u00020\u000e2\u0007\u0010\u0083\u0001\u001a\u00020\u000eH\u0002J\u0012\u0010\u0084\u0001\u001a\u00020\u00152\u0007\u0010\u0083\u0001\u001a\u00020\u000eH\u0002J\u0018\u0010\u0085\u0001\u001a\u0005\u0018\u00010\u0086\u00012\n\u0010\u0087\u0001\u001a\u0005\u0018\u00010\u0088\u0001H\u0002J\u0007\u0010\u0089\u0001\u001a\u00020\u0018J'\u0010\u008a\u0001\u001a\u00020\b2\t\b\u0002\u0010\u008b\u0001\u001a\u00020\u00182\u0011\b\u0002\u0010\u008c\u0001\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\t\u0010\u008d\u0001\u001a\u00020\bH\u0002J\t\u0010\u008e\u0001\u001a\u00020\u0018H\u0002J\u0011\u0010\u008f\u0001\u001a\u00020\b2\u0006\u0010j\u001a\u00020\u000bH\u0002J\u001b\u0010\u0090\u0001\u001a\u00020\b2\u0007\u0010\u0091\u0001\u001a\u00020\u000e2\u0007\u0010\u0092\u0001\u001a\u00020\u0018H\u0002J\u0012\u0010\u0093\u0001\u001a\u00020$2\u0007\u0010\u0094\u0001\u001a\u00020\u0005H\u0002J\t\u0010\u0095\u0001\u001a\u00020\u0001H\u0002J!\u0010\u0096\u0001\u001a\u00020$2\u0007\u0010\u0097\u0001\u001a\u00020\u00052\r\u0010\u0098\u0001\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\t\u0010\u0099\u0001\u001a\u00020\bH\u0002J\u0014\u0010\u009a\u0001\u001a\u00020\u00052\t\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u0005H\u0002J\u0016\u0010\u009c\u0001\u001a\u0005\u0018\u00010\u0086\u00012\b\u0010\u009d\u0001\u001a\u00030\u009e\u0001H\u0002J\t\u0010\u009f\u0001\u001a\u00020\bH\u0014J\t\u0010 \u0001\u001a\u00020\bH\u0002J\u0011\u0010¡\u0001\u001a\u00020\b2\u0006\u0010{\u001a\u00020\u0010H\u0002J\u001a\u0010¢\u0001\u001a\u00020\b2\u0006\u0010{\u001a\u00020\u00102\u0007\u0010£\u0001\u001a\u00020\u0018H\u0002J7\u0010¤\u0001\u001a\u001a\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0007\u0012\u0005\u0018\u00010\u009e\u00010¥\u00012\t\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u00052\t\b\u0002\u0010¦\u0001\u001a\u00020\u0005H\u0002J\u001d\u0010§\u0001\u001a\u0004\u0018\u00010\u000e2\n\u0010\u009b\u0001\u001a\u0005\u0018\u00010\u0088\u0001H\u0002¢\u0006\u0003\u0010¨\u0001J\u001b\u0010©\u0001\u001a\t\u0012\u0004\u0012\u00020C0ª\u00012\t\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u0005H\u0002J\u001b\u0010«\u0001\u001a\t\u0012\u0004\u0012\u00020\u00100ª\u00012\t\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u0005H\u0002J\u001b\u0010¬\u0001\u001a\n\u0012\u0005\u0012\u00030®\u00010\u00ad\u00012\b\u0010¯\u0001\u001a\u00030\u009e\u0001H\u0002J\u001b\u0010°\u0001\u001a\t\u0012\u0004\u0012\u00020C0ª\u00012\t\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u0005H\u0002J\u0012\u0010±\u0001\u001a\u00020\b2\u0007\u0010²\u0001\u001a\u00020\u0005H\u0002J3\u0010³\u0001\u001a\u0004\u0018\u00010\u00052\n\u0010\u009d\u0001\u001a\u0005\u0018\u00010\u009e\u00012\u0014\u0010´\u0001\u001a\u000b\u0012\u0006\b\u0001\u0012\u00020\u00050µ\u0001\"\u00020\u0005H\u0002¢\u0006\u0003\u0010¶\u0001J\u0011\u0010·\u0001\u001a\u00020\b2\u0006\u0010g\u001a\u00020CH\u0002J'\u0010¸\u0001\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u00050i2\u0006\u0010j\u001a\u00020\u000b2\u0006\u0010k\u001a\u00020\u000bH\u0002J]\u0010¹\u0001\u001a\u00020\u00052\u000e\u0010º\u0001\u001a\t\u0012\u0004\u0012\u00020\u00050\u00ad\u00012\u0007\u0010»\u0001\u001a\u00020\u00052\u0015\b\u0002\u0010²\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050p2\u0015\b\u0002\u0010¼\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050p2\u000b\b\u0002\u0010½\u0001\u001a\u0004\u0018\u00010\u0005H\u0002J\t\u0010¾\u0001\u001a\u00020\bH\u0002J\t\u0010¿\u0001\u001a\u00020\u000eH\u0002J.\u0010À\u0001\u001a\u00030Á\u00012\u0007\u0010Â\u0001\u001a\u00020\u000e2\u0007\u0010Ã\u0001\u001a\u00020\u000e2\u0007\u0010Ä\u0001\u001a\u00020\u000e2\u0007\u0010Å\u0001\u001a\u00020\u0015H\u0002J\t\u0010Æ\u0001\u001a\u00020\bH\u0002J\u0012\u0010Ç\u0001\u001a\u00020\b2\u0007\u0010È\u0001\u001a\u00020\u0018H\u0002J\u0012\u0010É\u0001\u001a\u00020\b2\u0007\u0010È\u0001\u001a\u00020\u0018H\u0002J\u0012\u0010Ê\u0001\u001a\u00020\b2\u0007\u0010Ë\u0001\u001a\u00020/H\u0002J-\u0010Ì\u0001\u001a\u00020\b2\u0006\u0010y\u001a\u00020\u00052\t\u0010Í\u0001\u001a\u0004\u0018\u00010\u00052\u000f\u0010Î\u0001\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\u0012\u0010Ï\u0001\u001a\u00020\b2\u0007\u0010\u0094\u0001\u001a\u00020\u0005H\u0002J\t\u0010Ð\u0001\u001a\u00020\bH\u0002J\u0012\u0010Ñ\u0001\u001a\u00020\b2\u0007\u0010Ò\u0001\u001a\u00020/H\u0002J\u0012\u0010Ó\u0001\u001a\u00020\b2\u0007\u0010Ô\u0001\u001a\u00020\u0010H\u0002J\u0015\u0010Õ\u0001\u001a\u00020\u00182\n\u0010\u0083\u0001\u001a\u0005\u0018\u00010\u0088\u0001H\u0002J\u001d\u0010Ö\u0001\u001a\u0004\u0018\u00010\u000e2\n\u0010\u0083\u0001\u001a\u0005\u0018\u00010\u0088\u0001H\u0002¢\u0006\u0003\u0010¨\u0001J\u001d\u0010×\u0001\u001a\u0004\u0018\u00010\u000b2\n\u0010\u0083\u0001\u001a\u0005\u0018\u00010\u0088\u0001H\u0002¢\u0006\u0003\u0010Ø\u0001J\t\u0010Ù\u0001\u001a\u00020\bH\u0002J\t\u0010Ú\u0001\u001a\u00020\bH\u0002JA\u0010Û\u0001\u001a\u001a\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0007\u0012\u0005\u0018\u00010\u009e\u00010¥\u00012\u0006\u0010j\u001a\u00020\u000b2\u0006\u0010}\u001a\u00020\u00052\u0006\u0010~\u001a\u00020\u00052\u0006\u0010\u007f\u001a\u00020\\H\u0002J\t\u0010Ü\u0001\u001a\u00020\bH\u0002R\u000e\u0010\r\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u001aX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010&\u001a\n (*\u0004\u0018\u00010'0'X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020/X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020,X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u000204X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u00106\u001a\u000607R\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010>\u001a\u00060?R\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u001aX\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010A\u001a\u0012\u0012\u0004\u0012\u00020C0Bj\b\u0012\u0004\u0012\u00020C`DX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010H\u001a\u0012\u0012\u0004\u0012\u00020\u00100Bj\b\u0012\u0004\u0012\u00020\u0010`DX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020LX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020/X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\b\u0018\u00010\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010O\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010P\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010Q\u001a\u0004\u0018\u00010RX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010S\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010T\u001a\u00020,X\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010U\u001a\u0012\u0012\u0004\u0012\u00020C0Bj\b\u0012\u0004\u0012\u00020C`DX\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010V\u001a\u00060WR\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010X\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010Y\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010Z\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010[\u001a\u00020\\X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010]\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010^\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010_\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010`\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010a\u001a\u00020\u001aX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010b\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010c\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010d\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010e\u001a\u00020$X\u0082.¢\u0006\u0002\n\u0000¨\u0006ç\u0001"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "onOpenSingle", "Lkotlin/Function1;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V", "accent", "", "activeList", "Lcom/filmkio/nativescreen/account/ListsScreenView$UserList;", "cardFill", "cardStroke", "createContainer", "createDragStartRawY", "", "createDragStartTranslation", "createMode", "", "createSheetCard", "Landroid/widget/LinearLayout;", "createSheetScrim", "Landroid/view/View;", "createSheetShown", "currentPage", "deletingList", "editInfoContainer", "Landroid/widget/ScrollView;", "editItemsContainer", "editItemsHeaderMeta", "Landroid/widget/TextView;", "editItemsHeaderTitle", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "fieldFill", "fieldStroke", "formDescInput", "Landroidx/appcompat/widget/AppCompatEditText;", "formEditItemsButton", "formReturnMode", "Lcom/filmkio/nativescreen/account/ListsScreenView$Mode;", "formSubmitButton", "formTitleInput", "hasMore", "imageLoader", "Lcoil/ImageLoader;", "isTouchDevice", "itemsAdapter", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListItemsAdapter;", "itemsEmptyText", "itemsLoading", "Landroid/widget/ProgressBar;", "itemsRecycler", "Landroidx/recyclerview/widget/RecyclerView;", "lastSearchQuery", "listAdapter", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListsAdapter;", "listContainer", "listItems", "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/querygrid/QueryItem;", "Lkotlin/collections/ArrayList;", "listLoading", "listLoadingMoreOverlay", "listRecycler", "lists", "loadingListItems", "loadingLists", "mainHandler", "Landroid/os/Handler;", "mode", "mutatingItem", "pendingSearchQuery", "screenFill", "searchDebounceRunnable", "Ljava/lang/Runnable;", "searchEmptyText", "searchInput", "searchItems", "searchResultsAdapter", "Lcom/filmkio/nativescreen/account/ListsScreenView$SearchResultAdapter;", "searchResultsLoading", "searchResultsRecycler", "searching", "selectedListType", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;", "sessionToken", "sessionUserId", "stateAction", "stateButton", "stateOverlay", "stateText", "submittingInfo", "typeMovieChip", "typeSeriesChip", "addItemToActiveList", "item", "addListItemRequest", "Lkotlin/Pair;", "listId", "itemId", "applyFieldStyle", "field", "applyTypeChipState", "authHeaders", "", "buildCreateContainer", "buildEditInfoContainer", "buildEditItemsContainer", "buildListContainer", "buildSubtitle", "release", "imdb", "clearSearchResults", "message", "confirmDeleteList", "list", "createListRequest", "title", "description", "type", "deleteList", "deleteListRequest", "dp", "v", "dpF", "extractArray", "Lorg/json/JSONArray;", "root", "", "handleBackPressed", "hideCreateSheet", "animated", "onHidden", "hideState", "isLoggedIn", "loadListItems", "loadLists", "page", "reset", "makeFieldLabel", "text", "makeLoadingMoreOverlay", "makeTypeChip", Constants.ScionAnalytics.PARAM_LABEL, "onClick", "maybeLoadNextLists", "normalizeSearchQuery", "raw", "numericObjectToArray", "obj", "Lorg/json/JSONObject;", "onDetachedFromWindow", "openCreateForm", "openEditInfoForm", "openEditItems", "loadFromServer", "parseActionResponse", "Lkotlin/Triple;", "successKey", "parseListItemsCount", "(Ljava/lang/Object;)Ljava/lang/Integer;", "parseListItemsResponse", "Lcom/filmkio/nativescreen/account/ListsScreenView$ParseResult;", "parseListsResponse", "parsePreviewItems", "", "Lcom/filmkio/nativescreen/account/ListsScreenView$PreviewItem;", "row", "parseQueryResponse", "performSearch", SearchIntents.EXTRA_QUERY, "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "removeItemFromActiveList", "removeListItemRequest", "requestWithFallback", "endpointPaths", FirebaseAnalytics.Param.METHOD, "headers", "bodyJson", "resetAndLoadLists", "resolveCreateSheetHeight", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "scheduleSearchFromInput", "setFormSubmitting", "loading", "setSearchLoading", "showCreateSheet", "returnMode", "showState", "buttonText", "action", "showToast", "submitListInfo", "switchMode", "next", "syncList", "updated", "toBool", "toInt", "toLong", "(Ljava/lang/Object;)Ljava/lang/Long;", "triggerSearchNow", "updateEditItemsHeader", "updateListInfoRequest", "updateSearchItemState", "Companion", "GridSpacingDecoration", "ListItemsAdapter", "ListType", "ListsAdapter", "Mode", "ParseResult", "PreviewItem", "SearchResultAdapter", "UserList", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class ListsScreenView extends FrameLayout {
    private static final int LISTS_PER_PAGE = 12;
    private final int accent;
    private UserList activeList;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private FrameLayout createContainer;
    private float createDragStartRawY;
    private float createDragStartTranslation;
    private boolean createMode;
    private LinearLayout createSheetCard;
    private View createSheetScrim;
    private boolean createSheetShown;
    private final Context ctx;
    private int currentPage;
    private boolean deletingList;
    private ScrollView editInfoContainer;
    private LinearLayout editItemsContainer;
    private TextView editItemsHeaderMeta;
    private TextView editItemsHeaderTitle;
    private final ExecutorService executor;
    private final int fieldFill;
    private final int fieldStroke;
    private AppCompatEditText formDescInput;
    private TextView formEditItemsButton;
    private Mode formReturnMode;
    private TextView formSubmitButton;
    private AppCompatEditText formTitleInput;
    private boolean hasMore;
    private final ImageLoader imageLoader;
    private final boolean isTouchDevice;
    private ListItemsAdapter itemsAdapter;
    private TextView itemsEmptyText;
    private ProgressBar itemsLoading;
    private RecyclerView itemsRecycler;
    private String lastSearchQuery;
    private ListsAdapter listAdapter;
    private LinearLayout listContainer;
    private final ArrayList<QueryItem> listItems;
    private ProgressBar listLoading;
    private FrameLayout listLoadingMoreOverlay;
    private RecyclerView listRecycler;
    private final ArrayList<UserList> lists;
    private boolean loadingListItems;
    private boolean loadingLists;
    private final Handler mainHandler;
    private Mode mode;
    private boolean mutatingItem;
    private final Function1<Long, Unit> onOpenSingle;
    private final Function0<Unit> onRequireLogin;
    private String pendingSearchQuery;
    private final int screenFill;
    private Runnable searchDebounceRunnable;
    private TextView searchEmptyText;
    private AppCompatEditText searchInput;
    private final ArrayList<QueryItem> searchItems;
    private SearchResultAdapter searchResultsAdapter;
    private ProgressBar searchResultsLoading;
    private RecyclerView searchResultsRecycler;
    private boolean searching;
    private ListType selectedListType;
    private String sessionToken;
    private long sessionUserId;
    private Function0<Unit> stateAction;
    private TextView stateButton;
    private LinearLayout stateOverlay;
    private TextView stateText;
    private boolean submittingInfo;
    private TextView typeMovieChip;
    private TextView typeSeriesChip;
    public static final int $stable = 8;

    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Mode.values().length];
            try {
                iArr[Mode.EDIT_ITEMS.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Mode.LIST.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$43$lambda$42(View view) {
    }

    public /* synthetic */ ListsScreenView(Context context, String str, Function0 function0, Function1 function1, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0, (i & 8) != 0 ? null : function1);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public ListsScreenView(Context ctx, String apiBase, Function0<Unit> function0, Function1<? super Long, Unit> function1) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.onOpenSingle = function1;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.imageLoader = NativeImageLoader.INSTANCE.get(ctx);
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.screenFill = -16315632;
        this.fieldFill = -15854306;
        this.fieldStroke = 860772969;
        this.mode = Mode.LIST;
        this.currentPage = 1;
        this.hasMore = true;
        this.lastSearchQuery = "";
        this.lists = new ArrayList<>();
        this.listItems = new ArrayList<>();
        this.searchItems = new ArrayList<>();
        this.createMode = true;
        this.selectedListType = ListType.MOVIES;
        this.formReturnMode = Mode.LIST;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        FrameLayout frameLayout = null;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setPadding(m381dp(14), m381dp(10), m381dp(14), m381dp(10));
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout2 = new FrameLayout(ctx);
        frameLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        linearLayout.addView(frameLayout2);
        buildListContainer();
        buildEditInfoContainer();
        buildCreateContainer();
        buildEditItemsContainer();
        LinearLayout linearLayout2 = this.listContainer;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout2 = null;
        }
        frameLayout2.addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout3 = this.editItemsContainer;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout3 = null;
        }
        frameLayout2.addView(linearLayout3, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setGravity(17);
        linearLayout4.setVisibility(8);
        linearLayout4.setPadding(m381dp(24), m381dp(24), m381dp(24), m381dp(24));
        linearLayout4.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout4;
        TextView textView = new TextView(ctx);
        textView.setTextColor(-419430401);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        this.stateText = textView;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-16052459);
        textView2.setTextSize(14.0f);
        textView2.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView2.setTypeface(typefaceBold == null ? textView2.getTypeface() : typefaceBold);
        textView2.setPadding(m381dp(16), m381dp(10), m381dp(16), m381dp(10));
        textView2.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView2.setFocusable(!zHasSystemFeature);
        textView2.setFocusableInTouchMode(!zHasSystemFeature);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda30
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.lambda$6$lambda$5(this.f$0, view);
            }
        });
        this.stateButton = textView2;
        LinearLayout linearLayout5 = this.stateOverlay;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout5 = null;
        }
        TextView textView3 = this.stateText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView3 = null;
        }
        linearLayout5.addView(textView3);
        LinearLayout linearLayout6 = this.stateOverlay;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout6 = null;
        }
        TextView textView4 = this.stateButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView4 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = m381dp(12);
        Unit unit = Unit.INSTANCE;
        linearLayout6.addView(textView4, layoutParams);
        LinearLayout linearLayout7 = this.stateOverlay;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout7 = null;
        }
        frameLayout2.addView(linearLayout7, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
        } else {
            frameLayout = frameLayout3;
        }
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        switchMode(Mode.LIST);
        if (!isLoggedIn()) {
            showState("برای مدیریت لیست\u200cها ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.5
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = ListsScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else {
            resetAndLoadLists();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$Mode;", "", "(Ljava/lang/String;I)V", "LIST", "EDIT_ITEMS", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class Mode {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ Mode[] $VALUES;
        public static final Mode LIST = new Mode("LIST", 0);
        public static final Mode EDIT_ITEMS = new Mode("EDIT_ITEMS", 1);

        private static final /* synthetic */ Mode[] $values() {
            return new Mode[]{LIST, EDIT_ITEMS};
        }

        public static EnumEntries<Mode> getEntries() {
            return $ENTRIES;
        }

        public static Mode valueOf(String str) {
            return (Mode) Enum.valueOf(Mode.class, str);
        }

        public static Mode[] values() {
            return (Mode[]) $VALUES.clone();
        }

        private Mode(String str, int i) {
        }

        static {
            Mode[] modeArr$values = $values();
            $VALUES = modeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(modeArr$values);
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000b\b\u0082\u0081\u0002\u0018\u0000 \r2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\rB\u001f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\bj\u0002\b\u000bj\u0002\b\f¨\u0006\u000e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;", "", "raw", "", Constants.ScionAnalytics.PARAM_LABEL, "queryPostType", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getLabel", "()Ljava/lang/String;", "getQueryPostType", "getRaw", "MOVIES", "SERIES", "Companion", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class ListType {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ ListType[] $VALUES;

        /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
        public static final Companion INSTANCE;
        public static final ListType MOVIES = new ListType("MOVIES", 0, "movies", "فیلم", "post");
        public static final ListType SERIES = new ListType("SERIES", 1, "series", "سریال", "series");
        private final String label;
        private final String queryPostType;
        private final String raw;

        private static final /* synthetic */ ListType[] $values() {
            return new ListType[]{MOVIES, SERIES};
        }

        public static EnumEntries<ListType> getEntries() {
            return $ENTRIES;
        }

        public static ListType valueOf(String str) {
            return (ListType) Enum.valueOf(ListType.class, str);
        }

        public static ListType[] values() {
            return (ListType[]) $VALUES.clone();
        }

        private ListType(String str, int i, String str2, String str3, String str4) {
            this.raw = str2;
            this.label = str3;
            this.queryPostType = str4;
        }

        public final String getRaw() {
            return this.raw;
        }

        public final String getLabel() {
            return this.label;
        }

        public final String getQueryPostType() {
            return this.queryPostType;
        }

        static {
            ListType[] listTypeArr$values = $values();
            $VALUES = listTypeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(listTypeArr$values);
            INSTANCE = new Companion(null);
        }

        /* JADX INFO: compiled from: ListsScreenView.kt */
        @Metadata(m779d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006¨\u0006\u0007"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListType$Companion;", "", "()V", "fromRaw", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;", "raw", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            public final ListType fromRaw(String raw) {
                String lowerCase;
                String string;
                if (raw == null || (string = StringsKt.trim((CharSequence) raw).toString()) == null) {
                    lowerCase = null;
                } else {
                    Locale US = Locale.US;
                    Intrinsics.checkNotNullExpressionValue(US, "US");
                    lowerCase = string.toLowerCase(US);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                }
                if (lowerCase == null) {
                    lowerCase = "";
                }
                if (Intrinsics.areEqual(lowerCase, ListType.SERIES.getRaw()) || StringsKt.contains$default((CharSequence) lowerCase, (CharSequence) "series", false, 2, (Object) null)) {
                    return ListType.SERIES;
                }
                return ListType.MOVIES;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B5\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\u0002\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0004HÆ\u0003J\u000b\u0010\u0015\u001a\u0004\u0018\u00010\u0006HÆ\u0003J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00028\u00000\bHÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\nHÆ\u0003JA\u0010\u0018\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\nHÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u00042\b\u0010\u001a\u001a\u0004\u0018\u00010\u0002HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u0006HÖ\u0001R\u0013\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u001e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ParseResult;", ExifInterface.GPS_DIRECTION_TRUE, "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "extra", "Lorg/json/JSONObject;", "(ZLjava/lang/String;Ljava/util/List;Lorg/json/JSONObject;)V", "getExtra", "()Lorg/json/JSONObject;", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ParseResult<T> {
        private final JSONObject extra;
        private final List<T> items;
        private final String message;
        private final boolean ok;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, boolean z, String str, List list, JSONObject jSONObject, int i, Object obj) {
            if ((i & 1) != 0) {
                z = parseResult.ok;
            }
            if ((i & 2) != 0) {
                str = parseResult.message;
            }
            if ((i & 4) != 0) {
                list = parseResult.items;
            }
            if ((i & 8) != 0) {
                jSONObject = parseResult.extra;
            }
            return parseResult.copy(z, str, list, jSONObject);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<T> component3() {
            return this.items;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final JSONObject getExtra() {
            return this.extra;
        }

        public final ParseResult<T> copy(boolean ok, String message, List<? extends T> items, JSONObject extra) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new ParseResult<>(ok, message, items, extra);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return this.ok == parseResult.ok && Intrinsics.areEqual(this.message, parseResult.message) && Intrinsics.areEqual(this.items, parseResult.items) && Intrinsics.areEqual(this.extra, parseResult.extra);
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            int iHashCode2 = (((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode()) * 31;
            JSONObject jSONObject = this.extra;
            return iHashCode2 + (jSONObject != null ? jSONObject.hashCode() : 0);
        }

        public String toString() {
            return "ParseResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ", extra=" + this.extra + ")";
        }

        /* JADX WARN: Multi-variable type inference failed */
        public ParseResult(boolean z, String str, List<? extends T> items, JSONObject jSONObject) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
            this.extra = jSONObject;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public /* synthetic */ ParseResult(boolean z, String str, List list, JSONObject jSONObject, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(z, (i & 2) != 0 ? null : str, (i & 4) != 0 ? CollectionsKt.emptyList() : list, (i & 8) != 0 ? null : jSONObject);
        }

        public final List<T> getItems() {
            return this.items;
        }

        public final JSONObject getExtra() {
            return this.extra;
        }
    }

    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0005HÆ\u0003J)\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000b¨\u0006\u0017"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$PreviewItem;", "", TtmlNode.ATTR_ID, "", "title", "", "poster", "(JLjava/lang/String;Ljava/lang/String;)V", "getId", "()J", "getPoster", "()Ljava/lang/String;", "getTitle", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class PreviewItem {
        private final long id;
        private final String poster;
        private final String title;

        public static /* synthetic */ PreviewItem copy$default(PreviewItem previewItem, long j, String str, String str2, int i, Object obj) {
            if ((i & 1) != 0) {
                j = previewItem.id;
            }
            if ((i & 2) != 0) {
                str = previewItem.title;
            }
            if ((i & 4) != 0) {
                str2 = previewItem.poster;
            }
            return previewItem.copy(j, str, str2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getTitle() {
            return this.title;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getPoster() {
            return this.poster;
        }

        public final PreviewItem copy(long id, String title, String poster) {
            Intrinsics.checkNotNullParameter(title, "title");
            return new PreviewItem(id, title, poster);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PreviewItem)) {
                return false;
            }
            PreviewItem previewItem = (PreviewItem) other;
            return this.id == previewItem.id && Intrinsics.areEqual(this.title, previewItem.title) && Intrinsics.areEqual(this.poster, previewItem.poster);
        }

        public int hashCode() {
            int iHashCode = ((Long.hashCode(this.id) * 31) + this.title.hashCode()) * 31;
            String str = this.poster;
            return iHashCode + (str == null ? 0 : str.hashCode());
        }

        public String toString() {
            return "PreviewItem(id=" + this.id + ", title=" + this.title + ", poster=" + this.poster + ")";
        }

        public PreviewItem(long j, String title, String str) {
            Intrinsics.checkNotNullParameter(title, "title");
            this.id = j;
            this.title = title;
            this.poster = str;
        }

        public final long getId() {
            return this.id;
        }

        public final String getTitle() {
            return this.title;
        }

        public final String getPoster() {
            return this.poster;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u001d\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f¢\u0006\u0002\u0010\u000eJ\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\u0005HÆ\u0003J\t\u0010%\u001a\u00020\u0005HÆ\u0003J\t\u0010&\u001a\u00020\bHÆ\u0003J\t\u0010'\u001a\u00020\nHÆ\u0003J\u000f\u0010(\u001a\b\u0012\u0004\u0012\u00020\r0\fHÆ\u0003JK\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\n2\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fHÆ\u0001J\u0013\u0010*\u001a\u00020+2\b\u0010,\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010-\u001a\u00020\nHÖ\u0001J\t\u0010.\u001a\u00020\u0005HÖ\u0001R\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R \u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0010\"\u0004\b\u001e\u0010\u0012R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"¨\u0006/"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$UserList;", "", TtmlNode.ATTR_ID, "", "title", "", "description", "type", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;", "itemCount", "", "preview", "", "Lcom/filmkio/nativescreen/account/ListsScreenView$PreviewItem;", "(JLjava/lang/String;Ljava/lang/String;Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;ILjava/util/List;)V", "getDescription", "()Ljava/lang/String;", "setDescription", "(Ljava/lang/String;)V", "getId", "()J", "getItemCount", "()I", "setItemCount", "(I)V", "getPreview", "()Ljava/util/List;", "setPreview", "(Ljava/util/List;)V", "getTitle", "setTitle", "getType", "()Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;", "setType", "(Lcom/filmkio/nativescreen/account/ListsScreenView$ListType;)V", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class UserList {
        private String description;
        private final long id;
        private int itemCount;
        private List<PreviewItem> preview;
        private String title;
        private ListType type;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getTitle() {
            return this.title;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getDescription() {
            return this.description;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final ListType getType() {
            return this.type;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final int getItemCount() {
            return this.itemCount;
        }

        public final List<PreviewItem> component6() {
            return this.preview;
        }

        public final UserList copy(long id, String title, String description, ListType type, int itemCount, List<PreviewItem> preview) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(description, "description");
            Intrinsics.checkNotNullParameter(type, "type");
            Intrinsics.checkNotNullParameter(preview, "preview");
            return new UserList(id, title, description, type, itemCount, preview);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof UserList)) {
                return false;
            }
            UserList userList = (UserList) other;
            return this.id == userList.id && Intrinsics.areEqual(this.title, userList.title) && Intrinsics.areEqual(this.description, userList.description) && this.type == userList.type && this.itemCount == userList.itemCount && Intrinsics.areEqual(this.preview, userList.preview);
        }

        public int hashCode() {
            return (((((((((Long.hashCode(this.id) * 31) + this.title.hashCode()) * 31) + this.description.hashCode()) * 31) + this.type.hashCode()) * 31) + Integer.hashCode(this.itemCount)) * 31) + this.preview.hashCode();
        }

        public String toString() {
            return "UserList(id=" + this.id + ", title=" + this.title + ", description=" + this.description + ", type=" + this.type + ", itemCount=" + this.itemCount + ", preview=" + this.preview + ")";
        }

        public UserList(long j, String title, String description, ListType type, int i, List<PreviewItem> preview) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(description, "description");
            Intrinsics.checkNotNullParameter(type, "type");
            Intrinsics.checkNotNullParameter(preview, "preview");
            this.id = j;
            this.title = title;
            this.description = description;
            this.type = type;
            this.itemCount = i;
            this.preview = preview;
        }

        public final long getId() {
            return this.id;
        }

        public final String getTitle() {
            return this.title;
        }

        public final void setTitle(String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.title = str;
        }

        public final String getDescription() {
            return this.description;
        }

        public final void setDescription(String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.description = str;
        }

        public final ListType getType() {
            return this.type;
        }

        public final void setType(ListType listType) {
            Intrinsics.checkNotNullParameter(listType, "<set-?>");
            this.type = listType;
        }

        public final int getItemCount() {
            return this.itemCount;
        }

        public final void setItemCount(int i) {
            this.itemCount = i;
        }

        public /* synthetic */ UserList(long j, String str, String str2, ListType listType, int i, List list, int i2, DefaultConstructorMarker defaultConstructorMarker) {
            this(j, str, str2, listType, i, (i2 & 32) != 0 ? new ArrayList() : list);
        }

        public final List<PreviewItem> getPreview() {
            return this.preview;
        }

        public final void setPreview(List<PreviewItem> list) {
            Intrinsics.checkNotNullParameter(list, "<set-?>");
            this.preview = list;
        }
    }

    static final void lambda$6$lambda$5(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.stateAction;
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final void buildListContainer() {
        FrameLayout frameLayout;
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(0);
        this.listContainer = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setBackground(roundedBg(336401178, DefaultTimeBar.DEFAULT_UNPLAYED_COLOR, m381dp(1), dpF(12)));
        linearLayout2.setPadding(m381dp(10), m381dp(8), m381dp(10), m381dp(8));
        TextView textView = new TextView(this.ctx);
        textView.setText("لیست\u200cهای شخصی فیلم و سریال");
        textView.setTextColor(-2957330);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular);
        textView.setIncludeFontPadding(false);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("ساخت لیست جدید");
        textView2.setTextColor(-16052459);
        textView2.setTextSize(13.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceBold);
        textView2.setIncludeFontPadding(false);
        textView2.setGravity(17);
        textView2.setPadding(m381dp(14), m381dp(8), m381dp(14), m381dp(8));
        textView2.setBackground(roundedBg(this.accent, 0, 0, dpF(999)));
        textView2.setClickable(true);
        textView2.setFocusable(!this.isTouchDevice);
        textView2.setFocusableInTouchMode(!this.isTouchDevice);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.buildListContainer$lambda$12$lambda$11(this.f$0, view);
            }
        });
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView2);
        LinearLayout linearLayout3 = this.listContainer;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout3 = null;
        }
        linearLayout3.addView(linearLayout2);
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams.topMargin = m381dp(10);
        frameLayout2.setLayoutParams(layoutParams);
        LinearLayout linearLayout4 = this.listContainer;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout4 = null;
        }
        linearLayout4.addView(frameLayout2);
        this.listAdapter = new ListsAdapter(this, this.lists, this.isTouchDevice, new Function1<UserList, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildListContainer.2
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(UserList userList) {
                invoke2(userList);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(UserList it) {
                Intrinsics.checkNotNullParameter(it, "it");
                ListsScreenView.this.openEditInfoForm(it);
            }
        }, new Function1<UserList, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildListContainer.3
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(UserList userList) {
                invoke2(userList);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(UserList it) {
                Intrinsics.checkNotNullParameter(it, "it");
                ListsScreenView.this.openEditItems(it, true);
            }
        }, new Function1<UserList, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildListContainer.4
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(UserList userList) {
                invoke2(userList);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(UserList it) {
                Intrinsics.checkNotNullParameter(it, "it");
                ListsScreenView.this.confirmDeleteList(it);
            }
        });
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        ListsAdapter listsAdapter = this.listAdapter;
        if (listsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
            listsAdapter = null;
        }
        recyclerView.setAdapter(listsAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m381dp(88));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$buildListContainer$5$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 3) {
                    return;
                }
                this.this$0.maybeLoadNextLists();
            }
        });
        this.listRecycler = recyclerView;
        frameLayout2.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        progressBar.setVisibility(8);
        this.listLoading = progressBar;
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        Unit unit = Unit.INSTANCE;
        frameLayout2.addView(progressBar, layoutParams2);
        FrameLayout frameLayoutMakeLoadingMoreOverlay = makeLoadingMoreOverlay();
        this.listLoadingMoreOverlay = frameLayoutMakeLoadingMoreOverlay;
        if (frameLayoutMakeLoadingMoreOverlay == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listLoadingMoreOverlay");
            frameLayout = null;
        } else {
            frameLayout = frameLayoutMakeLoadingMoreOverlay;
        }
        frameLayout2.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildListContainer$lambda$12$lambda$11(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.openCreateForm();
    }

    private final void buildEditInfoContainer() {
        TextView textView;
        ScrollView scrollView = new ScrollView(this.ctx);
        scrollView.setOverScrollMode(2);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setLayoutDirection(1);
        this.editInfoContainer = scrollView;
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setPadding(m381dp(14), m381dp(14), m381dp(14), m381dp(14));
        ScrollView scrollView2 = this.editInfoContainer;
        if (scrollView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editInfoContainer");
            scrollView2 = null;
        }
        scrollView2.addView(linearLayout, new FrameLayout.LayoutParams(-1, -2));
        TextView textViewMakeFieldLabel = makeFieldLabel("عنوان لیست");
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = 0;
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textViewMakeFieldLabel, layoutParams);
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint("یک عنوان مناسب برای لیست");
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        appCompatEditText.setGravity(21);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setSingleLine();
        appCompatEditText.setImeOptions(5);
        appCompatEditText.setPadding(m381dp(12), m381dp(12), m381dp(12), m381dp(12));
        applyFieldStyle(appCompatEditText);
        this.formTitleInput = appCompatEditText;
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m381dp(8);
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(appCompatEditText, layoutParams2);
        TextView textViewMakeFieldLabel2 = makeFieldLabel("نوع لیست");
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m381dp(14);
        Unit unit3 = Unit.INSTANCE;
        linearLayout.addView(textViewMakeFieldLabel2, layoutParams3);
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        this.typeMovieChip = makeTypeChip("فیلم", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildEditInfoContainer.6
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                ListsScreenView.this.selectedListType = ListType.MOVIES;
                ListsScreenView.this.applyTypeChipState();
            }
        });
        this.typeSeriesChip = makeTypeChip("سریال", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildEditInfoContainer.7
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                ListsScreenView.this.selectedListType = ListType.SERIES;
                ListsScreenView.this.applyTypeChipState();
            }
        });
        TextView textView2 = this.typeMovieChip;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeMovieChip");
            textView2 = null;
        }
        linearLayout2.addView(textView2, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView3 = this.typeSeriesChip;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeSeriesChip");
            textView = null;
        } else {
            textView = textView3;
        }
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams4.setMarginEnd(m381dp(8));
        Unit unit4 = Unit.INSTANCE;
        linearLayout2.addView(textView, layoutParams4);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = m381dp(8);
        Unit unit5 = Unit.INSTANCE;
        linearLayout.addView(linearLayout2, layoutParams5);
        TextView textViewMakeFieldLabel3 = makeFieldLabel("توضیحات لیست");
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = m381dp(14);
        Unit unit6 = Unit.INSTANCE;
        linearLayout.addView(textViewMakeFieldLabel3, layoutParams6);
        AppCompatEditText appCompatEditText2 = new AppCompatEditText(this.ctx);
        appCompatEditText2.setHint("توضیح کوتاه درباره لیست");
        appCompatEditText2.setTextColor(-1);
        appCompatEditText2.setHintTextColor(2142817248);
        appCompatEditText2.setTextSize(14.0f);
        appCompatEditText2.setGravity(53);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = appCompatEditText2.getTypeface();
        }
        appCompatEditText2.setTypeface(typefaceRegular2);
        appCompatEditText2.setMinLines(4);
        appCompatEditText2.setMaxLines(6);
        appCompatEditText2.setPadding(m381dp(12), m381dp(12), m381dp(12), m381dp(12));
        applyFieldStyle(appCompatEditText2);
        this.formDescInput = appCompatEditText2;
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.topMargin = m381dp(8);
        Unit unit7 = Unit.INSTANCE;
        linearLayout.addView(appCompatEditText2, layoutParams7);
        TextView textView4 = new TextView(this.ctx);
        textView4.setText("ساخت لیست");
        textView4.setTextColor(-16052459);
        textView4.setTextSize(14.0f);
        textView4.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView4.getTypeface();
        }
        textView4.setTypeface(typefaceBold);
        textView4.setIncludeFontPadding(false);
        textView4.setPadding(m381dp(16), m381dp(11), m381dp(16), m381dp(11));
        textView4.setBackground(roundedBg(this.accent, 0, 0, dpF(12)));
        textView4.setClickable(true);
        textView4.setFocusable(!this.isTouchDevice);
        textView4.setFocusableInTouchMode(!this.isTouchDevice);
        textView4.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.buildEditInfoContainer$lambda$31$lambda$30(this.f$0, view);
            }
        });
        this.formSubmitButton = textView4;
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams8.topMargin = m381dp(18);
        Unit unit8 = Unit.INSTANCE;
        linearLayout.addView(textView4, layoutParams8);
        TextView textView5 = new TextView(this.ctx);
        textView5.setText("ویرایش عناوین این لیست");
        textView5.setTextColor(-2628109);
        textView5.setTextSize(13.0f);
        textView5.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView5.getTypeface();
        }
        textView5.setTypeface(typefaceMedium);
        textView5.setIncludeFontPadding(false);
        textView5.setPadding(m381dp(16), m381dp(10), m381dp(16), m381dp(10));
        textView5.setBackground(roundedBg(403576094, 1157627903, m381dp(1), dpF(12)));
        textView5.setVisibility(8);
        textView5.setClickable(true);
        textView5.setFocusable(!this.isTouchDevice);
        textView5.setFocusableInTouchMode(!this.isTouchDevice);
        textView5.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.buildEditInfoContainer$lambda$35$lambda$34(this.f$0, view);
            }
        });
        this.formEditItemsButton = textView5;
        LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams9.topMargin = m381dp(10);
        Unit unit9 = Unit.INSTANCE;
        linearLayout.addView(textView5, layoutParams9);
        applyTypeChipState();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildEditInfoContainer$lambda$31$lambda$30(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitListInfo();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildEditInfoContainer$lambda$35$lambda$34(final ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        final UserList userList = this$0.activeList;
        if (userList != null) {
            hideCreateSheet$default(this$0, false, new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$buildEditInfoContainer$15$1$1$1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.openEditItems(userList, true);
                }
            }, 1, null);
        }
    }

    private final void buildCreateContainer() {
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setFocusableInTouchMode(true);
        frameLayout.setElevation(dpF(46));
        frameLayout.setTranslationZ(dpF(46));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.buildCreateContainer$lambda$38$lambda$37(this.f$0, view);
            }
        });
        this.createContainer = frameLayout;
        View view = new View(this.ctx);
        view.setBackgroundColor(-1291845632);
        view.setAlpha(0.0f);
        view.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                ListsScreenView.buildCreateContainer$lambda$40$lambda$39(this.f$0, view2);
            }
        });
        this.createSheetScrim = view;
        FrameLayout frameLayout2 = this.createContainer;
        ScrollView scrollView = null;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout2 = null;
        }
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        frameLayout2.addView(view2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setColor(-234156782);
        gradientDrawable.setStroke(m381dp(1), 778990720);
        gradientDrawable.setCornerRadii(new float[]{dpF(18), dpF(18), dpF(18), dpF(18), 0.0f, 0.0f, 0.0f, 0.0f});
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setClipToPadding(false);
        linearLayout.setPadding(0, 0, 0, 0);
        linearLayout.setTranslationY(m381dp(360));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                ListsScreenView.buildCreateContainer$lambda$43$lambda$42(view3);
            }
        });
        this.createSheetCard = linearLayout;
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout3 = null;
        }
        LinearLayout linearLayout2 = this.createSheetCard;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout2 = null;
        }
        frameLayout3.addView(linearLayout2, new FrameLayout.LayoutParams(-1, m381dp(430), 80));
        FrameLayout frameLayout4 = new FrameLayout(this.ctx);
        frameLayout4.setPadding(0, m381dp(8), 0, m381dp(10));
        frameLayout4.setClickable(true);
        frameLayout4.setFocusable(true);
        frameLayout4.setFocusableInTouchMode(true);
        View view3 = new View(this.ctx);
        view3.setBackground(roundedBg(1174405119, 0, 0, dpF(999)));
        frameLayout4.addView(view3, new FrameLayout.LayoutParams(m381dp(44), m381dp(4), 17));
        frameLayout4.setOnTouchListener(new View.OnTouchListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda13
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view4, MotionEvent motionEvent) {
                return ListsScreenView.buildCreateContainer$lambda$48(this.f$0, view4, motionEvent);
            }
        });
        LinearLayout linearLayout3 = this.createSheetCard;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout3 = null;
        }
        linearLayout3.addView(frameLayout4, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        ScrollView scrollView2 = this.editInfoContainer;
        if (scrollView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editInfoContainer");
        } else {
            scrollView = scrollView2;
        }
        linearLayout4.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$38$lambda$37(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.submittingInfo) {
            return;
        }
        hideCreateSheet$default(this$0, false, null, 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$40$lambda$39(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.submittingInfo) {
            return;
        }
        hideCreateSheet$default(this$0, false, null, 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00a9  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00b1  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final boolean buildCreateContainer$lambda$48(ListsScreenView this$0, View view, MotionEvent motionEvent) {
        LinearLayout linearLayout;
        Integer numValueOf;
        int iIntValue;
        LinearLayout linearLayout2;
        LinearLayout linearLayout3;
        View view2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        int actionMasked = motionEvent.getActionMasked();
        LinearLayout linearLayout4 = null;
        View view3 = null;
        View view4 = null;
        if (actionMasked == 0) {
            this$0.createDragStartRawY = motionEvent.getRawY();
            LinearLayout linearLayout5 = this$0.createSheetCard;
            if (linearLayout5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout4 = linearLayout5;
            }
            this$0.createDragStartTranslation = linearLayout4.getTranslationY();
        } else if (actionMasked == 1) {
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if ((numValueOf.intValue() <= 0) == false) {
                numValueOf = null;
            }
            iIntValue = numValueOf == null ? numValueOf.intValue() : this$0.m381dp(430);
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f && !this$0.submittingInfo) {
                hideCreateSheet$default(this$0, false, null, 3, null);
            } else {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                    linearLayout3 = null;
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                } else {
                    view4 = view2;
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        } else if (actionMasked == 2) {
            float fCoerceAtLeast = RangesKt.coerceAtLeast(this$0.createDragStartTranslation + RangesKt.coerceAtLeast(motionEvent.getRawY() - this$0.createDragStartRawY, 0.0f), 0.0f);
            LinearLayout linearLayout6 = this$0.createSheetCard;
            if (linearLayout6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout6 = null;
            }
            linearLayout6.setTranslationY(fCoerceAtLeast);
            LinearLayout linearLayout7 = this$0.createSheetCard;
            if (linearLayout7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout7 = null;
            }
            Integer numValueOf2 = Integer.valueOf(linearLayout7.getHeight());
            if (!(numValueOf2.intValue() > 0)) {
                numValueOf2 = null;
            }
            int iIntValue2 = numValueOf2 != null ? numValueOf2.intValue() : this$0.m381dp(430);
            View view5 = this$0.createSheetScrim;
            if (view5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            } else {
                view3 = view5;
            }
            view3.setAlpha(RangesKt.coerceIn(1.0f - (fCoerceAtLeast / (iIntValue2 * 0.9f)), 0.0f, 1.0f));
        } else {
            if (actionMasked != 3) {
                return false;
            }
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if ((numValueOf.intValue() <= 0) == false) {
            }
            if (numValueOf == null) {
            }
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f) {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        }
        return true;
    }

    private final void showCreateSheet(Mode returnMode) {
        this.formReturnMode = returnMode;
        final int iResolveCreateSheetHeight = resolveCreateSheetHeight();
        LinearLayout linearLayout = this.createSheetCard;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout = null;
        }
        ViewGroup.LayoutParams layoutParams = linearLayout.getLayoutParams();
        FrameLayout.LayoutParams layoutParams2 = layoutParams instanceof FrameLayout.LayoutParams ? (FrameLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 != null && layoutParams2.height != iResolveCreateSheetHeight) {
            layoutParams2.height = iResolveCreateSheetHeight;
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setLayoutParams(layoutParams2);
        }
        this.createSheetShown = true;
        FrameLayout frameLayout = this.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(0);
        View view = this.createSheetScrim;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view = null;
        }
        view.setAlpha(0.0f);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(1.0f).setDuration(200L).start();
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout2 = linearLayout4;
        }
        linearLayout2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.showCreateSheet$lambda$51(this.f$0, iResolveCreateSheetHeight);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showCreateSheet$lambda$51(ListsScreenView this$0, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            LinearLayout linearLayout = this$0.createSheetCard;
            LinearLayout linearLayout2 = null;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            Integer numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
                numValueOf = null;
            }
            if (numValueOf != null) {
                i = numValueOf.intValue();
            }
            LinearLayout linearLayout3 = this$0.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setTranslationY(i);
            LinearLayout linearLayout4 = this$0.createSheetCard;
            if (linearLayout4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout2 = linearLayout4;
            }
            linearLayout2.animate().translationY(0.0f).setDuration(220L).start();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void hideCreateSheet$default(ListsScreenView listsScreenView, boolean z, Function0 function0, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        if ((i & 2) != 0) {
            function0 = null;
        }
        listsScreenView.hideCreateSheet(z, function0);
    }

    private final void hideCreateSheet(boolean animated, final Function0<Unit> onHidden) {
        LinearLayout linearLayout = null;
        FrameLayout frameLayout = null;
        if (!this.createSheetShown) {
            FrameLayout frameLayout2 = this.createContainer;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
                frameLayout2 = null;
            }
            if (frameLayout2.getVisibility() != 0) {
                return;
            }
        }
        this.createSheetShown = false;
        if (!animated) {
            View view = this.createSheetScrim;
            if (view == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                view = null;
            }
            view.setAlpha(0.0f);
            LinearLayout linearLayout2 = this.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout2.setTranslationY(linearLayout3.getHeight());
            FrameLayout frameLayout3 = this.createContainer;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            } else {
                frameLayout = frameLayout3;
            }
            frameLayout.setVisibility(8);
            if (onHidden != null) {
                onHidden.invoke();
                return;
            } else {
                switchMode(this.formReturnMode);
                return;
            }
        }
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        Integer numValueOf = Integer.valueOf(linearLayout4.getHeight());
        if (!(numValueOf.intValue() > 0)) {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : m381dp(360);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(0.0f).setDuration(180L).start();
        LinearLayout linearLayout5 = this.createSheetCard;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout = linearLayout5;
        }
        linearLayout.animate().translationY(iIntValue).setDuration(200L).withEndAction(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.hideCreateSheet$lambda$53(this.f$0, onHidden);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void hideCreateSheet$lambda$53(ListsScreenView this$0, Function0 function0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            return;
        }
        FrameLayout frameLayout = this$0.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
        if (function0 != null) {
            function0.invoke();
        } else {
            this$0.switchMode(this$0.formReturnMode);
        }
    }

    private final int resolveCreateSheetHeight() {
        float f = getResources().getDisplayMetrics().heightPixels;
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (0.58f * f), m381dp(430));
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast((int) (f * 0.94f), iCoerceAtLeast);
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(RangesKt.coerceAtLeast(getResources().getDisplayMetrics().widthPixels - m381dp(28), m381dp(220)), 1073741824);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        ScrollView scrollView = this.editInfoContainer;
        ScrollView scrollView2 = null;
        if (scrollView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editInfoContainer");
            scrollView = null;
        }
        scrollView.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int iM381dp = m381dp(44);
        ScrollView scrollView3 = this.editInfoContainer;
        if (scrollView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editInfoContainer");
        } else {
            scrollView2 = scrollView3;
        }
        return RangesKt.coerceAtMost(RangesKt.coerceAtLeast(scrollView2.getMeasuredHeight() + iM381dp, iCoerceAtLeast), iCoerceAtLeast2);
    }

    private final void buildEditItemsContainer() {
        ListItemsAdapter listItemsAdapter;
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(8);
        linearLayout.setPadding(m381dp(2), m381dp(6), m381dp(2), m381dp(8));
        this.editItemsContainer = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setPadding(m381dp(12), m381dp(12), m381dp(12), m381dp(12));
        linearLayout2.setBackground(roundedBg(this.cardFill, this.cardStroke, m381dp(1), dpF(12)));
        TextView textView = new TextView(this.ctx);
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setGravity(5);
        textView.setIncludeFontPadding(false);
        this.editItemsHeaderTitle = textView;
        TextView textView2 = new TextView(this.ctx);
        textView2.setTextColor(-4798243);
        textView2.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceRegular);
        textView2.setGravity(5);
        textView2.setIncludeFontPadding(false);
        this.editItemsHeaderMeta = textView2;
        TextView textView3 = new TextView(this.ctx);
        textView3.setText("ویرایش اطلاعات");
        textView3.setTextColor(-2299660);
        textView3.setTextSize(12.0f);
        textView3.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView3.getTypeface();
        }
        textView3.setTypeface(typefaceMedium);
        textView3.setIncludeFontPadding(false);
        textView3.setPadding(m381dp(12), m381dp(8), m381dp(12), m381dp(8));
        textView3.setBackground(roundedBg(337521209, 1157627903, m381dp(1), dpF(999)));
        textView3.setClickable(true);
        textView3.setFocusable(!this.isTouchDevice);
        textView3.setFocusableInTouchMode(!this.isTouchDevice);
        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.buildEditItemsContainer$lambda$60$lambda$59(this.f$0, view);
            }
        });
        TextView textView4 = this.editItemsHeaderTitle;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderTitle");
            textView4 = null;
        }
        linearLayout2.addView(textView4);
        TextView textView5 = this.editItemsHeaderMeta;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderMeta");
            textView5 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m381dp(6);
        Unit unit = Unit.INSTANCE;
        linearLayout2.addView(textView5, layoutParams);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = m381dp(10);
        Unit unit2 = Unit.INSTANCE;
        linearLayout2.addView(textView3, layoutParams2);
        LinearLayout linearLayout3 = this.editItemsContainer;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout3 = null;
        }
        linearLayout3.addView(linearLayout2);
        TextView textViewMakeFieldLabel = makeFieldLabel("جستجوی عنوان در فیلمکیو");
        LinearLayout linearLayout4 = this.editItemsContainer;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout4 = null;
        }
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m381dp(14);
        Unit unit3 = Unit.INSTANCE;
        linearLayout4.addView(textViewMakeFieldLabel, layoutParams3);
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint("نام عنوان را وارد کنید");
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        appCompatEditText.setGravity(21);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular2);
        appCompatEditText.setSingleLine();
        appCompatEditText.setImeOptions(3);
        appCompatEditText.setPadding(m381dp(12), m381dp(12), m381dp(12), m381dp(12));
        applyFieldStyle(appCompatEditText);
        appCompatEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda22
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView6, int i, KeyEvent keyEvent) {
                return ListsScreenView.buildEditItemsContainer$lambda$65$lambda$64(this.f$0, textView6, i, keyEvent);
            }
        });
        appCompatEditText.addTextChangedListener(new TextWatcher() { // from class: com.filmkio.nativescreen.account.ListsScreenView$buildEditItemsContainer$7$2
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                this.this$0.scheduleSearchFromInput();
            }
        });
        this.searchInput = appCompatEditText;
        LinearLayout linearLayout5 = this.editItemsContainer;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout5 = null;
        }
        AppCompatEditText appCompatEditText2 = this.searchInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText2 = null;
        }
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = m381dp(8);
        Unit unit4 = Unit.INSTANCE;
        linearLayout5.addView(appCompatEditText2, layoutParams4);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setBackground(roundedBg(269358366, 659446377, m381dp(1), dpF(12)));
        frameLayout.setPadding(m381dp(6), m381dp(6), m381dp(6), m381dp(6));
        LinearLayout linearLayout6 = this.editItemsContainer;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout6 = null;
        }
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, m381dp(220));
        layoutParams5.topMargin = m381dp(8);
        Unit unit5 = Unit.INSTANCE;
        linearLayout6.addView(frameLayout, layoutParams5);
        this.searchResultsAdapter = new SearchResultAdapter(this, this.searchItems, this.isTouchDevice, new Function1<QueryItem, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildEditItemsContainer.10
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(QueryItem queryItem) {
                invoke2(queryItem);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(QueryItem it) {
                Intrinsics.checkNotNullParameter(it, "it");
                ListsScreenView.this.addItemToActiveList(it);
            }
        });
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        SearchResultAdapter searchResultAdapter = this.searchResultsAdapter;
        if (searchResultAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        }
        recyclerView.setAdapter(searchResultAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m381dp(4));
        this.searchResultsRecycler = recyclerView;
        frameLayout.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
            Unit unit6 = Unit.INSTANCE;
        }
        progressBar.setVisibility(8);
        this.searchResultsLoading = progressBar;
        FrameLayout.LayoutParams layoutParams6 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams6.gravity = 17;
        Unit unit7 = Unit.INSTANCE;
        frameLayout.addView(progressBar, layoutParams6);
        TextView textView6 = new TextView(this.ctx);
        textView6.setText("حداقل ۲ کاراکتر برای جستجو وارد کنید.");
        textView6.setTextColor(-1211639317);
        textView6.setTextSize(12.0f);
        textView6.setGravity(17);
        Typeface typefaceRegular3 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular3 == null) {
            typefaceRegular3 = textView6.getTypeface();
        }
        textView6.setTypeface(typefaceRegular3);
        textView6.setIncludeFontPadding(false);
        textView6.setLineSpacing(m381dp(1), 1.0f);
        textView6.setVisibility(0);
        this.searchEmptyText = textView6;
        frameLayout.addView(textView6, new FrameLayout.LayoutParams(-1, -1));
        TextView textViewMakeFieldLabel2 = makeFieldLabel("عناوین موجود در این لیست");
        LinearLayout linearLayout7 = this.editItemsContainer;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout7 = null;
        }
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.topMargin = m381dp(14);
        Unit unit8 = Unit.INSTANCE;
        linearLayout7.addView(textViewMakeFieldLabel2, layoutParams7);
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        LinearLayout linearLayout8 = this.editItemsContainer;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
            linearLayout8 = null;
        }
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams8.topMargin = m381dp(8);
        Unit unit9 = Unit.INSTANCE;
        linearLayout8.addView(frameLayout2, layoutParams8);
        this.itemsAdapter = new ListItemsAdapter(this, this.listItems, this.imageLoader, this.isTouchDevice, new Function1<QueryItem, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildEditItemsContainer.17
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(QueryItem queryItem) {
                invoke2(queryItem);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(QueryItem item) {
                Function1 function1;
                Intrinsics.checkNotNullParameter(item, "item");
                if (item.getId() <= 0 || (function1 = ListsScreenView.this.onOpenSingle) == null) {
                    return;
                }
                function1.invoke(Long.valueOf(item.getId()));
            }
        }, new Function1<QueryItem, Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView.buildEditItemsContainer.18
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(QueryItem queryItem) {
                invoke2(queryItem);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(QueryItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                ListsScreenView.this.removeItemFromActiveList(item);
            }
        });
        RecyclerView recyclerView2 = new RecyclerView(this.ctx);
        recyclerView2.setLayoutDirection(1);
        recyclerView2.setLayoutManager(new GridLayoutManager(this.ctx, 3));
        ListItemsAdapter listItemsAdapter2 = this.itemsAdapter;
        if (listItemsAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            listItemsAdapter = null;
        } else {
            listItemsAdapter = listItemsAdapter2;
        }
        recyclerView2.setAdapter(listItemsAdapter);
        recyclerView2.setOverScrollMode(2);
        recyclerView2.setVerticalScrollBarEnabled(false);
        recyclerView2.setClipToPadding(false);
        recyclerView2.setNestedScrollingEnabled(true);
        recyclerView2.setPaddingRelative(0, 0, 0, m381dp(8));
        if (recyclerView2.getItemDecorationCount() == 0) {
            recyclerView2.addItemDecoration(new GridSpacingDecoration(m381dp(8), m381dp(10)));
        }
        this.itemsRecycler = recyclerView2;
        frameLayout2.addView(recyclerView2, new FrameLayout.LayoutParams(-1, -2));
        ProgressBar progressBar2 = new ProgressBar(this.ctx);
        progressBar2.setIndeterminate(true);
        Drawable indeterminateDrawable2 = progressBar2.getIndeterminateDrawable();
        if (indeterminateDrawable2 != null) {
            indeterminateDrawable2.setTint(this.accent);
            Unit unit10 = Unit.INSTANCE;
        }
        progressBar2.setVisibility(8);
        this.itemsLoading = progressBar2;
        FrameLayout.LayoutParams layoutParams9 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams9.gravity = 17;
        Unit unit11 = Unit.INSTANCE;
        frameLayout2.addView(progressBar2, layoutParams9);
        TextView textView7 = new TextView(this.ctx);
        textView7.setText("هنوز عنوانی اضافه نشده است.");
        textView7.setTextColor(-1211639317);
        textView7.setTextSize(12.0f);
        textView7.setGravity(1);
        Typeface typefaceRegular4 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular4 == null) {
            typefaceRegular4 = textView7.getTypeface();
        }
        textView7.setTypeface(typefaceRegular4);
        textView7.setIncludeFontPadding(false);
        textView7.setVisibility(0);
        textView7.setPadding(0, m381dp(16), 0, m381dp(16));
        this.itemsEmptyText = textView7;
        FrameLayout.LayoutParams layoutParams10 = new FrameLayout.LayoutParams(-1, -2);
        layoutParams10.gravity = 17;
        Unit unit12 = Unit.INSTANCE;
        frameLayout2.addView(textView7, layoutParams10);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildEditItemsContainer$lambda$60$lambda$59(ListsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        UserList userList = this$0.activeList;
        if (userList != null) {
            this$0.openEditInfoForm(userList);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildEditItemsContainer$lambda$65$lambda$64(ListsScreenView this$0, TextView textView, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i != 3 && i != 6) {
            return false;
        }
        this$0.triggerSearchNow();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openCreateForm() {
        this.createMode = true;
        TextView textView = null;
        this.activeList = null;
        this.selectedListType = ListType.MOVIES;
        AppCompatEditText appCompatEditText = this.formTitleInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formTitleInput");
            appCompatEditText = null;
        }
        appCompatEditText.setText("");
        AppCompatEditText appCompatEditText2 = this.formDescInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formDescInput");
            appCompatEditText2 = null;
        }
        appCompatEditText2.setText("");
        TextView textView2 = this.formSubmitButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formSubmitButton");
            textView2 = null;
        }
        textView2.setText("ساخت لیست");
        TextView textView3 = this.formEditItemsButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formEditItemsButton");
        } else {
            textView = textView3;
        }
        textView.setVisibility(8);
        applyTypeChipState();
        showCreateSheet(this.mode);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openEditInfoForm(UserList list) {
        this.activeList = list;
        this.createMode = false;
        this.selectedListType = list.getType();
        AppCompatEditText appCompatEditText = this.formTitleInput;
        TextView textView = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formTitleInput");
            appCompatEditText = null;
        }
        appCompatEditText.setText(list.getTitle());
        AppCompatEditText appCompatEditText2 = this.formDescInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formDescInput");
            appCompatEditText2 = null;
        }
        appCompatEditText2.setText(list.getDescription());
        TextView textView2 = this.formSubmitButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formSubmitButton");
            textView2 = null;
        }
        textView2.setText("ذخیره تغییرات");
        TextView textView3 = this.formEditItemsButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formEditItemsButton");
        } else {
            textView = textView3;
        }
        textView.setVisibility(0);
        applyTypeChipState();
        showCreateSheet(this.mode);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openEditItems(UserList list, boolean loadFromServer) {
        this.activeList = list;
        updateEditItemsHeader();
        switchMode(Mode.EDIT_ITEMS);
        if (loadFromServer) {
            loadListItems(list.getId());
        }
    }

    private final void updateEditItemsHeader() {
        UserList userList = this.activeList;
        TextView textView = null;
        if (userList == null) {
            TextView textView2 = this.editItemsHeaderTitle;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderTitle");
                textView2 = null;
            }
            textView2.setText("ویرایش عناوین");
            TextView textView3 = this.editItemsHeaderMeta;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderMeta");
            } else {
                textView = textView3;
            }
            textView.setText("-");
            return;
        }
        TextView textView4 = this.editItemsHeaderTitle;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderTitle");
            textView4 = null;
        }
        textView4.setText(userList.getTitle());
        String str = userList.getType() == ListType.SERIES ? "سریال" : "فیلم";
        TextView textView5 = this.editItemsHeaderMeta;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsHeaderMeta");
        } else {
            textView = textView5;
        }
        textView.setText("نوع لیست: " + str + "   •   تعداد عناوین: " + userList.getItemCount());
    }

    private final void switchMode(Mode next) {
        this.mode = next;
        LinearLayout linearLayout = this.listContainer;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout = null;
        }
        linearLayout.setVisibility(next == Mode.LIST ? 0 : 8);
        LinearLayout linearLayout3 = this.editItemsContainer;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editItemsContainer");
        } else {
            linearLayout2 = linearLayout3;
        }
        linearLayout2.setVisibility(next != Mode.EDIT_ITEMS ? 8 : 0);
        if (next == Mode.LIST) {
            if (!this.lists.isEmpty()) {
                hideState();
                return;
            }
            return;
        }
        hideState();
    }

    public final boolean handleBackPressed() {
        if (this.createSheetShown) {
            hideCreateSheet$default(this, false, null, 3, null);
            return true;
        }
        int i = WhenMappings.$EnumSwitchMapping$0[this.mode.ordinal()];
        if (i == 1) {
            switchMode(Mode.LIST);
            return true;
        }
        if (i == 2) {
            return false;
        }
        throw new NoWhenBranchMatchedException();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetAndLoadLists() {
        int size = this.lists.size();
        this.lists.clear();
        if (size > 0) {
            ListsAdapter listsAdapter = this.listAdapter;
            if (listsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
                listsAdapter = null;
            }
            listsAdapter.notifyItemRangeRemoved(0, size);
        }
        this.currentPage = 1;
        this.hasMore = true;
        loadLists(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNextLists() {
        if (this.loadingLists || !this.hasMore) {
            return;
        }
        loadLists(this.currentPage + 1, false);
    }

    private final void loadLists(final int page, final boolean reset) {
        if (this.loadingLists || !isLoggedIn()) {
            return;
        }
        this.loadingLists = true;
        FrameLayout frameLayout = null;
        if (reset) {
            ProgressBar progressBar = this.listLoading;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listLoading");
                progressBar = null;
            }
            progressBar.setVisibility(0);
            FrameLayout frameLayout2 = this.listLoadingMoreOverlay;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout2;
            }
            frameLayout.setVisibility(8);
        } else {
            FrameLayout frameLayout3 = this.listLoadingMoreOverlay;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout3;
            }
            frameLayout.setVisibility(0);
        }
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda38
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.loadLists$lambda$82(this.f$0, page, reset);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadLists$lambda$82(final ListsScreenView this$0, final int i, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ParseResult<UserList> listsResponse = this$0.parseListsResponse(requestWithFallback$default(this$0, CollectionsKt.listOf((Object[]) new String[]{"/lists", "/getLists"}), "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("page", String.valueOf(i)), TuplesKt.m787to("per_page", "12")), this$0.authHeaders(), null, 16, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.loadLists$lambda$82$lambda$80(this.f$0, listsResponse, z, i);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.loadLists$lambda$82$lambda$81(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadLists$lambda$82$lambda$80(final ListsScreenView this$0, ParseResult parsed, boolean z, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loadingLists = false;
        ProgressBar progressBar = this$0.listLoading;
        ListsAdapter listsAdapter = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout = this$0.listLoadingMoreOverlay;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listLoadingMoreOverlay");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
        if (!parsed.getOk()) {
            this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت لیست\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$loadLists$1$1$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoadLists();
                }
            });
            return;
        }
        if (z) {
            int size = this$0.lists.size();
            this$0.lists.clear();
            if (size > 0) {
                ListsAdapter listsAdapter2 = this$0.listAdapter;
                if (listsAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
                    listsAdapter2 = null;
                }
                listsAdapter2.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.lists.size();
        this$0.lists.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            ListsAdapter listsAdapter3 = this$0.listAdapter;
            if (listsAdapter3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
            } else {
                listsAdapter = listsAdapter3;
            }
            listsAdapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentPage = i;
        this$0.hasMore = parsed.getItems().size() >= 12;
        if (this$0.lists.isEmpty()) {
            this$0.showState("هنوز لیستی ثبت نشده است.", "ساخت لیست جدید", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$loadLists$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.openCreateForm();
                }
            });
        } else {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadLists$lambda$82$lambda$81(final ListsScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        boolean z = false;
        this$0.loadingLists = false;
        ProgressBar progressBar = this$0.listLoading;
        FrameLayout frameLayout = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout2 = this$0.listLoadingMoreOverlay;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listLoadingMoreOverlay");
        } else {
            frameLayout = frameLayout2;
        }
        frameLayout.setVisibility(8);
        if (e instanceof FkApiClient.ApiException) {
            FkApiClient.ApiException apiException = (FkApiClient.ApiException) e;
            if (apiException.getCode() == 401 || apiException.getCode() == 403) {
                z = true;
            }
        }
        if (z || !this$0.isLoggedIn()) {
            this$0.showState("برای مدیریت لیست\u200cها ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$loadLists$1$2$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function0 = this.this$0.onRequireLogin;
                    if (function0 != null) {
                        function0.invoke();
                    }
                }
            });
        } else {
            this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت لیست\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$loadLists$1$2$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoadLists();
                }
            });
        }
    }

    private final void submitListInfo() {
        String string;
        String string2;
        if (this.submittingInfo) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        AppCompatEditText appCompatEditText = this.formTitleInput;
        String string3 = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formTitleInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        final String string4 = (text == null || (string2 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string4 == null) {
            string4 = "";
        }
        AppCompatEditText appCompatEditText2 = this.formDescInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formDescInput");
            appCompatEditText2 = null;
        }
        Editable text2 = appCompatEditText2.getText();
        if (text2 != null && (string = text2.toString()) != null) {
            string3 = StringsKt.trim((CharSequence) string).toString();
        }
        final String str = string3 != null ? string3 : "";
        if (StringsKt.isBlank(string4)) {
            showToast("عنوان لیست را وارد کنید");
        } else {
            if (StringsKt.isBlank(str)) {
                showToast("توضیحات لیست را وارد کنید");
                return;
            }
            this.submittingInfo = true;
            setFormSubmitting(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda15
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.submitListInfo$lambda$87(this.f$0, string4, str);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitListInfo$lambda$87(final ListsScreenView this$0, final String title, final String description) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(title, "$title");
        Intrinsics.checkNotNullParameter(description, "$description");
        try {
            if (this$0.createMode) {
                final UserList userListCreateListRequest = this$0.createListRequest(title, description, this$0.selectedListType);
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda17
                    @Override // java.lang.Runnable
                    public final void run() {
                        ListsScreenView.submitListInfo$lambda$87$lambda$83(this.f$0, userListCreateListRequest);
                    }
                });
                return;
            }
            final UserList userList = this$0.activeList;
            if (userList == null) {
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda18
                    @Override // java.lang.Runnable
                    public final void run() {
                        ListsScreenView.submitListInfo$lambda$87$lambda$84(this.f$0);
                    }
                });
            } else {
                final Triple<Boolean, String, JSONObject> tripleUpdateListInfoRequest = this$0.updateListInfoRequest(userList.getId(), title, description, this$0.selectedListType);
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda19
                    @Override // java.lang.Runnable
                    public final void run() {
                        ListsScreenView.submitListInfo$lambda$87$lambda$85(this.f$0, tripleUpdateListInfoRequest, userList, title, description);
                    }
                });
            }
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda20
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.submitListInfo$lambda$87$lambda$86(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitListInfo$lambda$87$lambda$83(ListsScreenView this$0, UserList userList) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submittingInfo = false;
        this$0.setFormSubmitting(false);
        if (userList == null) {
            this$0.showToast("ساخت لیست ناموفق بود");
            return;
        }
        this$0.lists.add(0, userList);
        ListsAdapter listsAdapter = this$0.listAdapter;
        if (listsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
            listsAdapter = null;
        }
        listsAdapter.notifyItemInserted(0);
        this$0.activeList = userList;
        this$0.showToast("لیست با موفقیت ساخته شد");
        hideCreateSheet$default(this$0, false, null, 2, null);
        this$0.openEditItems(userList, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitListInfo$lambda$87$lambda$84(ListsScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submittingInfo = false;
        this$0.setFormSubmitting(false);
        this$0.showToast("لیست انتخاب نشده است");
        hideCreateSheet$default(this$0, false, null, 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitListInfo$lambda$87$lambda$85(ListsScreenView this$0, Triple ok, UserList userList, String title, String description) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(ok, "$ok");
        Intrinsics.checkNotNullParameter(title, "$title");
        Intrinsics.checkNotNullParameter(description, "$description");
        this$0.submittingInfo = false;
        this$0.setFormSubmitting(false);
        if (!((Boolean) ok.getFirst()).booleanValue()) {
            String str = (String) ok.getSecond();
            if (str == null) {
                str = "ویرایش لیست ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        userList.setTitle(title);
        userList.setDescription(description);
        userList.setType(this$0.selectedListType);
        this$0.syncList(userList);
        String str2 = (String) ok.getSecond();
        if (str2 == null) {
            str2 = "لیست با موفقیت ویرایش شد";
        }
        this$0.showToast(str2);
        this$0.updateEditItemsHeader();
        hideCreateSheet$default(this$0, false, null, 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitListInfo$lambda$87$lambda$86(ListsScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.submittingInfo = false;
        this$0.setFormSubmitting(false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در ذخیره اطلاعات لیست"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void confirmDeleteList(final UserList list) {
        if (this.deletingList || this.mutatingItem || this.submittingInfo) {
            return;
        }
        new AlertDialog.Builder(this.ctx).setMessage("لیست «" + list.getTitle() + "» حذف شود؟").setPositiveButton("حذف", new DialogInterface.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda24
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                ListsScreenView.confirmDeleteList$lambda$88(this.f$0, list, dialogInterface, i);
            }
        }).setNegativeButton("انصراف", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void confirmDeleteList$lambda$88(ListsScreenView this$0, UserList list, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(list, "$list");
        this$0.deleteList(list);
    }

    private final void deleteList(final UserList list) {
        if (this.deletingList) {
            return;
        }
        this.deletingList = true;
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.deleteList$lambda$92(this.f$0, list);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void deleteList$lambda$92(final ListsScreenView this$0, final UserList list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(list, "$list");
        try {
            final Pair<Boolean, String> pairDeleteListRequest = this$0.deleteListRequest(list.getId());
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.deleteList$lambda$92$lambda$90(this.f$0, pairDeleteListRequest, list);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda23
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.deleteList$lambda$92$lambda$91(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void deleteList$lambda$92$lambda$90(final ListsScreenView this$0, Pair res, UserList list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(res, "$res");
        Intrinsics.checkNotNullParameter(list, "$list");
        boolean z = false;
        this$0.deletingList = false;
        if (!((Boolean) res.getFirst()).booleanValue()) {
            String str = (String) res.getSecond();
            if (str == null) {
                str = "حذف لیست ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        Iterator<UserList> it = this$0.lists.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            } else {
                if (it.next().getId() == list.getId()) {
                    break;
                } else {
                    i++;
                }
            }
        }
        ListItemsAdapter listItemsAdapter = null;
        if (i >= 0) {
            this$0.lists.remove(i);
            ListsAdapter listsAdapter = this$0.listAdapter;
            if (listsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
                listsAdapter = null;
            }
            listsAdapter.notifyItemRemoved(i);
            if (i < this$0.lists.size()) {
                ListsAdapter listsAdapter2 = this$0.listAdapter;
                if (listsAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
                    listsAdapter2 = null;
                }
                listsAdapter2.notifyItemRangeChanged(i, this$0.lists.size() - i);
            }
        }
        UserList userList = this$0.activeList;
        if (userList != null && userList.getId() == list.getId()) {
            z = true;
        }
        if (z) {
            this$0.activeList = null;
            this$0.listItems.clear();
            ListItemsAdapter listItemsAdapter2 = this$0.itemsAdapter;
            if (listItemsAdapter2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            } else {
                listItemsAdapter = listItemsAdapter2;
            }
            listItemsAdapter.notifyDataSetChanged();
        }
        String str2 = (String) res.getSecond();
        if (str2 == null) {
            str2 = "لیست حذف شد";
        }
        this$0.showToast(str2);
        if (this$0.lists.isEmpty()) {
            this$0.showState("هنوز لیستی ثبت نشده است.", "ساخت لیست جدید", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.ListsScreenView$deleteList$1$1$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.openCreateForm();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void deleteList$lambda$92$lambda$91(ListsScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.deletingList = false;
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "حذف لیست ناموفق بود"));
    }

    private final void loadListItems(final long listId) {
        if (this.loadingListItems || listId <= 0) {
            return;
        }
        this.loadingListItems = true;
        ProgressBar progressBar = this.itemsLoading;
        TextView textView = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsLoading");
            progressBar = null;
        }
        progressBar.setVisibility(0);
        TextView textView2 = this.itemsEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsEmptyText");
        } else {
            textView = textView2;
        }
        textView.setVisibility(8);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda31
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.loadListItems$lambda$98(this.f$0, listId);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadListItems$lambda$98(final ListsScreenView this$0, long j) {
        int i;
        boolean bool;
        Object objOpt;
        boolean z;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ArrayList arrayList = new ArrayList();
            boolean z2 = true;
            int i2 = 1;
            for (int i3 = 0; z2 && i3 < 20; i3++) {
                ParseResult<QueryItem> listItemsResponse = this$0.parseListItemsResponse(requestWithFallback$default(this$0, CollectionsKt.listOf((Object[]) new String[]{"/listItems", "/getListItems"}), "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("listID", String.valueOf(j)), TuplesKt.m787to("page", String.valueOf(i2)), TuplesKt.m787to("per_page", String.valueOf(120))), this$0.authHeaders(), null, 16, null));
                if (!listItemsResponse.getOk()) {
                    throw new RuntimeException(SafeUserMessage.INSTANCE.fromRaw(listItemsResponse.getMessage(), "خطا در دریافت عناوین لیست"));
                }
                if (!listItemsResponse.getItems().isEmpty()) {
                    i = 0;
                    for (QueryItem queryItem : listItemsResponse.getItems()) {
                        ArrayList arrayList2 = arrayList;
                        if ((arrayList2 instanceof Collection) && arrayList2.isEmpty()) {
                            z = true;
                        } else {
                            Iterator it = arrayList2.iterator();
                            while (it.hasNext()) {
                                if (((QueryItem) it.next()).getId() == queryItem.getId()) {
                                    z = false;
                                    break;
                                }
                            }
                            z = true;
                        }
                        if (z) {
                            arrayList.add(queryItem);
                            i++;
                        }
                    }
                } else {
                    i = 0;
                }
                JSONObject extra = listItemsResponse.getExtra();
                Object objOpt2 = null;
                JSONObject jSONObjectOptJSONObject = extra != null ? extra.optJSONObject("data") : null;
                if (extra != null && (objOpt = extra.opt("has_more")) != null) {
                    objOpt2 = objOpt;
                } else if (jSONObjectOptJSONObject != null) {
                    objOpt2 = jSONObjectOptJSONObject.opt("has_more");
                }
                UserList userList = this$0.activeList;
                int itemCount = userList != null ? userList.getItemCount() : 0;
                if (objOpt2 == null || Intrinsics.areEqual(objOpt2, JSONObject.NULL)) {
                    bool = (itemCount > 0 && arrayList.size() < itemCount && (listItemsResponse.getItems().isEmpty() ^ true)) || listItemsResponse.getItems().size() >= 120;
                } else {
                    bool = this$0.toBool(objOpt2);
                }
                z2 = bool && (listItemsResponse.getItems().isEmpty() ^ true) && (i > 0 || objOpt2 != null);
                i2++;
            }
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda32
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.loadListItems$lambda$98$lambda$96(this.f$0, arrayList);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda33
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.loadListItems$lambda$98$lambda$97(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadListItems$lambda$98$lambda$96(ListsScreenView this$0, ArrayList loaded) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(loaded, "$loaded");
        this$0.loadingListItems = false;
        ProgressBar progressBar = this$0.itemsLoading;
        TextView textView = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        int size = this$0.listItems.size();
        this$0.listItems.clear();
        if (size > 0) {
            ListItemsAdapter listItemsAdapter = this$0.itemsAdapter;
            if (listItemsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
                listItemsAdapter = null;
            }
            listItemsAdapter.notifyItemRangeRemoved(0, size);
        }
        this$0.listItems.addAll(loaded);
        if (!r5.isEmpty()) {
            ListItemsAdapter listItemsAdapter2 = this$0.itemsAdapter;
            if (listItemsAdapter2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
                listItemsAdapter2 = null;
            }
            listItemsAdapter2.notifyItemRangeInserted(0, loaded.size());
        }
        UserList userList = this$0.activeList;
        if (userList != null) {
            userList.setItemCount(this$0.listItems.size());
            List<QueryItem> listTake = CollectionsKt.take(this$0.listItems, 6);
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listTake, 10));
            for (QueryItem queryItem : listTake) {
                arrayList.add(new PreviewItem(queryItem.getId(), queryItem.getTitle(), queryItem.getPoster()));
            }
            userList.setPreview(CollectionsKt.toMutableList((Collection) arrayList));
            this$0.syncList(userList);
            this$0.updateEditItemsHeader();
        }
        this$0.updateSearchItemState();
        TextView textView2 = this$0.itemsEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsEmptyText");
        } else {
            textView = textView2;
        }
        textView.setVisibility(this$0.listItems.isEmpty() ? 0 : 8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadListItems$lambda$98$lambda$97(ListsScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.loadingListItems = false;
        ProgressBar progressBar = this$0.itemsLoading;
        TextView textView = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        if (this$0.listItems.isEmpty()) {
            TextView textView2 = this$0.itemsEmptyText;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("itemsEmptyText");
            } else {
                textView = textView2;
            }
            textView.setVisibility(0);
        }
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت عناوین لیست"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void addItemToActiveList(final QueryItem item) {
        final UserList userList;
        if (this.mutatingItem || (userList = this.activeList) == null || userList == null || item.getId() <= 0) {
            return;
        }
        ArrayList<QueryItem> arrayList = this.listItems;
        boolean z = false;
        if (!(arrayList instanceof Collection) || !arrayList.isEmpty()) {
            Iterator<T> it = arrayList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                if (((QueryItem) it.next()).getId() == item.getId()) {
                    z = true;
                    break;
                }
            }
        }
        if (z) {
            showToast("این عنوان قبلا اضافه شده است");
            return;
        }
        this.mutatingItem = true;
        SearchResultAdapter searchResultAdapter = this.searchResultsAdapter;
        if (searchResultAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        }
        searchResultAdapter.setMutatingItem(item.getId(), true);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.addItemToActiveList$lambda$103(this.f$0, userList, item);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addItemToActiveList$lambda$103(final ListsScreenView this$0, final UserList list, final QueryItem item) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(list, "$list");
        Intrinsics.checkNotNullParameter(item, "$item");
        try {
            final Pair<Boolean, String> pairAddListItemRequest = this$0.addListItemRequest(list.getId(), item.getId());
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda27
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.addItemToActiveList$lambda$103$lambda$101(this.f$0, item, pairAddListItemRequest, list);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda28
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.addItemToActiveList$lambda$103$lambda$102(this.f$0, item, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addItemToActiveList$lambda$103$lambda$101(ListsScreenView this$0, QueryItem item, Pair res, UserList list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        Intrinsics.checkNotNullParameter(res, "$res");
        Intrinsics.checkNotNullParameter(list, "$list");
        this$0.mutatingItem = false;
        SearchResultAdapter searchResultAdapter = this$0.searchResultsAdapter;
        TextView textView = null;
        if (searchResultAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        }
        searchResultAdapter.setMutatingItem(item.getId(), false);
        if (!((Boolean) res.getFirst()).booleanValue()) {
            String str = (String) res.getSecond();
            if (str == null) {
                str = "افزودن عنوان ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        int size = this$0.listItems.size();
        this$0.listItems.add(item);
        ListItemsAdapter listItemsAdapter = this$0.itemsAdapter;
        if (listItemsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            listItemsAdapter = null;
        }
        listItemsAdapter.notifyItemInserted(size);
        list.setItemCount(this$0.listItems.size());
        List<QueryItem> listTake = CollectionsKt.take(this$0.listItems, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listTake, 10));
        for (QueryItem queryItem : listTake) {
            arrayList.add(new PreviewItem(queryItem.getId(), queryItem.getTitle(), queryItem.getPoster()));
        }
        list.setPreview(CollectionsKt.toMutableList((Collection) arrayList));
        this$0.syncList(list);
        this$0.updateEditItemsHeader();
        this$0.updateSearchItemState();
        TextView textView2 = this$0.itemsEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsEmptyText");
        } else {
            textView = textView2;
        }
        textView.setVisibility(8);
        String str2 = (String) res.getSecond();
        if (str2 == null) {
            str2 = "عنوان به لیست اضافه شد";
        }
        this$0.showToast(str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addItemToActiveList$lambda$103$lambda$102(ListsScreenView this$0, QueryItem item, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.mutatingItem = false;
        SearchResultAdapter searchResultAdapter = this$0.searchResultsAdapter;
        if (searchResultAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        }
        searchResultAdapter.setMutatingItem(item.getId(), false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "افزودن عنوان ناموفق بود"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void removeItemFromActiveList(final QueryItem item) {
        final UserList userList;
        if (this.mutatingItem || (userList = this.activeList) == null || userList == null || item.getId() <= 0) {
            return;
        }
        this.mutatingItem = true;
        ListItemsAdapter listItemsAdapter = this.itemsAdapter;
        if (listItemsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            listItemsAdapter = null;
        }
        listItemsAdapter.setRemovingItem(item.getId(), true);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.removeItemFromActiveList$lambda$108(this.f$0, userList, item);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void removeItemFromActiveList$lambda$108(final ListsScreenView this$0, final UserList list, final QueryItem item) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(list, "$list");
        Intrinsics.checkNotNullParameter(item, "$item");
        try {
            final Pair<Boolean, String> pairRemoveListItemRequest = this$0.removeListItemRequest(list.getId(), item.getId());
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda34
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.removeItemFromActiveList$lambda$108$lambda$106(this.f$0, item, pairRemoveListItemRequest, list);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda35
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.removeItemFromActiveList$lambda$108$lambda$107(this.f$0, item, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void removeItemFromActiveList$lambda$108$lambda$106(ListsScreenView this$0, QueryItem item, Pair res, UserList list) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        Intrinsics.checkNotNullParameter(res, "$res");
        Intrinsics.checkNotNullParameter(list, "$list");
        this$0.mutatingItem = false;
        ListItemsAdapter listItemsAdapter = this$0.itemsAdapter;
        TextView textView = null;
        if (listItemsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            listItemsAdapter = null;
        }
        listItemsAdapter.setRemovingItem(item.getId(), false);
        if (!((Boolean) res.getFirst()).booleanValue()) {
            String str = (String) res.getSecond();
            if (str == null) {
                str = "حذف عنوان ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        Iterator<QueryItem> it = this$0.listItems.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            } else if (it.next().getId() == item.getId()) {
                break;
            } else {
                i++;
            }
        }
        if (i >= 0) {
            this$0.listItems.remove(i);
            ListItemsAdapter listItemsAdapter2 = this$0.itemsAdapter;
            if (listItemsAdapter2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
                listItemsAdapter2 = null;
            }
            listItemsAdapter2.notifyItemRemoved(i);
            if (i < this$0.listItems.size()) {
                ListItemsAdapter listItemsAdapter3 = this$0.itemsAdapter;
                if (listItemsAdapter3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
                    listItemsAdapter3 = null;
                }
                listItemsAdapter3.notifyItemRangeChanged(i, this$0.listItems.size() - i);
            }
        }
        list.setItemCount(this$0.listItems.size());
        List<QueryItem> listTake = CollectionsKt.take(this$0.listItems, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listTake, 10));
        for (QueryItem queryItem : listTake) {
            arrayList.add(new PreviewItem(queryItem.getId(), queryItem.getTitle(), queryItem.getPoster()));
        }
        list.setPreview(CollectionsKt.toMutableList((Collection) arrayList));
        this$0.syncList(list);
        this$0.updateEditItemsHeader();
        this$0.updateSearchItemState();
        TextView textView2 = this$0.itemsEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsEmptyText");
        } else {
            textView = textView2;
        }
        textView.setVisibility(this$0.listItems.isEmpty() ? 0 : 8);
        String str2 = (String) res.getSecond();
        if (str2 == null) {
            str2 = "عنوان از لیست حذف شد";
        }
        this$0.showToast(str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void removeItemFromActiveList$lambda$108$lambda$107(ListsScreenView this$0, QueryItem item, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(item, "$item");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.mutatingItem = false;
        ListItemsAdapter listItemsAdapter = this$0.itemsAdapter;
        if (listItemsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("itemsAdapter");
            listItemsAdapter = null;
        }
        listItemsAdapter.setRemovingItem(item.getId(), false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "حذف عنوان ناموفق بود"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void scheduleSearchFromInput() {
        AppCompatEditText appCompatEditText = this.searchInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        final String strNormalizeSearchQuery = normalizeSearchQuery(text != null ? text.toString() : null);
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        if (StringsKt.isBlank(strNormalizeSearchQuery)) {
            clearSearchResults("حداقل ۲ کاراکتر برای جستجو وارد کنید.");
        } else {
            if (strNormalizeSearchQuery.length() < 2) {
                clearSearchResults("حداقل ۲ کاراکتر برای جستجو وارد کنید.");
                return;
            }
            Runnable runnable2 = new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda29
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.scheduleSearchFromInput$lambda$110(this.f$0, strNormalizeSearchQuery);
                }
            };
            this.searchDebounceRunnable = runnable2;
            this.mainHandler.postDelayed(runnable2, 360L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleSearchFromInput$lambda$110(ListsScreenView this$0, String query) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(query, "$query");
        this$0.performSearch(query);
    }

    private final void triggerSearchNow() {
        AppCompatEditText appCompatEditText = this.searchInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        String strNormalizeSearchQuery = normalizeSearchQuery(text != null ? text.toString() : null);
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        if (StringsKt.isBlank(strNormalizeSearchQuery) || strNormalizeSearchQuery.length() < 2) {
            showToast("حداقل ۲ کاراکتر وارد کنید");
        } else {
            performSearch(strNormalizeSearchQuery);
        }
    }

    private final void performSearch(String query) {
        final UserList userList = this.activeList;
        if (userList == null || this.searching || this.mutatingItem || !isLoggedIn()) {
            return;
        }
        final String strNormalizeSearchQuery = normalizeSearchQuery(query);
        if (strNormalizeSearchQuery.length() < 2) {
            return;
        }
        if (Intrinsics.areEqual(strNormalizeSearchQuery, this.lastSearchQuery) && (!this.searchItems.isEmpty())) {
            return;
        }
        this.searching = true;
        TextView textView = null;
        this.pendingSearchQuery = null;
        this.lastSearchQuery = strNormalizeSearchQuery;
        setSearchLoading(true);
        TextView textView2 = this.searchEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
        } else {
            textView = textView2;
        }
        textView.setVisibility(8);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda37
            @Override // java.lang.Runnable
            public final void run() {
                ListsScreenView.performSearch$lambda$116(userList, strNormalizeSearchQuery, this);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void performSearch$lambda$116(UserList active, final String normalized, final ListsScreenView this$0) {
        Intrinsics.checkNotNullParameter(active, "$active");
        Intrinsics.checkNotNullParameter(normalized, "$normalized");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ParseResult<QueryItem> queryResponse = this$0.parseQueryResponse(requestWithFallback$default(this$0, CollectionsKt.listOf("/query"), "GET", MapsKt.linkedMapOf(TuplesKt.m787to("post_type", active.getType().getQueryPostType()), TuplesKt.m787to("str", normalized), TuplesKt.m787to("page", "1"), TuplesKt.m787to("per_page", "24")), this$0.authHeaders(), null, 16, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda25
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.performSearch$lambda$116$lambda$114(this.f$0, queryResponse, normalized);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda26
                @Override // java.lang.Runnable
                public final void run() {
                    ListsScreenView.performSearch$lambda$116$lambda$115(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void performSearch$lambda$116$lambda$114(ListsScreenView this$0, ParseResult parsed, String normalized) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        Intrinsics.checkNotNullParameter(normalized, "$normalized");
        this$0.searching = false;
        this$0.setSearchLoading(false);
        if (!parsed.getOk()) {
            this$0.showToast(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در جستجو"));
            if (this$0.searchItems.isEmpty()) {
                TextView textView = this$0.searchEmptyText;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView = null;
                }
                textView.setText(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در جستجو"));
                TextView textView2 = this$0.searchEmptyText;
                if (textView2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView2 = null;
                }
                textView2.setVisibility(0);
            }
            String str = this$0.pendingSearchQuery;
            if (str != null) {
                this$0.pendingSearchQuery = null;
                if (Intrinsics.areEqual(this$0.normalizeSearchQuery(str), normalized)) {
                    return;
                }
                this$0.performSearch(str);
                return;
            }
            return;
        }
        int size = this$0.searchItems.size();
        this$0.searchItems.clear();
        if (size > 0) {
            SearchResultAdapter searchResultAdapter = this$0.searchResultsAdapter;
            if (searchResultAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                searchResultAdapter = null;
            }
            searchResultAdapter.notifyItemRangeRemoved(0, size);
        }
        this$0.searchItems.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            SearchResultAdapter searchResultAdapter2 = this$0.searchResultsAdapter;
            if (searchResultAdapter2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                searchResultAdapter2 = null;
            }
            searchResultAdapter2.notifyItemRangeInserted(0, parsed.getItems().size());
        }
        this$0.updateSearchItemState();
        if (this$0.searchItems.isEmpty()) {
            TextView textView3 = this$0.searchEmptyText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                textView3 = null;
            }
            textView3.setText(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "نتیجه\u200cای پیدا نشد."));
            TextView textView4 = this$0.searchEmptyText;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                textView4 = null;
            }
            textView4.setVisibility(0);
        } else {
            TextView textView5 = this$0.searchEmptyText;
            if (textView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                textView5 = null;
            }
            textView5.setVisibility(8);
        }
        String str2 = this$0.pendingSearchQuery;
        if (str2 != null) {
            this$0.pendingSearchQuery = null;
            if (Intrinsics.areEqual(this$0.normalizeSearchQuery(str2), normalized)) {
                return;
            }
            this$0.performSearch(str2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void performSearch$lambda$116$lambda$115(ListsScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.searching = false;
        this$0.setSearchLoading(false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در جستجو"));
        if (this$0.searchItems.isEmpty()) {
            TextView textView = this$0.searchEmptyText;
            TextView textView2 = null;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                textView = null;
            }
            textView.setText("خطا در جستجو. دوباره تلاش کنید.");
            TextView textView3 = this$0.searchEmptyText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
            } else {
                textView2 = textView3;
            }
            textView2.setVisibility(0);
        }
    }

    private final void updateSearchItemState() {
        ArrayList<QueryItem> arrayList = this.listItems;
        HashSet hashSet = new HashSet();
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            hashSet.add(Long.valueOf(((QueryItem) it.next()).getId()));
        }
        HashSet hashSet2 = hashSet;
        SearchResultAdapter searchResultAdapter = this.searchResultsAdapter;
        if (searchResultAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        }
        searchResultAdapter.setExistingIds(hashSet2);
    }

    private final void clearSearchResults(String message) {
        int size = this.searchItems.size();
        this.searchItems.clear();
        TextView textView = null;
        if (size > 0) {
            SearchResultAdapter searchResultAdapter = this.searchResultsAdapter;
            if (searchResultAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                searchResultAdapter = null;
            }
            searchResultAdapter.notifyItemRangeRemoved(0, size);
        }
        SearchResultAdapter searchResultAdapter2 = this.searchResultsAdapter;
        if (searchResultAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter2 = null;
        }
        ArrayList<QueryItem> arrayList = this.listItems;
        HashSet hashSet = new HashSet();
        Iterator<T> it = arrayList.iterator();
        while (it.hasNext()) {
            hashSet.add(Long.valueOf(((QueryItem) it.next()).getId()));
        }
        searchResultAdapter2.setExistingIds(hashSet);
        TextView textView2 = this.searchEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
            textView2 = null;
        }
        textView2.setText(SafeUserMessage.INSTANCE.fromRaw(message, "نتیجه\u200cای یافت نشد."));
        TextView textView3 = this.searchEmptyText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
        } else {
            textView = textView3;
        }
        textView.setVisibility(0);
    }

    /* JADX WARN: Removed duplicated region for block: B:6:0x001e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final String normalizeSearchQuery(String raw) {
        String string;
        if (raw != null) {
            String strReplace = new Regex("\\s+").replace(raw, " ");
            string = strReplace != null ? StringsKt.trim((CharSequence) strReplace).toString() : null;
        }
        return string == null ? "" : string;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x00f0 A[PHI: r4
  0x00f0: PHI (r4v11 java.lang.Long) = (r4v4 java.lang.Long), (r4v7 java.lang.Long) binds: [B:18:0x00ee, B:24:0x0103] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final UserList createListRequest(String title, String description, ListType type) {
        long jLongValue;
        JSONObject jSONObjectOptJSONObject;
        JSONObject jSONObjectOptJSONObject2;
        String string = new JSONObject().put("userID", this.sessionUserId).put("title", title).put("name_list", title).put("description", description).put("description_list", description).put("type", type.getRaw()).put("type_list", type.getRaw()).toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        Triple<Boolean, String, JSONObject> actionResponse = parseActionResponse(requestWithFallback(CollectionsKt.listOf((Object[]) new String[]{"/createList", "/lists/create"}), "POST", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this.sessionUserId)), TuplesKt.m787to("title", title), TuplesKt.m787to("name_list", title), TuplesKt.m787to("description", description), TuplesKt.m787to("description_list", description), TuplesKt.m787to("type", type.getRaw()), TuplesKt.m787to("type_list", type.getRaw())), authHeaders(), string), NotificationCompat.CATEGORY_STATUS);
        if (!actionResponse.getFirst().booleanValue()) {
            return null;
        }
        JSONObject third = actionResponse.getThird();
        Long l = toLong(third != null ? third.opt("listID") : null);
        if (l != null) {
            jLongValue = l.longValue();
        } else {
            Long l2 = toLong(third != null ? third.opt("postID") : null);
            if (l2 == null) {
                l2 = toLong(third != null ? third.opt(TtmlNode.ATTR_ID) : null);
                if (l2 != null) {
                    jLongValue = l2.longValue();
                } else {
                    Long l3 = toLong((third == null || (jSONObjectOptJSONObject2 = third.optJSONObject("data")) == null) ? null : jSONObjectOptJSONObject2.opt("listID"));
                    if (l3 != null) {
                        jLongValue = l3.longValue();
                    } else {
                        Long l4 = toLong((third == null || (jSONObjectOptJSONObject = third.optJSONObject("data")) == null) ? null : jSONObjectOptJSONObject.opt("postID"));
                        jLongValue = l4 != null ? l4.longValue() : -1L;
                    }
                }
            }
        }
        long j = jLongValue;
        if (j > 0) {
            return new UserList(j, title, description, type, 0, new ArrayList());
        }
        resetAndLoadLists();
        return null;
    }

    private final Triple<Boolean, String, JSONObject> updateListInfoRequest(long listId, String title, String description, ListType type) {
        String string = new JSONObject().put("userID", this.sessionUserId).put("listID", listId).put("postID", listId).put("title", title).put("name_list", title).put("description", description).put("description_list", description).put("type", type.getRaw()).put("type_list", type.getRaw()).toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return parseActionResponse(requestWithFallback(CollectionsKt.listOf((Object[]) new String[]{"/editList", "/lists/edit"}), "POST", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this.sessionUserId)), TuplesKt.m787to("listID", String.valueOf(listId)), TuplesKt.m787to("postID", String.valueOf(listId))), authHeaders(), string), NotificationCompat.CATEGORY_STATUS);
    }

    private final Pair<Boolean, String> deleteListRequest(long listId) {
        String string = new JSONObject().put("userID", this.sessionUserId).put("listID", listId).put("postID", listId).toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        Triple<Boolean, String, JSONObject> actionResponse = parseActionResponse(requestWithFallback(CollectionsKt.listOf((Object[]) new String[]{"/deleteList", "/lists/delete"}), "POST", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this.sessionUserId)), TuplesKt.m787to("listID", String.valueOf(listId)), TuplesKt.m787to("postID", String.valueOf(listId))), authHeaders(), string), NotificationCompat.CATEGORY_STATUS);
        return TuplesKt.m787to(actionResponse.getFirst(), actionResponse.getSecond());
    }

    private final Pair<Boolean, String> addListItemRequest(long listId, long itemId) {
        String string = new JSONObject().put("userID", this.sessionUserId).put("listID", listId).put("postID", itemId).put("itemID", itemId).toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        Triple<Boolean, String, JSONObject> actionResponse = parseActionResponse(requestWithFallback(CollectionsKt.listOf((Object[]) new String[]{"/addListItem", "/lists/addItem"}), "POST", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this.sessionUserId)), TuplesKt.m787to("listID", String.valueOf(listId)), TuplesKt.m787to("postID", String.valueOf(itemId)), TuplesKt.m787to("itemID", String.valueOf(itemId))), authHeaders(), string), NotificationCompat.CATEGORY_STATUS);
        return TuplesKt.m787to(actionResponse.getFirst(), actionResponse.getSecond());
    }

    private final Pair<Boolean, String> removeListItemRequest(long listId, long itemId) {
        String string = new JSONObject().put("userID", this.sessionUserId).put("listID", listId).put("postID", itemId).put("itemID", itemId).toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        Triple<Boolean, String, JSONObject> actionResponse = parseActionResponse(requestWithFallback(CollectionsKt.listOf((Object[]) new String[]{"/removeListItem", "/lists/removeItem"}), "POST", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this.sessionUserId)), TuplesKt.m787to("listID", String.valueOf(listId)), TuplesKt.m787to("postID", String.valueOf(itemId)), TuplesKt.m787to("itemID", String.valueOf(itemId))), authHeaders(), string), NotificationCompat.CATEGORY_STATUS);
        return TuplesKt.m787to(actionResponse.getFirst(), actionResponse.getSecond());
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ String requestWithFallback$default(ListsScreenView listsScreenView, List list, String str, Map map, Map map2, String str2, int i, Object obj) {
        if ((i & 4) != 0) {
            map = MapsKt.emptyMap();
        }
        Map map3 = map;
        if ((i & 8) != 0) {
            map2 = MapsKt.emptyMap();
        }
        Map map4 = map2;
        if ((i & 16) != 0) {
            str2 = null;
        }
        return listsScreenView.requestWithFallback(list, str, map3, map4, str2);
    }

    private final String requestWithFallback(List<String> endpointPaths, String method, Map<String, String> query, Map<String, String> headers, String bodyJson) {
        FkApiClient.ApiException th = null;
        for (String str : endpointPaths) {
            try {
            } catch (Throwable th2) {
                th = th2;
            }
            try {
                return FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this.apiBase, str, method, query, headers, bodyJson, false, 64, null);
            } catch (Throwable th3) {
                th = th3;
                if (th instanceof FkApiClient.ApiException) {
                    FkApiClient.ApiException apiException = th;
                    if (apiException.getCode() == 404 || apiException.getCode() == 400) {
                    }
                }
                throw th;
            }
        }
        if (th == null) {
            throw new RuntimeException("Endpoint not available");
        }
        throw th;
    }

    private final ParseResult<UserList> parseListsResponse(String raw) {
        Long l;
        int size;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject != null) {
                String strOptString = jSONObject.optString("code", "");
                Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
                if (true ^ StringsKt.isBlank(StringsKt.trim((CharSequence) strOptString).toString())) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت لیست\u200cها"), null, null, 12, null);
                }
                Object objOpt = jSONObject.opt(NotificationCompat.CATEGORY_STATUS);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL) && !toBool(objOpt)) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت لیست\u200cها"), null, null, 12, null);
                }
            }
            JSONArray jSONArrayExtractArray = extractArray(objNextValue);
            if (jSONArrayExtractArray == null) {
                jSONArrayExtractArray = new JSONArray();
            }
            ArrayList arrayList = new ArrayList(jSONArrayExtractArray.length());
            int length = jSONArrayExtractArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject = jSONArrayExtractArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null && ((l = toLong(jSONObjectOptJSONObject.opt("ID"))) != null || (l = toLong(jSONObjectOptJSONObject.opt(TtmlNode.ATTR_ID))) != null || (l = toLong(jSONObjectOptJSONObject.opt("postID"))) != null)) {
                    long jLongValue = l.longValue();
                    String strPickString = pickString(jSONObjectOptJSONObject, "title", "name", "post_title");
                    if (strPickString == null) {
                        strPickString = "";
                    }
                    String str2 = strPickString;
                    if (StringsKt.isBlank(str2)) {
                        str2 = "لیست #" + jLongValue;
                    }
                    String str3 = str2;
                    String strPickString2 = pickString(jSONObjectOptJSONObject, "description", FirebaseAnalytics.Param.CONTENT, "post_content");
                    String str4 = strPickString2 == null ? "" : strPickString2;
                    ListType listTypeFromRaw = ListType.INSTANCE.fromRaw(pickString(jSONObjectOptJSONObject, "type", "listType", "type_list"));
                    List<PreviewItem> previewItems = parsePreviewItems(jSONObjectOptJSONObject);
                    Integer num = toInt(jSONObjectOptJSONObject.opt("item_count"));
                    if (num == null && (num = toInt(jSONObjectOptJSONObject.opt("items_count"))) == null && (num = toInt(jSONObjectOptJSONObject.opt("count"))) == null && (num = toInt(jSONObjectOptJSONObject.opt("list_count"))) == null) {
                        Integer listItemsCount = parseListItemsCount(jSONObjectOptJSONObject.opt("listItems"));
                        if (listItemsCount != null) {
                            size = listItemsCount.intValue();
                        } else {
                            size = previewItems.size();
                        }
                    } else {
                        size = num.intValue();
                    }
                    arrayList.add(new UserList(jLongValue, str3, str4, listTypeFromRaw, RangesKt.coerceAtLeast(size, 0), CollectionsKt.toMutableList((Collection) previewItems)));
                }
            }
            return new ParseResult<>(true, null, arrayList, jSONObject, 2, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
    }

    private final ParseResult<QueryItem> parseListItemsResponse(String raw) {
        JSONArray jSONArrayOptJSONArray;
        JSONObject jSONObjectOptJSONObject;
        JSONObject jSONObjectOptJSONObject2;
        Long l;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject != null) {
                String strOptString = jSONObject.optString("code", "");
                Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
                if (true ^ StringsKt.isBlank(StringsKt.trim((CharSequence) strOptString).toString())) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت عناوین لیست"), null, null, 12, null);
                }
                Object objOpt = jSONObject.opt(NotificationCompat.CATEGORY_STATUS);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL) && !toBool(objOpt)) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت عناوین لیست"), null, null, 12, null);
                }
            }
            if (jSONObject == null || (jSONArrayOptJSONArray = jSONObject.optJSONArray("listItems")) == null) {
                JSONArray jSONArrayOptJSONArray2 = (jSONObject == null || (jSONObjectOptJSONObject2 = jSONObject.optJSONObject("data")) == null) ? null : jSONObjectOptJSONObject2.optJSONArray("listItems");
                if (jSONArrayOptJSONArray2 == null) {
                    jSONArrayOptJSONArray = (jSONObject == null || (jSONObjectOptJSONObject = jSONObject.optJSONObject("data")) == null) ? null : jSONObjectOptJSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                    if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = extractArray(objNextValue)) == null) {
                        jSONArrayOptJSONArray = new JSONArray();
                    }
                } else {
                    jSONArrayOptJSONArray = jSONArrayOptJSONArray2;
                }
            }
            ArrayList arrayList = new ArrayList(jSONArrayOptJSONArray.length());
            int length = jSONArrayOptJSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject3 = jSONArrayOptJSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject3 != null && ((l = toLong(jSONObjectOptJSONObject3.opt("postID"))) != null || (l = toLong(jSONObjectOptJSONObject3.opt(TtmlNode.ATTR_ID))) != null || (l = toLong(jSONObjectOptJSONObject3.opt("ID"))) != null)) {
                    long jLongValue = l.longValue();
                    String strPickString = pickString(jSONObjectOptJSONObject3, "title", "name", "post_title");
                    if (strPickString == null) {
                        strPickString = "";
                    }
                    String str2 = strPickString;
                    if (StringsKt.isBlank(str2)) {
                        str2 = "بدون عنوان";
                    }
                    String str3 = str2;
                    String strPickString2 = pickString(jSONObjectOptJSONObject3, "thumbnail", "poster", "image", "bgback");
                    if (strPickString2 == null) {
                        strPickString2 = "";
                    }
                    String str4 = strPickString2;
                    if (StringsKt.isBlank(str4)) {
                        str4 = null;
                    }
                    String str5 = str4;
                    String strPickString3 = pickString(jSONObjectOptJSONObject3, "release");
                    if (strPickString3 == null) {
                        strPickString3 = "";
                    }
                    String strPickString4 = pickString(jSONObjectOptJSONObject3, "imdb_rate");
                    if (strPickString4 == null) {
                        strPickString4 = "";
                    }
                    arrayList.add(new QueryItem(jLongValue, str3, buildSubtitle(strPickString3, strPickString4), str5));
                }
            }
            return new ParseResult<>(true, null, arrayList, jSONObject, 2, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0097  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final ParseResult<QueryItem> parseQueryResponse(String raw) {
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            String strOptString = null;
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject != null) {
                String strOptString2 = jSONObject.optString("code", "");
                Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
                if (true ^ StringsKt.isBlank(StringsKt.trim((CharSequence) strOptString2).toString())) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در جستجو"), null, null, 12, null);
                }
                Object objOpt = jSONObject.opt("flag");
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    if (!toBool(objOpt)) {
                        return new ParseResult<>(false, jSONObject.optString("message", "خطا در جستجو"), null, null, 12, null);
                    }
                }
            }
            List<QueryItem> items = parseListItemsResponse(raw).getItems();
            if (items.isEmpty() && jSONObject != null) {
                strOptString = jSONObject.optString("message", "نتیجه\u200cای پیدا نشد.");
            }
            return new ParseResult<>(true, strOptString, items, null, 8, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, null, 12, null);
        }
    }

    static /* synthetic */ Triple parseActionResponse$default(ListsScreenView listsScreenView, String str, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = NotificationCompat.CATEGORY_STATUS;
        }
        return listsScreenView.parseActionResponse(str, str2);
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x00be A[PHI: r8
  0x00be: PHI (r8v3 java.lang.Object) = (r8v2 java.lang.Object), (r8v7 java.lang.Object), (r8v9 java.lang.Object) binds: [B:39:0x0090, B:49:0x00a9, B:55:0x00bc] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final Triple<Boolean, String, JSONObject> parseActionResponse(String raw, String successKey) {
        Object objNextValue;
        String str = raw;
        boolean z = false;
        Object obj = null;
        if (str == null || StringsKt.isBlank(str)) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        if (objNextValue == null) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
        if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r0).toString())) {
            return new Triple<>(false, jSONObject.optString("message", "عملیات ناموفق بود"), jSONObject);
        }
        String strPickString = pickString(jSONObject, "message");
        Object objOpt = jSONObject.opt(successKey);
        if (!((objOpt == null || Intrinsics.areEqual(objOpt, JSONObject.NULL)) ? false : true)) {
            objOpt = null;
        }
        if (objOpt != null) {
            obj = objOpt;
        } else {
            objOpt = jSONObject.opt("flag");
            if (!((objOpt == null || Intrinsics.areEqual(objOpt, JSONObject.NULL)) ? false : true)) {
                objOpt = null;
            }
            if (objOpt == null) {
                objOpt = jSONObject.opt("ok");
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    z = true;
                }
                if (z) {
                }
            }
        }
        return new Triple<>(Boolean.valueOf(obj != null ? toBool(obj) : true), strPickString, jSONObject);
    }

    private final List<PreviewItem> parsePreviewItems(JSONObject row) {
        Long l;
        JSONArray jSONArrayOptJSONArray = row.optJSONArray("preview");
        if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = row.optJSONArray("items_preview")) == null) {
            jSONArrayOptJSONArray = row.optJSONArray(FirebaseAnalytics.Param.ITEMS);
        }
        if (jSONArrayOptJSONArray == null) {
            jSONArrayOptJSONArray = new JSONArray();
        }
        ArrayList arrayList = new ArrayList(Math.min(6, jSONArrayOptJSONArray.length()));
        int length = jSONArrayOptJSONArray.length();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null && ((l = toLong(jSONObjectOptJSONObject.opt("postID"))) != null || (l = toLong(jSONObjectOptJSONObject.opt(TtmlNode.ATTR_ID))) != null || (l = toLong(jSONObjectOptJSONObject.opt("ID"))) != null)) {
                long jLongValue = l.longValue();
                String strPickString = pickString(jSONObjectOptJSONObject, "thumbnail", "poster", "image", "bgback");
                String strPickString2 = pickString(jSONObjectOptJSONObject, "title", "name", "post_title");
                if (strPickString2 == null) {
                    strPickString2 = "";
                }
                arrayList.add(new PreviewItem(jLongValue, strPickString2, strPickString));
                if (arrayList.size() >= 6) {
                    break;
                }
            }
        }
        return arrayList;
    }

    private final Integer parseListItemsCount(Object raw) {
        List<String> groupValues;
        String str;
        if (raw instanceof JSONArray) {
            return Integer.valueOf(((JSONArray) raw).length());
        }
        if (!(raw instanceof String)) {
            return null;
        }
        String string = StringsKt.trim((CharSequence) raw).toString();
        if (StringsKt.startsWith$default(string, "a:", false, 2, (Object) null)) {
            MatchResult matchResultFind$default = Regex.find$default(new Regex("^a:(\\d+):"), string, 0, 2, null);
            if (matchResultFind$default == null || (groupValues = matchResultFind$default.getGroupValues()) == null || (str = (String) CollectionsKt.getOrNull(groupValues, 1)) == null) {
                return null;
            }
            return StringsKt.toIntOrNull(str);
        }
        if (StringsKt.isBlank(string)) {
            return 0;
        }
        return StringsKt.toIntOrNull(string);
    }

    private final JSONArray extractArray(Object root) {
        if (root instanceof JSONArray) {
            return (JSONArray) root;
        }
        if (!(root instanceof JSONObject)) {
            return null;
        }
        JSONObject jSONObject = (JSONObject) root;
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
        return (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = jSONObject.optJSONArray("data")) == null && (jSONArrayOptJSONArray = jSONObject.optJSONArray("result")) == null) ? numericObjectToArray(jSONObject) : jSONArrayOptJSONArray;
    }

    private final String buildSubtitle(String release, String imdb) {
        String string = release != null ? StringsKt.trim((CharSequence) release).toString() : null;
        if (string == null) {
            string = "";
        }
        String string2 = imdb != null ? StringsKt.trim((CharSequence) imdb).toString() : null;
        String str = string2 != null ? string2 : "";
        String str2 = string;
        if (str2.length() == 0) {
            if (str.length() == 0) {
                return null;
            }
        }
        StringBuilder sb = new StringBuilder();
        if (str2.length() > 0) {
            sb.append("سال: ").append(string);
        }
        if (str.length() > 0) {
            if (sb.length() > 0) {
                sb.append("   ");
            }
            sb.append("IMDB: ").append(str);
        }
        return sb.toString();
    }

    private final JSONArray numericObjectToArray(JSONObject obj) {
        boolean z;
        Iterator<String> itKeys = obj.keys();
        JSONArray jSONArray = new JSONArray();
        boolean z2 = false;
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            Intrinsics.checkNotNull(next);
            String str = next;
            int i = 0;
            while (true) {
                if (i >= str.length()) {
                    z = true;
                    break;
                }
                if (!Character.isDigit(str.charAt(i))) {
                    z = false;
                    break;
                }
                i++;
            }
            if (z) {
                Object objOpt = obj.opt(next);
                if (objOpt instanceof JSONObject) {
                    jSONArray.put(objOpt);
                    z2 = true;
                }
            }
        }
        if (z2) {
            return jSONArray;
        }
        return null;
    }

    private final void syncList(UserList updated) {
        Iterator<UserList> it = this.lists.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            } else {
                if (it.next().getId() == updated.getId()) {
                    break;
                } else {
                    i++;
                }
            }
        }
        if (i >= 0) {
            this.lists.set(i, updated);
            ListsAdapter listsAdapter = this.listAdapter;
            if (listsAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("listAdapter");
                listsAdapter = null;
            }
            listsAdapter.notifyItemChanged(i);
        }
    }

    private final void setFormSubmitting(boolean loading) {
        TextView textView = this.formSubmitButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formSubmitButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.formSubmitButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formSubmitButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.75f : 1.0f);
        TextView textView4 = this.formSubmitButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formSubmitButton");
            textView4 = null;
        }
        textView4.setText(loading ? "در حال ذخیره..." : this.createMode ? "ساخت لیست" : "ذخیره تغییرات");
        AppCompatEditText appCompatEditText = this.formTitleInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formTitleInput");
            appCompatEditText = null;
        }
        appCompatEditText.setEnabled(!loading);
        AppCompatEditText appCompatEditText2 = this.formDescInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("formDescInput");
            appCompatEditText2 = null;
        }
        appCompatEditText2.setEnabled(!loading);
        TextView textView5 = this.typeMovieChip;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeMovieChip");
            textView5 = null;
        }
        textView5.setEnabled(!loading);
        TextView textView6 = this.typeSeriesChip;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeSeriesChip");
        } else {
            textView2 = textView6;
        }
        textView2.setEnabled(!loading);
    }

    private final void setSearchLoading(boolean loading) {
        AppCompatEditText appCompatEditText = this.searchInput;
        ProgressBar progressBar = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        appCompatEditText.setAlpha(loading ? 0.92f : 1.0f);
        ProgressBar progressBar2 = this.searchResultsLoading;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsLoading");
        } else {
            progressBar = progressBar2;
        }
        progressBar.setVisibility(loading ? 0 : 8);
    }

    private final void showState(String message, String buttonText, Function0<Unit> action) {
        TextView textView = this.stateText;
        LinearLayout linearLayout = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView = null;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت لیست\u200cها"));
        this.stateAction = action;
        String str = buttonText;
        if (str == null || StringsKt.isBlank(str)) {
            TextView textView2 = this.stateButton;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView2 = null;
            }
            textView2.setVisibility(8);
        } else {
            TextView textView3 = this.stateButton;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView3 = null;
            }
            textView3.setVisibility(0);
            TextView textView4 = this.stateButton;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView4 = null;
            }
            textView4.setText(str);
        }
        LinearLayout linearLayout2 = this.stateOverlay;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
        } else {
            linearLayout = linearLayout2;
        }
        linearLayout.setVisibility(0);
    }

    private final void hideState() {
        LinearLayout linearLayout = this.stateOverlay;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        }
        linearLayout.setVisibility(8);
        this.stateAction = null;
    }

    private final void showToast(String text) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(text, "عملیات انجام نشد"), 0).show();
    }

    private final boolean isLoggedIn() {
        if (this.sessionUserId > 0) {
            String str = this.sessionToken;
            if (!(str == null || StringsKt.isBlank(str))) {
                return true;
            }
        }
        return false;
    }

    private final Map<String, String> authHeaders() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        long j = this.sessionUserId;
        if (j > 0) {
            linkedHashMap.put("x-fk-user-id", String.valueOf(j));
        }
        String str = this.sessionToken;
        String str2 = str;
        if (!(str2 == null || StringsKt.isBlank(str2))) {
            linkedHashMap.put("x-fk-session", str);
        }
        return linkedHashMap;
    }

    private final TextView makeFieldLabel(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setTextColor(-3154708);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        return textView;
    }

    private final void applyFieldStyle(final AppCompatEditText field) {
        field.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m381dp(2), dpF(16)));
        field.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda5
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                ListsScreenView.applyFieldStyle$lambda$129(field, this, view, z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyFieldStyle$lambda$129(AppCompatEditText field, ListsScreenView this$0, View view, boolean z) {
        Intrinsics.checkNotNullParameter(field, "$field");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        field.setBackground(this$0.roundedBg(this$0.fieldFill, z ? this$0.accent : this$0.fieldStroke, this$0.m381dp(2), this$0.dpF(16)));
    }

    private final TextView makeTypeChip(String label, final Function0<Unit> onClick) {
        TextView textView = new TextView(this.ctx);
        textView.setText(label);
        textView.setTextSize(14.0f);
        textView.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setIncludeFontPadding(false);
        textView.setPadding(m381dp(12), m381dp(10), m381dp(12), m381dp(10));
        textView.setClickable(true);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(true ^ this.isTouchDevice);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$$ExternalSyntheticLambda36
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ListsScreenView.makeTypeChip$lambda$131$lambda$130(onClick, view);
            }
        });
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeTypeChip$lambda$131$lambda$130(Function0 onClick, View view) {
        Intrinsics.checkNotNullParameter(onClick, "$onClick");
        onClick.invoke();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void applyTypeChipState() {
        boolean z = this.selectedListType == ListType.MOVIES;
        boolean z2 = this.selectedListType == ListType.SERIES;
        TextView textView = this.typeMovieChip;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeMovieChip");
            textView = null;
        }
        textView.setTextColor(z ? -16052459 : -2299660);
        TextView textView3 = this.typeMovieChip;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeMovieChip");
            textView3 = null;
        }
        textView3.setBackground(roundedBg(z ? this.accent : 302912798, z ? 0 : 860772969, m381dp(1), dpF(12)));
        TextView textView4 = this.typeSeriesChip;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeSeriesChip");
            textView4 = null;
        }
        textView4.setTextColor(z2 ? -16052459 : -2299660);
        TextView textView5 = this.typeSeriesChip;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("typeSeriesChip");
        } else {
            textView2 = textView5;
        }
        textView2.setBackground(roundedBg(z2 ? this.accent : 302912798, z2 ? 0 : 860772969, m381dp(1), dpF(12)));
    }

    private final FrameLayout makeLoadingMoreOverlay() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m381dp(12), m381dp(8), m381dp(12), m381dp(8));
        linearLayout.setBackground(roundedBg(-653454566, 654311423, m381dp(1), dpF(12)));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        TextView textView = new TextView(this.ctx);
        textView.setText("در حال بارگیری بیشتر...");
        textView.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        linearLayout.addView(progressBar, new LinearLayout.LayoutParams(m381dp(14), m381dp(14)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(m381dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 81;
        layoutParams2.bottomMargin = m381dp(18);
        Unit unit2 = Unit.INSTANCE;
        frameLayout.addView(linearLayout, layoutParams2);
        return frameLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    private final String pickString(JSONObject obj, String... keys) {
        if (obj == null) {
            return null;
        }
        for (String str : keys) {
            Object objOpt = obj.opt(str);
            if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                if (!StringsKt.isBlank(string)) {
                    return string;
                }
            }
        }
        return null;
    }

    private final Long toLong(Object v) {
        if (v instanceof Number) {
            return Long.valueOf(((Number) v).longValue());
        }
        if (v instanceof String) {
            return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) StringsKt.replace$default((String) v, ",", "", false, 4, (Object) null)).toString());
        }
        return null;
    }

    private final Integer toInt(Object v) {
        if (v instanceof Number) {
            return Integer.valueOf(((Number) v).intValue());
        }
        if (v instanceof String) {
            return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
        }
        return null;
    }

    private final boolean toBool(Object v) {
        if (v instanceof Boolean) {
            return ((Boolean) v).booleanValue();
        }
        if (v instanceof Number) {
            if (((Number) v).intValue() != 0) {
                return true;
            }
        } else if (v instanceof String) {
            String string = StringsKt.trim((CharSequence) v).toString();
            Locale US = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US, "US");
            String lowerCase = string.toLowerCase(US);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, "1") || Intrinsics.areEqual(lowerCase, "true") || Intrinsics.areEqual(lowerCase, "ok") || Intrinsics.areEqual(lowerCase, FirebaseAnalytics.Param.SUCCESS)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m381dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.searchDebounceRunnable = null;
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0019BW\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0002\u0010\u000eJ\b\u0010\u000f\u001a\u00020\u0010H\u0016J \u0010\u0011\u001a\u00020\u000b2\u000e\u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0010H\u0016J \u0010\u0014\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0010H\u0016J\u0018\u0010\u0018\u001a\u00020\u000b2\u000e\u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListsAdapter$VH;", "Lcom/filmkio/nativescreen/account/ListsScreenView;", "lists", "", "Lcom/filmkio/nativescreen/account/ListsScreenView$UserList;", "isTouchDevice", "", "onEditInfo", "Lkotlin/Function1;", "", "onEditItems", "onDelete", "(Lcom/filmkio/nativescreen/account/ListsScreenView;Ljava/util/List;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "getItemCount", "", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class ListsAdapter extends RecyclerView.Adapter<C2658VH> {
        private final boolean isTouchDevice;
        private final List<UserList> lists;
        private final Function1<UserList, Unit> onDelete;
        private final Function1<UserList, Unit> onEditInfo;
        private final Function1<UserList, Unit> onEditItems;
        final /* synthetic */ ListsScreenView this$0;

        /* JADX WARN: Multi-variable type inference failed */
        public ListsAdapter(ListsScreenView listsScreenView, List<UserList> lists, boolean z, Function1<? super UserList, Unit> onEditInfo, Function1<? super UserList, Unit> onEditItems, Function1<? super UserList, Unit> onDelete) {
            Intrinsics.checkNotNullParameter(lists, "lists");
            Intrinsics.checkNotNullParameter(onEditInfo, "onEditInfo");
            Intrinsics.checkNotNullParameter(onEditItems, "onEditItems");
            Intrinsics.checkNotNullParameter(onDelete, "onDelete");
            this.this$0 = listsScreenView;
            this.lists = lists;
            this.isTouchDevice = z;
            this.onEditInfo = onEditInfo;
            this.onEditItems = onEditItems;
            this.onDelete = onDelete;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2658VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            ListsScreenView listsScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(listsScreenView.m381dp(4), listsScreenView.m381dp(4), listsScreenView.m381dp(4), listsScreenView.m381dp(8));
            linearLayout.setBackground(listsScreenView.roundedBg(-15789028, 778990720, listsScreenView.m381dp(1), listsScreenView.dpF(16)));
            linearLayout.setClipToOutline(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            linearLayout.setClickable(true);
            return new C2658VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2658VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.lists.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.lists.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2658VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m381dp(12);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.ListsScreenView$ListsAdapter$VH */
        /* JADX INFO: compiled from: ListsScreenView.kt */
        @Metadata(m779d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fJ(\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u0014H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0017"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListsAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/ListsScreenView$ListsAdapter;Landroid/widget/LinearLayout;)V", "deleteBtn", "Landroid/widget/TextView;", "editInfoBtn", "editItemsBtn", "metaCount", "metaType", "title", "bind", "", "item", "Lcom/filmkio/nativescreen/account/ListsScreenView$UserList;", "makeActionButton", Constants.ScionAnalytics.PARAM_LABEL, "", "textColor", "", "fill", "stroke", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2658VH extends RecyclerView.ViewHolder {
            private final TextView deleteBtn;
            private final TextView editInfoBtn;
            private final TextView editItemsBtn;
            private final TextView metaCount;
            private final TextView metaType;
            private final LinearLayout root;
            final /* synthetic */ ListsAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2658VH(ListsAdapter listsAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = listsAdapter;
                this.root = root;
                LinearLayout linearLayout = new LinearLayout(listsAdapter.this$0.ctx);
                ListsScreenView listsScreenView = listsAdapter.this$0;
                linearLayout.setOrientation(0);
                linearLayout.setLayoutDirection(1);
                linearLayout.setGravity(16);
                linearLayout.setPadding(listsScreenView.m381dp(8), listsScreenView.m381dp(10), listsScreenView.m381dp(8), listsScreenView.m381dp(8));
                ImageView imageView = new ImageView(listsAdapter.this$0.ctx);
                imageView.setImageResource(C2629R.drawable.ic_back);
                imageView.setColorFilter(-1);
                imageView.setAlpha(0.9f);
                TextView textView = new TextView(listsAdapter.this$0.ctx);
                ListsScreenView listsScreenView2 = listsAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(15.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(listsScreenView2.ctx);
                textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
                textView.setIncludeFontPadding(false);
                textView.setGravity(5);
                textView.setMaxLines(1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                textView.setTextAlignment(1);
                textView.setTextDirection(3);
                this.title = textView;
                linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(listsAdapter.this$0.m381dp(18), listsAdapter.this$0.m381dp(18));
                layoutParams.setMarginEnd(listsAdapter.this$0.m381dp(6));
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(imageView, layoutParams);
                View view = new View(listsAdapter.this$0.ctx);
                view.setBackgroundColor(778990720);
                LinearLayout linearLayout2 = new LinearLayout(listsAdapter.this$0.ctx);
                ListsScreenView listsScreenView3 = listsAdapter.this$0;
                linearLayout2.setOrientation(0);
                linearLayout2.setLayoutDirection(1);
                linearLayout2.setGravity(16);
                linearLayout2.setPadding(listsScreenView3.m381dp(8), listsScreenView3.m381dp(8), listsScreenView3.m381dp(8), listsScreenView3.m381dp(6));
                TextView textView2 = new TextView(listsAdapter.this$0.ctx);
                ListsScreenView listsScreenView4 = listsAdapter.this$0;
                textView2.setTextColor(-419430401);
                textView2.setTextSize(12.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(listsScreenView4.ctx);
                textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
                textView2.setIncludeFontPadding(false);
                textView2.setMaxLines(1);
                textView2.setEllipsize(TextUtils.TruncateAt.END);
                this.metaType = textView2;
                TextView textView3 = new TextView(listsAdapter.this$0.ctx);
                ListsScreenView listsScreenView5 = listsAdapter.this$0;
                textView3.setTextColor(-419430401);
                textView3.setTextSize(12.0f);
                Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(listsScreenView5.ctx);
                textView3.setTypeface(typefaceRegular2 == null ? textView3.getTypeface() : typefaceRegular2);
                textView3.setIncludeFontPadding(false);
                textView3.setMaxLines(1);
                textView3.setEllipsize(TextUtils.TruncateAt.END);
                textView3.setTextDirection(3);
                textView3.setGravity(3);
                textView3.setTextAlignment(5);
                this.metaCount = textView3;
                linearLayout2.addView(textView2, new LinearLayout.LayoutParams(-2, -2));
                linearLayout2.addView(new View(listsAdapter.this$0.ctx), new LinearLayout.LayoutParams(0, 0, 1.0f));
                linearLayout2.addView(textView3, new LinearLayout.LayoutParams(-2, -2));
                LinearLayout linearLayout3 = new LinearLayout(listsAdapter.this$0.ctx);
                linearLayout3.setOrientation(0);
                linearLayout3.setLayoutDirection(1);
                linearLayout3.setGravity(16);
                TextView textViewMakeActionButton = makeActionButton("ویرایش اطلاعات", -12082433, 303442752, 1430163414);
                this.editInfoBtn = textViewMakeActionButton;
                TextView textViewMakeActionButton2 = makeActionButton("ویرایش عناوین", listsAdapter.this$0.accent, 337521209, 1727376657);
                this.editItemsBtn = textViewMakeActionButton2;
                TextView textViewMakeActionButton3 = makeActionButton("حذف لیست", -37260, 404360462, 1728015988);
                this.deleteBtn = textViewMakeActionButton3;
                int iM381dp = listsAdapter.this$0.m381dp(3);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams2.setMarginStart(iM381dp);
                layoutParams2.setMarginEnd(iM381dp);
                Unit unit2 = Unit.INSTANCE;
                linearLayout3.addView(textViewMakeActionButton, layoutParams2);
                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams3.setMarginStart(iM381dp);
                layoutParams3.setMarginEnd(iM381dp);
                Unit unit3 = Unit.INSTANCE;
                linearLayout3.addView(textViewMakeActionButton2, layoutParams3);
                LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams4.setMarginStart(iM381dp);
                layoutParams4.setMarginEnd(iM381dp);
                Unit unit4 = Unit.INSTANCE;
                linearLayout3.addView(textViewMakeActionButton3, layoutParams4);
                root.addView(linearLayout, new LinearLayout.LayoutParams(-1, -2));
                LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, listsAdapter.this$0.m381dp(1));
                layoutParams5.topMargin = listsAdapter.this$0.m381dp(4);
                Unit unit5 = Unit.INSTANCE;
                root.addView(view, layoutParams5);
                root.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
                LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams6.topMargin = listsAdapter.this$0.m381dp(8);
                Unit unit6 = Unit.INSTANCE;
                root.addView(linearLayout3, layoutParams6);
            }

            public final void bind(final UserList item) {
                Intrinsics.checkNotNullParameter(item, "item");
                TextView textView = this.title;
                String string = StringsKt.trim((CharSequence) item.getTitle()).toString();
                if (StringsKt.isBlank(string)) {
                    string = "لیست بدون عنوان";
                }
                textView.setText(string);
                this.metaType.setText(item.getType() == ListType.SERIES ? "نوع: سریال" : "نوع: فیلم");
                this.metaCount.setText(item.getItemCount() + " عنوان");
                LinearLayout linearLayout = this.root;
                final ListsAdapter listsAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListsAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListsAdapter.C2658VH.bind$lambda$15(listsAdapter, item, view);
                    }
                });
                TextView textView2 = this.editInfoBtn;
                final ListsAdapter listsAdapter2 = this.this$0;
                textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListsAdapter$VH$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListsAdapter.C2658VH.bind$lambda$16(listsAdapter2, item, view);
                    }
                });
                TextView textView3 = this.editItemsBtn;
                final ListsAdapter listsAdapter3 = this.this$0;
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListsAdapter$VH$$ExternalSyntheticLambda2
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListsAdapter.C2658VH.bind$lambda$17(listsAdapter3, item, view);
                    }
                });
                TextView textView4 = this.deleteBtn;
                final ListsAdapter listsAdapter4 = this.this$0;
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListsAdapter$VH$$ExternalSyntheticLambda3
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListsAdapter.C2658VH.bind$lambda$18(listsAdapter4, item, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$15(ListsAdapter this$0, UserList item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onEditItems.invoke(item);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$16(ListsAdapter this$0, UserList item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onEditInfo.invoke(item);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$17(ListsAdapter this$0, UserList item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onEditItems.invoke(item);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$18(ListsAdapter this$0, UserList item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onDelete.invoke(item);
            }

            private final TextView makeActionButton(String label, int textColor, int fill, int stroke) {
                TextView textView = new TextView(this.this$0.this$0.ctx);
                ListsScreenView listsScreenView = this.this$0.this$0;
                ListsAdapter listsAdapter = this.this$0;
                textView.setText(label);
                textView.setTextColor(textColor);
                textView.setTextSize(12.0f);
                textView.setGravity(17);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(listsScreenView.ctx);
                if (typefaceBold == null) {
                    typefaceBold = textView.getTypeface();
                }
                textView.setTypeface(typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setPadding(listsScreenView.m381dp(8), listsScreenView.m381dp(9), listsScreenView.m381dp(8), listsScreenView.m381dp(9));
                textView.setBackground(listsScreenView.roundedBg(fill, stroke, listsScreenView.m381dp(1), listsScreenView.dpF(999)));
                textView.setFocusable(!listsAdapter.isTouchDevice);
                textView.setFocusableInTouchMode(!listsAdapter.isTouchDevice);
                textView.setMaxLines(1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                return textView;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\"\n\u0002\b\u0005\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\"B/\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0002\u0010\fJ\b\u0010\u0012\u001a\u00020\u0013H\u0016J \u0010\u0014\u001a\u00020\u000b2\u000e\u0010\u0015\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0016\u001a\u00020\u0013H\u0016J \u0010\u0017\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0013H\u0016J\u0018\u0010\u001b\u001a\u00020\u000b2\u000e\u0010\u0015\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016J\u0014\u0010\u001c\u001a\u00020\u000b2\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001eJ\u0016\u0010\u001f\u001a\u00020\u000b2\u0006\u0010 \u001a\u00020\u000f2\u0006\u0010!\u001a\u00020\bR\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\u000f0\u000ej\b\u0012\u0004\u0012\u00020\u000f`\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0011\u001a\u0012\u0012\u0004\u0012\u00020\u000f0\u000ej\b\u0012\u0004\u0012\u00020\u000f`\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006#"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$SearchResultAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/ListsScreenView$SearchResultAdapter$VH;", "Lcom/filmkio/nativescreen/account/ListsScreenView;", "data", "", "Lcom/filmkio/nativescreen/querygrid/QueryItem;", "isTouchDevice", "", "onAdd", "Lkotlin/Function1;", "", "(Lcom/filmkio/nativescreen/account/ListsScreenView;Ljava/util/List;ZLkotlin/jvm/functions/Function1;)V", "existingIds", "Ljava/util/HashSet;", "", "Lkotlin/collections/HashSet;", "mutatingIds", "getItemCount", "", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "setExistingIds", "ids", "", "setMutatingItem", TtmlNode.ATTR_ID, "loading", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class SearchResultAdapter extends RecyclerView.Adapter<C2659VH> {
        private final List<QueryItem> data;
        private final HashSet<Long> existingIds;
        private final boolean isTouchDevice;
        private final HashSet<Long> mutatingIds;
        private final Function1<QueryItem, Unit> onAdd;
        final /* synthetic */ ListsScreenView this$0;

        /* JADX WARN: Multi-variable type inference failed */
        public SearchResultAdapter(ListsScreenView listsScreenView, List<QueryItem> data, boolean z, Function1<? super QueryItem, Unit> onAdd) {
            Intrinsics.checkNotNullParameter(data, "data");
            Intrinsics.checkNotNullParameter(onAdd, "onAdd");
            this.this$0 = listsScreenView;
            this.data = data;
            this.isTouchDevice = z;
            this.onAdd = onAdd;
            this.existingIds = new HashSet<>();
            this.mutatingIds = new HashSet<>();
        }

        public final void setExistingIds(Set<Long> ids) {
            Intrinsics.checkNotNullParameter(ids, "ids");
            this.existingIds.clear();
            this.existingIds.addAll(ids);
            notifyDataSetChanged();
        }

        public final void setMutatingItem(long id, boolean loading) {
            if (loading) {
                this.mutatingIds.add(Long.valueOf(id));
            } else {
                this.mutatingIds.remove(Long.valueOf(id));
            }
            Iterator<QueryItem> it = this.data.iterator();
            int i = 0;
            while (true) {
                if (!it.hasNext()) {
                    i = -1;
                    break;
                } else {
                    if (it.next().getId() == id) {
                        break;
                    } else {
                        i++;
                    }
                }
            }
            if (i >= 0) {
                notifyItemChanged(i);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2659VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            ListsScreenView listsScreenView = this.this$0;
            linearLayout.setOrientation(0);
            linearLayout.setLayoutDirection(1);
            linearLayout.setGravity(16);
            linearLayout.setPadding(listsScreenView.m381dp(8), listsScreenView.m381dp(8), listsScreenView.m381dp(8), listsScreenView.m381dp(8));
            linearLayout.setBackground(listsScreenView.roundedBg(319690014, 642669161, listsScreenView.m381dp(1), listsScreenView.dpF(10)));
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2659VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2659VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2659VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m381dp(8);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.ListsScreenView$SearchResultAdapter$VH */
        /* JADX INFO: compiled from: ListsScreenView.kt */
        @Metadata(m779d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$SearchResultAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/ListsScreenView$SearchResultAdapter;Landroid/widget/LinearLayout;)V", "addBtn", "Landroid/widget/TextView;", "poster", "Landroid/widget/ImageView;", "subtitle", "title", "bind", "", "item", "Lcom/filmkio/nativescreen/querygrid/QueryItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2659VH extends RecyclerView.ViewHolder {
            private final TextView addBtn;
            private final ImageView poster;
            private final LinearLayout root;
            private final TextView subtitle;
            final /* synthetic */ SearchResultAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2659VH(SearchResultAdapter searchResultAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = searchResultAdapter;
                this.root = root;
                FrameLayout frameLayout = new FrameLayout(searchResultAdapter.this$0.ctx);
                ListsScreenView listsScreenView = searchResultAdapter.this$0;
                frameLayout.setBackground(listsScreenView.roundedBg(470684958, 709778025, listsScreenView.m381dp(1), listsScreenView.dpF(8)));
                frameLayout.setClipToOutline(true);
                ImageView imageView = new ImageView(searchResultAdapter.this$0.ctx);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageResource(C2629R.drawable.ic_panel_lists);
                imageView.setColorFilter(-2957330);
                this.poster = imageView;
                frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout linearLayout = new LinearLayout(searchResultAdapter.this$0.ctx);
                linearLayout.setOrientation(1);
                linearLayout.setLayoutDirection(1);
                linearLayout.setGravity(5);
                TextView textView = new TextView(searchResultAdapter.this$0.ctx);
                ListsScreenView listsScreenView2 = searchResultAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(13.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(listsScreenView2.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setGravity(5);
                textView.setTextAlignment(1);
                textView.setTextDirection(3);
                textView.setMaxLines(2);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                this.title = textView;
                TextView textView2 = new TextView(searchResultAdapter.this$0.ctx);
                ListsScreenView listsScreenView3 = searchResultAdapter.this$0;
                textView2.setTextColor(-4798243);
                textView2.setTextSize(11.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(listsScreenView3.ctx);
                textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
                textView2.setIncludeFontPadding(false);
                textView2.setGravity(5);
                textView2.setTextAlignment(1);
                textView2.setMaxLines(2);
                textView2.setEllipsize(TextUtils.TruncateAt.END);
                this.subtitle = textView2;
                linearLayout.addView(textView);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = searchResultAdapter.this$0.m381dp(4);
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(textView2, layoutParams);
                TextView textView3 = new TextView(searchResultAdapter.this$0.ctx);
                ListsScreenView listsScreenView4 = searchResultAdapter.this$0;
                textView3.setTextSize(11.0f);
                textView3.setGravity(17);
                Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(listsScreenView4.ctx);
                textView3.setTypeface(typefaceBold2 == null ? textView3.getTypeface() : typefaceBold2);
                textView3.setIncludeFontPadding(false);
                textView3.setPadding(listsScreenView4.m381dp(10), listsScreenView4.m381dp(7), listsScreenView4.m381dp(10), listsScreenView4.m381dp(7));
                this.addBtn = textView3;
                root.addView(frameLayout, new LinearLayout.LayoutParams(searchResultAdapter.this$0.m381dp(52), searchResultAdapter.this$0.m381dp(74)));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                ListsScreenView listsScreenView5 = searchResultAdapter.this$0;
                layoutParams2.setMarginStart(listsScreenView5.m381dp(8));
                layoutParams2.setMarginEnd(listsScreenView5.m381dp(8));
                Unit unit2 = Unit.INSTANCE;
                root.addView(linearLayout, layoutParams2);
                root.addView(textView3);
            }

            public final void bind(final QueryItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.title.setText(item.getTitle());
                TextView textView = this.subtitle;
                String subtitle = item.getSubtitle();
                if (subtitle == null) {
                    subtitle = "";
                }
                String str = subtitle;
                if (StringsKt.isBlank(str)) {
                    str = "-";
                }
                textView.setText(str);
                String poster = item.getPoster();
                if (poster == null || StringsKt.isBlank(poster)) {
                    this.poster.setImageResource(C2629R.drawable.ic_panel_lists);
                    this.poster.setColorFilter(-2957330);
                } else {
                    this.poster.clearColorFilter();
                    ImageView imageView = this.poster;
                    String poster2 = item.getPoster();
                    ImageLoader imageLoader = this.this$0.this$0.imageLoader;
                    ListsScreenView listsScreenView = this.this$0.this$0;
                    ImageRequest.Builder builderTarget = new ImageRequest.Builder(imageView.getContext()).data(poster2).target(imageView);
                    builderTarget.size(listsScreenView.m381dp(52), listsScreenView.m381dp(74));
                    builderTarget.allowHardware(true);
                    builderTarget.crossfade(false);
                    imageLoader.enqueue(builderTarget.build());
                }
                final boolean zContains = this.this$0.existingIds.contains(Long.valueOf(item.getId()));
                final boolean zContains2 = this.this$0.mutatingIds.contains(Long.valueOf(item.getId()));
                if (zContains2) {
                    this.addBtn.setText("...");
                    this.addBtn.setEnabled(false);
                    this.addBtn.setAlpha(0.8f);
                    this.addBtn.setTextColor(-2299660);
                    this.addBtn.setBackground(this.this$0.this$0.roundedBg(437130526, 1157627903, this.this$0.this$0.m381dp(1), this.this$0.this$0.dpF(999)));
                } else if (zContains) {
                    this.addBtn.setText("اضافه شده");
                    this.addBtn.setEnabled(false);
                    this.addBtn.setAlpha(1.0f);
                    this.addBtn.setTextColor(-16052459);
                    this.addBtn.setBackground(this.this$0.this$0.roundedBg(this.this$0.this$0.accent, 0, 0, this.this$0.this$0.dpF(999)));
                } else {
                    this.addBtn.setText("افزودن");
                    this.addBtn.setEnabled(true);
                    this.addBtn.setAlpha(1.0f);
                    this.addBtn.setTextColor(-2299660);
                    this.addBtn.setBackground(this.this$0.this$0.roundedBg(437130526, 1157627903, this.this$0.this$0.m381dp(1), this.this$0.this$0.dpF(999)));
                }
                LinearLayout linearLayout = this.root;
                final SearchResultAdapter searchResultAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$SearchResultAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.SearchResultAdapter.C2659VH.bind$lambda$10(zContains, zContains2, searchResultAdapter, item, view);
                    }
                });
                TextView textView2 = this.addBtn;
                final SearchResultAdapter searchResultAdapter2 = this.this$0;
                textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$SearchResultAdapter$VH$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.SearchResultAdapter.C2659VH.bind$lambda$11(zContains, zContains2, searchResultAdapter2, item, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$10(boolean z, boolean z2, SearchResultAdapter this$0, QueryItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                if (z || z2) {
                    return;
                }
                this$0.onAdd.invoke(item);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$11(boolean z, boolean z2, SearchResultAdapter this$0, QueryItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                if (z || z2) {
                    return;
                }
                this$0.onAdd.invoke(item);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001 BK\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0012\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\f\u0012\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\f¢\u0006\u0002\u0010\u000fJ\b\u0010\u0014\u001a\u00020\u0015H\u0016J \u0010\u0016\u001a\u00020\r2\u000e\u0010\u0017\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0018\u001a\u00020\u0015H\u0016J \u0010\u0019\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u0015H\u0016J\u0016\u0010\u001d\u001a\u00020\r2\u0006\u0010\u001e\u001a\u00020\u00122\u0006\u0010\u001f\u001a\u00020\nR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u0012\u0012\u0004\u0012\u00020\u00120\u0011j\b\u0012\u0004\u0012\u00020\u0012`\u0013X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListItemsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/ListsScreenView$ListItemsAdapter$VH;", "Lcom/filmkio/nativescreen/account/ListsScreenView;", FirebaseAnalytics.Param.ITEMS, "", "Lcom/filmkio/nativescreen/querygrid/QueryItem;", "imageLoader", "Lcoil/ImageLoader;", "isTouchDevice", "", "onClick", "Lkotlin/Function1;", "", "onRemove", "(Lcom/filmkio/nativescreen/account/ListsScreenView;Ljava/util/List;Lcoil/ImageLoader;ZLkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "removingIds", "Ljava/util/HashSet;", "", "Lkotlin/collections/HashSet;", "getItemCount", "", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setRemovingItem", TtmlNode.ATTR_ID, "loading", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class ListItemsAdapter extends RecyclerView.Adapter<C2657VH> {
        private final ImageLoader imageLoader;
        private final boolean isTouchDevice;
        private final List<QueryItem> items;
        private final Function1<QueryItem, Unit> onClick;
        private final Function1<QueryItem, Unit> onRemove;
        private final HashSet<Long> removingIds;
        final /* synthetic */ ListsScreenView this$0;

        /* JADX WARN: Multi-variable type inference failed */
        public ListItemsAdapter(ListsScreenView listsScreenView, List<QueryItem> items, ImageLoader imageLoader, boolean z, Function1<? super QueryItem, Unit> onClick, Function1<? super QueryItem, Unit> onRemove) {
            Intrinsics.checkNotNullParameter(items, "items");
            Intrinsics.checkNotNullParameter(imageLoader, "imageLoader");
            Intrinsics.checkNotNullParameter(onClick, "onClick");
            Intrinsics.checkNotNullParameter(onRemove, "onRemove");
            this.this$0 = listsScreenView;
            this.items = items;
            this.imageLoader = imageLoader;
            this.isTouchDevice = z;
            this.onClick = onClick;
            this.onRemove = onRemove;
            this.removingIds = new HashSet<>();
        }

        public final void setRemovingItem(long id, boolean loading) {
            if (loading) {
                this.removingIds.add(Long.valueOf(id));
            } else {
                this.removingIds.remove(Long.valueOf(id));
            }
            Iterator<QueryItem> it = this.items.iterator();
            int i = 0;
            while (true) {
                if (!it.hasNext()) {
                    i = -1;
                    break;
                } else {
                    if (it.next().getId() == id) {
                        break;
                    } else {
                        i++;
                    }
                }
            }
            if (i >= 0) {
                notifyItemChanged(i);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2657VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            ListsScreenView listsScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(listsScreenView.m381dp(4), listsScreenView.m381dp(4), listsScreenView.m381dp(4), listsScreenView.m381dp(6));
            linearLayout.setBackground(listsScreenView.roundedBg(302912798, 659446377, listsScreenView.m381dp(1), listsScreenView.dpF(10)));
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2657VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2657VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.items.get(position), this.removingIds.contains(Long.valueOf(this.items.get(position).getId())));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.items.size();
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.ListsScreenView$ListItemsAdapter$VH */
        /* JADX INFO: compiled from: ListsScreenView.kt */
        @Metadata(m779d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$ListItemsAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/ListsScreenView$ListItemsAdapter;Landroid/widget/LinearLayout;)V", "poster", "Landroid/widget/ImageView;", "posterWrap", "Landroid/widget/FrameLayout;", "removeBtn", "Landroid/widget/TextView;", "title", "bind", "", "item", "Lcom/filmkio/nativescreen/querygrid/QueryItem;", "removing", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2657VH extends RecyclerView.ViewHolder {
            private final ImageView poster;
            private final FrameLayout posterWrap;
            private final TextView removeBtn;
            private final LinearLayout root;
            final /* synthetic */ ListItemsAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2657VH(ListItemsAdapter listItemsAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = listItemsAdapter;
                this.root = root;
                FrameLayout frameLayout = new FrameLayout(listItemsAdapter.this$0.ctx);
                ListsScreenView listsScreenView = listItemsAdapter.this$0;
                frameLayout.setBackground(listsScreenView.roundedBg(470684958, 709778025, listsScreenView.m381dp(1), listsScreenView.dpF(8)));
                frameLayout.setClipToOutline(true);
                this.posterWrap = frameLayout;
                ImageView imageView = new ImageView(listItemsAdapter.this$0.ctx);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageResource(C2629R.drawable.ic_panel_lists);
                imageView.setColorFilter(-2957330);
                this.poster = imageView;
                frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                TextView textView = new TextView(listItemsAdapter.this$0.ctx);
                ListsScreenView listsScreenView2 = listItemsAdapter.this$0;
                textView.setText("✕");
                textView.setTextColor(-1);
                textView.setTextSize(16.0f);
                textView.setGravity(17);
                textView.setTextAlignment(4);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(listsScreenView2.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setBackground(listsScreenView2.roundedBg(-785772269, -1996525964, listsScreenView2.m381dp(1), listsScreenView2.dpF(10)));
                textView.setPadding(0, 0, 0, 0);
                textView.setClickable(true);
                textView.setFocusable(false);
                this.removeBtn = textView;
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(listItemsAdapter.this$0.m381dp(30), listItemsAdapter.this$0.m381dp(30), 51);
                ListsScreenView listsScreenView3 = listItemsAdapter.this$0;
                layoutParams.setMarginStart(listsScreenView3.m381dp(6));
                layoutParams.topMargin = listsScreenView3.m381dp(6);
                Unit unit = Unit.INSTANCE;
                frameLayout.addView(textView, layoutParams);
                TextView textView2 = new TextView(listItemsAdapter.this$0.ctx);
                ListsScreenView listsScreenView4 = listItemsAdapter.this$0;
                textView2.setTextColor(-1);
                textView2.setTextSize(12.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(listsScreenView4.ctx);
                textView2.setTypeface(typefaceMedium == null ? textView2.getTypeface() : typefaceMedium);
                textView2.setIncludeFontPadding(false);
                textView2.setGravity(5);
                textView2.setMaxLines(2);
                textView2.setEllipsize(TextUtils.TruncateAt.END);
                textView2.setTextAlignment(1);
                textView2.setTextDirection(3);
                this.title = textView2;
                root.addView(frameLayout, new LinearLayout.LayoutParams(-1, listItemsAdapter.this$0.m381dp(156)));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = listItemsAdapter.this$0.m381dp(6);
                Unit unit2 = Unit.INSTANCE;
                root.addView(textView2, layoutParams2);
            }

            public final void bind(final QueryItem item, final boolean removing) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.title.setText(item.getTitle());
                String poster = item.getPoster();
                if (poster == null || StringsKt.isBlank(poster)) {
                    this.poster.setImageResource(C2629R.drawable.ic_panel_lists);
                    this.poster.setColorFilter(-2957330);
                } else {
                    this.poster.clearColorFilter();
                    ImageView imageView = this.poster;
                    String poster2 = item.getPoster();
                    ImageLoader imageLoader = this.this$0.imageLoader;
                    ListsScreenView listsScreenView = this.this$0.this$0;
                    ImageRequest.Builder builderTarget = new ImageRequest.Builder(imageView.getContext()).data(poster2).target(imageView);
                    builderTarget.size(listsScreenView.m381dp(160), listsScreenView.m381dp(156));
                    builderTarget.allowHardware(true);
                    builderTarget.crossfade(false);
                    imageLoader.enqueue(builderTarget.build());
                }
                this.removeBtn.setAlpha(removing ? 0.6f : 1.0f);
                this.removeBtn.setEnabled(!removing);
                this.root.setAlpha(removing ? 0.82f : 1.0f);
                LinearLayout linearLayout = this.root;
                final ListItemsAdapter listItemsAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListItemsAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListItemsAdapter.C2657VH.bind$lambda$7(removing, listItemsAdapter, item, view);
                    }
                });
                TextView textView = this.removeBtn;
                final ListItemsAdapter listItemsAdapter2 = this.this$0;
                textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.ListsScreenView$ListItemsAdapter$VH$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        ListsScreenView.ListItemsAdapter.C2657VH.bind$lambda$8(removing, listItemsAdapter2, item, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$7(boolean z, ListItemsAdapter this$0, QueryItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                if (z) {
                    return;
                }
                this$0.onClick.invoke(item);
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$8(boolean z, ListItemsAdapter this$0, QueryItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                if (z) {
                    return;
                }
                this$0.onRemove.invoke(item);
            }
        }
    }

    /* JADX INFO: compiled from: ListsScreenView.kt */
    @Metadata(m779d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J(\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, m780d2 = {"Lcom/filmkio/nativescreen/account/ListsScreenView$GridSpacingDecoration;", "Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;", "colGap", "", "rowGap", "(II)V", "getItemOffsets", "", "outRect", "Landroid/graphics/Rect;", "view", "Landroid/view/View;", "parent", "Landroidx/recyclerview/widget/RecyclerView;", "state", "Landroidx/recyclerview/widget/RecyclerView$State;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class GridSpacingDecoration extends RecyclerView.ItemDecoration {
        private final int colGap;
        private final int rowGap;

        public GridSpacingDecoration(int i, int i2) {
            this.colGap = i;
            this.rowGap = i2;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.ItemDecoration
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            Intrinsics.checkNotNullParameter(outRect, "outRect");
            Intrinsics.checkNotNullParameter(view, "view");
            Intrinsics.checkNotNullParameter(parent, "parent");
            Intrinsics.checkNotNullParameter(state, "state");
            int i = this.colGap / 2;
            int i2 = this.rowGap / 2;
            outRect.left = i;
            outRect.right = i;
            outRect.top = i2;
            outRect.bottom = i2;
        }
    }
}
