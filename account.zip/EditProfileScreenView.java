package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.AbsoluteSizeSpan;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.autofill.HintConstants;
import androidx.core.app.NotificationCompat;
import androidx.core.view.ViewCompat;
import androidx.media3.extractor.p003ts.TsExtractor;
import com.filmkio.AppState;
import com.filmkio.BuildConfig;
import com.filmkio.C2629R;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.Constants;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: EditProfileScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000®\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\t\n\u0002\b\r\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\r\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u0001:\u0006\u0081\u0001\u0082\u0001\u0083\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\tJ\u0018\u00109\u001a\u00020\b2\u0006\u0010:\u001a\u00020\r2\u0006\u0010;\u001a\u00020\u000fH\u0002J\u0018\u0010<\u001a\u00020\b2\u0006\u0010=\u001a\u00020\u001c2\u0006\u0010;\u001a\u00020\u000fH\u0002J\u0014\u0010>\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050?H\u0002J\u0010\u0010@\u001a\u00020\u000b2\u0006\u0010A\u001a\u00020\u000bH\u0002J\u0010\u0010B\u001a\u00020C2\u0006\u0010A\u001a\u00020\u000bH\u0002J\u0010\u0010D\u001a\u00020\b2\u0006\u0010E\u001a\u00020FH\u0002J\b\u0010G\u001a\u00020\bH\u0002J\b\u0010H\u001a\u00020\u000fH\u0002J\b\u0010I\u001a\u00020\bH\u0002J\u0010\u0010J\u001a\u00020\r2\u0006\u0010K\u001a\u00020\u0005H\u0002J4\u0010L\u001a\u00020\u00132\u0006\u0010M\u001a\u00020\u00052\u0006\u0010N\u001a\u00020\u000b2\u0006\u0010O\u001a\u00020\u00052\b\b\u0002\u0010P\u001a\u00020\u000b2\b\b\u0002\u0010Q\u001a\u00020\u000bH\u0002J \u0010R\u001a\u00020\u001c2\u0006\u0010S\u001a\u00020\u00052\u0006\u0010T\u001a\u00020\u000b2\u0006\u0010U\u001a\u00020\u0005H\u0002J\u0010\u0010V\u001a\u00020\r2\u0006\u0010K\u001a\u00020\u0005H\u0002J\u0010\u0010W\u001a\u00020\u00052\u0006\u0010X\u001a\u00020\u0005H\u0002J\b\u0010Y\u001a\u00020\bH\u0014J \u0010Z\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0006\u0012\u0004\u0018\u00010\u00050[2\b\u0010X\u001a\u0004\u0018\u00010\u0005H\u0002J\u0014\u0010\\\u001a\u0004\u0018\u00010F2\b\u0010X\u001a\u0004\u0018\u00010\u0005H\u0002J-\u0010]\u001a\u0004\u0018\u00010\u00052\b\u0010^\u001a\u0004\u0018\u00010_2\u0012\u0010`\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00050a\"\u00020\u0005H\u0002¢\u0006\u0002\u0010bJ\b\u0010c\u001a\u00020\bH\u0002J(\u0010d\u001a\u00020e2\u0006\u0010f\u001a\u00020\u000b2\u0006\u0010g\u001a\u00020\u000b2\u0006\u0010h\u001a\u00020\u000b2\u0006\u0010i\u001a\u00020CH\u0002J\u0010\u0010j\u001a\u00020\b2\u0006\u0010k\u001a\u00020\u000fH\u0002J\u001a\u0010l\u001a\u00020\b2\b\u0010K\u001a\u0004\u0018\u00010\u00052\u0006\u0010m\u001a\u00020\u000bH\u0002J\u001a\u0010n\u001a\u00020\b2\b\u0010K\u001a\u0004\u0018\u00010\u00052\u0006\u0010m\u001a\u00020\u000bH\u0002J\u0010\u0010o\u001a\u00020\b2\u0006\u0010k\u001a\u00020\u000fH\u0002J(\u0010p\u001a\u00020\b2\u0006\u0010q\u001a\u00020\u00052\u0006\u0010r\u001a\u00020\u00052\u000e\u0010s\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\u0010\u0010t\u001a\u00020\b2\u0006\u0010K\u001a\u00020\u0005H\u0002J\u0010\u0010u\u001a\u00020v2\u0006\u0010K\u001a\u00020\u0005H\u0002J\b\u0010w\u001a\u00020\bH\u0002J\b\u0010x\u001a\u00020\bH\u0002J\u0010\u0010y\u001a\u00020\b2\u0006\u0010z\u001a\u00020\u0011H\u0002J\u0012\u0010{\u001a\u00020\u000f2\b\u0010A\u001a\u0004\u0018\u00010|H\u0002J\b\u0010}\u001a\u00020\bH\u0002J\u0019\u0010~\u001a\u00020\b2\u0006\u0010\u007f\u001a\u00020\u00132\u0007\u0010\u0080\u0001\u001a\u00020\u000fH\u0002R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0015\u001a\n \u0017*\u0004\u0018\u00010\u00160\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010/\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u000201X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u00102\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u001cX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000¨\u0006\u0084\u0001"}, m780d2 = {"Lcom/filmkio/nativescreen/account/EditProfileScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "accent", "", "changePasswordButton", "Landroid/widget/TextView;", "changingPassword", "", "currentTab", "Lcom/filmkio/nativescreen/account/EditProfileScreenView$EditTab;", "displayNameInput", "Lcom/filmkio/nativescreen/account/EditProfileScreenView$FloatingInput;", "emailInput", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "fieldFill", "fieldStroke", "firstNameInput", "genderFemaleChip", "Landroid/widget/LinearLayout;", "genderMaleChip", "isTouchDevice", "lastNameInput", "loadingProfile", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "messageText", "mobileInput", "newPasswordInput", "passwordContainer", "passwordMessageText", "profileContainer", "repeatPasswordInput", "saveButton", "screenFill", "selectedGender", "sessionToken", "sessionUserId", "", "stateAction", "stateButton", "stateOverlay", "stateText", "submitting", "tabPasswordButton", "tabProfileButton", "applyEditTabStyle", "view", "selected", "applyGenderChip", "chip", "authHeaders", "", "dp", "v", "dpF", "", "fillProfile", "data", "Lcom/filmkio/nativescreen/account/EditProfileScreenView$ProfileData;", "hideState", "isLoggedIn", "loadProfile", "makeEditTabButton", "text", "makeFloatingInput", "labelText", "leadingIconRes", "hint", "inputType", "imeAction", "makeGenderChip", Constants.ScionAnalytics.PARAM_LABEL, "iconRes", "value", "makePrimaryButton", "normalizeGender", "raw", "onDetachedFromWindow", "parseEditResponse", "Lkotlin/Pair;", "parseProfileResponse", "pickString", "obj", "Lorg/json/JSONObject;", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "renderGenderSelection", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "setChangePasswordLoading", "loading", "setMessage", "color", "setPasswordMessage", "setSaveLoading", "showState", "message", "buttonText", "action", "showToast", "styledHint", "", "submitPasswordChange", "submitProfile", "switchTab", "tab", "toBool", "", "updateEditTabUi", "updateFloatingLabel", "field", "animate", "EditTab", "FloatingInput", "ProfileData", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class EditProfileScreenView extends FrameLayout {
    public static final int $stable = 8;
    private final int accent;
    private final String apiBase;
    private TextView changePasswordButton;
    private boolean changingPassword;
    private final Context ctx;
    private EditTab currentTab;
    private FloatingInput displayNameInput;
    private FloatingInput emailInput;
    private final ExecutorService executor;
    private final int fieldFill;
    private final int fieldStroke;
    private FloatingInput firstNameInput;
    private LinearLayout genderFemaleChip;
    private LinearLayout genderMaleChip;
    private final boolean isTouchDevice;
    private FloatingInput lastNameInput;
    private boolean loadingProfile;
    private ProgressBar loadingView;
    private final Handler mainHandler;
    private TextView messageText;
    private FloatingInput mobileInput;
    private FloatingInput newPasswordInput;
    private final Function0<Unit> onRequireLogin;
    private LinearLayout passwordContainer;
    private TextView passwordMessageText;
    private LinearLayout profileContainer;
    private FloatingInput repeatPasswordInput;
    private TextView saveButton;
    private final int screenFill;
    private String selectedGender;
    private String sessionToken;
    private long sessionUserId;
    private Function0<Unit> stateAction;
    private TextView stateButton;
    private LinearLayout stateOverlay;
    private TextView stateText;
    private boolean submitting;
    private TextView tabPasswordButton;
    private TextView tabProfileButton;

    public /* synthetic */ EditProfileScreenView(Context context, String str, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public EditProfileScreenView(Context ctx, String apiBase, Function0<Unit> function0) {
        LinearLayout linearLayout;
        LinearLayout linearLayout2;
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.screenFill = -16315632;
        this.fieldFill = -16447475;
        this.fieldStroke = -13946310;
        this.currentTab = EditTab.PROFILE;
        this.selectedGender = "";
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        ScrollView scrollView = new ScrollView(ctx);
        scrollView.setOverScrollMode(2);
        scrollView.setVerticalScrollBarEnabled(false);
        addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout3 = new LinearLayout(ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setPadding(m379dp(14), m379dp(12), m379dp(14), m379dp(96));
        scrollView.addView(linearLayout3, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(0);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setBackground(roundedBg(-16447475, -13946310, m379dp(1), dpF(14)));
        linearLayout4.setPadding(m379dp(4), m379dp(4), m379dp(4), m379dp(4));
        this.tabProfileButton = makeEditTabButton("ویرایش پروفایل");
        this.tabPasswordButton = makeEditTabButton("تغییر رمز عبور");
        TextView textView = this.tabProfileButton;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabProfileButton");
            textView = null;
        }
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView._init_$lambda$4(this.f$0, view);
            }
        });
        TextView textView2 = this.tabPasswordButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabPasswordButton");
            textView2 = null;
        }
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView._init_$lambda$5(this.f$0, view);
            }
        });
        TextView textView3 = this.tabProfileButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabProfileButton");
            textView3 = null;
        }
        linearLayout4.addView(textView3, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView4 = this.tabPasswordButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabPasswordButton");
            textView4 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginStart(m379dp(6));
        Unit unit = Unit.INSTANCE;
        linearLayout4.addView(textView4, layoutParams);
        linearLayout3.addView(linearLayout4, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout5 = new LinearLayout(ctx);
        linearLayout5.setOrientation(1);
        linearLayout5.setLayoutDirection(1);
        linearLayout5.setBackground(null);
        linearLayout5.setPadding(0, 0, 0, 0);
        this.profileContainer = linearLayout5;
        LinearLayout linearLayout6 = new LinearLayout(ctx);
        linearLayout6.setOrientation(1);
        linearLayout6.setLayoutDirection(1);
        linearLayout6.setBackground(null);
        linearLayout6.setPadding(0, 0, 0, 0);
        this.passwordContainer = linearLayout6;
        LinearLayout linearLayout7 = this.profileContainer;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("profileContainer");
            linearLayout7 = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m379dp(12);
        Unit unit2 = Unit.INSTANCE;
        linearLayout3.addView(linearLayout7, layoutParams2);
        LinearLayout linearLayout8 = this.passwordContainer;
        if (linearLayout8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout8 = null;
        }
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m379dp(12);
        Unit unit3 = Unit.INSTANCE;
        linearLayout3.addView(linearLayout8, layoutParams3);
        LinearLayout linearLayout9 = this.profileContainer;
        if (linearLayout9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("profileContainer");
            linearLayout = null;
        } else {
            linearLayout = linearLayout9;
        }
        LinearLayout linearLayout10 = linearLayout;
        this.firstNameInput = makeFloatingInput$default(this, "نام", C2629R.drawable.ic_account_username, "نام را وارد کنید", 0, 0, 24, null);
        this.lastNameInput = makeFloatingInput$default(this, "نام خانوادگی", C2629R.drawable.ic_account_username, "نام خانوادگی را وارد کنید", 0, 0, 24, null);
        this.displayNameInput = makeFloatingInput$default(this, "نام نمایشی", C2629R.drawable.ic_user, "نام نمایشی را وارد کنید", 0, 0, 24, null);
        this.mobileInput = makeFloatingInput$default(this, "شماره موبایل", C2629R.drawable.ic_account_mobile, "شماره موبایل را وارد کنید", 3, 0, 16, null);
        this.emailInput = makeFloatingInput("ایمیل", C2629R.drawable.ic_account_email, "ایمیل را وارد کنید", 33, 6);
        int iM379dp = m379dp(8);
        FloatingInput floatingInput = this.firstNameInput;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("firstNameInput");
            floatingInput = null;
        }
        ViewGroup.LayoutParams layoutParams4 = floatingInput.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams5 = layoutParams4 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams4 : null;
        if (layoutParams5 != null) {
            layoutParams5.topMargin = m379dp(0);
            FloatingInput floatingInput2 = this.firstNameInput;
            if (floatingInput2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("firstNameInput");
                floatingInput2 = null;
            }
            floatingInput2.getRoot().setLayoutParams(layoutParams5);
            Unit unit4 = Unit.INSTANCE;
            Unit unit5 = Unit.INSTANCE;
        }
        FloatingInput floatingInput3 = this.lastNameInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("lastNameInput");
            floatingInput3 = null;
        }
        ViewGroup.LayoutParams layoutParams6 = floatingInput3.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams7 = layoutParams6 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams6 : null;
        if (layoutParams7 != null) {
            layoutParams7.topMargin = iM379dp;
            FloatingInput floatingInput4 = this.lastNameInput;
            if (floatingInput4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("lastNameInput");
                floatingInput4 = null;
            }
            floatingInput4.getRoot().setLayoutParams(layoutParams7);
            Unit unit6 = Unit.INSTANCE;
            Unit unit7 = Unit.INSTANCE;
        }
        FloatingInput floatingInput5 = this.displayNameInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("displayNameInput");
            floatingInput5 = null;
        }
        ViewGroup.LayoutParams layoutParams8 = floatingInput5.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams9 = layoutParams8 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams8 : null;
        if (layoutParams9 != null) {
            layoutParams9.topMargin = iM379dp;
            FloatingInput floatingInput6 = this.displayNameInput;
            if (floatingInput6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("displayNameInput");
                floatingInput6 = null;
            }
            floatingInput6.getRoot().setLayoutParams(layoutParams9);
            Unit unit8 = Unit.INSTANCE;
            Unit unit9 = Unit.INSTANCE;
        }
        FloatingInput floatingInput7 = this.mobileInput;
        if (floatingInput7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mobileInput");
            floatingInput7 = null;
        }
        ViewGroup.LayoutParams layoutParams10 = floatingInput7.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams11 = layoutParams10 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams10 : null;
        if (layoutParams11 != null) {
            layoutParams11.topMargin = iM379dp;
            FloatingInput floatingInput8 = this.mobileInput;
            if (floatingInput8 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mobileInput");
                floatingInput8 = null;
            }
            floatingInput8.getRoot().setLayoutParams(layoutParams11);
            Unit unit10 = Unit.INSTANCE;
            Unit unit11 = Unit.INSTANCE;
        }
        FloatingInput floatingInput9 = this.emailInput;
        if (floatingInput9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("emailInput");
            floatingInput9 = null;
        }
        ViewGroup.LayoutParams layoutParams12 = floatingInput9.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams13 = layoutParams12 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams12 : null;
        if (layoutParams13 != null) {
            layoutParams13.topMargin = iM379dp;
            FloatingInput floatingInput10 = this.emailInput;
            if (floatingInput10 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("emailInput");
                floatingInput10 = null;
            }
            floatingInput10.getRoot().setLayoutParams(layoutParams13);
            Unit unit12 = Unit.INSTANCE;
            Unit unit13 = Unit.INSTANCE;
        }
        FloatingInput floatingInput11 = this.firstNameInput;
        if (floatingInput11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("firstNameInput");
            floatingInput11 = null;
        }
        linearLayout10.addView(floatingInput11.getRoot());
        FloatingInput floatingInput12 = this.lastNameInput;
        if (floatingInput12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("lastNameInput");
            floatingInput12 = null;
        }
        linearLayout10.addView(floatingInput12.getRoot());
        FloatingInput floatingInput13 = this.displayNameInput;
        if (floatingInput13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("displayNameInput");
            floatingInput13 = null;
        }
        linearLayout10.addView(floatingInput13.getRoot());
        FloatingInput floatingInput14 = this.mobileInput;
        if (floatingInput14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mobileInput");
            floatingInput14 = null;
        }
        linearLayout10.addView(floatingInput14.getRoot());
        FloatingInput floatingInput15 = this.emailInput;
        if (floatingInput15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("emailInput");
            floatingInput15 = null;
        }
        linearLayout10.addView(floatingInput15.getRoot());
        TextView textView5 = new TextView(ctx);
        textView5.setText("جنسیت");
        textView5.setTextColor(-4666400);
        textView5.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(ctx);
        textView5.setTypeface(typefaceRegular == null ? textView5.getTypeface() : typefaceRegular);
        textView5.setIncludeFontPadding(false);
        LinearLayout.LayoutParams layoutParams14 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams14.topMargin = m379dp(10);
        Unit unit14 = Unit.INSTANCE;
        linearLayout10.addView(textView5, layoutParams14);
        LinearLayout linearLayout11 = new LinearLayout(ctx);
        linearLayout11.setOrientation(0);
        linearLayout11.setLayoutDirection(1);
        linearLayout11.setGravity(16);
        LinearLayout.LayoutParams layoutParams15 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams15.topMargin = m379dp(6);
        Unit unit15 = Unit.INSTANCE;
        linearLayout10.addView(linearLayout11, layoutParams15);
        this.genderMaleChip = makeGenderChip("مرد", C2629R.drawable.ic_gender_male, "male");
        this.genderFemaleChip = makeGenderChip("زن", C2629R.drawable.ic_gender_female, "female");
        LinearLayout linearLayout12 = this.genderMaleChip;
        if (linearLayout12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("genderMaleChip");
            linearLayout12 = null;
        }
        LinearLayout.LayoutParams layoutParams16 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams16.setMarginStart(m379dp(4));
        layoutParams16.setMarginEnd(m379dp(4));
        Unit unit16 = Unit.INSTANCE;
        linearLayout11.addView(linearLayout12, layoutParams16);
        LinearLayout linearLayout13 = this.genderFemaleChip;
        if (linearLayout13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("genderFemaleChip");
            linearLayout13 = null;
        }
        LinearLayout.LayoutParams layoutParams17 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams17.setMarginStart(m379dp(4));
        layoutParams17.setMarginEnd(m379dp(4));
        Unit unit17 = Unit.INSTANCE;
        linearLayout11.addView(linearLayout13, layoutParams17);
        TextView textView6 = new TextView(ctx);
        textView6.setTextColor(-3680022);
        textView6.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView6.setTypeface(typefaceMedium == null ? textView6.getTypeface() : typefaceMedium);
        textView6.setIncludeFontPadding(false);
        textView6.setVisibility(8);
        textView6.setGravity(5);
        textView6.setTextAlignment(5);
        this.messageText = textView6;
        LinearLayout.LayoutParams layoutParams18 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams18.topMargin = m379dp(10);
        Unit unit18 = Unit.INSTANCE;
        linearLayout10.addView(textView6, layoutParams18);
        TextView textViewMakePrimaryButton = makePrimaryButton("ذخیره اطلاعات");
        this.saveButton = textViewMakePrimaryButton;
        if (textViewMakePrimaryButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveButton");
            textViewMakePrimaryButton = null;
        }
        textViewMakePrimaryButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView._init_$lambda$24(this.f$0, view);
            }
        });
        TextView textView7 = this.saveButton;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveButton");
            textView7 = null;
        }
        LinearLayout.LayoutParams layoutParams19 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams19.topMargin = m379dp(16);
        Unit unit19 = Unit.INSTANCE;
        linearLayout10.addView(textView7, layoutParams19);
        this.newPasswordInput = makeFloatingInput$default(this, "رمز عبور جدید", C2629R.drawable.ic_account_password, "رمز عبور جدید را وارد کنید", TsExtractor.TS_STREAM_TYPE_AC3, 0, 16, null);
        this.repeatPasswordInput = makeFloatingInput("تکرار رمز عبور", C2629R.drawable.ic_account_password, "رمز عبور را دوباره وارد کنید", TsExtractor.TS_STREAM_TYPE_AC3, 6);
        FloatingInput floatingInput16 = this.newPasswordInput;
        if (floatingInput16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("newPasswordInput");
            floatingInput16 = null;
        }
        ViewGroup.LayoutParams layoutParams20 = floatingInput16.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams21 = layoutParams20 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams20 : null;
        if (layoutParams21 != null) {
            layoutParams21.topMargin = 0;
            FloatingInput floatingInput17 = this.newPasswordInput;
            if (floatingInput17 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("newPasswordInput");
                floatingInput17 = null;
            }
            floatingInput17.getRoot().setLayoutParams(layoutParams21);
            Unit unit20 = Unit.INSTANCE;
            Unit unit21 = Unit.INSTANCE;
        }
        FloatingInput floatingInput18 = this.repeatPasswordInput;
        if (floatingInput18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
            floatingInput18 = null;
        }
        ViewGroup.LayoutParams layoutParams22 = floatingInput18.getRoot().getLayoutParams();
        LinearLayout.LayoutParams layoutParams23 = layoutParams22 instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams22 : null;
        if (layoutParams23 != null) {
            layoutParams23.topMargin = iM379dp;
            FloatingInput floatingInput19 = this.repeatPasswordInput;
            if (floatingInput19 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
                floatingInput19 = null;
            }
            floatingInput19.getRoot().setLayoutParams(layoutParams23);
            Unit unit22 = Unit.INSTANCE;
            Unit unit23 = Unit.INSTANCE;
        }
        FloatingInput floatingInput20 = this.repeatPasswordInput;
        if (floatingInput20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
            floatingInput20 = null;
        }
        floatingInput20.getEdit().setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda5
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView8, int i, KeyEvent keyEvent) {
                return EditProfileScreenView._init_$lambda$28(this.f$0, textView8, i, keyEvent);
            }
        });
        LinearLayout linearLayout14 = this.passwordContainer;
        if (linearLayout14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout14 = null;
        }
        FloatingInput floatingInput21 = this.newPasswordInput;
        if (floatingInput21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("newPasswordInput");
            floatingInput21 = null;
        }
        linearLayout14.addView(floatingInput21.getRoot());
        LinearLayout linearLayout15 = this.passwordContainer;
        if (linearLayout15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout15 = null;
        }
        FloatingInput floatingInput22 = this.repeatPasswordInput;
        if (floatingInput22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
            floatingInput22 = null;
        }
        linearLayout15.addView(floatingInput22.getRoot());
        TextView textView8 = new TextView(ctx);
        textView8.setTextColor(-3680022);
        textView8.setTextSize(12.0f);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(ctx);
        textView8.setTypeface(typefaceMedium2 == null ? textView8.getTypeface() : typefaceMedium2);
        textView8.setIncludeFontPadding(false);
        textView8.setVisibility(8);
        textView8.setGravity(5);
        textView8.setTextAlignment(5);
        this.passwordMessageText = textView8;
        LinearLayout linearLayout16 = this.passwordContainer;
        if (linearLayout16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout16 = null;
        }
        TextView textView9 = this.passwordMessageText;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
            textView9 = null;
        }
        LinearLayout.LayoutParams layoutParams24 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams24.topMargin = m379dp(10);
        Unit unit24 = Unit.INSTANCE;
        linearLayout16.addView(textView9, layoutParams24);
        TextView textViewMakePrimaryButton2 = makePrimaryButton("تغییر رمز عبور");
        this.changePasswordButton = textViewMakePrimaryButton2;
        if (textViewMakePrimaryButton2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("changePasswordButton");
            textViewMakePrimaryButton2 = null;
        }
        textViewMakePrimaryButton2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView._init_$lambda$31(this.f$0, view);
            }
        });
        LinearLayout linearLayout17 = this.passwordContainer;
        if (linearLayout17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout17 = null;
        }
        TextView textView10 = this.changePasswordButton;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("changePasswordButton");
            textView10 = null;
        }
        LinearLayout.LayoutParams layoutParams25 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams25.topMargin = m379dp(16);
        Unit unit25 = Unit.INSTANCE;
        linearLayout17.addView(textView10, layoutParams25);
        switchTab(EditTab.PROFILE);
        ProgressBar progressBar = new ProgressBar(ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(-676591);
            Unit unit26 = Unit.INSTANCE;
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams26 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams26.gravity = 17;
        Unit unit27 = Unit.INSTANCE;
        addView(progressBar, layoutParams26);
        LinearLayout linearLayout18 = new LinearLayout(ctx);
        linearLayout18.setOrientation(1);
        linearLayout18.setLayoutDirection(1);
        linearLayout18.setGravity(17);
        linearLayout18.setVisibility(8);
        linearLayout18.setPadding(m379dp(24), m379dp(24), m379dp(24), m379dp(24));
        linearLayout18.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout18;
        TextView textView11 = new TextView(ctx);
        textView11.setTextColor(-419430401);
        textView11.setTextSize(15.0f);
        textView11.setGravity(17);
        Typeface typefaceMedium3 = NativeFonts.INSTANCE.medium(ctx);
        textView11.setTypeface(typefaceMedium3 == null ? textView11.getTypeface() : typefaceMedium3);
        textView11.setIncludeFontPadding(false);
        this.stateText = textView11;
        TextView textView12 = new TextView(ctx);
        textView12.setText("تلاش دوباره");
        textView12.setTextColor(-16052459);
        textView12.setTextSize(14.0f);
        textView12.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView12.setTypeface(typefaceBold == null ? textView12.getTypeface() : typefaceBold);
        textView12.setPadding(m379dp(16), m379dp(10), m379dp(16), m379dp(10));
        textView12.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView12.setFocusable(!zHasSystemFeature);
        textView12.setFocusableInTouchMode(!zHasSystemFeature);
        textView12.setClickable(true);
        textView12.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView.lambda$38$lambda$37(this.f$0, view);
            }
        });
        this.stateButton = textView12;
        LinearLayout linearLayout19 = this.stateOverlay;
        if (linearLayout19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout19 = null;
        }
        TextView textView13 = this.stateText;
        if (textView13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView13 = null;
        }
        linearLayout19.addView(textView13);
        LinearLayout linearLayout20 = this.stateOverlay;
        if (linearLayout20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout20 = null;
        }
        TextView textView14 = this.stateButton;
        if (textView14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView14 = null;
        }
        LinearLayout.LayoutParams layoutParams27 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams27.topMargin = m379dp(12);
        Unit unit28 = Unit.INSTANCE;
        linearLayout20.addView(textView14, layoutParams27);
        LinearLayout linearLayout21 = this.stateOverlay;
        if (linearLayout21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout2 = null;
        } else {
            linearLayout2 = linearLayout21;
        }
        addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        if (!isLoggedIn()) {
            showState("برای ویرایش اطلاعات، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView.34
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = EditProfileScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else {
            loadProfile();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: EditProfileScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, m780d2 = {"Lcom/filmkio/nativescreen/account/EditProfileScreenView$EditTab;", "", "(Ljava/lang/String;I)V", "PROFILE", "PASSWORD", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class EditTab {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ EditTab[] $VALUES;
        public static final EditTab PROFILE = new EditTab("PROFILE", 0);
        public static final EditTab PASSWORD = new EditTab("PASSWORD", 1);

        private static final /* synthetic */ EditTab[] $values() {
            return new EditTab[]{PROFILE, PASSWORD};
        }

        public static EnumEntries<EditTab> getEntries() {
            return $ENTRIES;
        }

        public static EditTab valueOf(String str) {
            return (EditTab) Enum.valueOf(EditTab.class, str);
        }

        public static EditTab[] values() {
            return (EditTab[]) $VALUES.clone();
        }

        private EditTab(String str, int i) {
        }

        static {
            EditTab[] editTabArr$values = $values();
            $VALUES = editTabArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(editTabArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: EditProfileScreenView.kt */
    @Metadata(m779d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0016\u001a\u00020\tHÆ\u0003J1\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\tHÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u001f"}, m780d2 = {"Lcom/filmkio/nativescreen/account/EditProfileScreenView$FloatingInput;", "", "root", "Landroid/widget/FrameLayout;", "shell", "Landroid/widget/LinearLayout;", Constants.ScionAnalytics.PARAM_LABEL, "Landroid/widget/TextView;", "edit", "Landroidx/appcompat/widget/AppCompatEditText;", "(Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroidx/appcompat/widget/AppCompatEditText;)V", "getEdit", "()Landroidx/appcompat/widget/AppCompatEditText;", "getLabel", "()Landroid/widget/TextView;", "getRoot", "()Landroid/widget/FrameLayout;", "getShell", "()Landroid/widget/LinearLayout;", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class FloatingInput {
        private final AppCompatEditText edit;
        private final TextView label;
        private final FrameLayout root;
        private final LinearLayout shell;

        public static /* synthetic */ FloatingInput copy$default(FloatingInput floatingInput, FrameLayout frameLayout, LinearLayout linearLayout, TextView textView, AppCompatEditText appCompatEditText, int i, Object obj) {
            if ((i & 1) != 0) {
                frameLayout = floatingInput.root;
            }
            if ((i & 2) != 0) {
                linearLayout = floatingInput.shell;
            }
            if ((i & 4) != 0) {
                textView = floatingInput.label;
            }
            if ((i & 8) != 0) {
                appCompatEditText = floatingInput.edit;
            }
            return floatingInput.copy(frameLayout, linearLayout, textView, appCompatEditText);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final FrameLayout getRoot() {
            return this.root;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final LinearLayout getShell() {
            return this.shell;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final TextView getLabel() {
            return this.label;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final AppCompatEditText getEdit() {
            return this.edit;
        }

        public final FloatingInput copy(FrameLayout root, LinearLayout shell, TextView label, AppCompatEditText edit) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(shell, "shell");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(edit, "edit");
            return new FloatingInput(root, shell, label, edit);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof FloatingInput)) {
                return false;
            }
            FloatingInput floatingInput = (FloatingInput) other;
            return Intrinsics.areEqual(this.root, floatingInput.root) && Intrinsics.areEqual(this.shell, floatingInput.shell) && Intrinsics.areEqual(this.label, floatingInput.label) && Intrinsics.areEqual(this.edit, floatingInput.edit);
        }

        public int hashCode() {
            return (((((this.root.hashCode() * 31) + this.shell.hashCode()) * 31) + this.label.hashCode()) * 31) + this.edit.hashCode();
        }

        public String toString() {
            return "FloatingInput(root=" + this.root + ", shell=" + this.shell + ", label=" + this.label + ", edit=" + this.edit + ")";
        }

        public FloatingInput(FrameLayout root, LinearLayout shell, TextView label, AppCompatEditText edit) {
            Intrinsics.checkNotNullParameter(root, "root");
            Intrinsics.checkNotNullParameter(shell, "shell");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(edit, "edit");
            this.root = root;
            this.shell = shell;
            this.label = label;
            this.edit = edit;
        }

        public final FrameLayout getRoot() {
            return this.root;
        }

        public final LinearLayout getShell() {
            return this.shell;
        }

        public final TextView getLabel() {
            return this.label;
        }

        public final AppCompatEditText getEdit() {
            return this.edit;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: EditProfileScreenView.kt */
    @Metadata(m779d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0002\u0010\tJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003JE\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000b¨\u0006\u001e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/EditProfileScreenView$ProfileData;", "", "firstName", "", "lastName", BuildConfig.FLAVOR, HintConstants.AUTOFILL_HINT_GENDER, "displayName", "email", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getDisplayName", "()Ljava/lang/String;", "getEmail", "getFirstName", "getGender", "getLastName", "getMobile", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ProfileData {
        private final String displayName;
        private final String email;
        private final String firstName;
        private final String gender;
        private final String lastName;
        private final String mobile;

        public static /* synthetic */ ProfileData copy$default(ProfileData profileData, String str, String str2, String str3, String str4, String str5, String str6, int i, Object obj) {
            if ((i & 1) != 0) {
                str = profileData.firstName;
            }
            if ((i & 2) != 0) {
                str2 = profileData.lastName;
            }
            String str7 = str2;
            if ((i & 4) != 0) {
                str3 = profileData.mobile;
            }
            String str8 = str3;
            if ((i & 8) != 0) {
                str4 = profileData.gender;
            }
            String str9 = str4;
            if ((i & 16) != 0) {
                str5 = profileData.displayName;
            }
            String str10 = str5;
            if ((i & 32) != 0) {
                str6 = profileData.email;
            }
            return profileData.copy(str, str7, str8, str9, str10, str6);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getFirstName() {
            return this.firstName;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getLastName() {
            return this.lastName;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getMobile() {
            return this.mobile;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getGender() {
            return this.gender;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getDisplayName() {
            return this.displayName;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getEmail() {
            return this.email;
        }

        public final ProfileData copy(String firstName, String lastName, String mobile, String gender, String displayName, String email) {
            Intrinsics.checkNotNullParameter(firstName, "firstName");
            Intrinsics.checkNotNullParameter(lastName, "lastName");
            Intrinsics.checkNotNullParameter(mobile, "mobile");
            Intrinsics.checkNotNullParameter(gender, "gender");
            Intrinsics.checkNotNullParameter(displayName, "displayName");
            Intrinsics.checkNotNullParameter(email, "email");
            return new ProfileData(firstName, lastName, mobile, gender, displayName, email);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ProfileData)) {
                return false;
            }
            ProfileData profileData = (ProfileData) other;
            return Intrinsics.areEqual(this.firstName, profileData.firstName) && Intrinsics.areEqual(this.lastName, profileData.lastName) && Intrinsics.areEqual(this.mobile, profileData.mobile) && Intrinsics.areEqual(this.gender, profileData.gender) && Intrinsics.areEqual(this.displayName, profileData.displayName) && Intrinsics.areEqual(this.email, profileData.email);
        }

        public int hashCode() {
            return (((((((((this.firstName.hashCode() * 31) + this.lastName.hashCode()) * 31) + this.mobile.hashCode()) * 31) + this.gender.hashCode()) * 31) + this.displayName.hashCode()) * 31) + this.email.hashCode();
        }

        public String toString() {
            return "ProfileData(firstName=" + this.firstName + ", lastName=" + this.lastName + ", mobile=" + this.mobile + ", gender=" + this.gender + ", displayName=" + this.displayName + ", email=" + this.email + ")";
        }

        public ProfileData(String firstName, String lastName, String mobile, String gender, String displayName, String email) {
            Intrinsics.checkNotNullParameter(firstName, "firstName");
            Intrinsics.checkNotNullParameter(lastName, "lastName");
            Intrinsics.checkNotNullParameter(mobile, "mobile");
            Intrinsics.checkNotNullParameter(gender, "gender");
            Intrinsics.checkNotNullParameter(displayName, "displayName");
            Intrinsics.checkNotNullParameter(email, "email");
            this.firstName = firstName;
            this.lastName = lastName;
            this.mobile = mobile;
            this.gender = gender;
            this.displayName = displayName;
            this.email = email;
        }

        public final String getFirstName() {
            return this.firstName;
        }

        public final String getLastName() {
            return this.lastName;
        }

        public final String getMobile() {
            return this.mobile;
        }

        public final String getGender() {
            return this.gender;
        }

        public final String getDisplayName() {
            return this.displayName;
        }

        public final String getEmail() {
            return this.email;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$4(EditProfileScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchTab(EditTab.PROFILE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$5(EditProfileScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchTab(EditTab.PASSWORD);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$24(EditProfileScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitProfile();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean _init_$lambda$28(EditProfileScreenView this$0, TextView textView, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i != 6) {
            return false;
        }
        this$0.submitPasswordChange();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$31(EditProfileScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitPasswordChange();
    }

    static final void lambda$38$lambda$37(EditProfileScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.stateAction;
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final TextView makeEditTabButton(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(13.0f);
        textView.setIncludeFontPadding(false);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setPadding(m379dp(10), m379dp(10), m379dp(10), m379dp(10));
        textView.setBackground(roundedBg(0, 0, 0, dpF(10)));
        textView.setClickable(true);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(true ^ this.isTouchDevice);
        textView.setTextColor(-4206364);
        return textView;
    }

    private final void switchTab(EditTab tab) {
        this.currentTab = tab;
        updateEditTabUi();
    }

    private final void updateEditTabUi() {
        boolean z = this.currentTab == EditTab.PROFILE;
        LinearLayout linearLayout = this.profileContainer;
        TextView textView = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("profileContainer");
            linearLayout = null;
        }
        linearLayout.setVisibility(z ? 0 : 8);
        LinearLayout linearLayout2 = this.passwordContainer;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordContainer");
            linearLayout2 = null;
        }
        linearLayout2.setVisibility(z ? 8 : 0);
        TextView textView2 = this.tabProfileButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabProfileButton");
            textView2 = null;
        }
        applyEditTabStyle(textView2, z);
        TextView textView3 = this.tabPasswordButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tabPasswordButton");
        } else {
            textView = textView3;
        }
        applyEditTabStyle(textView, !z);
    }

    private final void applyEditTabStyle(TextView view, boolean selected) {
        int i = selected ? this.accent : 0;
        int i2 = selected ? -16052459 : -4206364;
        view.setBackground(roundedBg(i, 0, 0, dpF(10)));
        view.setTextColor(i2);
    }

    static /* synthetic */ FloatingInput makeFloatingInput$default(EditProfileScreenView editProfileScreenView, String str, int i, String str2, int i2, int i3, int i4, Object obj) {
        if ((i4 & 8) != 0) {
            i2 = 1;
        }
        int i5 = i2;
        if ((i4 & 16) != 0) {
            i3 = 5;
        }
        return editProfileScreenView.makeFloatingInput(str, i, str2, i5, i3);
    }

    private final FloatingInput makeFloatingInput(String labelText, int leadingIconRes, String hint, int inputType, int imeAction) {
        int iM379dp = m379dp(4);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, m379dp(88));
        layoutParams.topMargin = m379dp(4);
        frameLayout.setLayoutParams(layoutParams);
        frameLayout.setLayoutDirection(1);
        final LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m379dp(2), dpF(16)));
        linearLayout.setPadding(m379dp(12), m379dp(12), m379dp(12), m379dp(12));
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, m379dp(64));
        layoutParams2.gravity = 80;
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(leadingIconRes);
        imageView.setColorFilter(-1);
        imageView.setAlpha(0.92f);
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint(styledHint(hint));
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(-9800576);
        appCompatEditText.setTextSize(14.0f);
        appCompatEditText.setGravity(21);
        appCompatEditText.setSingleLine();
        appCompatEditText.setBackground(null);
        appCompatEditText.setInputType(inputType);
        appCompatEditText.setImeOptions(imeAction);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setFocusable(true);
        appCompatEditText.setFocusableInTouchMode(true);
        appCompatEditText.setPadding(m379dp(6), 0, m379dp(5), 0);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(m379dp(22), m379dp(22));
        layoutParams3.setMarginStart(iM379dp);
        layoutParams3.setMarginEnd(m379dp(5));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(imageView, layoutParams3);
        linearLayout.addView(appCompatEditText, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView = new TextView(this.ctx);
        textView.setText(labelText);
        textView.setTextColor(-4666400);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular2);
        textView.setPadding(m379dp(7), m379dp(1), m379dp(7), 0);
        textView.setBackground(roundedBg(this.fieldFill, 0, 0, dpF(8)));
        textView.setTranslationY(0.0f);
        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams4.gravity = 53;
        layoutParams4.rightMargin = m379dp(40);
        layoutParams4.topMargin = m379dp(14);
        frameLayout.addView(linearLayout, layoutParams2);
        frameLayout.addView(textView, layoutParams4);
        final FloatingInput floatingInput = new FloatingInput(frameLayout, linearLayout, textView, appCompatEditText);
        appCompatEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda0
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                EditProfileScreenView.makeFloatingInput$lambda$50(linearLayout, this, floatingInput, view, z);
            }
        });
        appCompatEditText.addTextChangedListener(new TextWatcher() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView.makeFloatingInput.3
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                EditProfileScreenView.this.updateFloatingLabel(floatingInput, true);
            }
        });
        updateFloatingLabel(floatingInput, false);
        return floatingInput;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeFloatingInput$lambda$50(LinearLayout shell, EditProfileScreenView this$0, FloatingInput field, View view, boolean z) {
        Intrinsics.checkNotNullParameter(shell, "$shell");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(field, "$field");
        shell.setBackground(this$0.roundedBg(this$0.fieldFill, z ? this$0.accent : this$0.fieldStroke, this$0.m379dp(2), this$0.dpF(16)));
        this$0.updateFloatingLabel(field, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateFloatingLabel(FloatingInput field, boolean animate) {
        ViewGroup.LayoutParams layoutParams = field.getLabel().getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
        layoutParams2.rightMargin = m379dp(40);
        field.getLabel().setLayoutParams(layoutParams2);
        field.getLabel().setTextColor(-4666400);
        if (animate) {
            field.getLabel().animate().translationY(0.0f).scaleX(1.0f).scaleY(1.0f).setDuration(90L).start();
            return;
        }
        field.getLabel().setTranslationY(0.0f);
        field.getLabel().setScaleX(1.0f);
        field.getLabel().setScaleY(1.0f);
    }

    private final LinearLayout makeGenderChip(String label, int iconRes, final String value) {
        ImageView imageView = new ImageView(this.ctx);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(-1);
        imageView.setAlpha(0.95f);
        TextView textView = new TextView(this.ctx);
        textView.setText(label);
        textView.setTextColor(-3154451);
        textView.setTextSize(13.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        textView.setGravity(16);
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(17);
        linearLayout.setPadding(m379dp(12), m379dp(10), m379dp(12), m379dp(10));
        linearLayout.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m379dp(2), dpF(14)));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(!this.isTouchDevice);
        linearLayout.setFocusableInTouchMode(true ^ this.isTouchDevice);
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(m379dp(20), m379dp(20)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(m379dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditProfileScreenView.makeGenderChip$lambda$55$lambda$54(this.f$0, value, view);
            }
        });
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void makeGenderChip$lambda$55$lambda$54(EditProfileScreenView this$0, String value, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(value, "$value");
        this$0.selectedGender = value;
        this$0.renderGenderSelection();
    }

    private final void renderGenderSelection() {
        boolean zAreEqual = Intrinsics.areEqual(this.selectedGender, "male");
        boolean zAreEqual2 = Intrinsics.areEqual(this.selectedGender, "female");
        LinearLayout linearLayout = this.genderMaleChip;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("genderMaleChip");
            linearLayout = null;
        }
        applyGenderChip(linearLayout, zAreEqual);
        LinearLayout linearLayout3 = this.genderFemaleChip;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("genderFemaleChip");
        } else {
            linearLayout2 = linearLayout3;
        }
        applyGenderChip(linearLayout2, zAreEqual2);
    }

    private final void applyGenderChip(LinearLayout chip, boolean selected) {
        chip.setBackground(roundedBg(selected ? this.accent : this.fieldFill, selected ? ViewCompat.MEASURED_SIZE_MASK : this.fieldStroke, m379dp(2), dpF(14)));
        int childCount = chip.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = chip.getChildAt(i);
            if (childAt instanceof TextView) {
                ((TextView) childAt).setTextColor(selected ? -16052459 : -3154451);
            } else if (childAt instanceof ImageView) {
                ((ImageView) childAt).setColorFilter(selected ? -16052459 : -1);
            }
        }
    }

    private final TextView makePrimaryButton(String text) {
        TextView textView = new TextView(this.ctx);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(16.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setClickable(true);
        textView.setPadding(m379dp(14), m379dp(11), m379dp(14), m379dp(11));
        textView.setBackground(roundedBg(this.accent, 0, 0, dpF(12)));
        textView.setTextColor(-16052459);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void loadProfile() {
        if (this.loadingProfile || !isLoggedIn()) {
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            showState("آدرس سرور در دسترس نیست.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView.loadProfile.1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditProfileScreenView.this.loadProfile();
                }
            });
            return;
        }
        this.loadingProfile = true;
        ProgressBar progressBar = this.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(0);
        setMessage("در حال دریافت اطلاعات...", -3680022);
        hideState();
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                EditProfileScreenView.loadProfile$lambda$59(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadProfile$lambda$59(final EditProfileScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ProfileData profileResponse = this$0.parseProfileResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/profile", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("userId", String.valueOf(this$0.sessionUserId))), this$0.authHeaders(), null, false, 96, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.loadProfile$lambda$59$lambda$57(this.f$0, profileResponse);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.loadProfile$lambda$59$lambda$58(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadProfile$lambda$59$lambda$57(final EditProfileScreenView this$0, ProfileData profileData) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loadingProfile = false;
        ProgressBar progressBar = this$0.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        if (profileData == null) {
            this$0.showState("دریافت اطلاعات پروفایل ناموفق بود.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$loadProfile$2$1$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.loadProfile();
                }
            });
            this$0.setMessage("خطا در دریافت اطلاعات.", -25958);
        } else {
            this$0.fillProfile(profileData);
            this$0.setMessage("اطلاعات فعلی شما بارگذاری شد.", -3680022);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadProfile$lambda$59$lambda$58(final EditProfileScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loadingProfile = false;
        ProgressBar progressBar = this$0.loadingView;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("loadingView");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        this$0.showState("دریافت اطلاعات پروفایل ناموفق بود.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$loadProfile$2$2$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                this.this$0.loadProfile();
            }
        });
        this$0.setMessage("خطا در دریافت اطلاعات.", -25958);
    }

    private final void fillProfile(ProfileData data) {
        FloatingInput floatingInput = this.firstNameInput;
        FloatingInput floatingInput2 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("firstNameInput");
            floatingInput = null;
        }
        floatingInput.getEdit().setText(data.getFirstName());
        FloatingInput floatingInput3 = this.lastNameInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("lastNameInput");
            floatingInput3 = null;
        }
        floatingInput3.getEdit().setText(data.getLastName());
        FloatingInput floatingInput4 = this.mobileInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mobileInput");
            floatingInput4 = null;
        }
        floatingInput4.getEdit().setText(data.getMobile());
        FloatingInput floatingInput5 = this.displayNameInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("displayNameInput");
            floatingInput5 = null;
        }
        floatingInput5.getEdit().setText(data.getDisplayName());
        FloatingInput floatingInput6 = this.emailInput;
        if (floatingInput6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("emailInput");
        } else {
            floatingInput2 = floatingInput6;
        }
        floatingInput2.getEdit().setText(data.getEmail());
        this.selectedGender = data.getGender();
        renderGenderSelection();
    }

    private final void submitProfile() {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        if (this.submitting) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            showToast("آدرس سرور در دسترس نیست.");
            return;
        }
        FloatingInput floatingInput = this.firstNameInput;
        String string6 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("firstNameInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        String string7 = (text == null || (string5 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string5).toString();
        final String str = string7 == null ? "" : string7;
        FloatingInput floatingInput2 = this.lastNameInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("lastNameInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        String string8 = (text2 == null || (string4 = text2.toString()) == null) ? null : StringsKt.trim((CharSequence) string4).toString();
        final String str2 = string8 == null ? "" : string8;
        FloatingInput floatingInput3 = this.mobileInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mobileInput");
            floatingInput3 = null;
        }
        Editable text3 = floatingInput3.getEdit().getText();
        String string9 = (text3 == null || (string3 = text3.toString()) == null) ? null : StringsKt.trim((CharSequence) string3).toString();
        final String str3 = string9 == null ? "" : string9;
        FloatingInput floatingInput4 = this.displayNameInput;
        if (floatingInput4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("displayNameInput");
            floatingInput4 = null;
        }
        Editable text4 = floatingInput4.getEdit().getText();
        String string10 = (text4 == null || (string2 = text4.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        final String str4 = string10 == null ? "" : string10;
        FloatingInput floatingInput5 = this.emailInput;
        if (floatingInput5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("emailInput");
            floatingInput5 = null;
        }
        Editable text5 = floatingInput5.getEdit().getText();
        if (text5 != null && (string = text5.toString()) != null) {
            string6 = StringsKt.trim((CharSequence) string).toString();
        }
        final String str5 = string6 == null ? "" : string6;
        String str6 = str5;
        if (StringsKt.isBlank(str6)) {
            showToast("ایمیل را وارد کنید.");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(str6).matches()) {
            showToast("فرمت ایمیل صحیح نیست.");
            return;
        }
        this.submitting = true;
        setSaveLoading(true);
        setMessage("در حال ذخیره...", -534899);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                EditProfileScreenView.submitProfile$lambda$63(this.f$0, str, str2, str3, str4, str5);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitProfile$lambda$63(final EditProfileScreenView this$0, String firstName, String lastName, String mobile, String displayName, String email) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(firstName, "$firstName");
        Intrinsics.checkNotNullParameter(lastName, "$lastName");
        Intrinsics.checkNotNullParameter(mobile, "$mobile");
        Intrinsics.checkNotNullParameter(displayName, "$displayName");
        Intrinsics.checkNotNullParameter(email, "$email");
        try {
            LinkedHashMap linkedHashMapLinkedMapOf = MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("userId", String.valueOf(this$0.sessionUserId)));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userID", this$0.sessionUserId);
            jSONObject.put("first_name", firstName);
            jSONObject.put("last_name", lastName);
            jSONObject.put(BuildConfig.FLAVOR, mobile);
            jSONObject.put(HintConstants.AUTOFILL_HINT_GENDER, this$0.selectedGender);
            jSONObject.put("display_name", displayName);
            jSONObject.put("Email", email);
            jSONObject.put("email", email);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final Pair<Boolean, String> editResponse = this$0.parseEditResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/editProfile", "POST", linkedHashMapLinkedMapOf, this$0.authHeaders(), string, false, 64, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.submitProfile$lambda$63$lambda$61(this.f$0, editResponse);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.submitProfile$lambda$63$lambda$62(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitProfile$lambda$63$lambda$61(EditProfileScreenView this$0, Pair parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.submitting = false;
        this$0.setSaveLoading(false);
        if (!((Boolean) parsed.getFirst()).booleanValue()) {
            String str = (String) parsed.getSecond();
            if (str == null) {
                str = "ذخیره اطلاعات ناموفق بود.";
            }
            this$0.setMessage(str, -25958);
            this$0.showToast(str);
            return;
        }
        String str2 = (String) parsed.getSecond();
        if (str2 == null) {
            str2 = "اطلاعات با موفقیت بروزرسانی شد";
        }
        this$0.setMessage(str2, -8857441);
        this$0.showToast(str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitProfile$lambda$63$lambda$62(EditProfileScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitting = false;
        this$0.setSaveLoading(false);
        this$0.setMessage("خطا در ذخیره اطلاعات.", -25958);
        this$0.showToast("خطا در ذخیره اطلاعات.");
    }

    private final void submitPasswordChange() {
        String string;
        String string2;
        if (this.changingPassword) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        if (StringsKt.isBlank(this.apiBase)) {
            showToast("آدرس سرور در دسترس نیست.");
            return;
        }
        FloatingInput floatingInput = this.newPasswordInput;
        String string3 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("newPasswordInput");
            floatingInput = null;
        }
        Editable text = floatingInput.getEdit().getText();
        final String string4 = (text == null || (string2 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string4 == null) {
            string4 = "";
        }
        FloatingInput floatingInput2 = this.repeatPasswordInput;
        if (floatingInput2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
            floatingInput2 = null;
        }
        Editable text2 = floatingInput2.getEdit().getText();
        if (text2 != null && (string = text2.toString()) != null) {
            string3 = StringsKt.trim((CharSequence) string).toString();
        }
        final String str = string3 != null ? string3 : "";
        if (StringsKt.isBlank(string4) || StringsKt.isBlank(str)) {
            showToast("هر دو فیلد رمز عبور را تکمیل کنید.");
            return;
        }
        if (string4.length() < 6) {
            showToast("رمز عبور باید حداقل ۶ کاراکتر باشد.");
            return;
        }
        if (!Intrinsics.areEqual(string4, str)) {
            showToast("تکرار رمز عبور با رمز عبور جدید یکسان نیست.");
            return;
        }
        this.changingPassword = true;
        setChangePasswordLoading(true);
        setPasswordMessage("در حال تغییر رمز عبور...", -534899);
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                EditProfileScreenView.submitPasswordChange$lambda$67(this.f$0, string4, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitPasswordChange$lambda$67(final EditProfileScreenView this$0, String password, String repeat) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(password, "$password");
        Intrinsics.checkNotNullParameter(repeat, "$repeat");
        try {
            LinkedHashMap linkedHashMapLinkedMapOf = MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("userId", String.valueOf(this$0.sessionUserId)));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userID", this$0.sessionUserId);
            jSONObject.put(HintConstants.AUTOFILL_HINT_PASSWORD, password);
            jSONObject.put("repeat_password", repeat);
            jSONObject.put("password_repeat", repeat);
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final Pair<Boolean, String> editResponse = this$0.parseEditResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/changeProfilePassword", "POST", linkedHashMapLinkedMapOf, this$0.authHeaders(), string, false, 64, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.submitPasswordChange$lambda$67$lambda$65(this.f$0, editResponse);
                }
            });
        } catch (Throwable unused) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.EditProfileScreenView$$ExternalSyntheticLambda15
                @Override // java.lang.Runnable
                public final void run() {
                    EditProfileScreenView.submitPasswordChange$lambda$67$lambda$66(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitPasswordChange$lambda$67$lambda$65(EditProfileScreenView this$0, Pair parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.changingPassword = false;
        this$0.setChangePasswordLoading(false);
        if (!((Boolean) parsed.getFirst()).booleanValue()) {
            String str = (String) parsed.getSecond();
            if (str == null) {
                str = "تغییر رمز عبور انجام نشد.";
            }
            this$0.setPasswordMessage(str, -25958);
            this$0.showToast(str);
            return;
        }
        FloatingInput floatingInput = this$0.newPasswordInput;
        FloatingInput floatingInput2 = null;
        if (floatingInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("newPasswordInput");
            floatingInput = null;
        }
        floatingInput.getEdit().setText("");
        FloatingInput floatingInput3 = this$0.repeatPasswordInput;
        if (floatingInput3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("repeatPasswordInput");
        } else {
            floatingInput2 = floatingInput3;
        }
        floatingInput2.getEdit().setText("");
        String str2 = (String) parsed.getSecond();
        if (str2 == null) {
            str2 = "رمز عبور با موفقیت تغییر کرد";
        }
        this$0.setPasswordMessage(str2, -8857441);
        this$0.showToast(str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitPasswordChange$lambda$67$lambda$66(EditProfileScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.changingPassword = false;
        this$0.setChangePasswordLoading(false);
        this$0.setPasswordMessage("خطا در تغییر رمز عبور.", -25958);
        this$0.showToast("خطا در تغییر رمز عبور.");
    }

    private final void setSaveLoading(boolean loading) {
        TextView textView = this.saveButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.saveButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.76f : 1.0f);
        TextView textView4 = this.saveButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("saveButton");
        } else {
            textView2 = textView4;
        }
        textView2.setText(loading ? "در حال ذخیره..." : "ذخیره اطلاعات");
    }

    private final void setChangePasswordLoading(boolean loading) {
        TextView textView = this.changePasswordButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("changePasswordButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.changePasswordButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("changePasswordButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.76f : 1.0f);
        TextView textView4 = this.changePasswordButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("changePasswordButton");
        } else {
            textView2 = textView4;
        }
        textView2.setText(loading ? "در حال ثبت..." : "تغییر رمز عبور");
    }

    private final void setMessage(String text, int color) {
        String strFromRaw = SafeUserMessage.INSTANCE.fromRaw(text, "");
        TextView textView = null;
        if (StringsKt.isBlank(strFromRaw)) {
            TextView textView2 = this.messageText;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messageText");
                textView2 = null;
            }
            textView2.setVisibility(8);
            TextView textView3 = this.messageText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messageText");
            } else {
                textView = textView3;
            }
            textView.setText("");
            return;
        }
        TextView textView4 = this.messageText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageText");
            textView4 = null;
        }
        textView4.setVisibility(0);
        TextView textView5 = this.messageText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageText");
            textView5 = null;
        }
        textView5.setText(strFromRaw);
        TextView textView6 = this.messageText;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageText");
        } else {
            textView = textView6;
        }
        textView.setTextColor(color);
    }

    private final void setPasswordMessage(String text, int color) {
        String strFromRaw = SafeUserMessage.INSTANCE.fromRaw(text, "");
        TextView textView = null;
        if (StringsKt.isBlank(strFromRaw)) {
            TextView textView2 = this.passwordMessageText;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
                textView2 = null;
            }
            textView2.setVisibility(8);
            TextView textView3 = this.passwordMessageText;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
            } else {
                textView = textView3;
            }
            textView.setText("");
            return;
        }
        TextView textView4 = this.passwordMessageText;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
            textView4 = null;
        }
        textView4.setVisibility(0);
        TextView textView5 = this.passwordMessageText;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
            textView5 = null;
        }
        textView5.setText(strFromRaw);
        TextView textView6 = this.passwordMessageText;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("passwordMessageText");
        } else {
            textView = textView6;
        }
        textView.setTextColor(color);
    }

    private final ProfileData parseProfileResponse(String raw) {
        Object objNextValue;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return null;
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return null;
        }
        Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
        if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r0).toString())) {
            return null;
        }
        if (jSONObject.has(NotificationCompat.CATEGORY_STATUS) && !toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS))) {
            return null;
        }
        String strPickString = pickString(jSONObject, HintConstants.AUTOFILL_HINT_GENDER);
        if (strPickString == null) {
            strPickString = "";
        }
        String strPickString2 = pickString(jSONObject, "first_name");
        String str2 = strPickString2 == null ? "" : strPickString2;
        String strPickString3 = pickString(jSONObject, "last_name");
        String str3 = strPickString3 == null ? "" : strPickString3;
        String strPickString4 = pickString(jSONObject, BuildConfig.FLAVOR);
        String str4 = strPickString4 == null ? "" : strPickString4;
        String strNormalizeGender = normalizeGender(strPickString);
        String strPickString5 = pickString(jSONObject, "display_name", "nickname");
        String str5 = strPickString5 == null ? "" : strPickString5;
        String strPickString6 = pickString(jSONObject, "email", "Email");
        return new ProfileData(str2, str3, str4, strNormalizeGender, str5, strPickString6 == null ? "" : strPickString6);
    }

    private final Pair<Boolean, String> parseEditResponse(String raw) {
        Object objNextValue;
        String str = raw;
        boolean bool = true;
        if (str == null || StringsKt.isBlank(str)) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
        if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r6).toString())) {
            return TuplesKt.m787to(false, pickString(jSONObject, "message"));
        }
        if (jSONObject.has(NotificationCompat.CATEGORY_STATUS)) {
            bool = toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS));
        } else if (jSONObject.has("flag")) {
            bool = toBool(jSONObject.opt("flag"));
        }
        return TuplesKt.m787to(Boolean.valueOf(bool), pickString(jSONObject, "message"));
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0052, code lost:
    
        if (r4.equals("زن") == false) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0064, code lost:
    
        if (r4.equals("f") == false) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x006b, code lost:
    
        if (r4.equals("female") == false) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x002e, code lost:
    
        if (r4.equals("woman") == false) goto L30;
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final String normalizeGender(String raw) {
        String string = StringsKt.trim((CharSequence) raw).toString();
        Locale US = Locale.US;
        Intrinsics.checkNotNullExpressionValue(US, "US");
        String lowerCase = string.toLowerCase(US);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        switch (lowerCase.hashCode()) {
            case -1278174388:
                break;
            case 102:
                break;
            case 109:
                if (!lowerCase.equals("m")) {
                }
                break;
            case 50772:
                break;
            case 107866:
                if (!lowerCase.equals("man")) {
                }
                break;
            case 1593123:
                if (!lowerCase.equals("مرد")) {
                }
                break;
            case 3343885:
                if (lowerCase.equals("male")) {
                }
                break;
            case 113313666:
                break;
        }
        return "male";
    }

    private final void showState(String message, String buttonText, Function0<Unit> action) {
        TextView textView = this.stateText;
        LinearLayout linearLayout = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView = null;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت اطلاعات"));
        TextView textView2 = this.stateButton;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView2 = null;
        }
        textView2.setText(buttonText);
        this.stateAction = action;
        TextView textView3 = this.stateButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView3 = null;
        }
        textView3.setVisibility(action == null ? 8 : 0);
        LinearLayout linearLayout2 = this.stateOverlay;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
        } else {
            linearLayout = linearLayout2;
        }
        linearLayout.setVisibility(0);
    }

    private final void hideState() {
        LinearLayout linearLayout = this.stateOverlay;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        }
        linearLayout.setVisibility(8);
        this.stateAction = null;
    }

    private final boolean isLoggedIn() {
        if (this.sessionUserId > 0) {
            String str = this.sessionToken;
            if (!(str == null || StringsKt.isBlank(str))) {
                return true;
            }
        }
        return false;
    }

    private final Map<String, String> authHeaders() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        long j = this.sessionUserId;
        if (j > 0) {
            linkedHashMap.put("x-fk-user-id", String.valueOf(j));
        }
        String str = this.sessionToken;
        String str2 = str;
        if (!(str2 == null || StringsKt.isBlank(str2))) {
            linkedHashMap.put("x-fk-session", str);
        }
        return linkedHashMap;
    }

    private final void showToast(String text) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(text, "عملیات انجام نشد"), 0).show();
    }

    private final String pickString(JSONObject obj, String... keys) {
        if (obj == null) {
            return null;
        }
        for (String str : keys) {
            Object objOpt = obj.opt(str);
            if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                if (!StringsKt.isBlank(string)) {
                    return string;
                }
            }
        }
        return null;
    }

    private final boolean toBool(Object v) {
        if (v instanceof Boolean) {
            return ((Boolean) v).booleanValue();
        }
        if (v instanceof Number) {
            if (((Number) v).intValue() != 0) {
                return true;
            }
        } else if (v instanceof String) {
            String string = StringsKt.trim((CharSequence) v).toString();
            Locale US = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US, "US");
            String lowerCase = string.toLowerCase(US);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, "1") || Intrinsics.areEqual(lowerCase, "true") || Intrinsics.areEqual(lowerCase, "ok") || Intrinsics.areEqual(lowerCase, FirebaseAnalytics.Param.SUCCESS)) {
                return true;
            }
        }
        return false;
    }

    private final CharSequence styledHint(String text) {
        String str = text;
        if (StringsKt.isBlank(str)) {
            return str;
        }
        SpannableString spannableString = new SpannableString(str);
        spannableString.setSpan(new AbsoluteSizeSpan(12, true), 0, spannableString.length(), 33);
        return spannableString;
    }

    private final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        if (strokeWidth > 0) {
            gradientDrawable.setStroke(strokeWidth, stroke);
        }
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: renamed from: dp */
    private final int m379dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    private final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }
}
