package com.filmkio.nativescreen.account;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J1\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\n¨\u0006\u0019"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PlaySetState;", "", "quality", "", "sizeSubtitle", "", "colorSubtitle", "bgSubtitle", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getBgSubtitle", "()Ljava/lang/String;", "getColorSubtitle", "getQuality", "()I", "getSizeSubtitle", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class PlaySetState {
    public static final int $stable = 0;
    private final String bgSubtitle;
    private final String colorSubtitle;
    private final int quality;
    private final String sizeSubtitle;

    public static /* synthetic */ PlaySetState copy$default(PlaySetState playSetState, int i, String str, String str2, String str3, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = playSetState.quality;
        }
        if ((i2 & 2) != 0) {
            str = playSetState.sizeSubtitle;
        }
        if ((i2 & 4) != 0) {
            str2 = playSetState.colorSubtitle;
        }
        if ((i2 & 8) != 0) {
            str3 = playSetState.bgSubtitle;
        }
        return playSetState.copy(i, str, str2, str3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getQuality() {
        return this.quality;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getSizeSubtitle() {
        return this.sizeSubtitle;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getColorSubtitle() {
        return this.colorSubtitle;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getBgSubtitle() {
        return this.bgSubtitle;
    }

    public final PlaySetState copy(int quality, String sizeSubtitle, String colorSubtitle, String bgSubtitle) {
        Intrinsics.checkNotNullParameter(sizeSubtitle, "sizeSubtitle");
        Intrinsics.checkNotNullParameter(colorSubtitle, "colorSubtitle");
        Intrinsics.checkNotNullParameter(bgSubtitle, "bgSubtitle");
        return new PlaySetState(quality, sizeSubtitle, colorSubtitle, bgSubtitle);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PlaySetState)) {
            return false;
        }
        PlaySetState playSetState = (PlaySetState) other;
        return this.quality == playSetState.quality && Intrinsics.areEqual(this.sizeSubtitle, playSetState.sizeSubtitle) && Intrinsics.areEqual(this.colorSubtitle, playSetState.colorSubtitle) && Intrinsics.areEqual(this.bgSubtitle, playSetState.bgSubtitle);
    }

    public int hashCode() {
        return (((((Integer.hashCode(this.quality) * 31) + this.sizeSubtitle.hashCode()) * 31) + this.colorSubtitle.hashCode()) * 31) + this.bgSubtitle.hashCode();
    }

    public String toString() {
        return "PlaySetState(quality=" + this.quality + ", sizeSubtitle=" + this.sizeSubtitle + ", colorSubtitle=" + this.colorSubtitle + ", bgSubtitle=" + this.bgSubtitle + ")";
    }

    public PlaySetState(int i, String sizeSubtitle, String colorSubtitle, String bgSubtitle) {
        Intrinsics.checkNotNullParameter(sizeSubtitle, "sizeSubtitle");
        Intrinsics.checkNotNullParameter(colorSubtitle, "colorSubtitle");
        Intrinsics.checkNotNullParameter(bgSubtitle, "bgSubtitle");
        this.quality = i;
        this.sizeSubtitle = sizeSubtitle;
        this.colorSubtitle = colorSubtitle;
        this.bgSubtitle = bgSubtitle;
    }

    public final int getQuality() {
        return this.quality;
    }

    public final String getSizeSubtitle() {
        return this.sizeSubtitle;
    }

    public final String getColorSubtitle() {
        return this.colorSubtitle;
    }

    public final String getBgSubtitle() {
        return this.bgSubtitle;
    }
}
