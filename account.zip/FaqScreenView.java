package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import androidx.media3.exoplayer.upstream.CmcdData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.account.FaqScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: FaqScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\b\u0007\u0018\u00002\u00020\u0001:\u0003456B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007¢\u0006\u0002\u0010\bJ\u0010\u0010#\u001a\u00020\n2\u0006\u0010$\u001a\u00020\nH\u0002J\u0010\u0010%\u001a\u00020&2\u0006\u0010$\u001a\u00020\nH\u0002J\b\u0010'\u001a\u00020(H\u0002J\b\u0010)\u001a\u00020(H\u0002J\b\u0010*\u001a\u00020(H\u0014J\b\u0010+\u001a\u00020\u0005H\u0002J(\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020\n2\u0006\u0010/\u001a\u00020\n2\u0006\u00100\u001a\u00020\n2\u0006\u00101\u001a\u00020&H\u0002J\u0010\u00102\u001a\u00020(2\u0006\u00103\u001a\u00020\u0005H\u0002R\u000e\u0010\t\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u00060\fR\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u000f\u001a\n \u0011*\u0004\u0018\u00010\u00100\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0014\u001a\u0012\u0012\u0004\u0012\u00020\u00160\u0015j\b\u0012\u0004\u0012\u00020\u0016`\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u00067"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FaqScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "endpointPaths", "", "(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)V", "accent", "", "adapter", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqAdapter;", "cardFill", "cardStroke", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "isTouchDevice", "", FirebaseAnalytics.Param.ITEMS, "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqItem;", "Lkotlin/collections/ArrayList;", "list", "Landroidx/recyclerview/widget/RecyclerView;", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "stateButton", "Landroid/widget/TextView;", "stateOverlay", "Landroid/widget/LinearLayout;", "stateText", "dp", "v", "dpF", "", "hideState", "", "loadFaqs", "onDetachedFromWindow", "requestFaqs", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "showState", NotificationCompat.CATEGORY_MESSAGE, "FaqAdapter", "FaqItem", "Parser", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class FaqScreenView extends FrameLayout {
    public static final int $stable = 8;
    private final int accent;
    private final FaqAdapter adapter;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private final Context ctx;
    private final List<String> endpointPaths;
    private final ExecutorService executor;
    private final boolean isTouchDevice;
    private final ArrayList<FaqItem> items;
    private final RecyclerView list;
    private final ProgressBar loadingView;
    private final Handler mainHandler;
    private final TextView stateButton;
    private final LinearLayout stateOverlay;
    private final TextView stateText;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FaqScreenView(Context ctx, String apiBase, List<String> endpointPaths) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        Intrinsics.checkNotNullParameter(endpointPaths, "endpointPaths");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.endpointPaths = endpointPaths;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        ArrayList<FaqItem> arrayList = new ArrayList<>();
        this.items = arrayList;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        FaqAdapter faqAdapter = new FaqAdapter(this, arrayList, zHasSystemFeature);
        this.adapter = faqAdapter;
        RecyclerView recyclerView = new RecyclerView(ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx, 1, false));
        recyclerView.setAdapter(faqAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(m380dp(14), m380dp(14), m380dp(14), m380dp(96));
        this.list = recyclerView;
        addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(-676591);
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        Unit unit = Unit.INSTANCE;
        addView(progressBar, layoutParams);
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(17);
        linearLayout.setVisibility(8);
        linearLayout.setPadding(m380dp(24), m380dp(24), m380dp(24), m380dp(24));
        linearLayout.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout;
        TextView textView = new TextView(ctx);
        textView.setTextColor(-419430401);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        this.stateText = textView;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-16052459);
        textView2.setTextSize(14.0f);
        textView2.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView2.setTypeface(typefaceBold == null ? textView2.getTypeface() : typefaceBold);
        textView2.setPadding(m380dp(16), m380dp(10), m380dp(16), m380dp(10));
        textView2.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView2.setFocusable(!zHasSystemFeature);
        textView2.setFocusableInTouchMode(!zHasSystemFeature);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.FaqScreenView$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                FaqScreenView.lambda$6$lambda$5(this.f$0, view);
            }
        });
        this.stateButton = textView2;
        linearLayout.addView(textView);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = m380dp(12);
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(textView2, layoutParams2);
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        loadFaqs();
    }

    /* JADX INFO: compiled from: FaqScreenView.kt */
    @Metadata(m779d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000f\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0006HÆ\u0003J'\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0006HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00062\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\t¨\u0006\u0018"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FaqScreenView$FaqItem;", "", "question", "", "answer", "expanded", "", "(Ljava/lang/String;Ljava/lang/String;Z)V", "getAnswer", "()Ljava/lang/String;", "getExpanded", "()Z", "setExpanded", "(Z)V", "getQuestion", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class FaqItem {
        private final String answer;
        private boolean expanded;
        private final String question;

        public static /* synthetic */ FaqItem copy$default(FaqItem faqItem, String str, String str2, boolean z, int i, Object obj) {
            if ((i & 1) != 0) {
                str = faqItem.question;
            }
            if ((i & 2) != 0) {
                str2 = faqItem.answer;
            }
            if ((i & 4) != 0) {
                z = faqItem.expanded;
            }
            return faqItem.copy(str, str2, z);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getQuestion() {
            return this.question;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getAnswer() {
            return this.answer;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final boolean getExpanded() {
            return this.expanded;
        }

        public final FaqItem copy(String question, String answer, boolean expanded) {
            Intrinsics.checkNotNullParameter(question, "question");
            Intrinsics.checkNotNullParameter(answer, "answer");
            return new FaqItem(question, answer, expanded);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof FaqItem)) {
                return false;
            }
            FaqItem faqItem = (FaqItem) other;
            return Intrinsics.areEqual(this.question, faqItem.question) && Intrinsics.areEqual(this.answer, faqItem.answer) && this.expanded == faqItem.expanded;
        }

        public int hashCode() {
            return (((this.question.hashCode() * 31) + this.answer.hashCode()) * 31) + Boolean.hashCode(this.expanded);
        }

        public String toString() {
            return "FaqItem(question=" + this.question + ", answer=" + this.answer + ", expanded=" + this.expanded + ")";
        }

        public FaqItem(String question, String answer, boolean z) {
            Intrinsics.checkNotNullParameter(question, "question");
            Intrinsics.checkNotNullParameter(answer, "answer");
            this.question = question;
            this.answer = answer;
            this.expanded = z;
        }

        public /* synthetic */ FaqItem(String str, String str2, boolean z, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(str, str2, (i & 4) != 0 ? false : z);
        }

        public final String getQuestion() {
            return this.question;
        }

        public final String getAnswer() {
            return this.answer;
        }

        public final boolean getExpanded() {
            return this.expanded;
        }

        public final void setExpanded(boolean z) {
            this.expanded = z;
        }
    }

    static final void lambda$6$lambda$5(FaqScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.loadFaqs();
    }

    private final void loadFaqs() {
        this.loadingView.setVisibility(0);
        hideState();
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.FaqScreenView$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                FaqScreenView.loadFaqs$lambda$10(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadFaqs$lambda$10(final FaqScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final List<FaqItem> list = Parser.INSTANCE.parse(this$0.requestFaqs());
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.FaqScreenView$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    FaqScreenView.loadFaqs$lambda$10$lambda$8(this.f$0, list);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.FaqScreenView$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    FaqScreenView.loadFaqs$lambda$10$lambda$9(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadFaqs$lambda$10$lambda$8(FaqScreenView this$0, List parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loadingView.setVisibility(8);
        if (parsed.isEmpty()) {
            this$0.showState("سوالی برای نمایش وجود ندارد.");
            return;
        }
        int size = this$0.items.size();
        this$0.items.clear();
        if (size > 0) {
            this$0.adapter.notifyItemRangeRemoved(0, size);
        }
        this$0.items.addAll(parsed);
        this$0.adapter.notifyItemRangeInserted(0, parsed.size());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadFaqs$lambda$10$lambda$9(FaqScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.loadingView.setVisibility(8);
        this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت سوالات متداول"));
    }

    private final String requestFaqs() {
        Iterator<String> it = this.endpointPaths.iterator();
        FkApiClient.ApiException th = null;
        while (it.hasNext()) {
            try {
                return FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this.apiBase, it.next(), "GET", null, null, null, false, 120, null);
            } finally {
                th = th;
            }
        }
        if (th == null) {
            throw new RuntimeException("Endpoint not available");
        }
        throw th;
    }

    private final void showState(String msg) {
        this.stateText.setText(SafeUserMessage.INSTANCE.fromRaw(msg, "خطا در دریافت سوالات متداول"));
        this.stateButton.setText("تلاش دوباره");
        this.stateOverlay.setVisibility(0);
    }

    private final void hideState() {
        this.stateOverlay.setVisibility(8);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: FaqScreenView.kt */
    @Metadata(m779d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0015B\u001b\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\n\u001a\u00020\u000bH\u0016J \u0010\f\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016J\u0018\u0010\u0014\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FaqScreenView$FaqAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqAdapter$VH;", "Lcom/filmkio/nativescreen/account/FaqScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqItem;", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/FaqScreenView;Ljava/util/List;Z)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class FaqAdapter extends RecyclerView.Adapter<C2655VH> {
        private final List<FaqItem> data;
        private final boolean isTouchDevice;
        final /* synthetic */ FaqScreenView this$0;

        public FaqAdapter(FaqScreenView faqScreenView, List<FaqItem> data, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = faqScreenView;
            this.data = data;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2655VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            FaqScreenView faqScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(faqScreenView.m380dp(12), faqScreenView.m380dp(11), faqScreenView.m380dp(12), faqScreenView.m380dp(11));
            linearLayout.setBackground(faqScreenView.roundedBg(faqScreenView.cardFill, faqScreenView.cardStroke, faqScreenView.m380dp(1), faqScreenView.dpF(12)));
            linearLayout.setClickable(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2655VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2655VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position), position);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2655VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m380dp(10);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.FaqScreenView$FaqAdapter$VH */
        /* JADX INFO: compiled from: FaqScreenView.kt */
        @Metadata(m779d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0016\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FaqScreenView$FaqAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/FaqScreenView$FaqAdapter;Landroid/widget/LinearLayout;)V", "answerText", "Landroid/widget/TextView;", "questionText", "bind", "", "item", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqItem;", "position", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2655VH extends RecyclerView.ViewHolder {
            private final TextView answerText;
            private final TextView questionText;
            private final LinearLayout root;
            final /* synthetic */ FaqAdapter this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2655VH(FaqAdapter faqAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = faqAdapter;
                this.root = root;
                TextView textView = new TextView(faqAdapter.this$0.ctx);
                FaqScreenView faqScreenView = faqAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(15.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(faqScreenView.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setGravity(5);
                textView.setIncludeFontPadding(false);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                textView.setMaxLines(2);
                this.questionText = textView;
                TextView textView2 = new TextView(faqAdapter.this$0.ctx);
                FaqScreenView faqScreenView2 = faqAdapter.this$0;
                textView2.setTextColor(-3088659);
                textView2.setTextSize(13.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(faqScreenView2.ctx);
                textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
                textView2.setGravity(5);
                textView2.setIncludeFontPadding(false);
                textView2.setLineSpacing(faqScreenView2.m380dp(1), 1.0f);
                textView2.setVisibility(8);
                this.answerText = textView2;
                root.addView(textView);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = faqAdapter.this$0.m380dp(8);
                Unit unit = Unit.INSTANCE;
                root.addView(textView2, layoutParams);
            }

            public final void bind(FaqItem item, final int position) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.questionText.setText(item.getQuestion());
                this.answerText.setText(item.getAnswer());
                this.answerText.setVisibility(item.getExpanded() ? 0 : 8);
                LinearLayout linearLayout = this.root;
                final FaqAdapter faqAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.FaqScreenView$FaqAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        FaqScreenView.FaqAdapter.C2655VH.bind$lambda$3(faqAdapter, position, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$3(FaqAdapter this$0, int i, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                ((FaqItem) this$0.data.get(i)).setExpanded(!((FaqItem) this$0.data.get(i)).getExpanded());
                this$0.notifyItemChanged(i);
            }
        }
    }

    /* JADX INFO: compiled from: FaqScreenView.kt */
    @Metadata(m779d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0002J\u0016\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b2\b\u0010\n\u001a\u0004\u0018\u00010\u000bJ-\u0010\f\u001a\u0004\u0018\u00010\u000b2\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0012\u0010\r\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000b0\u000e\"\u00020\u000bH\u0002¢\u0006\u0002\u0010\u000f¨\u0006\u0010"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FaqScreenView$Parser;", "", "()V", "numericObjectToArray", "Lorg/json/JSONArray;", "obj", "Lorg/json/JSONObject;", "parse", "", "Lcom/filmkio/nativescreen/account/FaqScreenView$FaqItem;", "json", "", "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class Parser {
        public static final Parser INSTANCE = new Parser();

        private Parser() {
        }

        public final List<FaqItem> parse(String json) {
            JSONArray jSONArrayNumericObjectToArray;
            JSONArray jSONArrayOptJSONArray;
            String str = json;
            if (str == null || StringsKt.isBlank(str)) {
                return CollectionsKt.emptyList();
            }
            try {
                Object objNextValue = new JSONTokener(json).nextValue();
                if (objNextValue instanceof JSONArray) {
                    jSONArrayNumericObjectToArray = (JSONArray) objNextValue;
                } else if (objNextValue instanceof JSONObject) {
                    JSONObject jSONObject = (JSONObject) objNextValue;
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                    if ((jSONObjectOptJSONObject == null || (jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null) && (jSONArrayOptJSONArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null) {
                        Intrinsics.checkNotNull(objNextValue);
                        jSONArrayNumericObjectToArray = numericObjectToArray(jSONObject);
                    } else {
                        jSONArrayNumericObjectToArray = jSONArrayOptJSONArray;
                    }
                } else {
                    jSONArrayNumericObjectToArray = null;
                }
                if (jSONArrayNumericObjectToArray == null) {
                    jSONArrayNumericObjectToArray = new JSONArray();
                }
                ArrayList arrayList = new ArrayList(jSONArrayNumericObjectToArray.length());
                int length = jSONArrayNumericObjectToArray.length();
                for (int i = 0; i < length; i++) {
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayNumericObjectToArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject2 != null) {
                        String strPickString = pickString(jSONObjectOptJSONObject2, "question", "title", "q");
                        if (strPickString == null) {
                            strPickString = "";
                        }
                        String strPickString2 = pickString(jSONObjectOptJSONObject2, "answer", FirebaseAnalytics.Param.CONTENT, CmcdData.Factory.OBJECT_TYPE_AUDIO_ONLY);
                        String str2 = strPickString2 != null ? strPickString2 : "";
                        if (!StringsKt.isBlank(strPickString) && !StringsKt.isBlank(str2)) {
                            arrayList.add(new FaqItem(strPickString, str2, false));
                        }
                    }
                }
                return arrayList;
            } catch (Throwable unused) {
                return CollectionsKt.emptyList();
            }
        }

        private final String pickString(JSONObject obj, String... keys) {
            if (obj == null) {
                return null;
            }
            for (String str : keys) {
                Object objOpt = obj.opt(str);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                    if (!StringsKt.isBlank(string)) {
                        return string;
                    }
                }
            }
            return null;
        }

        private final JSONArray numericObjectToArray(JSONObject obj) {
            boolean z;
            Iterator<String> itKeys = obj.keys();
            JSONArray jSONArray = new JSONArray();
            boolean z2 = false;
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                Intrinsics.checkNotNull(next);
                String str = next;
                int i = 0;
                while (true) {
                    if (i >= str.length()) {
                        z = true;
                        break;
                    }
                    if (!Character.isDigit(str.charAt(i))) {
                        z = false;
                        break;
                    }
                    i++;
                }
                if (z) {
                    Object objOpt = obj.opt(next);
                    if (objOpt instanceof JSONObject) {
                        jSONArray.put(objOpt);
                        z2 = true;
                    }
                }
            }
            if (z2) {
                return jSONArray;
            }
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m380dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }
}
