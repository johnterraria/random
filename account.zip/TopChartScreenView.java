package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.BidiFormatter;
import android.text.SpannableStringBuilder;
import android.text.TextDirectionHeuristics;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import coil.Coil;
import coil.ImageLoader;
import coil.request.ImageRequest;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.account.TopChartScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: TopChartScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000 \u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 H2\u00020\u0001:\u0005FGHIJB;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007\u0012\u0016\b\u0002\u0010\b\u001a\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\t¢\u0006\u0002\u0010\fJ\u0010\u0010-\u001a\u00020\u000e2\u0006\u0010.\u001a\u00020\u000eH\u0002J\u0010\u0010/\u001a\u0002002\u0006\u0010.\u001a\u00020\u000eH\u0002J\b\u00101\u001a\u00020\u000bH\u0002J\u0018\u00102\u001a\u00020\u000b2\u0006\u00103\u001a\u00020\u000e2\u0006\u00104\u001a\u00020\u0018H\u0002J\b\u00105\u001a\u00020\u000bH\u0002J\b\u00106\u001a\u00020\u000bH\u0014J\u001c\u00107\u001a\u00020\u00052\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000509H\u0002J\b\u0010:\u001a\u00020\u000bH\u0002J(\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020\u000e2\u0006\u0010>\u001a\u00020\u000e2\u0006\u0010?\u001a\u00020\u000e2\u0006\u0010@\u001a\u000200H\u0002J(\u0010A\u001a\u00020\u000b2\u0006\u0010B\u001a\u00020\u00052\u0006\u0010C\u001a\u00020\u00052\u000e\u0010D\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010EH\u0002R\u000e\u0010\r\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u0012\u0010\u000f\u001a\u00060\u0010R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0014\u001a\n \u0016*\u0004\u0018\u00010\u00150\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u001a\u001a\u0012\u0012\u0004\u0012\u00020\u001c0\u001bj\b\u0012\u0004\u0012\u00020\u001c`\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\b\u001a\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010&\u001a\n \u0016*\u0004\u0018\u00010'0'X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020+X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006K"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "endpointPaths", "", "onOpenSingle", "Lkotlin/Function1;", "", "", "(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "accent", "", "adapter", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartAdapter;", "cardFill", "cardStroke", "currentPage", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "hasMore", "", "isTouchDevice", FirebaseAnalytics.Param.ITEMS, "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartItem;", "Lkotlin/collections/ArrayList;", "list", "Landroidx/recyclerview/widget/RecyclerView;", "loading", "loadingMoreOverlay", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "rtlBidi", "Landroid/text/BidiFormatter;", "stateButton", "Landroid/widget/TextView;", "stateOverlay", "Landroid/widget/LinearLayout;", "stateText", "dp", "v", "dpF", "", "hideState", "loadPage", "page", "reset", "maybeLoadNext", "onDetachedFromWindow", "requestChart", SearchIntents.EXTRA_QUERY, "", "resetAndLoad", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "showState", "message", "buttonText", "onClick", "Lkotlin/Function0;", "ChartAdapter", "ChartItem", "Companion", "ParseResult", "Parser", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class TopChartScreenView extends FrameLayout {
    private static final int PER_PAGE = 24;
    private final int accent;
    private final ChartAdapter adapter;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private final Context ctx;
    private int currentPage;
    private final List<String> endpointPaths;
    private final ExecutorService executor;
    private boolean hasMore;
    private final boolean isTouchDevice;
    private final ArrayList<ChartItem> items;
    private final RecyclerView list;
    private boolean loading;
    private final FrameLayout loadingMoreOverlay;
    private final ProgressBar loadingView;
    private final Handler mainHandler;
    private final Function1<Long, Unit> onOpenSingle;
    private final BidiFormatter rtlBidi;
    private final TextView stateButton;
    private final LinearLayout stateOverlay;
    private final TextView stateText;
    public static final int $stable = 8;

    public /* synthetic */ TopChartScreenView(Context context, String str, List list, Function1 function1, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, list, (i & 8) != 0 ? null : function1);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public TopChartScreenView(Context ctx, String apiBase, List<String> endpointPaths, Function1<? super Long, Unit> function1) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        Intrinsics.checkNotNullParameter(endpointPaths, "endpointPaths");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.endpointPaths = endpointPaths;
        this.onOpenSingle = function1;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.rtlBidi = BidiFormatter.getInstance(true);
        this.hasMore = true;
        this.currentPage = 1;
        ArrayList<ChartItem> arrayList = new ArrayList<>();
        this.items = arrayList;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        ChartAdapter chartAdapter = new ChartAdapter(this, arrayList, zHasSystemFeature);
        this.adapter = chartAdapter;
        RecyclerView recyclerView = new RecyclerView(ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx, 1, false));
        recyclerView.setAdapter(chartAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(m386dp(14), m386dp(14), m386dp(14), m386dp(96));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$1$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 4) {
                    return;
                }
                this.this$0.maybeLoadNext();
            }
        });
        this.list = recyclerView;
        addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(-676591);
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        Unit unit = Unit.INSTANCE;
        addView(progressBar, layoutParams);
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m386dp(12), m386dp(8), m386dp(12), m386dp(8));
        linearLayout.setBackground(roundedBg(-653454566, 654311423, m386dp(1), dpF(12)));
        ProgressBar progressBar2 = new ProgressBar(ctx);
        progressBar2.setIndeterminate(true);
        Drawable indeterminateDrawable2 = progressBar2.getIndeterminateDrawable();
        if (indeterminateDrawable2 != null) {
            indeterminateDrawable2.setTint(-676591);
        }
        TextView textView = new TextView(ctx);
        textView.setText("در حال بارگیری بیشتر...");
        textView.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        textView.setGravity(16);
        textView.setIncludeFontPadding(false);
        linearLayout.addView(progressBar2, new LinearLayout.LayoutParams(m386dp(14), m386dp(14)));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMarginStart(m386dp(8));
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams2);
        FrameLayout frameLayout = new FrameLayout(ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        this.loadingMoreOverlay = frameLayout;
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 81;
        layoutParams3.bottomMargin = m386dp(18);
        Unit unit3 = Unit.INSTANCE;
        frameLayout.addView(linearLayout, layoutParams3);
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout2 = new LinearLayout(ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(17);
        linearLayout2.setVisibility(8);
        linearLayout2.setPadding(m386dp(24), m386dp(24), m386dp(24), m386dp(24));
        linearLayout2.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout2;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-419430401);
        textView2.setTextSize(15.0f);
        textView2.setGravity(17);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(ctx);
        textView2.setTypeface(typefaceMedium2 == null ? textView2.getTypeface() : typefaceMedium2);
        this.stateText = textView2;
        TextView textView3 = new TextView(ctx);
        textView3.setTextColor(-16052459);
        textView3.setTextSize(14.0f);
        textView3.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView3.setTypeface(typefaceBold == null ? textView3.getTypeface() : typefaceBold);
        textView3.setPadding(m386dp(16), m386dp(10), m386dp(16), m386dp(10));
        textView3.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView3.setFocusable(!zHasSystemFeature);
        textView3.setFocusableInTouchMode(!zHasSystemFeature);
        this.stateButton = textView3;
        linearLayout2.addView(textView2);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.topMargin = m386dp(12);
        Unit unit4 = Unit.INSTANCE;
        linearLayout2.addView(textView3, layoutParams4);
        addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        resetAndLoad();
    }

    /* JADX INFO: compiled from: TopChartScreenView.kt */
    @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b-\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001Bu\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007\u0012\u0006\u0010\u000f\u001a\u00020\u0007\u0012\u0006\u0010\u0010\u001a\u00020\u0007\u0012\u0006\u0010\u0011\u001a\u00020\u0007\u0012\u0006\u0010\u0012\u001a\u00020\u0007¢\u0006\u0002\u0010\u0013J\t\u0010%\u001a\u00020\u0003HÆ\u0003J\t\u0010&\u001a\u00020\u0007HÆ\u0003J\t\u0010'\u001a\u00020\u0007HÆ\u0003J\t\u0010(\u001a\u00020\u0007HÆ\u0003J\t\u0010)\u001a\u00020\u0007HÆ\u0003J\t\u0010*\u001a\u00020\u0007HÆ\u0003J\t\u0010+\u001a\u00020\u0005HÆ\u0003J\t\u0010,\u001a\u00020\u0007HÆ\u0003J\t\u0010-\u001a\u00020\u0007HÆ\u0003J\t\u0010.\u001a\u00020\u0007HÆ\u0003J\t\u0010/\u001a\u00020\u0007HÆ\u0003J\t\u00100\u001a\u00020\u0007HÆ\u0003J\t\u00101\u001a\u00020\u0007HÆ\u0003J\t\u00102\u001a\u00020\u0007HÆ\u0003J\u0095\u0001\u00103\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\u00072\b\b\u0002\u0010\f\u001a\u00020\u00072\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u00072\b\b\u0002\u0010\u000f\u001a\u00020\u00072\b\b\u0002\u0010\u0010\u001a\u00020\u00072\b\b\u0002\u0010\u0011\u001a\u00020\u00072\b\b\u0002\u0010\u0012\u001a\u00020\u0007HÆ\u0001J\u0013\u00104\u001a\u0002052\b\u00106\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00107\u001a\u00020\u0003HÖ\u0001J\t\u00108\u001a\u00020\u0007HÖ\u0001R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u000e\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0015R\u0011\u0010\u000b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0015R\u0011\u0010\f\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0015R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0015R\u0011\u0010\u0010\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0015R\u0011\u0010\u0012\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0015R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0015R\u0011\u0010\u000f\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0015R\u0011\u0010\u0011\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0015¨\u00069"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartItem;", "", "rank", "", "postId", "", "title", "", "poster", "rating", "votes", "release", "runtime", "certificate", "episodes", "weekendGross", "totalGross", "weeks", "type", "(IJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCertificate", "()Ljava/lang/String;", "getEpisodes", "getPostId", "()J", "getPoster", "getRank", "()I", "getRating", "getRelease", "getRuntime", "getTitle", "getTotalGross", "getType", "getVotes", "getWeekendGross", "getWeeks", "component1", "component10", "component11", "component12", "component13", "component14", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class ChartItem {
        private final String certificate;
        private final String episodes;
        private final long postId;
        private final String poster;
        private final int rank;
        private final String rating;
        private final String release;
        private final String runtime;
        private final String title;
        private final String totalGross;
        private final String type;
        private final String votes;
        private final String weekendGross;
        private final String weeks;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final int getRank() {
            return this.rank;
        }

        /* JADX INFO: renamed from: component10, reason: from getter */
        public final String getEpisodes() {
            return this.episodes;
        }

        /* JADX INFO: renamed from: component11, reason: from getter */
        public final String getWeekendGross() {
            return this.weekendGross;
        }

        /* JADX INFO: renamed from: component12, reason: from getter */
        public final String getTotalGross() {
            return this.totalGross;
        }

        /* JADX INFO: renamed from: component13, reason: from getter */
        public final String getWeeks() {
            return this.weeks;
        }

        /* JADX INFO: renamed from: component14, reason: from getter */
        public final String getType() {
            return this.type;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final long getPostId() {
            return this.postId;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getTitle() {
            return this.title;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getPoster() {
            return this.poster;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getRating() {
            return this.rating;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getVotes() {
            return this.votes;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final String getRelease() {
            return this.release;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final String getRuntime() {
            return this.runtime;
        }

        /* JADX INFO: renamed from: component9, reason: from getter */
        public final String getCertificate() {
            return this.certificate;
        }

        public final ChartItem copy(int rank, long postId, String title, String poster, String rating, String votes, String release, String runtime, String certificate, String episodes, String weekendGross, String totalGross, String weeks, String type) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(poster, "poster");
            Intrinsics.checkNotNullParameter(rating, "rating");
            Intrinsics.checkNotNullParameter(votes, "votes");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(runtime, "runtime");
            Intrinsics.checkNotNullParameter(certificate, "certificate");
            Intrinsics.checkNotNullParameter(episodes, "episodes");
            Intrinsics.checkNotNullParameter(weekendGross, "weekendGross");
            Intrinsics.checkNotNullParameter(totalGross, "totalGross");
            Intrinsics.checkNotNullParameter(weeks, "weeks");
            Intrinsics.checkNotNullParameter(type, "type");
            return new ChartItem(rank, postId, title, poster, rating, votes, release, runtime, certificate, episodes, weekendGross, totalGross, weeks, type);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ChartItem)) {
                return false;
            }
            ChartItem chartItem = (ChartItem) other;
            return this.rank == chartItem.rank && this.postId == chartItem.postId && Intrinsics.areEqual(this.title, chartItem.title) && Intrinsics.areEqual(this.poster, chartItem.poster) && Intrinsics.areEqual(this.rating, chartItem.rating) && Intrinsics.areEqual(this.votes, chartItem.votes) && Intrinsics.areEqual(this.release, chartItem.release) && Intrinsics.areEqual(this.runtime, chartItem.runtime) && Intrinsics.areEqual(this.certificate, chartItem.certificate) && Intrinsics.areEqual(this.episodes, chartItem.episodes) && Intrinsics.areEqual(this.weekendGross, chartItem.weekendGross) && Intrinsics.areEqual(this.totalGross, chartItem.totalGross) && Intrinsics.areEqual(this.weeks, chartItem.weeks) && Intrinsics.areEqual(this.type, chartItem.type);
        }

        public int hashCode() {
            return (((((((((((((((((((((((((Integer.hashCode(this.rank) * 31) + Long.hashCode(this.postId)) * 31) + this.title.hashCode()) * 31) + this.poster.hashCode()) * 31) + this.rating.hashCode()) * 31) + this.votes.hashCode()) * 31) + this.release.hashCode()) * 31) + this.runtime.hashCode()) * 31) + this.certificate.hashCode()) * 31) + this.episodes.hashCode()) * 31) + this.weekendGross.hashCode()) * 31) + this.totalGross.hashCode()) * 31) + this.weeks.hashCode()) * 31) + this.type.hashCode();
        }

        public String toString() {
            return "ChartItem(rank=" + this.rank + ", postId=" + this.postId + ", title=" + this.title + ", poster=" + this.poster + ", rating=" + this.rating + ", votes=" + this.votes + ", release=" + this.release + ", runtime=" + this.runtime + ", certificate=" + this.certificate + ", episodes=" + this.episodes + ", weekendGross=" + this.weekendGross + ", totalGross=" + this.totalGross + ", weeks=" + this.weeks + ", type=" + this.type + ")";
        }

        public ChartItem(int i, long j, String title, String poster, String rating, String votes, String release, String runtime, String certificate, String episodes, String weekendGross, String totalGross, String weeks, String type) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(poster, "poster");
            Intrinsics.checkNotNullParameter(rating, "rating");
            Intrinsics.checkNotNullParameter(votes, "votes");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(runtime, "runtime");
            Intrinsics.checkNotNullParameter(certificate, "certificate");
            Intrinsics.checkNotNullParameter(episodes, "episodes");
            Intrinsics.checkNotNullParameter(weekendGross, "weekendGross");
            Intrinsics.checkNotNullParameter(totalGross, "totalGross");
            Intrinsics.checkNotNullParameter(weeks, "weeks");
            Intrinsics.checkNotNullParameter(type, "type");
            this.rank = i;
            this.postId = j;
            this.title = title;
            this.poster = poster;
            this.rating = rating;
            this.votes = votes;
            this.release = release;
            this.runtime = runtime;
            this.certificate = certificate;
            this.episodes = episodes;
            this.weekendGross = weekendGross;
            this.totalGross = totalGross;
            this.weeks = weeks;
            this.type = type;
        }

        public final int getRank() {
            return this.rank;
        }

        public final long getPostId() {
            return this.postId;
        }

        public final String getTitle() {
            return this.title;
        }

        public final String getPoster() {
            return this.poster;
        }

        public final String getRating() {
            return this.rating;
        }

        public final String getVotes() {
            return this.votes;
        }

        public final String getRelease() {
            return this.release;
        }

        public final String getRuntime() {
            return this.runtime;
        }

        public final String getCertificate() {
            return this.certificate;
        }

        public final String getEpisodes() {
            return this.episodes;
        }

        public final String getWeekendGross() {
            return this.weekendGross;
        }

        public final String getTotalGross() {
            return this.totalGross;
        }

        public final String getWeeks() {
            return this.weeks;
        }

        public final String getType() {
            return this.type;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TopChartScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0016\b\u0082\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u0003¢\u0006\u0002\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\t\u0010\u0019\u001a\u00020\nHÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003JC\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u00032\b\u0010\u001d\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001e\u001a\u00020\nHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006 "}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView$ParseResult;", "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartItem;", "page", "", "hasMore", "(ZLjava/lang/String;Ljava/util/List;IZ)V", "getHasMore", "()Z", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "getPage", "()I", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ParseResult {
        private final boolean hasMore;
        private final List<ChartItem> items;
        private final String message;
        private final boolean ok;
        private final int page;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, boolean z, String str, List list, int i, boolean z2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                z = parseResult.ok;
            }
            if ((i2 & 2) != 0) {
                str = parseResult.message;
            }
            String str2 = str;
            if ((i2 & 4) != 0) {
                list = parseResult.items;
            }
            List list2 = list;
            if ((i2 & 8) != 0) {
                i = parseResult.page;
            }
            int i3 = i;
            if ((i2 & 16) != 0) {
                z2 = parseResult.hasMore;
            }
            return parseResult.copy(z, str2, list2, i3, z2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<ChartItem> component3() {
            return this.items;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getPage() {
            return this.page;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final boolean getHasMore() {
            return this.hasMore;
        }

        public final ParseResult copy(boolean ok, String message, List<ChartItem> items, int page, boolean hasMore) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new ParseResult(ok, message, items, page, hasMore);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return this.ok == parseResult.ok && Intrinsics.areEqual(this.message, parseResult.message) && Intrinsics.areEqual(this.items, parseResult.items) && this.page == parseResult.page && this.hasMore == parseResult.hasMore;
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            return ((((((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode()) * 31) + Integer.hashCode(this.page)) * 31) + Boolean.hashCode(this.hasMore);
        }

        public String toString() {
            return "ParseResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ", page=" + this.page + ", hasMore=" + this.hasMore + ")";
        }

        public ParseResult(boolean z, String str, List<ChartItem> items, int i, boolean z2) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
            this.page = i;
            this.hasMore = z2;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public final List<ChartItem> getItems() {
            return this.items;
        }

        public final int getPage() {
            return this.page;
        }

        public final boolean getHasMore() {
            return this.hasMore;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetAndLoad() {
        int size = this.items.size();
        this.items.clear();
        if (size > 0) {
            this.adapter.notifyItemRangeRemoved(0, size);
        }
        this.currentPage = 1;
        this.hasMore = true;
        loadPage(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNext() {
        if (this.loading || !this.hasMore) {
            return;
        }
        loadPage(this.currentPage + 1, false);
    }

    private final void loadPage(final int page, final boolean reset) {
        if (this.loading) {
            return;
        }
        this.loading = true;
        if (reset) {
            this.loadingView.setVisibility(0);
            this.loadingMoreOverlay.setVisibility(8);
        } else {
            this.loadingMoreOverlay.setVisibility(0);
        }
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                TopChartScreenView.loadPage$lambda$16(this.f$0, page, reset);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$16(final TopChartScreenView this$0, final int i, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            linkedHashMap.put("page", String.valueOf(i));
            linkedHashMap.put("per_page", "24");
            linkedHashMap.put("perPage", "24");
            final ParseResult parseResult = Parser.INSTANCE.parse(this$0.requestChart(linkedHashMap), i, 24);
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    TopChartScreenView.loadPage$lambda$16$lambda$14(this.f$0, parseResult, z, i);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    TopChartScreenView.loadPage$lambda$16$lambda$15(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$16$lambda$14(final TopChartScreenView this$0, ParseResult parsed, boolean z, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        if (!parsed.getOk()) {
            this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت اطلاعات"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$loadPage$1$1$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoad();
                }
            });
            return;
        }
        if (z) {
            int size = this$0.items.size();
            this$0.items.clear();
            if (size > 0) {
                this$0.adapter.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.items.size();
        this$0.items.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            this$0.adapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentPage = RangesKt.coerceAtLeast(parsed.getPage(), i);
        this$0.hasMore = parsed.getHasMore();
        if (this$0.items.isEmpty()) {
            this$0.showState("موردی برای نمایش یافت نشد.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$loadPage$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoad();
                }
            });
        } else {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$16$lambda$15(final TopChartScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت اطلاعات"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$loadPage$1$2$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                this.this$0.resetAndLoad();
            }
        });
    }

    private final String requestChart(Map<String, String> query) {
        Iterator<String> it = this.endpointPaths.iterator();
        FkApiClient.ApiException th = null;
        while (it.hasNext()) {
            try {
                return FkApiClient.INSTANCE.signedGet(this.apiBase, it.next(), query);
            } finally {
                th = th;
            }
        }
        if (th == null) {
            throw new RuntimeException("Endpoint not available");
        }
        throw th;
    }

    private final void showState(String message, String buttonText, final Function0<Unit> onClick) {
        this.stateText.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت اطلاعات"));
        this.stateButton.setText(buttonText);
        this.stateButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TopChartScreenView.showState$lambda$17(onClick, view);
            }
        });
        this.stateOverlay.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showState$lambda$17(Function0 function0, View view) {
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final void hideState() {
        this.stateOverlay.setVisibility(8);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TopChartScreenView.kt */
    @Metadata(m779d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0015B\u001b\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\n\u001a\u00020\u000bH\u0016J \u0010\f\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016J\u0018\u0010\u0014\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartAdapter$VH;", "Lcom/filmkio/nativescreen/account/TopChartScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartItem;", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/TopChartScreenView;Ljava/util/List;Z)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class ChartAdapter extends RecyclerView.Adapter<C2689VH> {
        private final List<ChartItem> data;
        private final boolean isTouchDevice;
        final /* synthetic */ TopChartScreenView this$0;

        public ChartAdapter(TopChartScreenView topChartScreenView, List<ChartItem> data, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = topChartScreenView;
            this.data = data;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2689VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            TopChartScreenView topChartScreenView = this.this$0;
            linearLayout.setOrientation(0);
            linearLayout.setLayoutDirection(1);
            linearLayout.setGravity(16);
            linearLayout.setPadding(topChartScreenView.m386dp(10), topChartScreenView.m386dp(10), topChartScreenView.m386dp(10), topChartScreenView.m386dp(10));
            linearLayout.setBackground(topChartScreenView.roundedBg(topChartScreenView.cardFill, topChartScreenView.cardStroke, topChartScreenView.m386dp(1), topChartScreenView.dpF(12)));
            linearLayout.setClickable(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2689VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2689VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2689VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m386dp(10);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.TopChartScreenView$ChartAdapter$VH */
        /* JADX INFO: compiled from: TopChartScreenView.kt */
        @Metadata(m779d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\r\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0006J\u0018\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0014H\u0002J\u0010\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0002J\u0010\u0010\u0018\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0002J\u0010\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0002J\u0010\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0002J\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u0014H\u0002R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartAdapter;Landroid/widget/LinearLayout;)V", "currentItem", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ChartItem;", "metaLine1", "Landroid/widget/TextView;", "metaLine2", "poster", "Landroid/widget/ImageView;", "rankBadge", "title", "bind", "", "item", "buildRatingVoteLine", "", "ratingRaw", "", "votesRaw", "formatEpisodes", "raw", "formatMetaValue", "formatRating", "formatVotes", "isMostlyLtr", "", "text", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2689VH extends RecyclerView.ViewHolder {
            private ChartItem currentItem;
            private final TextView metaLine1;
            private final TextView metaLine2;
            private final ImageView poster;
            private final TextView rankBadge;
            private final LinearLayout root;
            final /* synthetic */ ChartAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2689VH(ChartAdapter chartAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = chartAdapter;
                this.root = root;
                ImageView imageView = new ImageView(chartAdapter.this$0.ctx);
                TopChartScreenView topChartScreenView = chartAdapter.this$0;
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setClipToOutline(true);
                imageView.setBackground(topChartScreenView.roundedBg(-15920358, 587202559, topChartScreenView.m386dp(1), topChartScreenView.dpF(8)));
                this.poster = imageView;
                LinearLayout linearLayout = new LinearLayout(chartAdapter.this$0.ctx);
                linearLayout.setOrientation(1);
                linearLayout.setLayoutDirection(1);
                TextView textView = new TextView(chartAdapter.this$0.ctx);
                TopChartScreenView topChartScreenView2 = chartAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(15.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(topChartScreenView2.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setMaxLines(2);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                textView.setIncludeFontPadding(false);
                textView.setGravity(5);
                textView.setTextAlignment(1);
                textView.setTextDirection(2);
                this.title = textView;
                TextView textView2 = new TextView(chartAdapter.this$0.ctx);
                TopChartScreenView topChartScreenView3 = chartAdapter.this$0;
                textView2.setTextColor(-3088659);
                textView2.setTextSize(12.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(topChartScreenView3.ctx);
                textView2.setTypeface(typefaceMedium == null ? textView2.getTypeface() : typefaceMedium);
                textView2.setIncludeFontPadding(false);
                textView2.setGravity(5);
                textView2.setTextAlignment(1);
                textView2.setTextDirection(2);
                this.metaLine1 = textView2;
                TextView textView3 = new TextView(chartAdapter.this$0.ctx);
                TopChartScreenView topChartScreenView4 = chartAdapter.this$0;
                textView3.setTextColor(-5521194);
                textView3.setTextSize(11.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(topChartScreenView4.ctx);
                textView3.setTypeface(typefaceRegular == null ? textView3.getTypeface() : typefaceRegular);
                textView3.setIncludeFontPadding(false);
                textView3.setMaxLines(2);
                textView3.setEllipsize(TextUtils.TruncateAt.END);
                textView3.setGravity(5);
                textView3.setTextAlignment(1);
                textView3.setTextDirection(2);
                this.metaLine2 = textView3;
                linearLayout.addView(textView);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = chartAdapter.this$0.m386dp(5);
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(textView2, layoutParams);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = chartAdapter.this$0.m386dp(4);
                Unit unit2 = Unit.INSTANCE;
                linearLayout.addView(textView3, layoutParams2);
                TextView textView4 = new TextView(chartAdapter.this$0.ctx);
                TopChartScreenView topChartScreenView5 = chartAdapter.this$0;
                textView4.setTextColor(topChartScreenView5.accent);
                textView4.setTextSize(13.0f);
                Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(topChartScreenView5.ctx);
                textView4.setTypeface(typefaceBold2 == null ? textView4.getTypeface() : typefaceBold2);
                textView4.setGravity(17);
                textView4.setIncludeFontPadding(false);
                textView4.setMinWidth(topChartScreenView5.m386dp(40));
                textView4.setPadding(topChartScreenView5.m386dp(10), topChartScreenView5.m386dp(6), topChartScreenView5.m386dp(10), topChartScreenView5.m386dp(6));
                textView4.setBackground(topChartScreenView5.roundedBg(387650568, 1442165522, topChartScreenView5.m386dp(1), topChartScreenView5.dpF(999)));
                this.rankBadge = textView4;
                root.addView(imageView, new LinearLayout.LayoutParams(chartAdapter.this$0.m386dp(70), chartAdapter.this$0.m386dp(104)));
                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                TopChartScreenView topChartScreenView6 = chartAdapter.this$0;
                layoutParams3.setMarginStart(topChartScreenView6.m386dp(10));
                layoutParams3.setMarginEnd(topChartScreenView6.m386dp(10));
                Unit unit3 = Unit.INSTANCE;
                root.addView(linearLayout, layoutParams3);
                root.addView(textView4);
                final TopChartScreenView topChartScreenView7 = chartAdapter.this$0;
                root.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TopChartScreenView$ChartAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        TopChartScreenView.ChartAdapter.C2689VH._init_$lambda$9(this.f$0, topChartScreenView7, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void _init_$lambda$9(C2689VH this$0, TopChartScreenView this$1, View view) {
                Function1 function1;
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(this$1, "this$1");
                ChartItem chartItem = this$0.currentItem;
                if (chartItem == null || chartItem.getPostId() <= 0 || (function1 = this$1.onOpenSingle) == null) {
                    return;
                }
                function1.invoke(Long.valueOf(chartItem.getPostId()));
            }

            public final void bind(ChartItem item) {
                String strJoinToString$default;
                Intrinsics.checkNotNullParameter(item, "item");
                this.currentItem = item;
                this.rankBadge.setText("#" + item.getRank());
                this.title.setText(item.getTitle());
                this.metaLine1.setText(buildRatingVoteLine(item.getRating(), item.getVotes()));
                String lowerCase = item.getType().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                if (Intrinsics.areEqual(lowerCase, "boxoffice")) {
                    List listListOf = CollectionsKt.listOf((Object[]) new String[]{StringsKt.isBlank(item.getWeekendGross()) ^ true ? "آخرهفته: " + formatMetaValue(item.getWeekendGross()) : "", StringsKt.isBlank(item.getTotalGross()) ^ true ? "فروش کل: " + formatMetaValue(item.getTotalGross()) : "", StringsKt.isBlank(item.getWeeks()) ^ true ? "هفته اکران: " + formatMetaValue(item.getWeeks()) : ""});
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : listListOf) {
                        if (!StringsKt.isBlank((String) obj)) {
                            arrayList.add(obj);
                        }
                    }
                    strJoinToString$default = CollectionsKt.joinToString$default(arrayList, " • ", null, null, 0, null, null, 62, null);
                } else {
                    if (Intrinsics.areEqual(lowerCase, "series")) {
                        String release = item.getRelease();
                        List listListOf2 = CollectionsKt.listOf((Object[]) new String[]{formatMetaValue(StringsKt.isBlank(release) ? "-" : release), formatEpisodes(item.getEpisodes()), StringsKt.isBlank(item.getRuntime()) ^ true ? formatMetaValue(item.getRuntime()) : ""});
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj2 : listListOf2) {
                            if (!StringsKt.isBlank((String) obj2)) {
                                arrayList2.add(obj2);
                            }
                        }
                        strJoinToString$default = CollectionsKt.joinToString$default(arrayList2, " • ", null, null, 0, null, null, 62, null);
                    } else {
                        String release2 = item.getRelease();
                        List listListOf3 = CollectionsKt.listOf((Object[]) new String[]{formatMetaValue(StringsKt.isBlank(release2) ? "-" : release2), formatMetaValue(item.getRuntime()), formatMetaValue(item.getCertificate())});
                        ArrayList arrayList3 = new ArrayList();
                        for (Object obj3 : listListOf3) {
                            if (!StringsKt.isBlank((String) obj3)) {
                                arrayList3.add(obj3);
                            }
                        }
                        strJoinToString$default = CollectionsKt.joinToString$default(arrayList3, " • ", null, null, 0, null, null, 62, null);
                    }
                }
                this.metaLine2.setText(strJoinToString$default);
                if (!StringsKt.isBlank(item.getPoster())) {
                    ImageView imageView = this.poster;
                    String poster = item.getPoster();
                    ImageLoader imageLoader = Coil.imageLoader(imageView.getContext());
                    ImageRequest.Builder builderTarget = new ImageRequest.Builder(imageView.getContext()).data(poster).target(imageView);
                    builderTarget.crossfade(true);
                    imageLoader.enqueue(builderTarget.build());
                } else {
                    this.poster.setImageDrawable(null);
                }
                this.root.setAlpha(item.getPostId() > 0 ? 1.0f : 0.88f);
            }

            private final String formatRating(String raw) {
                String string = StringsKt.trim((CharSequence) raw).toString();
                String str = string;
                return StringsKt.isBlank(str) ? "" : StringsKt.contains$default((CharSequence) str, '/', false, 2, (Object) null) ? string : string + "/10";
            }

            private final String formatVotes(String raw) {
                String string = StringsKt.trim((CharSequence) raw).toString();
                if (StringsKt.isBlank(string)) {
                    return "";
                }
                String strUnicodeWrap = this.this$0.this$0.rtlBidi.unicodeWrap("(" + string + ")", TextDirectionHeuristics.LTR);
                Intrinsics.checkNotNullExpressionValue(strUnicodeWrap, "unicodeWrap(...)");
                return strUnicodeWrap;
            }

            private final String formatEpisodes(String raw) {
                String string = StringsKt.trim((CharSequence) raw).toString();
                String str = string;
                if (StringsKt.isBlank(str)) {
                    return "";
                }
                String lowerCase = string.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String str2 = lowerCase;
                boolean z = StringsKt.contains$default((CharSequence) str2, (CharSequence) "eps", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str2, (CharSequence) "episode", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "قسمت", false, 2, (Object) null);
                MatchResult matchResult = (MatchResult) SequencesKt.lastOrNull(Regex.findAll$default(new Regex("\\d+[\\d,.]*"), str, 0, 2, null));
                String value = matchResult != null ? matchResult.getValue() : null;
                if (z && value != null) {
                    string = "eps " + value;
                } else if (!z || !StringsKt.startsWith$default(lowerCase, "eps", false, 2, (Object) null)) {
                    string = z ? "eps" : "eps " + string;
                }
                String strUnicodeWrap = this.this$0.this$0.rtlBidi.unicodeWrap(string, TextDirectionHeuristics.LTR);
                Intrinsics.checkNotNullExpressionValue(strUnicodeWrap, "unicodeWrap(...)");
                return strUnicodeWrap;
            }

            private final CharSequence buildRatingVoteLine(String ratingRaw, String votesRaw) {
                String rating = formatRating(ratingRaw);
                String votes = formatVotes(votesRaw);
                String str = rating;
                if (StringsKt.isBlank(str) && StringsKt.isBlank(votes)) {
                    return "";
                }
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                if (!StringsKt.isBlank(str)) {
                    spannableStringBuilder.append((char) 8206);
                    int length = spannableStringBuilder.length();
                    spannableStringBuilder.append((CharSequence) str);
                    int length2 = spannableStringBuilder.length();
                    spannableStringBuilder.append((char) 8206);
                    int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str, '/', 0, false, 6, (Object) null);
                    if (iIndexOf$default >= 0) {
                        spannableStringBuilder.setSpan(new RelativeSizeSpan(0.74f), length + iIndexOf$default, length2, 33);
                    }
                }
                String str2 = votes;
                if (!StringsKt.isBlank(str2)) {
                    if (spannableStringBuilder.length() > 0) {
                        spannableStringBuilder.append((CharSequence) "  ");
                    }
                    spannableStringBuilder.append((CharSequence) str2);
                }
                return spannableStringBuilder;
            }

            private final String formatMetaValue(String raw) {
                String string = StringsKt.trim((CharSequence) raw).toString();
                if (StringsKt.isBlank(string)) {
                    return "";
                }
                if (!isMostlyLtr(string)) {
                    return string;
                }
                String strUnicodeWrap = this.this$0.this$0.rtlBidi.unicodeWrap(string, TextDirectionHeuristics.LTR);
                Intrinsics.checkNotNull(strUnicodeWrap);
                return strUnicodeWrap;
            }

            /* JADX WARN: Removed duplicated region for block: B:25:0x0036  */
            /* JADX WARN: Removed duplicated region for block: B:42:0x0057  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            private final boolean isMostlyLtr(String text) {
                int length = text.length();
                boolean z = false;
                boolean z2 = false;
                for (int i = 0; i < length; i++) {
                    char cCharAt = text.charAt(i);
                    if (1536 <= cCharAt && cCharAt < 1792) {
                        z2 = true;
                    } else if (!(1872 <= cCharAt && cCharAt < 1920)) {
                        if (2208 <= cCharAt && cCharAt < 2304) {
                        }
                    }
                    if (Character.isDigit(cCharAt)) {
                        z = true;
                    } else if (!('a' <= cCharAt && cCharAt < '{')) {
                        if ('A' <= cCharAt && cCharAt < '[') {
                        }
                    }
                    if (z2 && z) {
                        return false;
                    }
                }
                return z;
            }
        }
    }

    /* JADX INFO: compiled from: TopChartScreenView.kt */
    @Metadata(m779d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0002J \u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\fJ-\u0010\u000e\u001a\u0004\u0018\u00010\n2\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0012\u0010\u000f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\n0\u0010\"\u00020\nH\u0002¢\u0006\u0002\u0010\u0011J\u0012\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u0002J\u0019\u0010\u0015\u001a\u0004\u0018\u00010\f2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0016J\u0019\u0010\u0017\u001a\u0004\u0018\u00010\u00182\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0019¨\u0006\u001a"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TopChartScreenView$Parser;", "", "()V", "numericObjectToArray", "Lorg/json/JSONArray;", "obj", "Lorg/json/JSONObject;", "parse", "Lcom/filmkio/nativescreen/account/TopChartScreenView$ParseResult;", "json", "", "requestedPage", "", "perPage", "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "toBool", "", "v", "toInt", "(Ljava/lang/Object;)Ljava/lang/Integer;", "toLong", "", "(Ljava/lang/Object;)Ljava/lang/Long;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class Parser {
        public static final Parser INSTANCE = new Parser();

        private Parser() {
        }

        /* JADX WARN: Removed duplicated region for block: B:165:0x029f  */
        /* JADX WARN: Removed duplicated region for block: B:166:0x02a2  */
        /* JADX WARN: Removed duplicated region for block: B:30:0x0063  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final ParseResult parse(String json, int requestedPage, int perPage) {
            boolean z;
            JSONArray jSONArrayNumericObjectToArray;
            JSONObject jSONObjectOptJSONObject;
            boolean z2;
            boolean bool;
            String str = json;
            int i = 1;
            if (str == null || StringsKt.isBlank(str)) {
                return new ParseResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
            try {
                Object objNextValue = new JSONTokener(json).nextValue();
                JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
                JSONObject jSONObjectOptJSONObject2 = jSONObject != null ? jSONObject.optJSONObject("data") : null;
                if (jSONObject != null ? jSONObject.optBoolean("flag", true) : true) {
                    z = true;
                } else {
                    if (!(jSONObject != null ? jSONObject.optBoolean(NotificationCompat.CATEGORY_STATUS, true) : true)) {
                        z = false;
                    }
                }
                String strPickString = pickString(jSONObject, "message", NotificationCompat.CATEGORY_MESSAGE);
                if (strPickString == null) {
                    strPickString = pickString(jSONObjectOptJSONObject2, "message", NotificationCompat.CATEGORY_MESSAGE);
                }
                String str2 = strPickString;
                if ((jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS) : null) != null) {
                    jSONArrayNumericObjectToArray = jSONObjectOptJSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                } else {
                    if ((jSONObject != null ? jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS) : null) != null) {
                        jSONArrayNumericObjectToArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                    } else if (objNextValue instanceof JSONArray) {
                        jSONArrayNumericObjectToArray = (JSONArray) objNextValue;
                    } else {
                        jSONArrayNumericObjectToArray = jSONObject != null ? numericObjectToArray(jSONObject) : null;
                    }
                }
                if (jSONArrayNumericObjectToArray == null) {
                    jSONArrayNumericObjectToArray = new JSONArray();
                }
                ArrayList arrayList = new ArrayList(jSONArrayNumericObjectToArray.length());
                int length = jSONArrayNumericObjectToArray.length();
                int i2 = 0;
                while (i2 < length) {
                    JSONObject jSONObjectOptJSONObject3 = jSONArrayNumericObjectToArray.optJSONObject(i2);
                    if (jSONObjectOptJSONObject3 != null) {
                        Integer num = toInt(jSONObjectOptJSONObject3.opt("rank"));
                        int iIntValue = num != null ? num.intValue() : ((requestedPage - 1) * perPage) + i2 + i;
                        String strPickString2 = pickString(jSONObjectOptJSONObject3, "name", "title", "post_title", "postTitle");
                        if (strPickString2 == null) {
                            strPickString2 = "";
                        }
                        String str3 = strPickString2;
                        if (StringsKt.isBlank(str3)) {
                            str3 = "بدون عنوان";
                        }
                        String str4 = str3;
                        Long l = toLong(jSONObjectOptJSONObject3.opt("post_id"));
                        long jLongValue = (l == null && (l = toLong(jSONObjectOptJSONObject3.opt("postID"))) == null) ? 0L : l.longValue();
                        String strPickString3 = pickString(jSONObjectOptJSONObject3, "item_type", "type");
                        if (strPickString3 == null) {
                            strPickString3 = "";
                        }
                        String str5 = strPickString3;
                        if (StringsKt.isBlank(str5)) {
                            str5 = "movie";
                        }
                        String str6 = str5;
                        String strPickString4 = pickString(jSONObjectOptJSONObject3, "poster", "thumbnail", "image");
                        String str7 = strPickString4 == null ? "" : strPickString4;
                        String strPickString5 = pickString(jSONObjectOptJSONObject3, "rating", "imdb_rate");
                        String str8 = strPickString5 == null ? "" : strPickString5;
                        String strPickString6 = pickString(jSONObjectOptJSONObject3, "votes", "imdb_vote");
                        String str9 = strPickString6 == null ? "" : strPickString6;
                        String strPickString7 = pickString(jSONObjectOptJSONObject3, "release");
                        String str10 = strPickString7 == null ? "" : strPickString7;
                        String strPickString8 = pickString(jSONObjectOptJSONObject3, "runtime");
                        String str11 = strPickString8 == null ? "" : strPickString8;
                        String strPickString9 = pickString(jSONObjectOptJSONObject3, "certificate");
                        String str12 = strPickString9 == null ? "" : strPickString9;
                        String strPickString10 = pickString(jSONObjectOptJSONObject3, "episodes");
                        String str13 = strPickString10 == null ? "" : strPickString10;
                        String strPickString11 = pickString(jSONObjectOptJSONObject3, "weekend_gross", "Weekend Gross");
                        String str14 = strPickString11 == null ? "" : strPickString11;
                        String strPickString12 = pickString(jSONObjectOptJSONObject3, "total_gross", "Total Gross");
                        String str15 = strPickString12 == null ? "" : strPickString12;
                        String strPickString13 = pickString(jSONObjectOptJSONObject3, "weeks");
                        arrayList.add(new ChartItem(iIntValue, jLongValue, str4, str7, str8, str9, str10, str11, str12, str13, str14, str15, strPickString13 == null ? "" : strPickString13, str6));
                    }
                    i2++;
                    i = 1;
                }
                if (jSONObjectOptJSONObject2 == null || (jSONObjectOptJSONObject = jSONObjectOptJSONObject2.optJSONObject("pagination")) == null) {
                    jSONObjectOptJSONObject = jSONObject != null ? jSONObject.optJSONObject("pagination") : null;
                }
                Integer num2 = toInt(jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.opt("page") : null);
                int iIntValue2 = num2 != null ? num2.intValue() : requestedPage;
                if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("has_more")) {
                    bool = toBool(jSONObjectOptJSONObject.opt("has_more"));
                } else {
                    if (jSONObjectOptJSONObject == null || !jSONObjectOptJSONObject.has("hasMore")) {
                        if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("total_pages")) {
                            Integer num3 = toInt(jSONObjectOptJSONObject.opt("total_pages"));
                            if (iIntValue2 < (num3 != null ? num3.intValue() : 1)) {
                            }
                        } else if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.has("totalPages")) {
                            Integer num4 = toInt(jSONObjectOptJSONObject.opt("totalPages"));
                            if (iIntValue2 < (num4 != null ? num4.intValue() : 1)) {
                            }
                        } else {
                            z2 = arrayList.size() >= perPage;
                        }
                        if (z && arrayList.isEmpty()) {
                            if (str2 == null) {
                                str2 = "خطا در دریافت اطلاعات";
                            }
                            return new ParseResult(false, str2, CollectionsKt.emptyList(), iIntValue2, false);
                        }
                        return new ParseResult(true, str2, arrayList, iIntValue2, z2);
                    }
                    bool = toBool(jSONObjectOptJSONObject.opt("hasMore"));
                }
                z2 = bool;
                if (z) {
                }
                return new ParseResult(true, str2, arrayList, iIntValue2, z2);
            } catch (Throwable unused) {
                return new ParseResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
        }

        private final String pickString(JSONObject obj, String... keys) {
            if (obj == null) {
                return null;
            }
            for (String str : keys) {
                Object objOpt = obj.opt(str);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                    if (!StringsKt.isBlank(string)) {
                        return string;
                    }
                }
            }
            return null;
        }

        private final JSONArray numericObjectToArray(JSONObject obj) {
            boolean z;
            Iterator<String> itKeys = obj.keys();
            JSONArray jSONArray = new JSONArray();
            boolean z2 = false;
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                Intrinsics.checkNotNull(next);
                String str = next;
                int i = 0;
                while (true) {
                    if (i >= str.length()) {
                        z = true;
                        break;
                    }
                    if (!Character.isDigit(str.charAt(i))) {
                        z = false;
                        break;
                    }
                    i++;
                }
                if (z) {
                    Object objOpt = obj.opt(next);
                    if (objOpt instanceof JSONObject) {
                        jSONArray.put(objOpt);
                        z2 = true;
                    }
                }
            }
            if (z2) {
                return jSONArray;
            }
            return null;
        }

        private final Integer toInt(Object v) {
            if (v instanceof Number) {
                return Integer.valueOf(((Number) v).intValue());
            }
            if (v instanceof String) {
                return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
            }
            return null;
        }

        private final Long toLong(Object v) {
            if (v instanceof Number) {
                return Long.valueOf(((Number) v).longValue());
            }
            if (v instanceof String) {
                return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) v).toString());
            }
            return null;
        }

        private final boolean toBool(Object v) {
            if (v instanceof Boolean) {
                return ((Boolean) v).booleanValue();
            }
            if (v instanceof Number) {
                if (((Number) v).intValue() == 0) {
                    return false;
                }
            } else {
                if (!(v instanceof String)) {
                    return false;
                }
                if (!Intrinsics.areEqual(v, "1")) {
                    String str = (String) v;
                    if (!StringsKt.equals(str, "true", true) && !StringsKt.equals(str, "yes", true) && !StringsKt.equals(str, "ok", true)) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m386dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }
}
