package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.app.NotificationCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import coil.ImageLoader;
import coil.request.ImageRequest;
import com.filmkio.AppState;
import com.filmkio.C2629R;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.NativeImageLoader;
import com.filmkio.nativescreen.account.RequestsScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Triple;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: RequestsScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000ö\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\u0011\b\u0007\u0018\u0000  \u00012\u00020\u0001:\u000e \u0001¡\u0001¢\u0001£\u0001¤\u0001¥\u0001¦\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\tJ\u0010\u0010P\u001a\u00020\b2\u0006\u0010Q\u001a\u00020>H\u0002J\u0014\u0010R\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050SH\u0002J\b\u0010T\u001a\u00020\bH\u0002J\b\u0010U\u001a\u00020\bH\u0002J\b\u0010V\u001a\u00020\bH\u0002J\u0010\u0010W\u001a\u00020\b2\u0006\u0010X\u001a\u00020\u0005H\u0002J\u0010\u0010Y\u001a\u00020\u000b2\u0006\u0010Z\u001a\u00020\u000bH\u0002J\u0010\u0010[\u001a\u00020\u00102\u0006\u0010Z\u001a\u00020\u000bH\u0002J\b\u0010\\\u001a\u00020\u001cH\u0002J\u0010\u0010]\u001a\u00020\u00182\u0006\u0010^\u001a\u00020:H\u0002J\u0006\u0010_\u001a\u00020\u0018J\u0012\u0010`\u001a\u00020\b2\b\b\u0002\u0010a\u001a\u00020\u0018H\u0002J\b\u0010b\u001a\u00020\bH\u0002J\b\u0010c\u001a\u00020\u0018H\u0002J\u0010\u0010d\u001a\u00020\u00182\u0006\u0010e\u001a\u00020\u0005H\u0002J\u0018\u0010f\u001a\u00020\b2\u0006\u0010g\u001a\u00020\u000b2\u0006\u0010h\u001a\u00020\u0018H\u0002J\u0010\u0010i\u001a\u00020<2\u0006\u0010j\u001a\u00020\u0005H\u0002J\b\u0010k\u001a\u00020\u0001H\u0002J\b\u0010l\u001a\u00020\bH\u0002J\u0012\u0010m\u001a\u00020\u00052\b\u0010n\u001a\u0004\u0018\u00010\u0005H\u0002J\u0012\u0010o\u001a\u0004\u0018\u00010p2\u0006\u0010q\u001a\u00020rH\u0002J\b\u0010s\u001a\u00020\bH\u0014J\b\u0010t\u001a\u00020\bH\u0014J\u0018\u0010u\u001a\b\u0012\u0004\u0012\u00020/0v2\b\u0010n\u001a\u0004\u0018\u00010\u0005H\u0002J\u0018\u0010w\u001a\b\u0012\u0004\u0012\u00020@0v2\b\u0010n\u001a\u0004\u0018\u00010\u0005H\u0002J \u0010x\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0006\u0012\u0004\u0018\u00010\u00050y2\b\u0010n\u001a\u0004\u0018\u00010\u0005H\u0002J\u0010\u0010z\u001a\u00020\b2\u0006\u0010e\u001a\u00020\u0005H\u0002J-\u0010{\u001a\u0004\u0018\u00010\u00052\b\u0010q\u001a\u0004\u0018\u00010r2\u0012\u0010|\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00050}\"\u00020\u0005H\u0002¢\u0006\u0002\u0010~J\b\u0010\u007f\u001a\u00020\bH\u0002J\t\u0010\u0080\u0001\u001a\u00020\u000bH\u0002J.\u0010\u0081\u0001\u001a\u00030\u0082\u00012\u0007\u0010\u0083\u0001\u001a\u00020\u000b2\u0007\u0010\u0084\u0001\u001a\u00020\u000b2\u0007\u0010\u0085\u0001\u001a\u00020\u000b2\u0007\u0010\u0086\u0001\u001a\u00020\u0010H\u0002J\u0018\u0010\u0087\u0001\u001a\u00020\u00182\r\u0010\u0088\u0001\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\t\u0010\u0089\u0001\u001a\u00020\bH\u0002J\u0012\u0010\u008a\u0001\u001a\u00020\b2\u0007\u0010\u008b\u0001\u001a\u00020\u0018H\u0002J\u0012\u0010\u008c\u0001\u001a\u00020\b2\u0007\u0010\u008b\u0001\u001a\u00020\u0018H\u0002J\t\u0010\u008d\u0001\u001a\u00020\bH\u0002J-\u0010\u008e\u0001\u001a\u00020\b2\u0006\u0010X\u001a\u00020\u00052\t\u0010\u008f\u0001\u001a\u0004\u0018\u00010\u00052\u000f\u0010\u0090\u0001\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\u0012\u0010\u0091\u0001\u001a\u00020\b2\u0007\u0010\u0092\u0001\u001a\u00020\u0005H\u0002J\u0012\u0010\u0093\u0001\u001a\u00020\u00052\u0007\u0010\u0094\u0001\u001a\u00020\u000bH\u0002J%\u0010\u0095\u0001\u001a\u0015\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b0\u0096\u00012\u0007\u0010\u0094\u0001\u001a\u00020\u000bH\u0002J\t\u0010\u0097\u0001\u001a\u00020\bH\u0002J\u0012\u0010\u0098\u0001\u001a\u00020\b2\u0007\u0010\u0099\u0001\u001a\u00020+H\u0002J\u0013\u0010\u009a\u0001\u001a\u00020\u00182\b\u0010Z\u001a\u0004\u0018\u00010\u001eH\u0002J\u001b\u0010\u009b\u0001\u001a\u0004\u0018\u00010\u000b2\b\u0010Z\u001a\u0004\u0018\u00010\u001eH\u0002¢\u0006\u0003\u0010\u009c\u0001J\u001b\u0010\u009d\u0001\u001a\u0004\u0018\u00010J2\b\u0010Z\u001a\u0004\u0018\u00010\u001eH\u0002¢\u0006\u0003\u0010\u009e\u0001J\t\u0010\u009f\u0001\u001a\u00020\bH\u0002R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020+X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010-\u001a\u0012\u0012\u0004\u0012\u00020/0.j\b\u0012\u0004\u0012\u00020/`0X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u00101\u001a\u000602R\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u000204X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u000207X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u0010\u00109\u001a\u0004\u0018\u00010:X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020>X\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010?\u001a\u0012\u0012\u0004\u0012\u00020@0.j\b\u0012\u0004\u0012\u00020@`0X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010A\u001a\u00060BR\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u000204X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u000207X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010F\u001a\u0004\u0018\u00010@X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010H\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020JX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010K\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010O\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000¨\u0006§\u0001"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "accent", "", "cardFill", "cardStroke", "createContainer", "createDragStartRawY", "", "createDragStartTranslation", "createFormContent", "Landroid/widget/LinearLayout;", "createSheetCard", "createSheetScrim", "Landroid/view/View;", "createSheetShown", "", "currentPage", "detached", "executor", "Ljava/util/concurrent/ExecutorService;", "executorLock", "", "fieldFill", "fieldStroke", "hasMore", "imageLoader", "Lcoil/ImageLoader;", "isTouchDevice", "lastSearchedQuery", "listContainer", "loadingRequests", "mainHandler", "Landroid/os/Handler;", "mode", "Lcom/filmkio/nativescreen/account/RequestsScreenView$Mode;", "pendingSearchQuery", "requestItems", "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestItem;", "Lkotlin/collections/ArrayList;", "requestsAdapter", "Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestListAdapter;", "requestsLoading", "Landroid/widget/ProgressBar;", "requestsLoadingMoreOverlay", "requestsRecycler", "Landroidx/recyclerview/widget/RecyclerView;", "screenFill", "searchDebounceRunnable", "Ljava/lang/Runnable;", "searchEmptyText", "Landroid/widget/TextView;", "searchInput", "Landroidx/appcompat/widget/AppCompatEditText;", "searchItems", "Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchItem;", "searchResultsAdapter", "Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchResultAdapter;", "searchResultsLoading", "searchResultsRecycler", "searching", "selectedSearchItem", "sendingRequest", "sessionToken", "sessionUserId", "", "stateAction", "stateButton", "stateOverlay", "stateText", "submitButton", "applyFieldStyle", "field", "authHeaders", "", "buildCreateContainer", "buildListContainer", "clearCreateForm", "clearSearchResults", "message", "dp", "v", "dpF", "ensureExecutorLocked", "executeOnWorker", "runBlock", "handleBackPressed", "hideCreateSheet", "animated", "hideState", "isLoggedIn", "isSearchThresholdReached", SearchIntents.EXTRA_QUERY, "loadRequests", "page", "reset", "makeFieldLabel", "title", "makeLoadingMoreOverlay", "maybeLoadNextRequests", "normalizeSearchQuery", "raw", "numericObjectToArray", "Lorg/json/JSONArray;", "obj", "Lorg/json/JSONObject;", "onAttachedToWindow", "onDetachedFromWindow", "parseRequestListResponse", "Lcom/filmkio/nativescreen/account/RequestsScreenView$ParseResult;", "parseSearchResponse", "parseSendResponse", "Lkotlin/Pair;", "performSearch", "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "resetRequestsAndLoad", "resolveCreateSheetHeight", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "safeExecute", "block", "scheduleSearchFromInput", "setSearchLoading", "loading", "setSubmitLoading", "showCreateSheet", "showState", "buttonTitle", "action", "showToast", "text", "statusLabel", NotificationCompat.CATEGORY_STATUS, "statusStyle", "Lkotlin/Triple;", "submitRequest", "switchMode", "next", "toBool", "toInt", "(Ljava/lang/Object;)Ljava/lang/Integer;", "toLong", "(Ljava/lang/Object;)Ljava/lang/Long;", "triggerSearchNow", "Companion", "Mode", "ParseResult", "RequestItem", "RequestListAdapter", "SearchItem", "SearchResultAdapter", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class RequestsScreenView extends FrameLayout {
    private static final int REQUESTS_PER_PAGE = 20;
    private final int accent;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private FrameLayout createContainer;
    private float createDragStartRawY;
    private float createDragStartTranslation;
    private LinearLayout createFormContent;
    private LinearLayout createSheetCard;
    private View createSheetScrim;
    private boolean createSheetShown;
    private final Context ctx;
    private int currentPage;
    private boolean detached;
    private volatile ExecutorService executor;
    private final Object executorLock;
    private final int fieldFill;
    private final int fieldStroke;
    private boolean hasMore;
    private final ImageLoader imageLoader;
    private final boolean isTouchDevice;
    private String lastSearchedQuery;
    private LinearLayout listContainer;
    private boolean loadingRequests;
    private final Handler mainHandler;
    private Mode mode;
    private final Function0<Unit> onRequireLogin;
    private String pendingSearchQuery;
    private final ArrayList<RequestItem> requestItems;
    private RequestListAdapter requestsAdapter;
    private ProgressBar requestsLoading;
    private FrameLayout requestsLoadingMoreOverlay;
    private RecyclerView requestsRecycler;
    private final int screenFill;
    private Runnable searchDebounceRunnable;
    private TextView searchEmptyText;
    private AppCompatEditText searchInput;
    private final ArrayList<SearchItem> searchItems;
    private SearchResultAdapter searchResultsAdapter;
    private ProgressBar searchResultsLoading;
    private RecyclerView searchResultsRecycler;
    private boolean searching;
    private SearchItem selectedSearchItem;
    private boolean sendingRequest;
    private String sessionToken;
    private long sessionUserId;
    private Function0<Unit> stateAction;
    private TextView stateButton;
    private LinearLayout stateOverlay;
    private TextView stateText;
    private TextView submitButton;
    public static final int $stable = 8;

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$25$lambda$24(View view) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$32$lambda$31(View view) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String statusLabel(int status) {
        return status != 1 ? status != 2 ? "در انتظار بررسی" : "رد شده" : "انجام\u200cشده";
    }

    public /* synthetic */ RequestsScreenView(Context context, String str, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public RequestsScreenView(Context ctx, String apiBase, Function0<Unit> function0) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executorLock = new Object();
        ExecutorService executorServiceNewSingleThreadExecutor = Executors.newSingleThreadExecutor();
        Intrinsics.checkNotNullExpressionValue(executorServiceNewSingleThreadExecutor, "newSingleThreadExecutor(...)");
        this.executor = executorServiceNewSingleThreadExecutor;
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.imageLoader = NativeImageLoader.INSTANCE.get(ctx);
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.screenFill = -16315632;
        this.fieldFill = -15854306;
        this.fieldStroke = 860772969;
        this.mode = Mode.LIST;
        this.currentPage = 1;
        this.hasMore = true;
        this.lastSearchedQuery = "";
        this.requestItems = new ArrayList<>();
        this.searchItems = new ArrayList<>();
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        FrameLayout frameLayout = null;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setPadding(m384dp(14), m384dp(10), m384dp(14), m384dp(10));
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout2 = new FrameLayout(ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams.topMargin = m384dp(8);
        frameLayout2.setLayoutParams(layoutParams);
        linearLayout.addView(frameLayout2);
        buildListContainer();
        buildCreateContainer();
        LinearLayout linearLayout2 = this.listContainer;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout2 = null;
        }
        frameLayout2.addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout3 = new LinearLayout(ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setGravity(17);
        linearLayout3.setVisibility(8);
        linearLayout3.setPadding(m384dp(24), m384dp(24), m384dp(24), m384dp(24));
        linearLayout3.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout3;
        TextView textView = new TextView(ctx);
        textView.setTextColor(-419430401);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        this.stateText = textView;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-16052459);
        textView2.setTextSize(14.0f);
        textView2.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView2.setTypeface(typefaceBold == null ? textView2.getTypeface() : typefaceBold);
        textView2.setPadding(m384dp(16), m384dp(10), m384dp(16), m384dp(10));
        textView2.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView2.setFocusable(!zHasSystemFeature);
        textView2.setFocusableInTouchMode(!zHasSystemFeature);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RequestsScreenView.lambda$7$lambda$6(this.f$0, view);
            }
        });
        this.stateButton = textView2;
        LinearLayout linearLayout4 = this.stateOverlay;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout4 = null;
        }
        TextView textView3 = this.stateText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView3 = null;
        }
        linearLayout4.addView(textView3);
        LinearLayout linearLayout5 = this.stateOverlay;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout5 = null;
        }
        TextView textView4 = this.stateButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView4 = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = m384dp(12);
        Unit unit = Unit.INSTANCE;
        linearLayout5.addView(textView4, layoutParams2);
        LinearLayout linearLayout6 = this.stateOverlay;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout6 = null;
        }
        frameLayout2.addView(linearLayout6, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
        } else {
            frameLayout = frameLayout3;
        }
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        switchMode(Mode.LIST);
        if (!isLoggedIn()) {
            showState("برای مشاهده و ثبت درخواست، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView.5
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = RequestsScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else {
            resetRequestsAndLoad();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004¨\u0006\u0005"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$Mode;", "", "(Ljava/lang/String;I)V", "LIST", "CREATE", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class Mode {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ Mode[] $VALUES;
        public static final Mode LIST = new Mode("LIST", 0);
        public static final Mode CREATE = new Mode("CREATE", 1);

        private static final /* synthetic */ Mode[] $values() {
            return new Mode[]{LIST, CREATE};
        }

        public static EnumEntries<Mode> getEntries() {
            return $ENTRIES;
        }

        public static Mode valueOf(String str) {
            return (Mode) Enum.valueOf(Mode.class, str);
        }

        public static Mode[] values() {
            return (Mode[]) $VALUES.clone();
        }

        private Mode(String str, int i) {
        }

        static {
            Mode[] modeArr$values = $values();
            $VALUES = modeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(modeArr$values);
        }
    }

    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fJ\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001c\u001a\u00020\nHÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003JO\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\"\u001a\u00020\nHÖ\u0001J\t\u0010#\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016¨\u0006$"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestItem;", "", TtmlNode.ATTR_ID, "", "name", "", "release", "imdbId", "message", NotificationCompat.CATEGORY_STATUS, "", "createdAt", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V", "getCreatedAt", "()Ljava/lang/String;", "getId", "()J", "getImdbId", "getMessage", "getName", "getRelease", "getStatus", "()I", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class RequestItem {
        private final String createdAt;
        private final long id;
        private final String imdbId;
        private final String message;
        private final String name;
        private final String release;
        private final int status;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getName() {
            return this.name;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getRelease() {
            return this.release;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getImdbId() {
            return this.imdbId;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final int getStatus() {
            return this.status;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final String getCreatedAt() {
            return this.createdAt;
        }

        public final RequestItem copy(long id, String name, String release, String imdbId, String message, int status, String createdAt) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(imdbId, "imdbId");
            Intrinsics.checkNotNullParameter(message, "message");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            return new RequestItem(id, name, release, imdbId, message, status, createdAt);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof RequestItem)) {
                return false;
            }
            RequestItem requestItem = (RequestItem) other;
            return this.id == requestItem.id && Intrinsics.areEqual(this.name, requestItem.name) && Intrinsics.areEqual(this.release, requestItem.release) && Intrinsics.areEqual(this.imdbId, requestItem.imdbId) && Intrinsics.areEqual(this.message, requestItem.message) && this.status == requestItem.status && Intrinsics.areEqual(this.createdAt, requestItem.createdAt);
        }

        public int hashCode() {
            return (((((((((((Long.hashCode(this.id) * 31) + this.name.hashCode()) * 31) + this.release.hashCode()) * 31) + this.imdbId.hashCode()) * 31) + this.message.hashCode()) * 31) + Integer.hashCode(this.status)) * 31) + this.createdAt.hashCode();
        }

        public String toString() {
            return "RequestItem(id=" + this.id + ", name=" + this.name + ", release=" + this.release + ", imdbId=" + this.imdbId + ", message=" + this.message + ", status=" + this.status + ", createdAt=" + this.createdAt + ")";
        }

        public RequestItem(long j, String name, String release, String imdbId, String message, int i, String createdAt) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(imdbId, "imdbId");
            Intrinsics.checkNotNullParameter(message, "message");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            this.id = j;
            this.name = name;
            this.release = release;
            this.imdbId = imdbId;
            this.message = message;
            this.status = i;
            this.createdAt = createdAt;
        }

        public final long getId() {
            return this.id;
        }

        public final String getName() {
            return this.name;
        }

        public final String getRelease() {
            return this.release;
        }

        public final String getImdbId() {
            return this.imdbId;
        }

        public final String getMessage() {
            return this.message;
        }

        public final int getStatus() {
            return this.status;
        }

        public final String getCreatedAt() {
            return this.createdAt;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0002\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J1\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\t¨\u0006\u0018"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchItem;", "", "name", "", "release", "imdbId", "imageUrl", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getImageUrl", "()Ljava/lang/String;", "getImdbId", "getName", "getRelease", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class SearchItem {
        private final String imageUrl;
        private final String imdbId;
        private final String name;
        private final String release;

        public static /* synthetic */ SearchItem copy$default(SearchItem searchItem, String str, String str2, String str3, String str4, int i, Object obj) {
            if ((i & 1) != 0) {
                str = searchItem.name;
            }
            if ((i & 2) != 0) {
                str2 = searchItem.release;
            }
            if ((i & 4) != 0) {
                str3 = searchItem.imdbId;
            }
            if ((i & 8) != 0) {
                str4 = searchItem.imageUrl;
            }
            return searchItem.copy(str, str2, str3, str4);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getName() {
            return this.name;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getRelease() {
            return this.release;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getImdbId() {
            return this.imdbId;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getImageUrl() {
            return this.imageUrl;
        }

        public final SearchItem copy(String name, String release, String imdbId, String imageUrl) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(imdbId, "imdbId");
            Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
            return new SearchItem(name, release, imdbId, imageUrl);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof SearchItem)) {
                return false;
            }
            SearchItem searchItem = (SearchItem) other;
            return Intrinsics.areEqual(this.name, searchItem.name) && Intrinsics.areEqual(this.release, searchItem.release) && Intrinsics.areEqual(this.imdbId, searchItem.imdbId) && Intrinsics.areEqual(this.imageUrl, searchItem.imageUrl);
        }

        public int hashCode() {
            return (((((this.name.hashCode() * 31) + this.release.hashCode()) * 31) + this.imdbId.hashCode()) * 31) + this.imageUrl.hashCode();
        }

        public String toString() {
            return "SearchItem(name=" + this.name + ", release=" + this.release + ", imdbId=" + this.imdbId + ", imageUrl=" + this.imageUrl + ")";
        }

        public SearchItem(String name, String release, String imdbId, String imageUrl) {
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(release, "release");
            Intrinsics.checkNotNullParameter(imdbId, "imdbId");
            Intrinsics.checkNotNullParameter(imageUrl, "imageUrl");
            this.name = name;
            this.release = release;
            this.imdbId = imdbId;
            this.imageUrl = imageUrl;
        }

        public final String getName() {
            return this.name;
        }

        public final String getRelease() {
            return this.release;
        }

        public final String getImdbId() {
            return this.imdbId;
        }

        public final String getImageUrl() {
            return this.imageUrl;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B)\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\u0002\u0010\tJ\t\u0010\u0010\u001a\u00020\u0004HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0006HÆ\u0003J\u000f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\bHÆ\u0003J5\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bHÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00042\b\u0010\u0015\u001a\u0004\u0018\u00010\u0002HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0006HÖ\u0001R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$ParseResult;", ExifInterface.GPS_DIRECTION_TRUE, "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "(ZLjava/lang/String;Ljava/util/List;)V", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ParseResult<T> {
        private final List<T> items;
        private final String message;
        private final boolean ok;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, boolean z, String str, List list, int i, Object obj) {
            if ((i & 1) != 0) {
                z = parseResult.ok;
            }
            if ((i & 2) != 0) {
                str = parseResult.message;
            }
            if ((i & 4) != 0) {
                list = parseResult.items;
            }
            return parseResult.copy(z, str, list);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<T> component3() {
            return this.items;
        }

        public final ParseResult<T> copy(boolean ok, String message, List<? extends T> items) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new ParseResult<>(ok, message, items);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return this.ok == parseResult.ok && Intrinsics.areEqual(this.message, parseResult.message) && Intrinsics.areEqual(this.items, parseResult.items);
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            return ((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode();
        }

        public String toString() {
            return "ParseResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ")";
        }

        /* JADX WARN: Multi-variable type inference failed */
        public ParseResult(boolean z, String str, List<? extends T> items) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public /* synthetic */ ParseResult(boolean z, String str, List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(z, (i & 2) != 0 ? null : str, (i & 4) != 0 ? CollectionsKt.emptyList() : list);
        }

        public final List<T> getItems() {
            return this.items;
        }
    }

    static final void lambda$7$lambda$6(RequestsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.stateAction;
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final void buildListContainer() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(0);
        this.listContainer = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setBackground(roundedBg(336401178, DefaultTimeBar.DEFAULT_UNPLAYED_COLOR, m384dp(1), dpF(12)));
        linearLayout2.setPadding(m384dp(10), m384dp(8), m384dp(10), m384dp(8));
        TextView textView = new TextView(this.ctx);
        textView.setText("پیگیری درخواست\u200cهای ارسال\u200cشده");
        textView.setTextColor(-2957330);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular);
        textView.setIncludeFontPadding(false);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("ثبت درخواست جدید");
        textView2.setTextColor(-16052459);
        textView2.setTextSize(13.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceBold);
        textView2.setIncludeFontPadding(false);
        textView2.setGravity(17);
        textView2.setPadding(m384dp(14), m384dp(8), m384dp(14), m384dp(8));
        textView2.setBackground(roundedBg(this.accent, 0, 0, dpF(999)));
        textView2.setClickable(true);
        textView2.setFocusable(!this.isTouchDevice);
        textView2.setFocusableInTouchMode(!this.isTouchDevice);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RequestsScreenView.buildListContainer$lambda$13$lambda$12(this.f$0, view);
            }
        });
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView2);
        LinearLayout linearLayout3 = this.listContainer;
        FrameLayout frameLayout = null;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout3 = null;
        }
        linearLayout3.addView(linearLayout2);
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams.topMargin = m384dp(10);
        frameLayout2.setLayoutParams(layoutParams);
        LinearLayout linearLayout4 = this.listContainer;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout4 = null;
        }
        linearLayout4.addView(frameLayout2);
        this.requestsAdapter = new RequestListAdapter(this, this.requestItems, this.isTouchDevice);
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        RequestListAdapter requestListAdapter = this.requestsAdapter;
        if (requestListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("requestsAdapter");
            requestListAdapter = null;
        }
        recyclerView.setAdapter(requestListAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m384dp(88));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$buildListContainer$2$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 4) {
                    return;
                }
                this.this$0.maybeLoadNextRequests();
            }
        });
        this.requestsRecycler = recyclerView;
        frameLayout2.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        progressBar.setVisibility(8);
        this.requestsLoading = progressBar;
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        Unit unit = Unit.INSTANCE;
        frameLayout2.addView(progressBar, layoutParams2);
        FrameLayout frameLayoutMakeLoadingMoreOverlay = makeLoadingMoreOverlay();
        this.requestsLoadingMoreOverlay = frameLayoutMakeLoadingMoreOverlay;
        if (frameLayoutMakeLoadingMoreOverlay == null) {
            Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
        } else {
            frameLayout = frameLayoutMakeLoadingMoreOverlay;
        }
        frameLayout2.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildListContainer$lambda$13$lambda$12(RequestsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchMode(Mode.CREATE);
    }

    private final void buildCreateContainer() {
        SearchResultAdapter searchResultAdapter;
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setFocusableInTouchMode(true);
        frameLayout.setElevation(dpF(46));
        frameLayout.setTranslationZ(dpF(46));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RequestsScreenView.buildCreateContainer$lambda$20$lambda$19(this.f$0, view);
            }
        });
        this.createContainer = frameLayout;
        View view = new View(this.ctx);
        view.setBackgroundColor(-1291845632);
        view.setAlpha(0.0f);
        view.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                RequestsScreenView.buildCreateContainer$lambda$22$lambda$21(this.f$0, view2);
            }
        });
        this.createSheetScrim = view;
        FrameLayout frameLayout2 = this.createContainer;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout2 = null;
        }
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        frameLayout2.addView(view2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setColor(-234156782);
        gradientDrawable.setStroke(m384dp(1), 778990720);
        gradientDrawable.setCornerRadii(new float[]{dpF(18), dpF(18), dpF(18), dpF(18), 0.0f, 0.0f, 0.0f, 0.0f});
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setClipToPadding(false);
        linearLayout.setPadding(0, m384dp(8), 0, m384dp(10));
        linearLayout.setTranslationY(m384dp(360));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                RequestsScreenView.buildCreateContainer$lambda$25$lambda$24(view3);
            }
        });
        this.createSheetCard = linearLayout;
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout3 = null;
        }
        LinearLayout linearLayout2 = this.createSheetCard;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout2 = null;
        }
        frameLayout3.addView(linearLayout2, new FrameLayout.LayoutParams(-1, m384dp(380), 80));
        FrameLayout frameLayout4 = new FrameLayout(this.ctx);
        frameLayout4.setPadding(0, m384dp(8), 0, m384dp(10));
        frameLayout4.setClickable(true);
        frameLayout4.setFocusable(true);
        frameLayout4.setFocusableInTouchMode(true);
        View view3 = new View(this.ctx);
        view3.setBackground(roundedBg(1174405119, 0, 0, dpF(999)));
        frameLayout4.addView(view3, new FrameLayout.LayoutParams(m384dp(44), m384dp(4), 17));
        frameLayout4.setOnTouchListener(new View.OnTouchListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda11
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view4, MotionEvent motionEvent) {
                return RequestsScreenView.buildCreateContainer$lambda$30(this.f$0, view4, motionEvent);
            }
        });
        ScrollView scrollView = new ScrollView(this.ctx);
        scrollView.setOverScrollMode(2);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setLayoutDirection(1);
        scrollView.setClipToPadding(false);
        scrollView.setPadding(0, 0, 0, m384dp(6));
        scrollView.setFillViewport(true);
        scrollView.setClickable(true);
        scrollView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view4) {
                RequestsScreenView.buildCreateContainer$lambda$32$lambda$31(view4);
            }
        });
        LinearLayout linearLayout3 = this.createSheetCard;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout3 = null;
        }
        linearLayout3.addView(frameLayout4, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        linearLayout4.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayout5 = new LinearLayout(this.ctx);
        linearLayout5.setOrientation(1);
        linearLayout5.setLayoutDirection(1);
        linearLayout5.setPadding(m384dp(14), m384dp(14), m384dp(14), m384dp(14));
        this.createFormContent = linearLayout5;
        scrollView.addView(linearLayout5, new FrameLayout.LayoutParams(-1, -2));
        linearLayout5.addView(makeFieldLabel("جستجو در IMDb"));
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint("نام فیلم یا سریال را وارد کنید");
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setSingleLine();
        appCompatEditText.setImeOptions(3);
        appCompatEditText.setGravity(21);
        appCompatEditText.setPadding(m384dp(12), m384dp(12), m384dp(12), m384dp(12));
        applyFieldStyle(appCompatEditText);
        appCompatEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda13
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                return RequestsScreenView.buildCreateContainer$lambda$35$lambda$34(this.f$0, textView, i, keyEvent);
            }
        });
        appCompatEditText.addTextChangedListener(new TextWatcher() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$buildCreateContainer$5$2
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                this.this$0.scheduleSearchFromInput();
            }
        });
        this.searchInput = appCompatEditText;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m384dp(8);
        Unit unit = Unit.INSTANCE;
        linearLayout5.addView(appCompatEditText, layoutParams);
        TextView textViewMakeFieldLabel = makeFieldLabel("نتایج جستجو");
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m384dp(12);
        Unit unit2 = Unit.INSTANCE;
        linearLayout5.addView(textViewMakeFieldLabel, layoutParams2);
        FrameLayout frameLayout5 = new FrameLayout(this.ctx);
        frameLayout5.setBackground(roundedBg(269358366, 659446377, m384dp(1), dpF(12)));
        frameLayout5.setPadding(m384dp(6), m384dp(6), m384dp(6), m384dp(6));
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, m384dp(220));
        layoutParams3.topMargin = m384dp(8);
        Unit unit3 = Unit.INSTANCE;
        linearLayout5.addView(frameLayout5, layoutParams3);
        this.searchResultsAdapter = new SearchResultAdapter(this, this.searchItems, this.isTouchDevice, new Function1<SearchItem, Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView.buildCreateContainer.9
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(SearchItem searchItem) {
                invoke2(searchItem);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(SearchItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                RequestsScreenView.this.selectedSearchItem = item;
                SearchResultAdapter searchResultAdapter2 = RequestsScreenView.this.searchResultsAdapter;
                if (searchResultAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                    searchResultAdapter2 = null;
                }
                searchResultAdapter2.setSelectedImdb(item.getImdbId());
            }
        });
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        SearchResultAdapter searchResultAdapter2 = this.searchResultsAdapter;
        if (searchResultAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter = null;
        } else {
            searchResultAdapter = searchResultAdapter2;
        }
        recyclerView.setAdapter(searchResultAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m384dp(4));
        this.searchResultsRecycler = recyclerView;
        frameLayout5.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        progressBar.setVisibility(8);
        this.searchResultsLoading = progressBar;
        FrameLayout.LayoutParams layoutParams4 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams4.gravity = 17;
        Unit unit4 = Unit.INSTANCE;
        frameLayout5.addView(progressBar, layoutParams4);
        TextView textView = new TextView(this.ctx);
        textView.setText("برای شروع جستجو، نام فیلم یا سریال را وارد کنید.");
        textView.setTextColor(-1211639317);
        textView.setTextSize(12.0f);
        textView.setGravity(17);
        Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular2 == null) {
            typefaceRegular2 = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular2);
        textView.setIncludeFontPadding(false);
        textView.setLineSpacing(m384dp(1), 1.0f);
        textView.setVisibility(0);
        this.searchEmptyText = textView;
        frameLayout5.addView(textView, new FrameLayout.LayoutParams(-1, -1));
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("ارسال درخواست");
        textView2.setTextColor(-16052459);
        textView2.setTextSize(14.0f);
        textView2.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceBold);
        textView2.setIncludeFontPadding(false);
        textView2.setPadding(m384dp(16), m384dp(11), m384dp(16), m384dp(11));
        textView2.setBackground(roundedBg(this.accent, 0, 0, dpF(12)));
        textView2.setClickable(true);
        textView2.setFocusable(!this.isTouchDevice);
        textView2.setFocusableInTouchMode(true ^ this.isTouchDevice);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view4) {
                RequestsScreenView.buildCreateContainer$lambda$45$lambda$44(this.f$0, view4);
            }
        });
        this.submitButton = textView2;
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = m384dp(16);
        Unit unit5 = Unit.INSTANCE;
        linearLayout5.addView(textView2, layoutParams5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$20$lambda$19(RequestsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.sendingRequest || this$0.searching) {
            return;
        }
        this$0.switchMode(Mode.LIST);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$22$lambda$21(RequestsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.sendingRequest || this$0.searching) {
            return;
        }
        this$0.switchMode(Mode.LIST);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d2  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00ef  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final boolean buildCreateContainer$lambda$30(RequestsScreenView this$0, View view, MotionEvent motionEvent) {
        LinearLayout linearLayout;
        Integer numValueOf;
        int iIntValue;
        LinearLayout linearLayout2;
        LinearLayout linearLayout3;
        View view2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        int actionMasked = motionEvent.getActionMasked();
        LinearLayout linearLayout4 = null;
        View view3 = null;
        View view4 = null;
        if (actionMasked == 0) {
            this$0.createDragStartRawY = motionEvent.getRawY();
            LinearLayout linearLayout5 = this$0.createSheetCard;
            if (linearLayout5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout4 = linearLayout5;
            }
            this$0.createDragStartTranslation = linearLayout4.getTranslationY();
        } else if (actionMasked == 1) {
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
                numValueOf = null;
            }
            iIntValue = numValueOf == null ? numValueOf.intValue() : this$0.m384dp(380);
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f && !this$0.sendingRequest && !this$0.searching) {
                this$0.switchMode(Mode.LIST);
            } else {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                    linearLayout3 = null;
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                } else {
                    view4 = view2;
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        } else if (actionMasked == 2) {
            float fCoerceAtLeast = RangesKt.coerceAtLeast(this$0.createDragStartTranslation + RangesKt.coerceAtLeast(motionEvent.getRawY() - this$0.createDragStartRawY, 0.0f), 0.0f);
            LinearLayout linearLayout6 = this$0.createSheetCard;
            if (linearLayout6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout6 = null;
            }
            linearLayout6.setTranslationY(fCoerceAtLeast);
            LinearLayout linearLayout7 = this$0.createSheetCard;
            if (linearLayout7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout7 = null;
            }
            Integer numValueOf2 = Integer.valueOf(linearLayout7.getHeight());
            if (!(numValueOf2.intValue() > 0)) {
                numValueOf2 = null;
            }
            int iIntValue2 = numValueOf2 != null ? numValueOf2.intValue() : this$0.m384dp(380);
            View view5 = this$0.createSheetScrim;
            if (view5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            } else {
                view3 = view5;
            }
            view3.setAlpha(RangesKt.coerceIn(1.0f - (fCoerceAtLeast / (iIntValue2 * 0.9f)), 0.0f, 1.0f));
        } else {
            if (actionMasked != 3) {
                return false;
            }
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
            }
            if (numValueOf == null) {
            }
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f) {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildCreateContainer$lambda$35$lambda$34(RequestsScreenView this$0, TextView textView, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i != 3 && i != 6) {
            return false;
        }
        this$0.triggerSearchNow();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$45$lambda$44(RequestsScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitRequest();
    }

    private final void applyFieldStyle(final AppCompatEditText field) {
        field.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m384dp(2), dpF(16)));
        field.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda6
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                RequestsScreenView.applyFieldStyle$lambda$47(field, this, view, z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyFieldStyle$lambda$47(AppCompatEditText field, RequestsScreenView this$0, View view, boolean z) {
        Intrinsics.checkNotNullParameter(field, "$field");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        field.setBackground(this$0.roundedBg(this$0.fieldFill, z ? this$0.accent : this$0.fieldStroke, this$0.m384dp(2), this$0.dpF(16)));
    }

    private final TextView makeFieldLabel(String title) {
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-3154708);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void switchMode(Mode next) {
        this.mode = next;
        if (next == Mode.CREATE) {
            hideState();
            showCreateSheet();
            return;
        }
        hideCreateSheet$default(this, false, 1, null);
        if (isLoggedIn() && this.requestItems.isEmpty() && !this.loadingRequests) {
            resetRequestsAndLoad();
        }
    }

    private final void showCreateSheet() {
        if (this.createContainer == null || this.createSheetCard == null || this.createSheetShown) {
            return;
        }
        final int iResolveCreateSheetHeight = resolveCreateSheetHeight();
        LinearLayout linearLayout = this.createSheetCard;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout = null;
        }
        ViewGroup.LayoutParams layoutParams = linearLayout.getLayoutParams();
        FrameLayout.LayoutParams layoutParams2 = layoutParams instanceof FrameLayout.LayoutParams ? (FrameLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 != null && layoutParams2.height != iResolveCreateSheetHeight) {
            layoutParams2.height = iResolveCreateSheetHeight;
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setLayoutParams(layoutParams2);
        }
        this.createSheetShown = true;
        FrameLayout frameLayout = this.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(0);
        View view = this.createSheetScrim;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view = null;
        }
        view.setAlpha(0.0f);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(1.0f).setDuration(200L).start();
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout2 = linearLayout4;
        }
        linearLayout2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                RequestsScreenView.showCreateSheet$lambda$51(this.f$0, iResolveCreateSheetHeight);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showCreateSheet$lambda$51(RequestsScreenView this$0, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            LinearLayout linearLayout = this$0.createSheetCard;
            LinearLayout linearLayout2 = null;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            Integer numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
                numValueOf = null;
            }
            if (numValueOf != null) {
                i = numValueOf.intValue();
            }
            LinearLayout linearLayout3 = this$0.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setTranslationY(i);
            LinearLayout linearLayout4 = this$0.createSheetCard;
            if (linearLayout4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout2 = linearLayout4;
            }
            linearLayout2.animate().translationY(0.0f).setDuration(220L).start();
        }
    }

    static /* synthetic */ void hideCreateSheet$default(RequestsScreenView requestsScreenView, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        requestsScreenView.hideCreateSheet(z);
    }

    private final void hideCreateSheet(boolean animated) {
        FrameLayout frameLayout = this.createContainer;
        if (frameLayout == null || this.createSheetCard == null) {
            return;
        }
        LinearLayout linearLayout = null;
        FrameLayout frameLayout2 = null;
        if (!this.createSheetShown) {
            if (frameLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
                frameLayout = null;
            }
            if (frameLayout.getVisibility() != 0) {
                return;
            }
        }
        this.createSheetShown = false;
        if (!animated) {
            View view = this.createSheetScrim;
            if (view == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                view = null;
            }
            view.setAlpha(0.0f);
            LinearLayout linearLayout2 = this.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout2.setTranslationY(linearLayout3.getHeight());
            FrameLayout frameLayout3 = this.createContainer;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            } else {
                frameLayout2 = frameLayout3;
            }
            frameLayout2.setVisibility(8);
            return;
        }
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        Integer numValueOf = Integer.valueOf(linearLayout4.getHeight());
        if (!(numValueOf.intValue() > 0)) {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : m384dp(360);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(0.0f).setDuration(180L).start();
        LinearLayout linearLayout5 = this.createSheetCard;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout = linearLayout5;
        }
        linearLayout.animate().translationY(iIntValue).setDuration(200L).withEndAction(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                RequestsScreenView.hideCreateSheet$lambda$53(this.f$0);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void hideCreateSheet$lambda$53(RequestsScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            return;
        }
        FrameLayout frameLayout = this$0.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
    }

    private final int resolveCreateSheetHeight() {
        float f = getResources().getDisplayMetrics().heightPixels;
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (0.58f * f), m384dp(380));
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast((int) (f * 0.94f), iCoerceAtLeast);
        if (this.createFormContent == null) {
            return iCoerceAtLeast;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(RangesKt.coerceAtLeast(getResources().getDisplayMetrics().widthPixels - m384dp(28), m384dp(220)), 1073741824);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        LinearLayout linearLayout = this.createFormContent;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createFormContent");
            linearLayout = null;
        }
        linearLayout.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int iM384dp = m384dp(44);
        LinearLayout linearLayout3 = this.createFormContent;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createFormContent");
        } else {
            linearLayout2 = linearLayout3;
        }
        return RangesKt.coerceAtMost(RangesKt.coerceAtLeast(linearLayout2.getMeasuredHeight() + iM384dp, iCoerceAtLeast), iCoerceAtLeast2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetRequestsAndLoad() {
        this.requestItems.clear();
        RequestListAdapter requestListAdapter = this.requestsAdapter;
        if (requestListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("requestsAdapter");
            requestListAdapter = null;
        }
        requestListAdapter.notifyDataSetChanged();
        this.currentPage = 1;
        this.hasMore = true;
        loadRequests(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNextRequests() {
        if (this.loadingRequests || !this.hasMore) {
            return;
        }
        loadRequests(this.currentPage + 1, false);
    }

    private final void loadRequests(int page, boolean reset) {
        if (this.loadingRequests || !isLoggedIn()) {
            return;
        }
        this.loadingRequests = true;
        FrameLayout frameLayout = null;
        if (reset) {
            ProgressBar progressBar = this.requestsLoading;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoading");
                progressBar = null;
            }
            progressBar.setVisibility(0);
            FrameLayout frameLayout2 = this.requestsLoadingMoreOverlay;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
                frameLayout2 = null;
            }
            frameLayout2.setVisibility(8);
        } else {
            FrameLayout frameLayout3 = this.requestsLoadingMoreOverlay;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
                frameLayout3 = null;
            }
            frameLayout3.setVisibility(0);
        }
        if (safeExecute(new C26811(page, reset))) {
            return;
        }
        this.loadingRequests = false;
        ProgressBar progressBar2 = this.requestsLoading;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("requestsLoading");
            progressBar2 = null;
        }
        progressBar2.setVisibility(8);
        FrameLayout frameLayout4 = this.requestsLoadingMoreOverlay;
        if (frameLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
        } else {
            frameLayout = frameLayout4;
        }
        frameLayout.setVisibility(8);
    }

    /* JADX INFO: renamed from: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1 */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, m780d2 = {"<anonymous>", "", "invoke"}, m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    static final class C26811 extends Lambda implements Function0<Unit> {
        final /* synthetic */ int $page;
        final /* synthetic */ boolean $reset;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C26811(int i, boolean z) {
            super(0);
            this.$page = i;
            this.$reset = z;
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            try {
                final ParseResult requestListResponse = RequestsScreenView.this.parseRequestListResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, RequestsScreenView.this.apiBase, "/getRequests", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(RequestsScreenView.this.sessionUserId)), TuplesKt.m787to("page", String.valueOf(this.$page)), TuplesKt.m787to("per_page", "20")), RequestsScreenView.this.authHeaders(), null, false, 96, null));
                Handler handler = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView = RequestsScreenView.this;
                final boolean z = this.$reset;
                final int i = this.$page;
                handler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26811.invoke$lambda$0(requestsScreenView, requestListResponse, z, i);
                    }
                });
            } catch (Throwable th) {
                Handler handler2 = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView2 = RequestsScreenView.this;
                handler2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26811.invoke$lambda$1(requestsScreenView2, th);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(final RequestsScreenView this$0, ParseResult parsed, boolean z, int i) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(parsed, "$parsed");
            this$0.loadingRequests = false;
            ProgressBar progressBar = this$0.requestsLoading;
            RequestListAdapter requestListAdapter = null;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoading");
                progressBar = null;
            }
            progressBar.setVisibility(8);
            FrameLayout frameLayout = this$0.requestsLoadingMoreOverlay;
            if (frameLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
                frameLayout = null;
            }
            frameLayout.setVisibility(8);
            if (!parsed.getOk()) {
                if (this$0.mode == Mode.LIST) {
                    this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت درخواست\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$1$1
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            this$0.resetRequestsAndLoad();
                        }
                    });
                    return;
                }
                return;
            }
            if (z) {
                int size = this$0.requestItems.size();
                this$0.requestItems.clear();
                if (size > 0) {
                    RequestListAdapter requestListAdapter2 = this$0.requestsAdapter;
                    if (requestListAdapter2 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("requestsAdapter");
                        requestListAdapter2 = null;
                    }
                    requestListAdapter2.notifyItemRangeRemoved(0, size);
                }
            }
            int size2 = this$0.requestItems.size();
            this$0.requestItems.addAll(parsed.getItems());
            if (!parsed.getItems().isEmpty()) {
                RequestListAdapter requestListAdapter3 = this$0.requestsAdapter;
                if (requestListAdapter3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("requestsAdapter");
                } else {
                    requestListAdapter = requestListAdapter3;
                }
                requestListAdapter.notifyItemRangeInserted(size2, parsed.getItems().size());
            }
            this$0.currentPage = i;
            this$0.hasMore = parsed.getItems().size() >= 20;
            if (!this$0.requestItems.isEmpty() || this$0.mode != Mode.LIST) {
                if (this$0.mode == Mode.LIST) {
                    this$0.hideState();
                    return;
                }
                return;
            }
            this$0.showState("هنوز درخواستی ثبت نشده است.", "ثبت درخواست جدید", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this$0.switchMode(RequestsScreenView.Mode.CREATE);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$1(final RequestsScreenView this$0, Throwable e) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(e, "$e");
            boolean z = false;
            this$0.loadingRequests = false;
            ProgressBar progressBar = this$0.requestsLoading;
            FrameLayout frameLayout = null;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoading");
                progressBar = null;
            }
            progressBar.setVisibility(8);
            FrameLayout frameLayout2 = this$0.requestsLoadingMoreOverlay;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("requestsLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout2;
            }
            frameLayout.setVisibility(8);
            if (this$0.mode == Mode.LIST) {
                if (e instanceof FkApiClient.ApiException) {
                    FkApiClient.ApiException apiException = (FkApiClient.ApiException) e;
                    if (apiException.getCode() == 401 || apiException.getCode() == 403) {
                        z = true;
                    }
                }
                if (z) {
                    this$0.showState("برای مشاهده و ثبت درخواست، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$2$1
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            Function0 function0 = this$0.onRequireLogin;
                            if (function0 != null) {
                                function0.invoke();
                            }
                        }
                    });
                } else {
                    this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت درخواست\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$loadRequests$1$2$2
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            this$0.resetRequestsAndLoad();
                        }
                    });
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void scheduleSearchFromInput() {
        AppCompatEditText appCompatEditText = this.searchInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        final String strNormalizeSearchQuery = normalizeSearchQuery(text != null ? text.toString() : null);
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        if (StringsKt.isBlank(strNormalizeSearchQuery)) {
            clearSearchResults("برای شروع جستجو، نام فیلم یا سریال را وارد کنید.");
        } else {
            if (!isSearchThresholdReached(strNormalizeSearchQuery)) {
                clearSearchResults("جستجو بعد از وارد کردن حداقل ۳ کاراکتر انجام می\u200cشود.");
                return;
            }
            Runnable runnable2 = new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    RequestsScreenView.scheduleSearchFromInput$lambda$55(this.f$0, strNormalizeSearchQuery);
                }
            };
            this.searchDebounceRunnable = runnable2;
            this.mainHandler.postDelayed(runnable2, 420L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleSearchFromInput$lambda$55(RequestsScreenView this$0, String query) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(query, "$query");
        this$0.performSearch(query);
    }

    private final void triggerSearchNow() {
        AppCompatEditText appCompatEditText = this.searchInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        String strNormalizeSearchQuery = normalizeSearchQuery(text != null ? text.toString() : null);
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        if (StringsKt.isBlank(strNormalizeSearchQuery)) {
            clearSearchResults("برای شروع جستجو، نام فیلم یا سریال را وارد کنید.");
        } else if (!isSearchThresholdReached(strNormalizeSearchQuery)) {
            showToast("حداقل ۳ کاراکتر وارد کنید");
        } else {
            performSearch(strNormalizeSearchQuery);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void performSearch(String query) {
        if (this.sendingRequest) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        if (this.searching) {
            this.pendingSearchQuery = query;
            return;
        }
        String strNormalizeSearchQuery = normalizeSearchQuery(query);
        if (!StringsKt.isBlank(strNormalizeSearchQuery) && isSearchThresholdReached(strNormalizeSearchQuery)) {
            if (Intrinsics.areEqual(strNormalizeSearchQuery, this.lastSearchedQuery) && (!this.searchItems.isEmpty())) {
                return;
            }
            this.searching = true;
            TextView textView = null;
            this.pendingSearchQuery = null;
            this.lastSearchedQuery = strNormalizeSearchQuery;
            setSearchLoading(true);
            TextView textView2 = this.searchEmptyText;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
            } else {
                textView = textView2;
            }
            textView.setVisibility(8);
            if (safeExecute(new C26821(strNormalizeSearchQuery))) {
                return;
            }
            this.searching = false;
            setSearchLoading(false);
        }
    }

    /* JADX INFO: renamed from: com.filmkio.nativescreen.account.RequestsScreenView$performSearch$1 */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, m780d2 = {"<anonymous>", "", "invoke"}, m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    static final class C26821 extends Lambda implements Function0<Unit> {
        final /* synthetic */ String $normalized;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C26821(String str) {
            super(0);
            this.$normalized = str;
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            try {
                final ParseResult searchResponse = RequestsScreenView.this.parseSearchResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, RequestsScreenView.this.apiBase, "/requests", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(RequestsScreenView.this.sessionUserId)), TuplesKt.m787to("str", this.$normalized)), RequestsScreenView.this.authHeaders(), null, false, 96, null));
                Handler handler = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView = RequestsScreenView.this;
                final String str = this.$normalized;
                handler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$performSearch$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26821.invoke$lambda$3(requestsScreenView, searchResponse, str);
                    }
                });
            } catch (Throwable th) {
                Handler handler2 = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView2 = RequestsScreenView.this;
                handler2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$performSearch$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26821.invoke$lambda$5(requestsScreenView2, th);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Removed duplicated region for block: B:48:0x010f  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public static final void invoke$lambda$3(RequestsScreenView this$0, ParseResult parsed, String normalized) {
            String lowerCase;
            String imdbId;
            String string;
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(parsed, "$parsed");
            Intrinsics.checkNotNullParameter(normalized, "$normalized");
            this$0.searching = false;
            this$0.setSearchLoading(false);
            if (!parsed.getOk()) {
                this$0.showToast(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در جستجو"));
                String str = this$0.pendingSearchQuery;
                if (str != null) {
                    this$0.pendingSearchQuery = null;
                    this$0.performSearch(str);
                    return;
                }
                return;
            }
            int size = this$0.searchItems.size();
            this$0.searchItems.clear();
            if (size > 0) {
                SearchResultAdapter searchResultAdapter = this$0.searchResultsAdapter;
                if (searchResultAdapter == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                    searchResultAdapter = null;
                }
                searchResultAdapter.notifyItemRangeRemoved(0, size);
            }
            this$0.searchItems.addAll(parsed.getItems());
            boolean z = true;
            if (!this$0.searchItems.isEmpty()) {
                SearchResultAdapter searchResultAdapter2 = this$0.searchResultsAdapter;
                if (searchResultAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                    searchResultAdapter2 = null;
                }
                searchResultAdapter2.notifyItemRangeInserted(0, this$0.searchItems.size());
            }
            SearchItem searchItem = this$0.selectedSearchItem;
            if (searchItem == null || (imdbId = searchItem.getImdbId()) == null || (string = StringsKt.trim((CharSequence) imdbId).toString()) == null) {
                lowerCase = null;
            } else {
                Locale US = Locale.US;
                Intrinsics.checkNotNullExpressionValue(US, "US");
                lowerCase = string.toLowerCase(US);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            }
            String str2 = lowerCase;
            if (!(str2 == null || StringsKt.isBlank(str2))) {
                ArrayList arrayList = this$0.searchItems;
                if (!(arrayList instanceof Collection) || !arrayList.isEmpty()) {
                    Iterator it = arrayList.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            break;
                        }
                        String string2 = StringsKt.trim((CharSequence) ((SearchItem) it.next()).getImdbId()).toString();
                        Locale US2 = Locale.US;
                        Intrinsics.checkNotNullExpressionValue(US2, "US");
                        String lowerCase2 = string2.toLowerCase(US2);
                        Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                        if (Intrinsics.areEqual(lowerCase2, lowerCase)) {
                            z = false;
                            break;
                        }
                    }
                }
                if (z) {
                    this$0.selectedSearchItem = null;
                    SearchResultAdapter searchResultAdapter3 = this$0.searchResultsAdapter;
                    if (searchResultAdapter3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                        searchResultAdapter3 = null;
                    }
                    searchResultAdapter3.setSelectedImdb(null);
                }
            }
            if (this$0.searchItems.isEmpty()) {
                TextView textView = this$0.searchEmptyText;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView = null;
                }
                textView.setText(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "نتیجه\u200cای پیدا نشد."));
                TextView textView2 = this$0.searchEmptyText;
                if (textView2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView2 = null;
                }
                textView2.setVisibility(0);
            } else {
                TextView textView3 = this$0.searchEmptyText;
                if (textView3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView3 = null;
                }
                textView3.setVisibility(8);
            }
            String str3 = this$0.pendingSearchQuery;
            if (str3 != null) {
                this$0.pendingSearchQuery = null;
                if (Intrinsics.areEqual(this$0.normalizeSearchQuery(str3), normalized)) {
                    return;
                }
                this$0.performSearch(str3);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$5(RequestsScreenView this$0, Throwable e) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(e, "$e");
            this$0.searching = false;
            this$0.setSearchLoading(false);
            this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در جستجو"));
            if (this$0.searchItems.isEmpty()) {
                TextView textView = this$0.searchEmptyText;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView = null;
                }
                textView.setText("خطا در جستجو. دوباره تلاش کنید.");
                TextView textView2 = this$0.searchEmptyText;
                if (textView2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
                    textView2 = null;
                }
                textView2.setVisibility(0);
            }
            String str = this$0.pendingSearchQuery;
            if (str != null) {
                this$0.pendingSearchQuery = null;
                this$0.performSearch(str);
            }
        }
    }

    private final void submitRequest() {
        if (this.sendingRequest || this.searching) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        SearchItem searchItem = this.selectedSearchItem;
        if (searchItem == null) {
            showToast("ابتدا یک مورد را از نتایج انتخاب کنید");
            return;
        }
        if (StringsKt.isBlank(searchItem.getImdbId())) {
            showToast("شناسه IMDb معتبر نیست");
            return;
        }
        this.sendingRequest = true;
        setSubmitLoading(true);
        if (safeExecute(new C26831(searchItem))) {
            return;
        }
        this.sendingRequest = false;
        setSubmitLoading(false);
    }

    /* JADX INFO: renamed from: com.filmkio.nativescreen.account.RequestsScreenView$submitRequest$1 */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, m780d2 = {"<anonymous>", "", "invoke"}, m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    static final class C26831 extends Lambda implements Function0<Unit> {
        final /* synthetic */ SearchItem $selected;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C26831(SearchItem searchItem) {
            super(0);
            this.$selected = searchItem;
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            try {
                LinkedHashMap linkedHashMapLinkedMapOf = MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(RequestsScreenView.this.sessionUserId)), TuplesKt.m787to("name", this.$selected.getName()), TuplesKt.m787to("imdb_id", this.$selected.getImdbId()), TuplesKt.m787to("release", this.$selected.getRelease()));
                String string = new JSONObject().put("userID", RequestsScreenView.this.sessionUserId).put("name", this.$selected.getName()).put("imdb_id", this.$selected.getImdbId()).put("release", this.$selected.getRelease()).toString();
                Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                final Pair sendResponse = RequestsScreenView.this.parseSendResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, RequestsScreenView.this.apiBase, "/sendRequest", "POST", linkedHashMapLinkedMapOf, RequestsScreenView.this.authHeaders(), string, false, 64, null));
                Handler handler = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView = RequestsScreenView.this;
                handler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$submitRequest$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26831.invoke$lambda$0(requestsScreenView, sendResponse);
                    }
                });
            } catch (Throwable th) {
                Handler handler2 = RequestsScreenView.this.mainHandler;
                final RequestsScreenView requestsScreenView2 = RequestsScreenView.this;
                handler2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$submitRequest$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        RequestsScreenView.C26831.invoke$lambda$1(requestsScreenView2, th);
                    }
                });
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(RequestsScreenView this$0, Pair parsed) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(parsed, "$parsed");
            this$0.sendingRequest = false;
            this$0.setSubmitLoading(false);
            if (!((Boolean) parsed.getFirst()).booleanValue()) {
                String str = (String) parsed.getSecond();
                if (str == null) {
                    str = "ارسال درخواست ناموفق بود";
                }
                this$0.showToast(str);
                return;
            }
            String str2 = (String) parsed.getSecond();
            if (str2 == null) {
                str2 = "درخواست شما ثبت شد";
            }
            this$0.showToast(str2);
            this$0.clearCreateForm();
            this$0.switchMode(Mode.LIST);
            this$0.resetRequestsAndLoad();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$1(RequestsScreenView this$0, Throwable e) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(e, "$e");
            this$0.sendingRequest = false;
            this$0.setSubmitLoading(false);
            this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "ارسال درخواست ناموفق بود"));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void clearCreateForm() {
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        AppCompatEditText appCompatEditText = null;
        this.searchDebounceRunnable = null;
        this.pendingSearchQuery = null;
        this.lastSearchedQuery = "";
        AppCompatEditText appCompatEditText2 = this.searchInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
        } else {
            appCompatEditText = appCompatEditText2;
        }
        appCompatEditText.setText("");
        clearSearchResults("برای شروع جستجو، نام فیلم یا سریال را وارد کنید.");
    }

    private final void clearSearchResults(String message) {
        int size = this.searchItems.size();
        this.searchItems.clear();
        TextView textView = null;
        if (size > 0) {
            SearchResultAdapter searchResultAdapter = this.searchResultsAdapter;
            if (searchResultAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
                searchResultAdapter = null;
            }
            searchResultAdapter.notifyItemRangeRemoved(0, size);
        }
        this.selectedSearchItem = null;
        SearchResultAdapter searchResultAdapter2 = this.searchResultsAdapter;
        if (searchResultAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsAdapter");
            searchResultAdapter2 = null;
        }
        searchResultAdapter2.setSelectedImdb(null);
        TextView textView2 = this.searchEmptyText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
            textView2 = null;
        }
        textView2.setText(SafeUserMessage.INSTANCE.fromRaw(message, "نتیجه\u200cای یافت نشد."));
        TextView textView3 = this.searchEmptyText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchEmptyText");
        } else {
            textView = textView3;
        }
        textView.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:6:0x001e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String normalizeSearchQuery(String raw) {
        String string;
        if (raw != null) {
            String strReplace = new Regex("\\s+").replace(raw, " ");
            string = strReplace != null ? StringsKt.trim((CharSequence) strReplace).toString() : null;
        }
        return string == null ? "" : string;
    }

    private final boolean isSearchThresholdReached(String query) {
        return query.length() >= 3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setSearchLoading(boolean loading) {
        AppCompatEditText appCompatEditText = this.searchInput;
        ProgressBar progressBar = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchInput");
            appCompatEditText = null;
        }
        appCompatEditText.setAlpha(loading ? 0.92f : 1.0f);
        ProgressBar progressBar2 = this.searchResultsLoading;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("searchResultsLoading");
        } else {
            progressBar = progressBar2;
        }
        progressBar.setVisibility(loading ? 0 : 8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setSubmitLoading(boolean loading) {
        TextView textView = this.submitButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.submitButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.75f : 1.0f);
        TextView textView4 = this.submitButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
        } else {
            textView2 = textView4;
        }
        textView2.setText(loading ? "در حال ارسال..." : "ارسال درخواست");
    }

    public final boolean handleBackPressed() {
        if (this.mode != Mode.CREATE) {
            return false;
        }
        switchMode(Mode.LIST);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ParseResult<RequestItem> parseRequestListResponse(String raw) {
        JSONArray jSONArray;
        Long l;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            boolean z = objNextValue instanceof JSONObject;
            if (z) {
                JSONObject jSONObject = (JSONObject) objNextValue;
                String strOptString = jSONObject.optString("code", "");
                Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
                if (true ^ StringsKt.isBlank(StringsKt.trim((CharSequence) strOptString).toString())) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت درخواست\u200cها"), null, 4, null);
                }
            }
            if (objNextValue instanceof JSONArray) {
                Intrinsics.checkNotNull(objNextValue);
                jSONArray = (JSONArray) objNextValue;
            } else if (z) {
                JSONObject jSONObject2 = (JSONObject) objNextValue;
                JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
                if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = jSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null) {
                    Intrinsics.checkNotNull(objNextValue);
                    jSONArray = numericObjectToArray(jSONObject2);
                    if (jSONArray == null) {
                        jSONArray = new JSONArray();
                    }
                } else {
                    jSONArray = jSONArrayOptJSONArray;
                }
            } else {
                jSONArray = new JSONArray();
            }
            ArrayList arrayList = new ArrayList(jSONArray.length());
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null && ((l = toLong(jSONObjectOptJSONObject.opt("ID"))) != null || (l = toLong(jSONObjectOptJSONObject.opt(TtmlNode.ATTR_ID))) != null)) {
                    long jLongValue = l.longValue();
                    String strPickString = pickString(jSONObjectOptJSONObject, "name", "name_item");
                    if (strPickString == null) {
                        strPickString = "";
                    }
                    String str2 = strPickString;
                    if (StringsKt.isBlank(str2)) {
                        str2 = "آیتم #" + jLongValue;
                    }
                    String str3 = str2;
                    String strPickString2 = pickString(jSONObjectOptJSONObject, "release");
                    String str4 = strPickString2 == null ? "" : strPickString2;
                    String strPickString3 = pickString(jSONObjectOptJSONObject, "imdb_id", "imdbId");
                    String str5 = strPickString3 == null ? "" : strPickString3;
                    String strPickString4 = pickString(jSONObjectOptJSONObject, "message");
                    String str6 = strPickString4 == null ? "" : strPickString4;
                    Integer num = toInt(jSONObjectOptJSONObject.opt(NotificationCompat.CATEGORY_STATUS));
                    int iIntValue = num != null ? num.intValue() : 0;
                    String strPickString5 = pickString(jSONObjectOptJSONObject, "created_at", "createdAt");
                    if (strPickString5 == null) {
                        strPickString5 = "";
                    }
                    String str7 = strPickString5;
                    if (StringsKt.isBlank(str7)) {
                        str7 = "-";
                    }
                    arrayList.add(new RequestItem(jLongValue, str3, str4, str5, str6, iIntValue, str7));
                }
            }
            return new ParseResult<>(true, null, arrayList, 2, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final ParseResult<SearchItem> parseSearchResponse(String raw) {
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
            if (jSONObject == null) {
                return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
            }
            Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
            if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r0).toString())) {
                return new ParseResult<>(false, jSONObject.optString("message", "خطا در جستجو"), null, 4, null);
            }
            String strPickString = pickString(jSONObject, "message");
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
            if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = numericObjectToArray(jSONObject)) == null) {
                jSONArrayOptJSONArray = new JSONArray();
            }
            ArrayList arrayList = new ArrayList(jSONArrayOptJSONArray.length());
            int length = jSONArrayOptJSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null) {
                    String strPickString2 = pickString(jSONObjectOptJSONObject, "name");
                    if (strPickString2 == null) {
                        strPickString2 = "";
                    }
                    String strPickString3 = pickString(jSONObjectOptJSONObject, "imdb_id", "imdbId");
                    if (strPickString3 == null) {
                        strPickString3 = "";
                    }
                    if (!StringsKt.isBlank(strPickString2) && !StringsKt.isBlank(strPickString3)) {
                        String strPickString4 = pickString(jSONObjectOptJSONObject, "release");
                        if (strPickString4 == null) {
                            strPickString4 = "";
                        }
                        String strPickString5 = pickString(jSONObjectOptJSONObject, "image", "thumbnail");
                        if (strPickString5 == null) {
                            strPickString5 = "";
                        }
                        arrayList.add(new SearchItem(strPickString2, strPickString4, strPickString3, strPickString5));
                    }
                }
            }
            return new ParseResult<>(true, strPickString, arrayList);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Pair<Boolean, String> parseSendResponse(String raw) {
        Object objNextValue;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        if (objNextValue == null) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
        if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r6).toString())) {
            return TuplesKt.m787to(false, jSONObject.optString("message", "ارسال درخواست ناموفق بود"));
        }
        return TuplesKt.m787to(Boolean.valueOf(toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS))), pickString(jSONObject, "message"));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Triple<Integer, Integer, Integer> statusStyle(int status) {
        if (status == 1) {
            return new Triple<>(521282584, 1430184070, -10955126);
        }
        if (status == 2) {
            return new Triple<>(857673487, 1442802282, -25701);
        }
        return new Triple<>(337516296, 1173730066, -468598);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showState(String message, String buttonTitle, Function0<Unit> action) {
        TextView textView = this.stateText;
        LinearLayout linearLayout = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView = null;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت درخواست\u200cها"));
        this.stateAction = action;
        String str = buttonTitle;
        if (str == null || StringsKt.isBlank(str)) {
            TextView textView2 = this.stateButton;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView2 = null;
            }
            textView2.setVisibility(8);
        } else {
            TextView textView3 = this.stateButton;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView3 = null;
            }
            textView3.setVisibility(0);
            TextView textView4 = this.stateButton;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView4 = null;
            }
            textView4.setText(str);
        }
        LinearLayout linearLayout2 = this.stateOverlay;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
        } else {
            linearLayout = linearLayout2;
        }
        linearLayout.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void hideState() {
        LinearLayout linearLayout = this.stateOverlay;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        }
        linearLayout.setVisibility(8);
        this.stateAction = null;
    }

    private final FrameLayout makeLoadingMoreOverlay() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m384dp(12), m384dp(8), m384dp(12), m384dp(8));
        linearLayout.setBackground(roundedBg(-653454566, 654311423, m384dp(1), dpF(12)));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        TextView textView = new TextView(this.ctx);
        textView.setText("در حال بارگیری بیشتر...");
        textView.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        linearLayout.addView(progressBar, new LinearLayout.LayoutParams(m384dp(14), m384dp(14)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(m384dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 81;
        layoutParams2.bottomMargin = m384dp(18);
        Unit unit2 = Unit.INSTANCE;
        frameLayout.addView(linearLayout, layoutParams2);
        return frameLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showToast(String text) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(text, "عملیات انجام نشد"), 0).show();
    }

    private final boolean isLoggedIn() {
        if (this.sessionUserId > 0) {
            String str = this.sessionToken;
            if (!(str == null || StringsKt.isBlank(str))) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Map<String, String> authHeaders() {
        String str = this.sessionToken;
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        long j = this.sessionUserId;
        if (j > 0) {
            linkedHashMap.put("x-fk-user-id", String.valueOf(j));
        }
        String str2 = str;
        if (!(str2 == null || StringsKt.isBlank(str2))) {
            linkedHashMap.put("x-fk-session", str);
        }
        return linkedHashMap;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    private final String pickString(JSONObject obj, String... keys) {
        if (obj == null) {
            return null;
        }
        for (String str : keys) {
            Object objOpt = obj.opt(str);
            if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                if (!StringsKt.isBlank(string)) {
                    return string;
                }
            }
        }
        return null;
    }

    private final Long toLong(Object v) {
        if (v instanceof Number) {
            return Long.valueOf(((Number) v).longValue());
        }
        if (v instanceof String) {
            return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) StringsKt.replace$default((String) v, ",", "", false, 4, (Object) null)).toString());
        }
        return null;
    }

    private final Integer toInt(Object v) {
        if (v instanceof Number) {
            return Integer.valueOf(((Number) v).intValue());
        }
        if (v instanceof String) {
            return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
        }
        return null;
    }

    private final boolean toBool(Object v) {
        if (v instanceof Boolean) {
            return ((Boolean) v).booleanValue();
        }
        if (v instanceof Number) {
            if (((Number) v).intValue() != 0) {
                return true;
            }
        } else if (v instanceof String) {
            String string = StringsKt.trim((CharSequence) v).toString();
            Locale US = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US, "US");
            String lowerCase = string.toLowerCase(US);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, "1") || Intrinsics.areEqual(lowerCase, "true") || Intrinsics.areEqual(lowerCase, "ok") || Intrinsics.areEqual(lowerCase, FirebaseAnalytics.Param.SUCCESS)) {
                return true;
            }
        }
        return false;
    }

    private final JSONArray numericObjectToArray(JSONObject obj) {
        boolean z;
        Iterator<String> itKeys = obj.keys();
        JSONArray jSONArray = new JSONArray();
        boolean z2 = false;
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            Intrinsics.checkNotNull(next);
            String str = next;
            int i = 0;
            while (true) {
                if (i >= str.length()) {
                    z = true;
                    break;
                }
                if (!Character.isDigit(str.charAt(i))) {
                    z = false;
                    break;
                }
                i++;
            }
            if (z) {
                Object objOpt = obj.opt(next);
                if (objOpt instanceof JSONObject) {
                    jSONArray.put(objOpt);
                    z2 = true;
                }
            }
        }
        if (z2) {
            return jSONArray;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m384dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    private final ExecutorService ensureExecutorLocked() {
        if (this.executor.isShutdown() || this.executor.isTerminated()) {
            ExecutorService executorServiceNewSingleThreadExecutor = Executors.newSingleThreadExecutor();
            Intrinsics.checkNotNullExpressionValue(executorServiceNewSingleThreadExecutor, "newSingleThreadExecutor(...)");
            this.executor = executorServiceNewSingleThreadExecutor;
        }
        return this.executor;
    }

    private final boolean executeOnWorker(Runnable runBlock) {
        synchronized (this.executorLock) {
            boolean z = false;
            if (this.detached) {
                return false;
            }
            try {
                ensureExecutorLocked().execute(runBlock);
                z = true;
            } catch (Throwable unused) {
            }
            return z;
        }
    }

    private final boolean safeExecute(final Function0<Unit> block) {
        if (this.detached) {
            return false;
        }
        Runnable runnable = new Runnable() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                RequestsScreenView.safeExecute$lambda$69(this.f$0, block);
            }
        };
        if (executeOnWorker(runnable)) {
            return true;
        }
        if (this.detached) {
            return false;
        }
        return executeOnWorker(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void safeExecute$lambda$69(RequestsScreenView this$0, Function0 block) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(block, "$block");
        if (this$0.detached) {
            return;
        }
        block.invoke();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.detached = false;
        synchronized (this.executorLock) {
            ensureExecutorLocked();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        this.detached = true;
        Runnable runnable = this.searchDebounceRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        this.searchDebounceRunnable = null;
        this.pendingSearchQuery = null;
        synchronized (this.executorLock) {
            try {
                Result.Companion companion = Result.INSTANCE;
                RequestsScreenView requestsScreenView = this;
                Result.m7195constructorimpl(this.executor.shutdownNow());
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m7195constructorimpl(ResultKt.createFailure(th));
            }
        }
        super.onDetachedFromWindow();
    }

    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0015B\u001b\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\n\u001a\u00020\u000bH\u0016J \u0010\f\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016J\u0018\u0010\u0014\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestListAdapter$VH;", "Lcom/filmkio/nativescreen/account/RequestsScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestItem;", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/RequestsScreenView;Ljava/util/List;Z)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private final class RequestListAdapter extends RecyclerView.Adapter<C2677VH> {
        private final List<RequestItem> data;
        private final boolean isTouchDevice;
        final /* synthetic */ RequestsScreenView this$0;

        public RequestListAdapter(RequestsScreenView requestsScreenView, List<RequestItem> data, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = requestsScreenView;
            this.data = data;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2677VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            RequestsScreenView requestsScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(requestsScreenView.m384dp(12), requestsScreenView.m384dp(10), requestsScreenView.m384dp(12), requestsScreenView.m384dp(10));
            linearLayout.setBackground(requestsScreenView.roundedBg(requestsScreenView.cardFill, requestsScreenView.cardStroke, requestsScreenView.m384dp(1), requestsScreenView.dpF(12)));
            linearLayout.setClickable(false);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2677VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2677VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2677VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m384dp(10);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.RequestsScreenView$RequestListAdapter$VH */
        /* JADX INFO: compiled from: RequestsScreenView.kt */
        @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestListAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestListAdapter;Landroid/widget/LinearLayout;)V", "meta", "Landroid/widget/TextView;", "note", "statusChip", "title", "bind", "", "item", "Lcom/filmkio/nativescreen/account/RequestsScreenView$RequestItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2677VH extends RecyclerView.ViewHolder {
            private final TextView meta;
            private final TextView note;
            private final LinearLayout root;
            private final TextView statusChip;
            final /* synthetic */ RequestListAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2677VH(RequestListAdapter requestListAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = requestListAdapter;
                this.root = root;
                LinearLayout linearLayout = new LinearLayout(requestListAdapter.this$0.ctx);
                linearLayout.setOrientation(0);
                linearLayout.setLayoutDirection(0);
                linearLayout.setGravity(16);
                TextView textView = new TextView(requestListAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView = requestListAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(14.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(requestsScreenView.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setGravity(8388627);
                textView.setTextAlignment(5);
                textView.setTextDirection(3);
                textView.setMaxLines(1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                this.title = textView;
                TextView textView2 = new TextView(requestListAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView2 = requestListAdapter.this$0;
                textView2.setTextSize(11.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(requestsScreenView2.ctx);
                textView2.setTypeface(typefaceMedium == null ? textView2.getTypeface() : typefaceMedium);
                textView2.setGravity(17);
                textView2.setIncludeFontPadding(false);
                textView2.setPadding(requestsScreenView2.m384dp(10), requestsScreenView2.m384dp(4), requestsScreenView2.m384dp(10), requestsScreenView2.m384dp(4));
                this.statusChip = textView2;
                linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
                linearLayout.addView(textView2);
                TextView textView3 = new TextView(requestListAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView3 = requestListAdapter.this$0;
                textView3.setTextColor(-5324327);
                textView3.setTextSize(12.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(requestsScreenView3.ctx);
                textView3.setTypeface(typefaceRegular == null ? textView3.getTypeface() : typefaceRegular);
                textView3.setIncludeFontPadding(false);
                textView3.setMaxLines(3);
                textView3.setEllipsize(TextUtils.TruncateAt.END);
                this.meta = textView3;
                TextView textView4 = new TextView(requestListAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView4 = requestListAdapter.this$0;
                textView4.setTextColor(-7363139);
                textView4.setTextSize(11.0f);
                Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(requestsScreenView4.ctx);
                textView4.setTypeface(typefaceRegular2 == null ? textView4.getTypeface() : typefaceRegular2);
                textView4.setIncludeFontPadding(false);
                textView4.setMaxLines(2);
                textView4.setEllipsize(TextUtils.TruncateAt.END);
                textView4.setVisibility(8);
                this.note = textView4;
                root.addView(linearLayout);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = requestListAdapter.this$0.m384dp(8);
                Unit unit = Unit.INSTANCE;
                root.addView(textView3, layoutParams);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = requestListAdapter.this$0.m384dp(4);
                Unit unit2 = Unit.INSTANCE;
                root.addView(textView4, layoutParams2);
            }

            public final void bind(RequestItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.title.setText(item.getName());
                String release = item.getRelease();
                if (StringsKt.isBlank(release)) {
                    release = "-";
                }
                String str = release;
                String imdbId = item.getImdbId();
                this.meta.setText("IMDb: " + (StringsKt.isBlank(imdbId) ? "-" : imdbId) + "   •   سال: " + str + "   •   تاریخ: " + item.getCreatedAt());
                if (StringsKt.isBlank(item.getMessage())) {
                    this.note.setVisibility(8);
                } else {
                    this.note.setVisibility(0);
                    this.note.setText(SafeUserMessage.INSTANCE.fromRaw(item.getMessage(), "پیام جدید"));
                }
                Triple tripleStatusStyle = this.this$0.this$0.statusStyle(item.getStatus());
                this.statusChip.setText(this.this$0.this$0.statusLabel(item.getStatus()));
                this.statusChip.setTextColor(((Number) tripleStatusStyle.getThird()).intValue());
                this.statusChip.setBackground(this.this$0.this$0.roundedBg(((Number) tripleStatusStyle.getFirst()).intValue(), ((Number) tripleStatusStyle.getSecond()).intValue(), this.this$0.this$0.m384dp(1), this.this$0.this$0.dpF(999)));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: RequestsScreenView.kt */
    @Metadata(m779d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u001bB/\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0002\u0010\fJ\b\u0010\u000f\u001a\u00020\u0010H\u0016J \u0010\u0011\u001a\u00020\u000b2\u000e\u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u0010H\u0016J \u0010\u0014\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0010H\u0016J\u0018\u0010\u0018\u001a\u00020\u000b2\u000e\u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016J\u0010\u0010\u0019\u001a\u00020\u000b2\b\u0010\u001a\u001a\u0004\u0018\u00010\u000eR\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001c"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchResultAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchResultAdapter$VH;", "Lcom/filmkio/nativescreen/account/RequestsScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchItem;", "isTouchDevice", "", "onSelect", "Lkotlin/Function1;", "", "(Lcom/filmkio/nativescreen/account/RequestsScreenView;Ljava/util/List;ZLkotlin/jvm/functions/Function1;)V", "selectedImdbId", "", "getItemCount", "", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "setSelectedImdb", "imdbId", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class SearchResultAdapter extends RecyclerView.Adapter<C2678VH> {
        private final List<SearchItem> data;
        private final boolean isTouchDevice;
        private final Function1<SearchItem, Unit> onSelect;
        private String selectedImdbId;
        final /* synthetic */ RequestsScreenView this$0;

        /* JADX WARN: Multi-variable type inference failed */
        public SearchResultAdapter(RequestsScreenView requestsScreenView, List<SearchItem> data, boolean z, Function1<? super SearchItem, Unit> onSelect) {
            Intrinsics.checkNotNullParameter(data, "data");
            Intrinsics.checkNotNullParameter(onSelect, "onSelect");
            this.this$0 = requestsScreenView;
            this.data = data;
            this.isTouchDevice = z;
            this.onSelect = onSelect;
        }

        public final void setSelectedImdb(String imdbId) {
            String lowerCase;
            String string;
            if (imdbId == null || (string = StringsKt.trim((CharSequence) imdbId).toString()) == null) {
                lowerCase = null;
            } else {
                Locale US = Locale.US;
                Intrinsics.checkNotNullExpressionValue(US, "US");
                lowerCase = string.toLowerCase(US);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            }
            this.selectedImdbId = lowerCase;
            notifyDataSetChanged();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2678VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            RequestsScreenView requestsScreenView = this.this$0;
            linearLayout.setOrientation(0);
            linearLayout.setLayoutDirection(1);
            linearLayout.setGravity(16);
            linearLayout.setPadding(requestsScreenView.m384dp(8), requestsScreenView.m384dp(8), requestsScreenView.m384dp(8), requestsScreenView.m384dp(8));
            linearLayout.setBackground(requestsScreenView.roundedBg(319690014, 642669161, requestsScreenView.m384dp(1), requestsScreenView.dpF(10)));
            linearLayout.setClickable(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2678VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2678VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2678VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m384dp(8);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.RequestsScreenView$SearchResultAdapter$VH */
        /* JADX INFO: compiled from: RequestsScreenView.kt */
        @Metadata(m779d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, m780d2 = {"Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchResultAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchResultAdapter;Landroid/widget/LinearLayout;)V", "meta", "Landroid/widget/TextView;", "pick", "poster", "Landroid/widget/ImageView;", "title", "bind", "", "item", "Lcom/filmkio/nativescreen/account/RequestsScreenView$SearchItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2678VH extends RecyclerView.ViewHolder {
            private final TextView meta;
            private final TextView pick;
            private final ImageView poster;
            private final LinearLayout root;
            final /* synthetic */ SearchResultAdapter this$0;
            private final TextView title;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2678VH(SearchResultAdapter searchResultAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = searchResultAdapter;
                this.root = root;
                FrameLayout frameLayout = new FrameLayout(searchResultAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView = searchResultAdapter.this$0;
                frameLayout.setBackground(requestsScreenView.roundedBg(470684958, 709778025, requestsScreenView.m384dp(1), requestsScreenView.dpF(8)));
                frameLayout.setClipToOutline(true);
                ImageView imageView = new ImageView(searchResultAdapter.this$0.ctx);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setImageResource(C2629R.drawable.ic_panel_requests);
                imageView.setColorFilter(-2957330);
                this.poster = imageView;
                frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout linearLayout = new LinearLayout(searchResultAdapter.this$0.ctx);
                linearLayout.setOrientation(1);
                linearLayout.setLayoutDirection(1);
                linearLayout.setGravity(5);
                TextView textView = new TextView(searchResultAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView2 = searchResultAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(13.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(requestsScreenView2.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setGravity(5);
                textView.setTextAlignment(1);
                textView.setTextDirection(3);
                textView.setMaxLines(2);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                this.title = textView;
                TextView textView2 = new TextView(searchResultAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView3 = searchResultAdapter.this$0;
                textView2.setTextColor(-4798243);
                textView2.setTextSize(11.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(requestsScreenView3.ctx);
                textView2.setTypeface(typefaceRegular == null ? textView2.getTypeface() : typefaceRegular);
                textView2.setIncludeFontPadding(false);
                textView2.setGravity(5);
                textView2.setTextAlignment(1);
                textView2.setMaxLines(2);
                textView2.setEllipsize(TextUtils.TruncateAt.END);
                this.meta = textView2;
                linearLayout.addView(textView);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = searchResultAdapter.this$0.m384dp(4);
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(textView2, layoutParams);
                TextView textView3 = new TextView(searchResultAdapter.this$0.ctx);
                RequestsScreenView requestsScreenView4 = searchResultAdapter.this$0;
                textView3.setTextSize(11.0f);
                textView3.setGravity(17);
                Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(requestsScreenView4.ctx);
                textView3.setTypeface(typefaceBold2 == null ? textView3.getTypeface() : typefaceBold2);
                textView3.setIncludeFontPadding(false);
                textView3.setPadding(requestsScreenView4.m384dp(10), requestsScreenView4.m384dp(7), requestsScreenView4.m384dp(10), requestsScreenView4.m384dp(7));
                this.pick = textView3;
                root.addView(frameLayout, new LinearLayout.LayoutParams(searchResultAdapter.this$0.m384dp(52), searchResultAdapter.this$0.m384dp(74)));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                RequestsScreenView requestsScreenView5 = searchResultAdapter.this$0;
                layoutParams2.setMarginStart(requestsScreenView5.m384dp(8));
                layoutParams2.setMarginEnd(requestsScreenView5.m384dp(8));
                Unit unit2 = Unit.INSTANCE;
                root.addView(linearLayout, layoutParams2);
                root.addView(textView3);
            }

            public final void bind(final SearchItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                String str = this.this$0.selectedImdbId;
                String string = StringsKt.trim((CharSequence) item.getImdbId()).toString();
                Locale US = Locale.US;
                Intrinsics.checkNotNullExpressionValue(US, "US");
                String lowerCase = string.toLowerCase(US);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                boolean zAreEqual = Intrinsics.areEqual(str, lowerCase);
                this.title.setText(item.getName());
                String release = item.getRelease();
                if (StringsKt.isBlank(release)) {
                    release = "-";
                }
                String str2 = release;
                String imdbId = item.getImdbId();
                this.meta.setText("سال: " + str2 + "   •   IMDb: " + (StringsKt.isBlank(imdbId) ? "-" : imdbId));
                this.pick.setText(zAreEqual ? "انتخاب شده" : "انتخاب");
                this.pick.setTextColor(zAreEqual ? -16052459 : -2299660);
                this.pick.setBackground(this.this$0.this$0.roundedBg(zAreEqual ? this.this$0.this$0.accent : 437130526, zAreEqual ? 0 : 1157627903, this.this$0.this$0.m384dp(1), this.this$0.this$0.dpF(999)));
                this.root.setBackground(this.this$0.this$0.roundedBg(zAreEqual ? 488582722 : 319690014, zAreEqual ? -1997165295 : 642669161, this.this$0.this$0.m384dp(1), this.this$0.this$0.dpF(10)));
                if (!StringsKt.isBlank(item.getImageUrl())) {
                    this.poster.clearColorFilter();
                    ImageView imageView = this.poster;
                    String imageUrl = item.getImageUrl();
                    ImageLoader imageLoader = this.this$0.this$0.imageLoader;
                    RequestsScreenView requestsScreenView = this.this$0.this$0;
                    ImageRequest.Builder builderTarget = new ImageRequest.Builder(imageView.getContext()).data(imageUrl).target(imageView);
                    builderTarget.size(requestsScreenView.m384dp(52), requestsScreenView.m384dp(74));
                    builderTarget.allowHardware(true);
                    builderTarget.crossfade(false);
                    imageLoader.enqueue(builderTarget.build());
                } else {
                    this.poster.setImageResource(C2629R.drawable.ic_panel_requests);
                    this.poster.setColorFilter(-2957330);
                }
                LinearLayout linearLayout = this.root;
                final SearchResultAdapter searchResultAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.RequestsScreenView$SearchResultAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        RequestsScreenView.SearchResultAdapter.C2678VH.bind$lambda$11(searchResultAdapter, item, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$11(SearchResultAdapter this$0, SearchItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onSelect.invoke(item);
            }
        }
    }
}
