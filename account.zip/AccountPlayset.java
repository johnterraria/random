package com.filmkio.nativescreen.account;

import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012J&\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0014\u001a\u00020\u00122\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\u00042\u0006\u0010\u0017\u001a\u00020\u0001H\u0002J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0016H\u0002R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0007R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\t0\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0007R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\t0\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0007¨\u0006\u001b"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountPlayset;", "", "()V", "PLAY_QUALITIES", "", "Lcom/filmkio/nativescreen/account/QualityOption;", "getPLAY_QUALITIES", "()Ljava/util/List;", "SUB_BACKGROUNDS", "Lcom/filmkio/nativescreen/account/PlayOption;", "getSUB_BACKGROUNDS", "SUB_COLORS", "getSUB_COLORS", "SUB_SIZES", "getSUB_SIZES", "normalizePlayset", "Lcom/filmkio/nativescreen/account/PlaySetState;", "raw", "Lorg/json/JSONObject;", "pickAny", "obj", "keys", "", "fallback", "toQuality", "", "v", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AccountPlayset {
    public static final AccountPlayset INSTANCE = new AccountPlayset();
    private static final List<QualityOption> PLAY_QUALITIES = CollectionsKt.listOf((Object[]) new QualityOption[]{new QualityOption("1080", 0, 1080), new QualityOption("720", 1, 720), new QualityOption("480", 2, 480)});
    private static final List<PlayOption> SUB_SIZES = CollectionsKt.listOf((Object[]) new PlayOption[]{new PlayOption("کوچک", "18.1"), new PlayOption("متوسط", "28.96"), new PlayOption("بزرگ", "45"), new PlayOption("خیلی بزرگ", "65")});
    private static final List<PlayOption> SUB_COLORS = CollectionsKt.listOf((Object[]) new PlayOption[]{new PlayOption("سفید", "#FFFFFF"), new PlayOption("زرد", "#FFFF00"), new PlayOption("نیلی", "#00FFFF"), new PlayOption("سبز", "#00FF00")});
    private static final List<PlayOption> SUB_BACKGROUNDS = CollectionsKt.listOf((Object[]) new PlayOption[]{new PlayOption("بی\u200cرنگ", "none"), new PlayOption("تیره کم\u200cرنگ", "rgba(0, 0, 0, 0.5)"), new PlayOption("مشکی", "#000000")});
    public static final int $stable = 8;

    private AccountPlayset() {
    }

    public final List<QualityOption> getPLAY_QUALITIES() {
        return PLAY_QUALITIES;
    }

    public final List<PlayOption> getSUB_SIZES() {
        return SUB_SIZES;
    }

    public final List<PlayOption> getSUB_COLORS() {
        return SUB_COLORS;
    }

    public final List<PlayOption> getSUB_BACKGROUNDS() {
        return SUB_BACKGROUNDS;
    }

    public final PlaySetState normalizePlayset(JSONObject raw) {
        if (raw == null) {
            raw = new JSONObject();
        }
        return new PlaySetState(toQuality(pickAny(raw, CollectionsKt.listOf("quality"), "0").toString()), pickAny(raw, CollectionsKt.listOf((Object[]) new String[]{"size_subtitle", "subtitle_size"}), "28.96").toString(), pickAny(raw, CollectionsKt.listOf((Object[]) new String[]{"color_subtitle", "subtitle_color"}), "#FFFFFF").toString(), pickAny(raw, CollectionsKt.listOf((Object[]) new String[]{"bg_subtitle", "subtitle_bg"}), "rgba(0, 0, 0, 0.5)").toString());
    }

    private final int toQuality(String v) {
        Integer intOrNull = StringsKt.toIntOrNull(v);
        int iIntValue = intOrNull != null ? intOrNull.intValue() : 0;
        if (iIntValue != 1) {
            return iIntValue != 2 ? 0 : 2;
        }
        return 1;
    }

    private final Object pickAny(JSONObject obj, List<String> keys, Object fallback) {
        Iterator<String> it = keys.iterator();
        while (it.hasNext()) {
            Object objOpt = obj.opt(it.next());
            if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL) && (!StringsKt.isBlank(objOpt.toString()))) {
                return objOpt;
            }
        }
        return fallback;
    }
}
