package com.filmkio.nativescreen.account;

import androidx.autofill.HintConstants;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u001c\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001Be\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\b\u0012\b\u0010\n\u001a\u0004\u0018\u00010\b\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\b\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\b¢\u0006\u0002\u0010\u0010J\u000f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003HÆ\u0003J\u000b\u0010\u001f\u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010 \u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010!\u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\bHÆ\u0003J\t\u0010#\u001a\u00020\rHÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\bHÆ\u0003J{\u0010&\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u00032\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\b2\b\b\u0002\u0010\f\u001a\u00020\r2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\bHÆ\u0001J\u0013\u0010'\u001a\u00020\r2\b\u0010(\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010)\u001a\u00020*HÖ\u0001J\t\u0010+\u001a\u00020\bHÖ\u0001R\u0013\u0010\n\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0013\u0010\u000f\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0013\u0010\u000e\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0012R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0017R\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0013\u0010\t\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0012¨\u0006,"}, m780d2 = {"Lcom/filmkio/nativescreen/account/UserData;", "", "notifItems", "", "Lcom/filmkio/nativescreen/account/NotifItem;", "fields", "Lcom/filmkio/nativescreen/account/FieldItem;", HintConstants.AUTOFILL_HINT_GENDER, "", "userName", "displayName", "email", "subscriberStatus", "", "expaireDayLeft", "expaireDate", "(Ljava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V", "getDisplayName", "()Ljava/lang/String;", "getEmail", "getExpaireDate", "getExpaireDayLeft", "getFields", "()Ljava/util/List;", "getGender", "getNotifItems", "getSubscriberStatus", "()Z", "getUserName", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class UserData {
    public static final int $stable = 8;
    private final String displayName;
    private final String email;
    private final String expaireDate;
    private final String expaireDayLeft;
    private final List<FieldItem> fields;
    private final String gender;
    private final List<NotifItem> notifItems;
    private final boolean subscriberStatus;
    private final String userName;

    public final List<NotifItem> component1() {
        return this.notifItems;
    }

    public final List<FieldItem> component2() {
        return this.fields;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getGender() {
        return this.gender;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getUserName() {
        return this.userName;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getDisplayName() {
        return this.displayName;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getEmail() {
        return this.email;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final boolean getSubscriberStatus() {
        return this.subscriberStatus;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final String getExpaireDayLeft() {
        return this.expaireDayLeft;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final String getExpaireDate() {
        return this.expaireDate;
    }

    public final UserData copy(List<NotifItem> notifItems, List<FieldItem> fields, String gender, String userName, String displayName, String email, boolean subscriberStatus, String expaireDayLeft, String expaireDate) {
        Intrinsics.checkNotNullParameter(notifItems, "notifItems");
        Intrinsics.checkNotNullParameter(fields, "fields");
        return new UserData(notifItems, fields, gender, userName, displayName, email, subscriberStatus, expaireDayLeft, expaireDate);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UserData)) {
            return false;
        }
        UserData userData = (UserData) other;
        return Intrinsics.areEqual(this.notifItems, userData.notifItems) && Intrinsics.areEqual(this.fields, userData.fields) && Intrinsics.areEqual(this.gender, userData.gender) && Intrinsics.areEqual(this.userName, userData.userName) && Intrinsics.areEqual(this.displayName, userData.displayName) && Intrinsics.areEqual(this.email, userData.email) && this.subscriberStatus == userData.subscriberStatus && Intrinsics.areEqual(this.expaireDayLeft, userData.expaireDayLeft) && Intrinsics.areEqual(this.expaireDate, userData.expaireDate);
    }

    public int hashCode() {
        int iHashCode = ((this.notifItems.hashCode() * 31) + this.fields.hashCode()) * 31;
        String str = this.gender;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        String str2 = this.userName;
        int iHashCode3 = (iHashCode2 + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.displayName;
        int iHashCode4 = (iHashCode3 + (str3 == null ? 0 : str3.hashCode())) * 31;
        String str4 = this.email;
        int iHashCode5 = (((iHashCode4 + (str4 == null ? 0 : str4.hashCode())) * 31) + Boolean.hashCode(this.subscriberStatus)) * 31;
        String str5 = this.expaireDayLeft;
        int iHashCode6 = (iHashCode5 + (str5 == null ? 0 : str5.hashCode())) * 31;
        String str6 = this.expaireDate;
        return iHashCode6 + (str6 != null ? str6.hashCode() : 0);
    }

    public String toString() {
        return "UserData(notifItems=" + this.notifItems + ", fields=" + this.fields + ", gender=" + this.gender + ", userName=" + this.userName + ", displayName=" + this.displayName + ", email=" + this.email + ", subscriberStatus=" + this.subscriberStatus + ", expaireDayLeft=" + this.expaireDayLeft + ", expaireDate=" + this.expaireDate + ")";
    }

    public UserData(List<NotifItem> notifItems, List<FieldItem> fields, String str, String str2, String str3, String str4, boolean z, String str5, String str6) {
        Intrinsics.checkNotNullParameter(notifItems, "notifItems");
        Intrinsics.checkNotNullParameter(fields, "fields");
        this.notifItems = notifItems;
        this.fields = fields;
        this.gender = str;
        this.userName = str2;
        this.displayName = str3;
        this.email = str4;
        this.subscriberStatus = z;
        this.expaireDayLeft = str5;
        this.expaireDate = str6;
    }

    public final List<NotifItem> getNotifItems() {
        return this.notifItems;
    }

    public final List<FieldItem> getFields() {
        return this.fields;
    }

    public final String getGender() {
        return this.gender;
    }

    public final String getUserName() {
        return this.userName;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public final String getEmail() {
        return this.email;
    }

    public final boolean getSubscriberStatus() {
        return this.subscriberStatus;
    }

    public final String getExpaireDayLeft() {
        return this.expaireDayLeft;
    }

    public final String getExpaireDate() {
        return this.expaireDate;
    }
}
