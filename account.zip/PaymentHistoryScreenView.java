package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.filmkio.AppState;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.android.gms.actions.SearchIntents;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.Constants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\u0090\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000e\b\u0007\u0018\u0000 D2\u00020\u0001:\u0005DEFGHB'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\tJ\u0010\u0010+\u001a\u00020\u000b2\u0006\u0010,\u001a\u00020\u000bH\u0002J\u0010\u0010-\u001a\u00020.2\u0006\u0010,\u001a\u00020\u000bH\u0002J\b\u0010/\u001a\u00020\bH\u0002J\u0018\u00100\u001a\u00020\b2\u0006\u00101\u001a\u00020\u000b2\u0006\u00102\u001a\u00020\u0015H\u0002J\b\u00103\u001a\u00020\bH\u0002J\b\u00104\u001a\u00020\bH\u0014J0\u00105\u001a\u00020\u00052\u0012\u00106\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0005072\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u000507H\u0002J\b\u00109\u001a\u00020\bH\u0002J(\u0010:\u001a\u00020;2\u0006\u0010<\u001a\u00020\u000b2\u0006\u0010=\u001a\u00020\u000b2\u0006\u0010>\u001a\u00020\u000b2\u0006\u0010?\u001a\u00020.H\u0002J*\u0010@\u001a\u00020\b2\u0006\u0010A\u001a\u00020\u00052\b\u0010B\u001a\u0004\u0018\u00010\u00052\u000e\u0010C\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u0012\u0010\f\u001a\u00060\rR\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0011\u001a\n \u0013*\u0004\u0018\u00010\u00120\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0017\u001a\u0012\u0012\u0004\u0012\u00020\u00190\u0018j\b\u0012\u0004\u0012\u00020\u0019`\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020'X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020'X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006I"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "accent", "", "adapter", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryAdapter;", "cardFill", "cardStroke", "currentPage", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "hasMore", "", "isTouchDevice", FirebaseAnalytics.Param.ITEMS, "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryItem;", "Lkotlin/collections/ArrayList;", "list", "Landroidx/recyclerview/widget/RecyclerView;", "loading", "loadingMoreOverlay", "loadingView", "Landroid/widget/ProgressBar;", "mainHandler", "Landroid/os/Handler;", "sessionToken", "sessionUserId", "", "stateButton", "Landroid/widget/TextView;", "stateOverlay", "Landroid/widget/LinearLayout;", "stateText", "dp", "v", "dpF", "", "hideState", "loadPage", "page", "reset", "maybeLoadNext", "onDetachedFromWindow", "requestHistory", SearchIntents.EXTRA_QUERY, "", "headers", "resetAndLoad", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "showState", "message", "buttonText", "onClick", "Companion", "PaymentHistoryAdapter", "PaymentHistoryItem", "PaymentHistoryParser", "PaymentHistoryResult", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class PaymentHistoryScreenView extends FrameLayout {
    private static final int PER_PAGE = 20;
    private final int accent;
    private final PaymentHistoryAdapter adapter;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private final Context ctx;
    private int currentPage;
    private final ExecutorService executor;
    private boolean hasMore;
    private final boolean isTouchDevice;
    private final ArrayList<PaymentHistoryItem> items;
    private final RecyclerView list;
    private boolean loading;
    private final FrameLayout loadingMoreOverlay;
    private final ProgressBar loadingView;
    private final Handler mainHandler;
    private final Function0<Unit> onRequireLogin;
    private String sessionToken;
    private long sessionUserId;
    private final TextView stateButton;
    private final LinearLayout stateOverlay;
    private final TextView stateText;
    public static final int $stable = 8;

    public /* synthetic */ PaymentHistoryScreenView(Context context, String str, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PaymentHistoryScreenView(Context ctx, String apiBase, Function0<Unit> function0) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.hasMore = true;
        this.currentPage = 1;
        ArrayList<PaymentHistoryItem> arrayList = new ArrayList<>();
        this.items = arrayList;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        PaymentHistoryAdapter paymentHistoryAdapter = new PaymentHistoryAdapter(this, arrayList, zHasSystemFeature);
        this.adapter = paymentHistoryAdapter;
        RecyclerView recyclerView = new RecyclerView(ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx, 1, false));
        recyclerView.setAdapter(paymentHistoryAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(m382dp(14), m382dp(14), m382dp(14), m382dp(90));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$1$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 4) {
                    return;
                }
                this.this$0.maybeLoadNext();
            }
        });
        this.list = recyclerView;
        addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(-676591);
        }
        progressBar.setVisibility(8);
        this.loadingView = progressBar;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        Unit unit = Unit.INSTANCE;
        addView(progressBar, layoutParams);
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m382dp(12), m382dp(8), m382dp(12), m382dp(8));
        linearLayout.setBackground(roundedBg(-653454566, 654311423, m382dp(1), dpF(12)));
        ProgressBar progressBar2 = new ProgressBar(ctx);
        progressBar2.setIndeterminate(true);
        Drawable indeterminateDrawable2 = progressBar2.getIndeterminateDrawable();
        if (indeterminateDrawable2 != null) {
            indeterminateDrawable2.setTint(-676591);
        }
        TextView textView = new TextView(ctx);
        textView.setText("در حال بارگیری بیشتر...");
        textView.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        textView.setGravity(16);
        textView.setIncludeFontPadding(false);
        linearLayout.addView(progressBar2, new LinearLayout.LayoutParams(m382dp(14), m382dp(14)));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMarginStart(m382dp(8));
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams2);
        FrameLayout frameLayout = new FrameLayout(ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        this.loadingMoreOverlay = frameLayout;
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 81;
        layoutParams3.bottomMargin = m382dp(18);
        Unit unit3 = Unit.INSTANCE;
        frameLayout.addView(linearLayout, layoutParams3);
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout2 = new LinearLayout(ctx);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(17);
        linearLayout2.setVisibility(8);
        linearLayout2.setPadding(m382dp(24), m382dp(24), m382dp(24), m382dp(24));
        this.stateOverlay = linearLayout2;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-419430401);
        textView2.setTextSize(15.0f);
        textView2.setGravity(17);
        Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(ctx);
        textView2.setTypeface(typefaceMedium2 == null ? textView2.getTypeface() : typefaceMedium2);
        this.stateText = textView2;
        TextView textView3 = new TextView(ctx);
        textView3.setText("تلاش دوباره");
        textView3.setTextColor(-16052459);
        textView3.setTextSize(14.0f);
        textView3.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView3.setTypeface(typefaceBold == null ? textView3.getTypeface() : typefaceBold);
        textView3.setPadding(m382dp(16), m382dp(10), m382dp(16), m382dp(10));
        textView3.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView3.setFocusable(!zHasSystemFeature);
        textView3.setFocusableInTouchMode(!zHasSystemFeature);
        this.stateButton = textView3;
        linearLayout2.addView(textView2);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.topMargin = m382dp(12);
        Unit unit4 = Unit.INSTANCE;
        linearLayout2.addView(textView3, layoutParams4);
        addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        if (this.sessionUserId <= 0) {
            showState("برای مشاهده سوابق پرداخت، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView.11
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = PaymentHistoryScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else {
            resetAndLoad();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetAndLoad() {
        int size = this.items.size();
        this.items.clear();
        if (size > 0) {
            this.adapter.notifyItemRangeRemoved(0, size);
        }
        this.currentPage = 1;
        this.hasMore = true;
        loadPage(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNext() {
        if (this.loading || !this.hasMore) {
            return;
        }
        loadPage(this.currentPage + 1, false);
    }

    private final void loadPage(final int page, final boolean reset) {
        if (!this.loading && this.sessionUserId > 0) {
            this.loading = true;
            if (reset) {
                this.loadingView.setVisibility(0);
                this.loadingMoreOverlay.setVisibility(8);
            } else {
                this.loadingMoreOverlay.setVisibility(0);
            }
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    PaymentHistoryScreenView.loadPage$lambda$17(this.f$0, page, reset);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$17(final PaymentHistoryScreenView this$0, final int i, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            linkedHashMap.put("userID", String.valueOf(this$0.sessionUserId));
            linkedHashMap.put("page", String.valueOf(i));
            linkedHashMap.put("perPage", "20");
            linkedHashMap.put("per_page", "20");
            LinkedHashMap linkedHashMap2 = new LinkedHashMap();
            String str = this$0.sessionToken;
            String str2 = str;
            if (!(str2 == null || StringsKt.isBlank(str2))) {
                linkedHashMap2.put("x-fk-user-id", String.valueOf(this$0.sessionUserId));
                linkedHashMap2.put("x-fk-session", str);
            }
            final PaymentHistoryResult paymentHistoryResult = PaymentHistoryParser.INSTANCE.parse(this$0.requestHistory(linkedHashMap, linkedHashMap2), i, 20);
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    PaymentHistoryScreenView.loadPage$lambda$17$lambda$15(this.f$0, paymentHistoryResult, z, i);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    PaymentHistoryScreenView.loadPage$lambda$17$lambda$16(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$17$lambda$15(final PaymentHistoryScreenView this$0, PaymentHistoryResult parsed, boolean z, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        if (!parsed.getOk()) {
            this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت سوابق پرداخت"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$loadPage$1$1$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoad();
                }
            });
            return;
        }
        if (z) {
            int size = this$0.items.size();
            this$0.items.clear();
            if (size > 0) {
                this$0.adapter.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.items.size();
        this$0.items.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            this$0.adapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentPage = RangesKt.coerceAtLeast(parsed.getPage(), i);
        this$0.hasMore = parsed.getHasMore();
        if (this$0.items.isEmpty()) {
            this$0.showState("هنوز تراکنشی ثبت نشده است.", "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$loadPage$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoad();
                }
            });
        } else {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadPage$lambda$17$lambda$16(final PaymentHistoryScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        boolean z = false;
        this$0.loading = false;
        this$0.loadingView.setVisibility(8);
        this$0.loadingMoreOverlay.setVisibility(8);
        if (e instanceof FkApiClient.ApiException) {
            FkApiClient.ApiException apiException = (FkApiClient.ApiException) e;
            if (apiException.getCode() == 401 || apiException.getCode() == 403) {
                z = true;
            }
        }
        if (z || this$0.sessionUserId <= 0) {
            this$0.showState("برای مشاهده سوابق پرداخت، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$loadPage$1$2$1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function0 = this.this$0.onRequireLogin;
                    if (function0 != null) {
                        function0.invoke();
                    }
                }
            });
        } else {
            this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت سوابق پرداخت"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$loadPage$1$2$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetAndLoad();
                }
            });
        }
    }

    private final String requestHistory(Map<String, String> query, Map<String, String> headers) {
        Iterator it = CollectionsKt.listOf((Object[]) new String[]{"/paymentHistory", "/payment_history", "/purchaseHistory"}).iterator();
        FkApiClient.ApiException th = null;
        while (it.hasNext()) {
            try {
                return FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this.apiBase, (String) it.next(), "GET", query, headers, null, false, 96, null);
            } finally {
                th = th;
            }
        }
        if (th == null) {
            throw new RuntimeException("Endpoint not available");
        }
        throw th;
    }

    private final void showState(String message, String buttonText, final Function0<Unit> onClick) {
        this.stateText.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت سوابق پرداخت"));
        String str = buttonText;
        if (str == null || StringsKt.isBlank(str)) {
            this.stateButton.setVisibility(8);
            this.stateButton.setOnClickListener(null);
        } else {
            this.stateButton.setVisibility(0);
            this.stateButton.setText(str);
            this.stateButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.PaymentHistoryScreenView$$ExternalSyntheticLambda2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    PaymentHistoryScreenView.showState$lambda$18(onClick, view);
                }
            });
        }
        this.stateOverlay.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showState$lambda$18(Function0 function0, View view) {
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final void hideState() {
        this.stateOverlay.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m382dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }

    /* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0015B\u001b\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ\b\u0010\n\u001a\u00020\u000bH\u0016J \u0010\f\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016J\u0018\u0010\u0014\u001a\u00020\r2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryAdapter$VH;", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryItem;", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView;Ljava/util/List;Z)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private final class PaymentHistoryAdapter extends RecyclerView.Adapter<C2669VH> {
        private final List<PaymentHistoryItem> data;
        private final boolean isTouchDevice;
        final /* synthetic */ PaymentHistoryScreenView this$0;

        public PaymentHistoryAdapter(PaymentHistoryScreenView paymentHistoryScreenView, List<PaymentHistoryItem> data, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = paymentHistoryScreenView;
            this.data = data;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2669VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            PaymentHistoryScreenView paymentHistoryScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(paymentHistoryScreenView.m382dp(12), paymentHistoryScreenView.m382dp(10), paymentHistoryScreenView.m382dp(12), paymentHistoryScreenView.m382dp(10));
            linearLayout.setBackground(paymentHistoryScreenView.roundedBg(paymentHistoryScreenView.cardFill, paymentHistoryScreenView.cardStroke, paymentHistoryScreenView.m382dp(1), paymentHistoryScreenView.dpF(12)));
            linearLayout.setClickable(false);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2669VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2669VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2669VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m382dp(10);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.PaymentHistoryScreenView$PaymentHistoryAdapter$VH */
        /* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
        @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryAdapter;Landroid/widget/LinearLayout;)V", "amountText", "Landroid/widget/TextView;", "metaText", "paymentNo", "statusChip", "bind", "", "item", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2669VH extends RecyclerView.ViewHolder {
            private final TextView amountText;
            private final TextView metaText;
            private final TextView paymentNo;
            private final LinearLayout root;
            private final TextView statusChip;
            final /* synthetic */ PaymentHistoryAdapter this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2669VH(PaymentHistoryAdapter paymentHistoryAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = paymentHistoryAdapter;
                this.root = root;
                LinearLayout linearLayout = new LinearLayout(paymentHistoryAdapter.this$0.ctx);
                linearLayout.setOrientation(0);
                linearLayout.setLayoutDirection(1);
                linearLayout.setGravity(16);
                TextView textView = new TextView(paymentHistoryAdapter.this$0.ctx);
                PaymentHistoryScreenView paymentHistoryScreenView = paymentHistoryAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(14.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(paymentHistoryScreenView.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                this.paymentNo = textView;
                TextView textView2 = new TextView(paymentHistoryAdapter.this$0.ctx);
                PaymentHistoryScreenView paymentHistoryScreenView2 = paymentHistoryAdapter.this$0;
                textView2.setTextSize(11.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(paymentHistoryScreenView2.ctx);
                textView2.setTypeface(typefaceMedium == null ? textView2.getTypeface() : typefaceMedium);
                textView2.setGravity(17);
                textView2.setIncludeFontPadding(false);
                textView2.setPadding(paymentHistoryScreenView2.m382dp(10), paymentHistoryScreenView2.m382dp(4), paymentHistoryScreenView2.m382dp(10), paymentHistoryScreenView2.m382dp(4));
                this.statusChip = textView2;
                linearLayout.addView(textView);
                linearLayout.addView(new View(paymentHistoryAdapter.this$0.ctx), new LinearLayout.LayoutParams(0, 1, 1.0f));
                linearLayout.addView(textView2);
                TextView textView3 = new TextView(paymentHistoryAdapter.this$0.ctx);
                PaymentHistoryScreenView paymentHistoryScreenView3 = paymentHistoryAdapter.this$0;
                textView3.setTextColor(paymentHistoryScreenView3.accent);
                textView3.setTextSize(14.0f);
                Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(paymentHistoryScreenView3.ctx);
                textView3.setTypeface(typefaceBold2 == null ? textView3.getTypeface() : typefaceBold2);
                textView3.setIncludeFontPadding(false);
                this.amountText = textView3;
                TextView textView4 = new TextView(paymentHistoryAdapter.this$0.ctx);
                PaymentHistoryScreenView paymentHistoryScreenView4 = paymentHistoryAdapter.this$0;
                textView4.setTextColor(-5324327);
                textView4.setTextSize(12.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(paymentHistoryScreenView4.ctx);
                textView4.setTypeface(typefaceRegular == null ? textView4.getTypeface() : typefaceRegular);
                textView4.setIncludeFontPadding(false);
                textView4.setLineSpacing(paymentHistoryScreenView4.m382dp(1), 1.0f);
                this.metaText = textView4;
                root.addView(linearLayout);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = paymentHistoryAdapter.this$0.m382dp(8);
                Unit unit = Unit.INSTANCE;
                root.addView(textView3, layoutParams);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = paymentHistoryAdapter.this$0.m382dp(6);
                Unit unit2 = Unit.INSTANCE;
                root.addView(textView4, layoutParams2);
            }

            public final void bind(PaymentHistoryItem item) {
                Triple triple;
                Intrinsics.checkNotNullParameter(item, "item");
                this.paymentNo.setText(item.getPaymentNo());
                this.amountText.setText("مبلغ پرداختی: " + item.getPriceText());
                this.metaText.setText("کد تراکنش: " + item.getGatewayCode() + "   •   تاریخ: " + item.getDateText());
                String statusKey = item.getStatusKey();
                if (Intrinsics.areEqual(statusKey, "accepted")) {
                    triple = new Triple(521282584, 1430184070, -10955126);
                } else {
                    triple = Intrinsics.areEqual(statusKey, "rejected") ? new Triple(857673487, 1442802282, -25701) : new Triple(337516296, 1173730066, -468598);
                }
                this.statusChip.setText(item.getStatusLabel());
                this.statusChip.setTextColor(((Number) triple.getThird()).intValue());
                this.statusChip.setBackground(this.this$0.this$0.roundedBg(((Number) triple.getFirst()).intValue(), ((Number) triple.getSecond()).intValue(), this.this$0.this$0.m382dp(1), this.this$0.this$0.dpF(999)));
            }
        }
    }

    /* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005¢\u0006\u0002\u0010\u000bJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003JO\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020!HÖ\u0001J\t\u0010\"\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\rR\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\r¨\u0006#"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryItem;", "", TtmlNode.ATTR_ID, "", "paymentNo", "", "priceText", "gatewayCode", "statusKey", "statusLabel", "dateText", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getDateText", "()Ljava/lang/String;", "getGatewayCode", "getId", "()J", "getPaymentNo", "getPriceText", "getStatusKey", "getStatusLabel", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class PaymentHistoryItem {
        private final String dateText;
        private final String gatewayCode;
        private final long id;
        private final String paymentNo;
        private final String priceText;
        private final String statusKey;
        private final String statusLabel;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getPaymentNo() {
            return this.paymentNo;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final String getPriceText() {
            return this.priceText;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getGatewayCode() {
            return this.gatewayCode;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getStatusKey() {
            return this.statusKey;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getStatusLabel() {
            return this.statusLabel;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final String getDateText() {
            return this.dateText;
        }

        public final PaymentHistoryItem copy(long id, String paymentNo, String priceText, String gatewayCode, String statusKey, String statusLabel, String dateText) {
            Intrinsics.checkNotNullParameter(paymentNo, "paymentNo");
            Intrinsics.checkNotNullParameter(priceText, "priceText");
            Intrinsics.checkNotNullParameter(gatewayCode, "gatewayCode");
            Intrinsics.checkNotNullParameter(statusKey, "statusKey");
            Intrinsics.checkNotNullParameter(statusLabel, "statusLabel");
            Intrinsics.checkNotNullParameter(dateText, "dateText");
            return new PaymentHistoryItem(id, paymentNo, priceText, gatewayCode, statusKey, statusLabel, dateText);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PaymentHistoryItem)) {
                return false;
            }
            PaymentHistoryItem paymentHistoryItem = (PaymentHistoryItem) other;
            return this.id == paymentHistoryItem.id && Intrinsics.areEqual(this.paymentNo, paymentHistoryItem.paymentNo) && Intrinsics.areEqual(this.priceText, paymentHistoryItem.priceText) && Intrinsics.areEqual(this.gatewayCode, paymentHistoryItem.gatewayCode) && Intrinsics.areEqual(this.statusKey, paymentHistoryItem.statusKey) && Intrinsics.areEqual(this.statusLabel, paymentHistoryItem.statusLabel) && Intrinsics.areEqual(this.dateText, paymentHistoryItem.dateText);
        }

        public int hashCode() {
            return (((((((((((Long.hashCode(this.id) * 31) + this.paymentNo.hashCode()) * 31) + this.priceText.hashCode()) * 31) + this.gatewayCode.hashCode()) * 31) + this.statusKey.hashCode()) * 31) + this.statusLabel.hashCode()) * 31) + this.dateText.hashCode();
        }

        public String toString() {
            return "PaymentHistoryItem(id=" + this.id + ", paymentNo=" + this.paymentNo + ", priceText=" + this.priceText + ", gatewayCode=" + this.gatewayCode + ", statusKey=" + this.statusKey + ", statusLabel=" + this.statusLabel + ", dateText=" + this.dateText + ")";
        }

        public PaymentHistoryItem(long j, String paymentNo, String priceText, String gatewayCode, String statusKey, String statusLabel, String dateText) {
            Intrinsics.checkNotNullParameter(paymentNo, "paymentNo");
            Intrinsics.checkNotNullParameter(priceText, "priceText");
            Intrinsics.checkNotNullParameter(gatewayCode, "gatewayCode");
            Intrinsics.checkNotNullParameter(statusKey, "statusKey");
            Intrinsics.checkNotNullParameter(statusLabel, "statusLabel");
            Intrinsics.checkNotNullParameter(dateText, "dateText");
            this.id = j;
            this.paymentNo = paymentNo;
            this.priceText = priceText;
            this.gatewayCode = gatewayCode;
            this.statusKey = statusKey;
            this.statusLabel = statusLabel;
            this.dateText = dateText;
        }

        public final long getId() {
            return this.id;
        }

        public final String getPaymentNo() {
            return this.paymentNo;
        }

        public final String getPriceText() {
            return this.priceText;
        }

        public final String getGatewayCode() {
            return this.gatewayCode;
        }

        public final String getStatusKey() {
            return this.statusKey;
        }

        public final String getStatusLabel() {
            return this.statusLabel;
        }

        public final String getDateText() {
            return this.dateText;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0016\b\u0082\b\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\u0003¢\u0006\u0002\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\t\u0010\u0019\u001a\u00020\nHÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003JC\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u00032\b\u0010\u001d\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001e\u001a\u00020\nHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006 "}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryResult;", "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryItem;", "page", "", "hasMore", "(ZLjava/lang/String;Ljava/util/List;IZ)V", "getHasMore", "()Z", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "getPage", "()I", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class PaymentHistoryResult {
        private final boolean hasMore;
        private final List<PaymentHistoryItem> items;
        private final String message;
        private final boolean ok;
        private final int page;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ PaymentHistoryResult copy$default(PaymentHistoryResult paymentHistoryResult, boolean z, String str, List list, int i, boolean z2, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                z = paymentHistoryResult.ok;
            }
            if ((i2 & 2) != 0) {
                str = paymentHistoryResult.message;
            }
            String str2 = str;
            if ((i2 & 4) != 0) {
                list = paymentHistoryResult.items;
            }
            List list2 = list;
            if ((i2 & 8) != 0) {
                i = paymentHistoryResult.page;
            }
            int i3 = i;
            if ((i2 & 16) != 0) {
                z2 = paymentHistoryResult.hasMore;
            }
            return paymentHistoryResult.copy(z, str2, list2, i3, z2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<PaymentHistoryItem> component3() {
            return this.items;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getPage() {
            return this.page;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final boolean getHasMore() {
            return this.hasMore;
        }

        public final PaymentHistoryResult copy(boolean ok, String message, List<PaymentHistoryItem> items, int page, boolean hasMore) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new PaymentHistoryResult(ok, message, items, page, hasMore);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PaymentHistoryResult)) {
                return false;
            }
            PaymentHistoryResult paymentHistoryResult = (PaymentHistoryResult) other;
            return this.ok == paymentHistoryResult.ok && Intrinsics.areEqual(this.message, paymentHistoryResult.message) && Intrinsics.areEqual(this.items, paymentHistoryResult.items) && this.page == paymentHistoryResult.page && this.hasMore == paymentHistoryResult.hasMore;
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            return ((((((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode()) * 31) + Integer.hashCode(this.page)) * 31) + Boolean.hashCode(this.hasMore);
        }

        public String toString() {
            return "PaymentHistoryResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ", page=" + this.page + ", hasMore=" + this.hasMore + ")";
        }

        public PaymentHistoryResult(boolean z, String str, List<PaymentHistoryItem> items, int i, boolean z2) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
            this.page = i;
            this.hasMore = z2;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public final List<PaymentHistoryItem> getItems() {
            return this.items;
        }

        public final int getPage() {
            return this.page;
        }

        public final boolean getHasMore() {
            return this.hasMore;
        }
    }

    /* JADX INFO: compiled from: PaymentHistoryScreenView.kt */
    @Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\bÂ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0002J \u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\u00042\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000bJ-\u0010\r\u001a\u0004\u0018\u00010\u00042\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0012\u0010\u0010\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0011\"\u00020\u0004H\u0002¢\u0006\u0002\u0010\u0012J\u0012\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001H\u0002J\u0019\u0010\u0016\u001a\u0004\u0018\u00010\u000b2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0017J\u0019\u0010\u0018\u001a\u0004\u0018\u00010\u00062\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001H\u0002¢\u0006\u0002\u0010\u0019¨\u0006\u001a"}, m780d2 = {"Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryParser;", "", "()V", "formatToman", "", "value", "", "parse", "Lcom/filmkio/nativescreen/account/PaymentHistoryScreenView$PaymentHistoryResult;", "json", "requestedPage", "", "perPage", "pickString", "obj", "Lorg/json/JSONObject;", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "toBool", "", "v", "toInt", "(Ljava/lang/Object;)Ljava/lang/Integer;", "toLong", "(Ljava/lang/Object;)Ljava/lang/Long;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class PaymentHistoryParser {
        public static final PaymentHistoryParser INSTANCE = new PaymentHistoryParser();

        private PaymentHistoryParser() {
        }

        /* JADX WARN: Removed duplicated region for block: B:107:0x021e  */
        /* JADX WARN: Removed duplicated region for block: B:113:0x0230  */
        /* JADX WARN: Removed duplicated region for block: B:116:0x0244  */
        /* JADX WARN: Removed duplicated region for block: B:117:0x0247  */
        /* JADX WARN: Removed duplicated region for block: B:120:0x0250  */
        /* JADX WARN: Removed duplicated region for block: B:121:0x0253  */
        /* JADX WARN: Removed duplicated region for block: B:149:0x02cd  */
        /* JADX WARN: Removed duplicated region for block: B:150:0x02cf  */
        /* JADX WARN: Removed duplicated region for block: B:65:0x0130  */
        /* JADX WARN: Removed duplicated region for block: B:68:0x013d  */
        /* JADX WARN: Removed duplicated region for block: B:69:0x0147  */
        /* JADX WARN: Removed duplicated region for block: B:72:0x015a  */
        /* JADX WARN: Removed duplicated region for block: B:75:0x0163  */
        /* JADX WARN: Removed duplicated region for block: B:78:0x017a  */
        /* JADX WARN: Removed duplicated region for block: B:79:0x0190  */
        /* JADX WARN: Removed duplicated region for block: B:82:0x01bb  */
        /* JADX WARN: Removed duplicated region for block: B:85:0x01c5  */
        /* JADX WARN: Removed duplicated region for block: B:88:0x01d4  */
        /* JADX WARN: Removed duplicated region for block: B:89:0x01d9  */
        /* JADX WARN: Removed duplicated region for block: B:92:0x01e0  */
        /* JADX WARN: Removed duplicated region for block: B:93:0x01e5  */
        /* JADX WARN: Removed duplicated region for block: B:99:0x0202  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final PaymentHistoryResult parse(String json, int requestedPage, int perPage) {
            boolean bool;
            boolean z;
            long j;
            String str;
            String strPickString;
            Long l;
            JSONArray jSONArray;
            int i;
            long j2;
            String strPickString2;
            String str2;
            String strPickString3;
            String str3;
            Integer num;
            int iIntValue;
            String strPickString4;
            String strPickString5;
            String str4;
            String str5 = json;
            if (str5 == null || StringsKt.isBlank(str5)) {
                return new PaymentHistoryResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
            try {
                Object objNextValue = new JSONTokener(json).nextValue();
                JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
                if (jSONObject == null) {
                    return new PaymentHistoryResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
                }
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                if (jSONObjectOptJSONObject == null) {
                    jSONObjectOptJSONObject = jSONObject;
                }
                String strPickString6 = pickString(jSONObject, "message", NotificationCompat.CATEGORY_MESSAGE);
                if (strPickString6 == null) {
                    strPickString6 = pickString(jSONObjectOptJSONObject, "message", NotificationCompat.CATEGORY_MESSAGE);
                }
                String str6 = strPickString6;
                boolean z2 = toBool(jSONObject.opt("flag")) || toBool(jSONObject.opt(FirebaseAnalytics.Param.SUCCESS)) || jSONObject.opt("flag") == null;
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS);
                if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = jSONObject.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null && (jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("transactions")) == null) {
                    jSONArrayOptJSONArray = jSONObject.optJSONArray("transactions");
                }
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                ArrayList arrayList = new ArrayList(jSONArrayOptJSONArray.length());
                int length = jSONArrayOptJSONArray.length();
                int i2 = 0;
                while (i2 < length) {
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i2);
                    if (jSONObjectOptJSONObject2 == null) {
                        z = z2;
                        jSONArray = jSONArrayOptJSONArray;
                        i = length;
                    } else {
                        Long l2 = toLong(jSONObjectOptJSONObject2.opt(TtmlNode.ATTR_ID));
                        if (l2 == null && (l2 = toLong(jSONObjectOptJSONObject2.opt("ID"))) == null) {
                            z = z2;
                            j = 0;
                        } else {
                            long jLongValue = l2.longValue();
                            z = z2;
                            j = jLongValue;
                        }
                        String strPickString7 = pickString(jSONObjectOptJSONObject2, "paymentNo", "payment_no");
                        if (strPickString7 != null) {
                            str = strPickString7;
                            strPickString = pickString(jSONObjectOptJSONObject2, "priceFormatted", "price_formatted");
                            if (strPickString == null) {
                                strPickString = "";
                            }
                            l = toLong(jSONObjectOptJSONObject2.opt(FirebaseAnalytics.Param.PRICE));
                            if (l != null) {
                                long jLongValue2 = l.longValue();
                                jSONArray = jSONArrayOptJSONArray;
                                i = length;
                                j2 = jLongValue2;
                            } else {
                                jSONArray = jSONArrayOptJSONArray;
                                i = length;
                                j2 = 0;
                            }
                            strPickString2 = pickString(jSONObjectOptJSONObject2, FirebaseAnalytics.Param.CURRENCY);
                            if (strPickString2 == null) {
                                strPickString2 = "";
                            }
                            str2 = strPickString2;
                            if (StringsKt.isBlank(str2)) {
                                str2 = "تومان";
                            }
                            String str7 = str2;
                            String str8 = StringsKt.isBlank(strPickString) ^ true ? strPickString + " " + str7 : formatToman(j2) + " " + str7;
                            strPickString3 = pickString(jSONObjectOptJSONObject2, "gatewayCode", "gateway_id", "code");
                            if (strPickString3 == null) {
                                strPickString3 = "";
                            }
                            str3 = strPickString3;
                            if (StringsKt.isBlank(str3)) {
                                str3 = "-";
                            }
                            String str9 = str3;
                            JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2.optJSONObject(NotificationCompat.CATEGORY_STATUS);
                            num = toInt(jSONObjectOptJSONObject3 != null ? jSONObjectOptJSONObject3.opt("code") : null);
                            if (num != null) {
                                iIntValue = num.intValue();
                            } else {
                                Integer num2 = toInt(jSONObjectOptJSONObject2.opt(NotificationCompat.CATEGORY_STATUS));
                                iIntValue = num2 != null ? num2.intValue() : 0;
                            }
                            strPickString4 = pickString(jSONObjectOptJSONObject3, "key");
                            if (strPickString4 == null) {
                                strPickString4 = iIntValue != 1 ? iIntValue != 3 ? "pending" : "rejected" : "accepted";
                            }
                            String str10 = strPickString4;
                            strPickString5 = pickString(jSONObjectOptJSONObject3, Constants.ScionAnalytics.PARAM_LABEL);
                            if (strPickString5 == null) {
                                str4 = iIntValue != 1 ? iIntValue != 3 ? "در حال بررسی" : "ناموفق" : "موفق";
                            } else {
                                str4 = strPickString5;
                            }
                            String strPickString8 = pickString(jSONObjectOptJSONObject2, "createdAtText", "dateText", "createdAt", "created_at");
                            String str11 = strPickString8 == null ? "" : strPickString8;
                            arrayList.add(new PaymentHistoryItem(j, str, str8, str9, str10, str4, StringsKt.isBlank(str11) ? "-" : str11));
                        } else if (j > 0) {
                            strPickString7 = "#" + j;
                            str = strPickString7;
                            strPickString = pickString(jSONObjectOptJSONObject2, "priceFormatted", "price_formatted");
                            if (strPickString == null) {
                            }
                            l = toLong(jSONObjectOptJSONObject2.opt(FirebaseAnalytics.Param.PRICE));
                            if (l != null) {
                            }
                            strPickString2 = pickString(jSONObjectOptJSONObject2, FirebaseAnalytics.Param.CURRENCY);
                            if (strPickString2 == null) {
                            }
                            str2 = strPickString2;
                            if (StringsKt.isBlank(str2)) {
                            }
                            String str72 = str2;
                            String str82 = StringsKt.isBlank(strPickString) ^ true ? strPickString + " " + str72 : formatToman(j2) + " " + str72;
                            strPickString3 = pickString(jSONObjectOptJSONObject2, "gatewayCode", "gateway_id", "code");
                            if (strPickString3 == null) {
                            }
                            str3 = strPickString3;
                            if (StringsKt.isBlank(str3)) {
                            }
                            String str92 = str3;
                            JSONObject jSONObjectOptJSONObject32 = jSONObjectOptJSONObject2.optJSONObject(NotificationCompat.CATEGORY_STATUS);
                            num = toInt(jSONObjectOptJSONObject32 != null ? jSONObjectOptJSONObject32.opt("code") : null);
                            if (num != null) {
                            }
                            strPickString4 = pickString(jSONObjectOptJSONObject32, "key");
                            if (strPickString4 == null) {
                            }
                            String str102 = strPickString4;
                            strPickString5 = pickString(jSONObjectOptJSONObject32, Constants.ScionAnalytics.PARAM_LABEL);
                            if (strPickString5 == null) {
                            }
                            String strPickString82 = pickString(jSONObjectOptJSONObject2, "createdAtText", "dateText", "createdAt", "created_at");
                            String str112 = strPickString82 == null ? "" : strPickString82;
                            arrayList.add(new PaymentHistoryItem(j, str, str82, str92, str102, str4, StringsKt.isBlank(str112) ? "-" : str112));
                        } else {
                            str = "-";
                            strPickString = pickString(jSONObjectOptJSONObject2, "priceFormatted", "price_formatted");
                            if (strPickString == null) {
                            }
                            l = toLong(jSONObjectOptJSONObject2.opt(FirebaseAnalytics.Param.PRICE));
                            if (l != null) {
                            }
                            strPickString2 = pickString(jSONObjectOptJSONObject2, FirebaseAnalytics.Param.CURRENCY);
                            if (strPickString2 == null) {
                            }
                            str2 = strPickString2;
                            if (StringsKt.isBlank(str2)) {
                            }
                            String str722 = str2;
                            String str822 = StringsKt.isBlank(strPickString) ^ true ? strPickString + " " + str722 : formatToman(j2) + " " + str722;
                            strPickString3 = pickString(jSONObjectOptJSONObject2, "gatewayCode", "gateway_id", "code");
                            if (strPickString3 == null) {
                            }
                            str3 = strPickString3;
                            if (StringsKt.isBlank(str3)) {
                            }
                            String str922 = str3;
                            JSONObject jSONObjectOptJSONObject322 = jSONObjectOptJSONObject2.optJSONObject(NotificationCompat.CATEGORY_STATUS);
                            num = toInt(jSONObjectOptJSONObject322 != null ? jSONObjectOptJSONObject322.opt("code") : null);
                            if (num != null) {
                            }
                            strPickString4 = pickString(jSONObjectOptJSONObject322, "key");
                            if (strPickString4 == null) {
                            }
                            String str1022 = strPickString4;
                            strPickString5 = pickString(jSONObjectOptJSONObject322, Constants.ScionAnalytics.PARAM_LABEL);
                            if (strPickString5 == null) {
                            }
                            String strPickString822 = pickString(jSONObjectOptJSONObject2, "createdAtText", "dateText", "createdAt", "created_at");
                            String str1122 = strPickString822 == null ? "" : strPickString822;
                            arrayList.add(new PaymentHistoryItem(j, str, str822, str922, str1022, str4, StringsKt.isBlank(str1122) ? "-" : str1122));
                        }
                    }
                    i2++;
                    z2 = z;
                    jSONArrayOptJSONArray = jSONArray;
                    length = i;
                }
                boolean z3 = z2;
                JSONObject jSONObjectOptJSONObject4 = jSONObjectOptJSONObject.optJSONObject("pagination");
                if (jSONObjectOptJSONObject4 == null) {
                    jSONObjectOptJSONObject4 = jSONObject.optJSONObject("pagination");
                }
                Integer num3 = toInt(jSONObjectOptJSONObject4 != null ? jSONObjectOptJSONObject4.opt("page") : null);
                int iIntValue2 = num3 != null ? num3.intValue() : requestedPage;
                if (jSONObjectOptJSONObject4 != null && jSONObjectOptJSONObject4.has("hasMore")) {
                    bool = toBool(jSONObjectOptJSONObject4.opt("hasMore"));
                } else if (jSONObjectOptJSONObject4 != null && jSONObjectOptJSONObject4.has("totalPages")) {
                    Integer num4 = toInt(jSONObjectOptJSONObject4.opt("totalPages"));
                    if (iIntValue2 < (num4 != null ? num4.intValue() : 1)) {
                    }
                } else {
                    bool = arrayList.size() >= perPage;
                }
                if (!z3 && arrayList.isEmpty()) {
                    if (str6 == null) {
                        str6 = "خطا در دریافت اطلاعات";
                    }
                    return new PaymentHistoryResult(false, str6, CollectionsKt.emptyList(), iIntValue2, false);
                }
                return new PaymentHistoryResult(true, str6, arrayList, iIntValue2, bool);
            } catch (Throwable unused) {
                return new PaymentHistoryResult(false, "پاسخ نامعتبر است", CollectionsKt.emptyList(), requestedPage, false);
            }
        }

        private final String pickString(JSONObject obj, String... keys) {
            if (obj == null) {
                return null;
            }
            for (String str : keys) {
                Object objOpt = obj.opt(str);
                if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                    String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                    if (!StringsKt.isBlank(string)) {
                        return string;
                    }
                }
            }
            return null;
        }

        private final Long toLong(Object v) {
            if (v instanceof Number) {
                return Long.valueOf(((Number) v).longValue());
            }
            if (v instanceof String) {
                return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) StringsKt.replace$default((String) v, ",", "", false, 4, (Object) null)).toString());
            }
            return null;
        }

        private final Integer toInt(Object v) {
            if (v instanceof Number) {
                return Integer.valueOf(((Number) v).intValue());
            }
            if (v instanceof String) {
                return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
            }
            return null;
        }

        private final boolean toBool(Object v) {
            if (v instanceof Boolean) {
                return ((Boolean) v).booleanValue();
            }
            if (v instanceof Number) {
                if (((Number) v).intValue() == 0) {
                    return false;
                }
            } else {
                if (!(v instanceof String)) {
                    return false;
                }
                if (!Intrinsics.areEqual(v, "1")) {
                    String str = (String) v;
                    if (!StringsKt.equals(str, "true", true) && !StringsKt.equals(str, "ok", true) && !StringsKt.equals(str, FirebaseAnalytics.Param.SUCCESS, true)) {
                        return false;
                    }
                }
            }
            return true;
        }

        private final String formatToman(long value) {
            return new Regex("\\B(?=(\\d{3})+(?!\\d))").replace(String.valueOf(Math.max(0L, value)), ",");
        }
    }
}
