package com.filmkio.nativescreen.account;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.media3.extractor.text.ttml.TtmlNode;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.filmkio.AppState;
import com.filmkio.Session;
import com.filmkio.SessionStore;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.account.TicketSupportScreenView;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/* JADX INFO: compiled from: TicketSupportScreenView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000ò\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010$\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u0000\n\u0002\b\r\b\u0007\u0018\u0000 ª\u00012\u00020\u0001:\u0010ª\u0001«\u0001¬\u0001\u00ad\u0001®\u0001¯\u0001°\u0001±\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007¢\u0006\u0002\u0010\tJ\u0010\u0010V\u001a\u00020\b2\u0006\u0010W\u001a\u00020/H\u0002J\u0014\u0010X\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050YH\u0002J\b\u0010Z\u001a\u00020\bH\u0002J\b\u0010[\u001a\u00020\bH\u0002J\b\u0010\\\u001a\u00020\bH\u0002J\u0010\u0010]\u001a\u00020\u00052\u0006\u0010^\u001a\u00020\u000bH\u0002J\u0010\u0010_\u001a\u00020\u000b2\u0006\u0010`\u001a\u00020\u000bH\u0002J\u0010\u0010a\u001a\u00020\u00122\u0006\u0010`\u001a\u00020\u000bH\u0002J\u0006\u0010b\u001a\u00020\u001aJ\u0012\u0010c\u001a\u00020\b2\b\b\u0002\u0010d\u001a\u00020\u001aH\u0002J\b\u0010e\u001a\u00020\bH\u0002J\b\u0010f\u001a\u00020\u001aH\u0002J \u0010g\u001a\u00020\b2\u0006\u0010h\u001a\u00020F2\u0006\u0010i\u001a\u00020\u000b2\u0006\u0010j\u001a\u00020\u001aH\u0002J\u0018\u0010k\u001a\u00020\b2\u0006\u0010i\u001a\u00020\u000b2\u0006\u0010j\u001a\u00020\u001aH\u0002J\u0010\u0010l\u001a\u00020?2\u0006\u0010m\u001a\u00020\u0005H\u0002J\b\u0010n\u001a\u00020\u0001H\u0002J\u0010\u0010o\u001a\u00020/2\u0006\u0010p\u001a\u00020\u0005H\u0002J\u0010\u0010q\u001a\u00020/2\u0006\u0010p\u001a\u00020\u0005H\u0002J\u0010\u0010r\u001a\u00020/2\u0006\u0010p\u001a\u00020\u0005H\u0002J\b\u0010s\u001a\u00020\bH\u0002J\b\u0010t\u001a\u00020\bH\u0002J\u0012\u0010u\u001a\u0004\u0018\u00010v2\u0006\u0010w\u001a\u00020xH\u0002J\b\u0010y\u001a\u00020\bH\u0014J\u0010\u0010z\u001a\u00020\b2\u0006\u0010{\u001a\u00020\rH\u0002J0\u0010|\u001a\u0018\u0012\u0004\u0012\u00020\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u0001020}2\b\u0010~\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u007f\u001a\u00020\u0005H\u0002J\"\u0010\u0080\u0001\u001a\u0011\u0012\u0004\u0012\u00020\u001a\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0081\u00012\b\u0010~\u001a\u0004\u0018\u00010\u0005H\u0002J\u001a\u0010\u0082\u0001\u001a\t\u0012\u0004\u0012\u00020\r0\u0083\u00012\b\u0010~\u001a\u0004\u0018\u00010\u0005H\u0002J\u001a\u0010\u0084\u0001\u001a\t\u0012\u0004\u0012\u0002020\u0083\u00012\b\u0010~\u001a\u0004\u0018\u00010\u0005H\u0002J1\u0010\u0085\u0001\u001a\u0004\u0018\u00010\u00052\b\u0010w\u001a\u0004\u0018\u00010x2\u0014\u0010\u0086\u0001\u001a\u000b\u0012\u0006\b\u0001\u0012\u00020\u00050\u0087\u0001\"\u00020\u0005H\u0002¢\u0006\u0003\u0010\u0088\u0001J\t\u0010\u0089\u0001\u001a\u00020\bH\u0002J\u0011\u0010\u008a\u0001\u001a\u00020\b2\u0006\u0010h\u001a\u00020FH\u0002J\t\u0010\u008b\u0001\u001a\u00020\bH\u0002J\t\u0010\u008c\u0001\u001a\u00020\u000bH\u0002J.\u0010\u008d\u0001\u001a\u00030\u008e\u00012\u0007\u0010\u008f\u0001\u001a\u00020\u000b2\u0007\u0010\u0090\u0001\u001a\u00020\u000b2\u0007\u0010\u0091\u0001\u001a\u00020\u000b2\u0007\u0010\u0092\u0001\u001a\u00020\u0012H\u0002J\u0012\u0010\u0093\u0001\u001a\u00020\b2\u0007\u0010\u0094\u0001\u001a\u00020\u001aH\u0002J\u0012\u0010\u0095\u0001\u001a\u00020\b2\u0007\u0010\u0094\u0001\u001a\u00020\u001aH\u0002J\t\u0010\u0096\u0001\u001a\u00020\bH\u0002J.\u0010\u0097\u0001\u001a\u00020\b2\u0007\u0010\u0098\u0001\u001a\u00020\u00052\t\u0010\u0099\u0001\u001a\u0004\u0018\u00010\u00052\u000f\u0010\u009a\u0001\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007H\u0002J\u0012\u0010\u009b\u0001\u001a\u00020\b2\u0007\u0010\u009c\u0001\u001a\u00020\u0005H\u0002J\t\u0010\u009d\u0001\u001a\u00020\bH\u0002J\t\u0010\u009e\u0001\u001a\u00020\bH\u0002J\u0012\u0010\u009f\u0001\u001a\u00020\b2\u0007\u0010 \u0001\u001a\u00020<H\u0002J\u0012\u0010¡\u0001\u001a\u00020\u00052\u0007\u0010¢\u0001\u001a\u00020\u000bH\u0002J$\u0010£\u0001\u001a\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u000b0}2\u0007\u0010¢\u0001\u001a\u00020\u000bH\u0002J\u0014\u0010¤\u0001\u001a\u00020\u001a2\t\u0010`\u001a\u0005\u0018\u00010¥\u0001H\u0002J\u001c\u0010¦\u0001\u001a\u0004\u0018\u00010\u000b2\t\u0010`\u001a\u0005\u0018\u00010¥\u0001H\u0002¢\u0006\u0003\u0010§\u0001J\u001c\u0010¨\u0001\u001a\u0004\u0018\u00010F2\t\u0010`\u001a\u0005\u0018\u00010¥\u0001H\u0002¢\u0006\u0003\u0010©\u0001R\u000e\u0010\n\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010!\u001a\n #*\u0004\u0018\u00010\"0\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020-X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020/X\u0082.¢\u0006\u0002\n\u0000R\u001e\u00100\u001a\u0012\u0012\u0004\u0012\u00020201j\b\u0012\u0004\u0012\u000202`3X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u00104\u001a\u000605R\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u000207X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020<X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020/X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u000bX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010D\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020FX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010G\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010H\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\u0015X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020?X\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010O\u001a\u0012\u0012\u0004\u0012\u00020\r01j\b\u0012\u0004\u0012\u00020\r`3X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010P\u001a\u00060QR\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010R\u001a\u000207X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010S\u001a\u00020\u0001X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010T\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010U\u001a\u00020/X\u0082.¢\u0006\u0002\n\u0000¨\u0006²\u0001"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "apiBase", "", "onRequireLogin", "Lkotlin/Function0;", "", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "accent", "", "activeTicket", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketItem;", "cardFill", "cardStroke", "createContainer", "createDragStartRawY", "", "createDragStartTranslation", "createFormContent", "Landroid/widget/LinearLayout;", "createSheetCard", "createSheetScrim", "Landroid/view/View;", "createSheetShown", "", "currentMessagePage", "currentTicketPage", "departChipWrap", "departOptions", "", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$DepartOption;", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "fieldFill", "fieldStroke", "hasMoreMessages", "hasMoreTickets", "isTouchDevice", "listContainer", "loadingMessages", "loadingTickets", "mainHandler", "Landroid/os/Handler;", "messageInput", "Landroidx/appcompat/widget/AppCompatEditText;", "messageItems", "Ljava/util/ArrayList;", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessage;", "Lkotlin/collections/ArrayList;", "messagesAdapter", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessageAdapter;", "messagesLoading", "Landroid/widget/ProgressBar;", "messagesLoadingMoreOverlay", "messagesRecycler", "Landroidx/recyclerview/widget/RecyclerView;", "mode", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$Mode;", "replyInput", "replySendButton", "Landroid/widget/TextView;", "screenFill", "selectedDepartId", "sendingReply", "sendingTicket", "sessionToken", "sessionUserId", "", "stateAction", "stateButton", "stateOverlay", "stateText", "submitButton", "threadContainer", "threadMeta", "threadTitle", "ticketItems", "ticketsAdapter", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketListAdapter;", "ticketsLoading", "ticketsLoadingMoreOverlay", "ticketsRecycler", "titleInput", "applyLoginLikeFieldStyle", "field", "authHeaders", "", "buildCreateContainer", "buildListContainer", "buildThreadContainer", "departLabel", "depart", "dp", "v", "dpF", "handleBackPressed", "hideCreateSheet", "animated", "hideState", "isLoggedIn", "loadMessages", "ticketId", "page", "reset", "loadTickets", "makeFieldLabel", "title", "makeLoadingMoreOverlay", "makeMultiLineInput", "hint", "makeReplyInput", "makeSingleLineInput", "maybeLoadNextMessages", "maybeLoadNextTickets", "numericObjectToArray", "Lorg/json/JSONArray;", "obj", "Lorg/json/JSONObject;", "onDetachedFromWindow", "openTicketThread", "item", "parseResponseTicketResponse", "Lkotlin/Triple;", "raw", "fallbackText", "parseSendTicketResponse", "Lkotlin/Pair;", "parseTicketListResponse", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$ParseResult;", "parseTicketMessageResponse", "pickString", "keys", "", "(Lorg/json/JSONObject;[Ljava/lang/String;)Ljava/lang/String;", "rebuildDepartChips", "resetMessagesAndLoad", "resetTicketsAndLoad", "resolveCreateSheetHeight", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "setReplyLoading", "loading", "setSubmitLoading", "showCreateSheet", "showState", "message", "buttonTitle", "action", "showToast", "text", "submitReply", "submitTicket", "switchMode", "next", "ticketStatusLabel", NotificationCompat.CATEGORY_STATUS, "ticketStatusStyle", "toBool", "", "toInt", "(Ljava/lang/Object;)Ljava/lang/Integer;", "toLong", "(Ljava/lang/Object;)Ljava/lang/Long;", "Companion", "DepartOption", "Mode", "ParseResult", "TicketItem", "TicketListAdapter", "TicketMessage", "TicketMessageAdapter", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class TicketSupportScreenView extends FrameLayout {
    private static final int MESSAGES_PER_PAGE = 20;
    private static final int TICKETS_PER_PAGE = 20;
    private final int accent;
    private TicketItem activeTicket;
    private final String apiBase;
    private final int cardFill;
    private final int cardStroke;
    private FrameLayout createContainer;
    private float createDragStartRawY;
    private float createDragStartTranslation;
    private LinearLayout createFormContent;
    private LinearLayout createSheetCard;
    private View createSheetScrim;
    private boolean createSheetShown;
    private final Context ctx;
    private int currentMessagePage;
    private int currentTicketPage;
    private LinearLayout departChipWrap;
    private final List<DepartOption> departOptions;
    private final ExecutorService executor;
    private final int fieldFill;
    private final int fieldStroke;
    private boolean hasMoreMessages;
    private boolean hasMoreTickets;
    private final boolean isTouchDevice;
    private LinearLayout listContainer;
    private boolean loadingMessages;
    private boolean loadingTickets;
    private final Handler mainHandler;
    private AppCompatEditText messageInput;
    private final ArrayList<TicketMessage> messageItems;
    private TicketMessageAdapter messagesAdapter;
    private ProgressBar messagesLoading;
    private FrameLayout messagesLoadingMoreOverlay;
    private RecyclerView messagesRecycler;
    private Mode mode;
    private final Function0<Unit> onRequireLogin;
    private AppCompatEditText replyInput;
    private TextView replySendButton;
    private final int screenFill;
    private int selectedDepartId;
    private boolean sendingReply;
    private boolean sendingTicket;
    private String sessionToken;
    private long sessionUserId;
    private Function0<Unit> stateAction;
    private TextView stateButton;
    private LinearLayout stateOverlay;
    private TextView stateText;
    private TextView submitButton;
    private LinearLayout threadContainer;
    private TextView threadMeta;
    private TextView threadTitle;
    private final ArrayList<TicketItem> ticketItems;
    private TicketListAdapter ticketsAdapter;
    private ProgressBar ticketsLoading;
    private FrameLayout ticketsLoadingMoreOverlay;
    private RecyclerView ticketsRecycler;
    private AppCompatEditText titleInput;
    public static final int $stable = 8;

    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m781k = 3, m782mv = {1, 9, 0}, m784xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Mode.values().length];
            try {
                iArr[Mode.LIST.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Mode.CREATE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Mode.THREAD.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$25$lambda$24(View view) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$32$lambda$31(View view) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String ticketStatusLabel(int status) {
        return status != 1 ? status != 2 ? status != 3 ? status != 4 ? "نامشخص" : "بسته شده" : "پاسخ داده شده" : "در حال پیگیری" : "باز";
    }

    public /* synthetic */ TicketSupportScreenView(Context context, String str, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, str, (i & 4) != 0 ? null : function0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TicketSupportScreenView(Context ctx, String apiBase, Function0<Unit> function0) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(apiBase, "apiBase");
        this.ctx = ctx;
        this.apiBase = apiBase;
        this.onRequireLogin = function0;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newSingleThreadExecutor();
        boolean zHasSystemFeature = ctx.getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        this.isTouchDevice = zHasSystemFeature;
        this.accent = -676591;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        this.screenFill = -16315632;
        this.fieldFill = -15854306;
        this.fieldStroke = 860772969;
        List<DepartOption> listListOf = CollectionsKt.listOf((Object[]) new DepartOption[]{new DepartOption(1, "پشتیبانی فنی"), new DepartOption(2, "مالی"), new DepartOption(3, "سایر")});
        this.departOptions = listListOf;
        this.selectedDepartId = ((DepartOption) CollectionsKt.first((List) listListOf)).getId();
        this.mode = Mode.LIST;
        this.currentTicketPage = 1;
        this.currentMessagePage = 1;
        this.hasMoreTickets = true;
        this.hasMoreMessages = true;
        this.ticketItems = new ArrayList<>();
        this.messageItems = new ArrayList<>();
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        Session session = AppState.INSTANCE.getSession();
        if (session == null) {
            session = SessionStore.INSTANCE.load(ctx);
            AppState.INSTANCE.setSession(session);
        }
        this.sessionUserId = session != null ? session.getUserId() : 0L;
        FrameLayout frameLayout = null;
        this.sessionToken = session != null ? session.getSessionToken() : null;
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setPadding(m385dp(14), m385dp(10), m385dp(14), m385dp(10));
        addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout2 = new FrameLayout(ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams.topMargin = m385dp(8);
        frameLayout2.setLayoutParams(layoutParams);
        linearLayout.addView(frameLayout2);
        buildListContainer();
        buildCreateContainer();
        buildThreadContainer();
        LinearLayout linearLayout2 = this.listContainer;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout2 = null;
        }
        frameLayout2.addView(linearLayout2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout3 = this.threadContainer;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadContainer");
            linearLayout3 = null;
        }
        frameLayout2.addView(linearLayout3, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setGravity(17);
        linearLayout4.setVisibility(8);
        linearLayout4.setPadding(m385dp(24), m385dp(24), m385dp(24), m385dp(24));
        linearLayout4.setBackground(roundedBg(-922285296, 0, 0, dpF(0)));
        this.stateOverlay = linearLayout4;
        TextView textView = new TextView(ctx);
        textView.setTextColor(-419430401);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView.setTypeface(typefaceMedium == null ? textView.getTypeface() : typefaceMedium);
        this.stateText = textView;
        TextView textView2 = new TextView(ctx);
        textView2.setTextColor(-16052459);
        textView2.setTextSize(14.0f);
        textView2.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView2.setTypeface(typefaceBold == null ? textView2.getTypeface() : typefaceBold);
        textView2.setPadding(m385dp(16), m385dp(10), m385dp(16), m385dp(10));
        textView2.setBackground(roundedBg(-676591, 0, 0, dpF(12)));
        textView2.setFocusable(!zHasSystemFeature);
        textView2.setFocusableInTouchMode(!zHasSystemFeature);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TicketSupportScreenView.lambda$7$lambda$6(this.f$0, view);
            }
        });
        this.stateButton = textView2;
        LinearLayout linearLayout5 = this.stateOverlay;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout5 = null;
        }
        TextView textView3 = this.stateText;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView3 = null;
        }
        linearLayout5.addView(textView3);
        LinearLayout linearLayout6 = this.stateOverlay;
        if (linearLayout6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout6 = null;
        }
        TextView textView4 = this.stateButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateButton");
            textView4 = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = m385dp(12);
        Unit unit = Unit.INSTANCE;
        linearLayout6.addView(textView4, layoutParams2);
        LinearLayout linearLayout7 = this.stateOverlay;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout7 = null;
        }
        frameLayout2.addView(linearLayout7, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
        } else {
            frameLayout = frameLayout3;
        }
        addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        switchMode(Mode.LIST);
        if (!isLoggedIn()) {
            showState("برای پشتیبانی، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView.5
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Function0 function02 = TicketSupportScreenView.this.onRequireLogin;
                    if (function02 != null) {
                        function02.invoke();
                    }
                }
            });
        } else {
            resetTicketsAndLoad();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$Mode;", "", "(Ljava/lang/String;I)V", "LIST", "CREATE", "THREAD", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final class Mode {
        private static final /* synthetic */ EnumEntries $ENTRIES;
        private static final /* synthetic */ Mode[] $VALUES;
        public static final Mode LIST = new Mode("LIST", 0);
        public static final Mode CREATE = new Mode("CREATE", 1);
        public static final Mode THREAD = new Mode("THREAD", 2);

        private static final /* synthetic */ Mode[] $values() {
            return new Mode[]{LIST, CREATE, THREAD};
        }

        public static EnumEntries<Mode> getEntries() {
            return $ENTRIES;
        }

        public static Mode valueOf(String str) {
            return (Mode) Enum.valueOf(Mode.class, str);
        }

        public static Mode[] values() {
            return (Mode[]) $VALUES.clone();
        }

        private Mode(String str, int i) {
        }

        static {
            Mode[] modeArr$values = $values();
            $VALUES = modeArr$values;
            $ENTRIES = EnumEntriesKt.enumEntries(modeArr$values);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J;\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0007HÖ\u0001J\t\u0010\u001d\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\f¨\u0006\u001e"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketItem;", "", TtmlNode.ATTR_ID, "", "title", "", NotificationCompat.CATEGORY_STATUS, "", "depart", "createdAt", "(JLjava/lang/String;IILjava/lang/String;)V", "getCreatedAt", "()Ljava/lang/String;", "getDepart", "()I", "getId", "()J", "getStatus", "getTitle", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class TicketItem {
        private final String createdAt;
        private final int depart;
        private final long id;
        private final int status;
        private final String title;

        public static /* synthetic */ TicketItem copy$default(TicketItem ticketItem, long j, String str, int i, int i2, String str2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                j = ticketItem.id;
            }
            long j2 = j;
            if ((i3 & 2) != 0) {
                str = ticketItem.title;
            }
            String str3 = str;
            if ((i3 & 4) != 0) {
                i = ticketItem.status;
            }
            int i4 = i;
            if ((i3 & 8) != 0) {
                i2 = ticketItem.depart;
            }
            int i5 = i2;
            if ((i3 & 16) != 0) {
                str2 = ticketItem.createdAt;
            }
            return ticketItem.copy(j2, str3, i4, i5, str2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getTitle() {
            return this.title;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getStatus() {
            return this.status;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getDepart() {
            return this.depart;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final String getCreatedAt() {
            return this.createdAt;
        }

        public final TicketItem copy(long id, String title, int status, int depart, String createdAt) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            return new TicketItem(id, title, status, depart, createdAt);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TicketItem)) {
                return false;
            }
            TicketItem ticketItem = (TicketItem) other;
            return this.id == ticketItem.id && Intrinsics.areEqual(this.title, ticketItem.title) && this.status == ticketItem.status && this.depart == ticketItem.depart && Intrinsics.areEqual(this.createdAt, ticketItem.createdAt);
        }

        public int hashCode() {
            return (((((((Long.hashCode(this.id) * 31) + this.title.hashCode()) * 31) + Integer.hashCode(this.status)) * 31) + Integer.hashCode(this.depart)) * 31) + this.createdAt.hashCode();
        }

        public String toString() {
            return "TicketItem(id=" + this.id + ", title=" + this.title + ", status=" + this.status + ", depart=" + this.depart + ", createdAt=" + this.createdAt + ")";
        }

        public TicketItem(long j, String title, int i, int i2, String createdAt) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            this.id = j;
            this.title = title;
            this.status = i;
            this.depart = i2;
            this.createdAt = createdAt;
        }

        public final long getId() {
            return this.id;
        }

        public final String getTitle() {
            return this.title;
        }

        public final int getStatus() {
            return this.status;
        }

        public final int getDepart() {
            return this.depart;
        }

        public final String getCreatedAt() {
            return this.createdAt;
        }
    }

    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0005¢\u0006\u0002\u0010\bJ\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J1\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\f¨\u0006\u001a"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessage;", "", TtmlNode.ATTR_ID, "", "text", "", "userId", "createdAt", "(JLjava/lang/String;JLjava/lang/String;)V", "getCreatedAt", "()Ljava/lang/String;", "getId", "()J", "getText", "getUserId", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class TicketMessage {
        private final String createdAt;
        private final long id;
        private final String text;
        private final long userId;

        public static /* synthetic */ TicketMessage copy$default(TicketMessage ticketMessage, long j, String str, long j2, String str2, int i, Object obj) {
            if ((i & 1) != 0) {
                j = ticketMessage.id;
            }
            long j3 = j;
            if ((i & 2) != 0) {
                str = ticketMessage.text;
            }
            String str3 = str;
            if ((i & 4) != 0) {
                j2 = ticketMessage.userId;
            }
            long j4 = j2;
            if ((i & 8) != 0) {
                str2 = ticketMessage.createdAt;
            }
            return ticketMessage.copy(j3, str3, j4, str2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final long getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getText() {
            return this.text;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final long getUserId() {
            return this.userId;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getCreatedAt() {
            return this.createdAt;
        }

        public final TicketMessage copy(long id, String text, long userId, String createdAt) {
            Intrinsics.checkNotNullParameter(text, "text");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            return new TicketMessage(id, text, userId, createdAt);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TicketMessage)) {
                return false;
            }
            TicketMessage ticketMessage = (TicketMessage) other;
            return this.id == ticketMessage.id && Intrinsics.areEqual(this.text, ticketMessage.text) && this.userId == ticketMessage.userId && Intrinsics.areEqual(this.createdAt, ticketMessage.createdAt);
        }

        public int hashCode() {
            return (((((Long.hashCode(this.id) * 31) + this.text.hashCode()) * 31) + Long.hashCode(this.userId)) * 31) + this.createdAt.hashCode();
        }

        public String toString() {
            return "TicketMessage(id=" + this.id + ", text=" + this.text + ", userId=" + this.userId + ", createdAt=" + this.createdAt + ")";
        }

        public TicketMessage(long j, String text, long j2, String createdAt) {
            Intrinsics.checkNotNullParameter(text, "text");
            Intrinsics.checkNotNullParameter(createdAt, "createdAt");
            this.id = j;
            this.text = text;
            this.userId = j2;
            this.createdAt = createdAt;
        }

        public final long getId() {
            return this.id;
        }

        public final String getText() {
            return this.text;
        }

        public final long getUserId() {
            return this.userId;
        }

        public final String getCreatedAt() {
            return this.createdAt;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0002\b\u0082\b\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B)\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\u0002\u0010\tJ\t\u0010\u0010\u001a\u00020\u0004HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0006HÆ\u0003J\u000f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\bHÆ\u0003J5\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\b\b\u0002\u0010\u0003\u001a\u00020\u00042\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\bHÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00042\b\u0010\u0015\u001a\u0004\u0018\u00010\u0002HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0006HÖ\u0001R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\b¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$ParseResult;", ExifInterface.GPS_DIRECTION_TRUE, "", "ok", "", "message", "", FirebaseAnalytics.Param.ITEMS, "", "(ZLjava/lang/String;Ljava/util/List;)V", "getItems", "()Ljava/util/List;", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "component1", "component2", "component3", "copy", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class ParseResult<T> {
        private final List<T> items;
        private final String message;
        private final boolean ok;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, boolean z, String str, List list, int i, Object obj) {
            if ((i & 1) != 0) {
                z = parseResult.ok;
            }
            if ((i & 2) != 0) {
                str = parseResult.message;
            }
            if ((i & 4) != 0) {
                list = parseResult.items;
            }
            return parseResult.copy(z, str, list);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final List<T> component3() {
            return this.items;
        }

        public final ParseResult<T> copy(boolean ok, String message, List<? extends T> items) {
            Intrinsics.checkNotNullParameter(items, "items");
            return new ParseResult<>(ok, message, items);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return this.ok == parseResult.ok && Intrinsics.areEqual(this.message, parseResult.message) && Intrinsics.areEqual(this.items, parseResult.items);
        }

        public int hashCode() {
            int iHashCode = Boolean.hashCode(this.ok) * 31;
            String str = this.message;
            return ((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + this.items.hashCode();
        }

        public String toString() {
            return "ParseResult(ok=" + this.ok + ", message=" + this.message + ", items=" + this.items + ")";
        }

        /* JADX WARN: Multi-variable type inference failed */
        public ParseResult(boolean z, String str, List<? extends T> items) {
            Intrinsics.checkNotNullParameter(items, "items");
            this.ok = z;
            this.message = str;
            this.items = items;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final String getMessage() {
            return this.message;
        }

        public /* synthetic */ ParseResult(boolean z, String str, List list, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(z, (i & 2) != 0 ? null : str, (i & 4) != 0 ? CollectionsKt.emptyList() : list);
        }

        public final List<T> getItems() {
            return this.items;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\t\u0010\f\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\r\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$DepartOption;", "", TtmlNode.ATTR_ID, "", "title", "", "(ILjava/lang/String;)V", "getId", "()I", "getTitle", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class DepartOption {
        private final int id;
        private final String title;

        public static /* synthetic */ DepartOption copy$default(DepartOption departOption, int i, String str, int i2, Object obj) {
            if ((i2 & 1) != 0) {
                i = departOption.id;
            }
            if ((i2 & 2) != 0) {
                str = departOption.title;
            }
            return departOption.copy(i, str);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final int getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getTitle() {
            return this.title;
        }

        public final DepartOption copy(int id, String title) {
            Intrinsics.checkNotNullParameter(title, "title");
            return new DepartOption(id, title);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof DepartOption)) {
                return false;
            }
            DepartOption departOption = (DepartOption) other;
            return this.id == departOption.id && Intrinsics.areEqual(this.title, departOption.title);
        }

        public int hashCode() {
            return (Integer.hashCode(this.id) * 31) + this.title.hashCode();
        }

        public String toString() {
            return "DepartOption(id=" + this.id + ", title=" + this.title + ")";
        }

        public DepartOption(int i, String title) {
            Intrinsics.checkNotNullParameter(title, "title");
            this.id = i;
            this.title = title;
        }

        public final int getId() {
            return this.id;
        }

        public final String getTitle() {
            return this.title;
        }
    }

    static final void lambda$7$lambda$6(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.stateAction;
        if (function0 != null) {
            function0.invoke();
        }
    }

    private final void buildListContainer() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(0);
        this.listContainer = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setBackground(roundedBg(336401178, DefaultTimeBar.DEFAULT_UNPLAYED_COLOR, m385dp(1), dpF(12)));
        linearLayout2.setPadding(m385dp(10), m385dp(8), m385dp(10), m385dp(8));
        TextView textView = new TextView(this.ctx);
        textView.setText("پیگیری و ثبت تیکت\u200cهای پشتیبانی");
        textView.setTextColor(-2957330);
        textView.setTextSize(12.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView.getTypeface();
        }
        textView.setTypeface(typefaceRegular);
        textView.setIncludeFontPadding(false);
        TextView textView2 = new TextView(this.ctx);
        textView2.setText("ثبت تیکت جدید");
        textView2.setTextColor(-16052459);
        textView2.setTextSize(13.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceBold);
        textView2.setIncludeFontPadding(false);
        textView2.setGravity(17);
        textView2.setPadding(m385dp(14), m385dp(8), m385dp(14), m385dp(8));
        textView2.setBackground(roundedBg(this.accent, 0, 0, dpF(999)));
        textView2.setClickable(true);
        textView2.setFocusable(!this.isTouchDevice);
        textView2.setFocusableInTouchMode(!this.isTouchDevice);
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TicketSupportScreenView.buildListContainer$lambda$13$lambda$12(this.f$0, view);
            }
        });
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView2);
        LinearLayout linearLayout3 = this.listContainer;
        FrameLayout frameLayout = null;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout3 = null;
        }
        linearLayout3.addView(linearLayout2);
        FrameLayout frameLayout2 = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams.topMargin = m385dp(10);
        frameLayout2.setLayoutParams(layoutParams);
        LinearLayout linearLayout4 = this.listContainer;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout4 = null;
        }
        linearLayout4.addView(frameLayout2);
        this.ticketsAdapter = new TicketListAdapter(this, this.ticketItems, this.isTouchDevice, new Function1<TicketItem, Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView.buildListContainer.2
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(TicketItem ticketItem) {
                invoke2(ticketItem);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(TicketItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                TicketSupportScreenView.this.openTicketThread(item);
            }
        });
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        TicketListAdapter ticketListAdapter = this.ticketsAdapter;
        if (ticketListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsAdapter");
            ticketListAdapter = null;
        }
        recyclerView.setAdapter(ticketListAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m385dp(88));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$buildListContainer$3$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 4) {
                    return;
                }
                this.this$0.maybeLoadNextTickets();
            }
        });
        this.ticketsRecycler = recyclerView;
        frameLayout2.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        progressBar.setVisibility(8);
        this.ticketsLoading = progressBar;
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        Unit unit = Unit.INSTANCE;
        frameLayout2.addView(progressBar, layoutParams2);
        FrameLayout frameLayoutMakeLoadingMoreOverlay = makeLoadingMoreOverlay();
        this.ticketsLoadingMoreOverlay = frameLayoutMakeLoadingMoreOverlay;
        if (frameLayoutMakeLoadingMoreOverlay == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsLoadingMoreOverlay");
        } else {
            frameLayout = frameLayoutMakeLoadingMoreOverlay;
        }
        frameLayout2.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildListContainer$lambda$13$lambda$12(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchMode(Mode.CREATE);
    }

    private final void buildCreateContainer() {
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setFocusableInTouchMode(true);
        frameLayout.setElevation(dpF(46));
        frameLayout.setTranslationZ(dpF(46));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TicketSupportScreenView.buildCreateContainer$lambda$20$lambda$19(this.f$0, view);
            }
        });
        this.createContainer = frameLayout;
        View view = new View(this.ctx);
        view.setBackgroundColor(-1291845632);
        view.setAlpha(0.0f);
        view.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                TicketSupportScreenView.buildCreateContainer$lambda$22$lambda$21(this.f$0, view2);
            }
        });
        this.createSheetScrim = view;
        FrameLayout frameLayout2 = this.createContainer;
        AppCompatEditText appCompatEditText = null;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout2 = null;
        }
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        frameLayout2.addView(view2, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setColor(-234156782);
        gradientDrawable.setStroke(m385dp(1), 778990720);
        gradientDrawable.setCornerRadii(new float[]{dpF(18), dpF(18), dpF(18), dpF(18), 0.0f, 0.0f, 0.0f, 0.0f});
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setClipToPadding(false);
        linearLayout.setPadding(0, m385dp(8), 0, m385dp(10));
        linearLayout.setTranslationY(m385dp(360));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda22
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                TicketSupportScreenView.buildCreateContainer$lambda$25$lambda$24(view3);
            }
        });
        this.createSheetCard = linearLayout;
        FrameLayout frameLayout3 = this.createContainer;
        if (frameLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout3 = null;
        }
        LinearLayout linearLayout2 = this.createSheetCard;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout2 = null;
        }
        frameLayout3.addView(linearLayout2, new FrameLayout.LayoutParams(-1, m385dp(320), 80));
        FrameLayout frameLayout4 = new FrameLayout(this.ctx);
        frameLayout4.setPadding(0, m385dp(8), 0, m385dp(10));
        frameLayout4.setClickable(true);
        frameLayout4.setFocusable(true);
        frameLayout4.setFocusableInTouchMode(true);
        View view3 = new View(this.ctx);
        view3.setBackground(roundedBg(1174405119, 0, 0, dpF(999)));
        frameLayout4.addView(view3, new FrameLayout.LayoutParams(m385dp(44), m385dp(4), 17));
        frameLayout4.setOnTouchListener(new View.OnTouchListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda23
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view4, MotionEvent motionEvent) {
                return TicketSupportScreenView.buildCreateContainer$lambda$30(this.f$0, view4, motionEvent);
            }
        });
        ScrollView scrollView = new ScrollView(this.ctx);
        scrollView.setOverScrollMode(2);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setLayoutDirection(1);
        scrollView.setClipToPadding(false);
        scrollView.setPadding(0, 0, 0, m385dp(6));
        scrollView.setFillViewport(true);
        scrollView.setClickable(true);
        scrollView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda24
            @Override // android.view.View.OnClickListener
            public final void onClick(View view4) {
                TicketSupportScreenView.buildCreateContainer$lambda$32$lambda$31(view4);
            }
        });
        LinearLayout linearLayout3 = this.createSheetCard;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout3 = null;
        }
        linearLayout3.addView(frameLayout4, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        linearLayout4.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayout5 = new LinearLayout(this.ctx);
        linearLayout5.setOrientation(1);
        linearLayout5.setLayoutDirection(1);
        linearLayout5.setPadding(m385dp(14), m385dp(14), m385dp(14), m385dp(14));
        this.createFormContent = linearLayout5;
        scrollView.addView(linearLayout5, new FrameLayout.LayoutParams(-1, -2));
        TextView textViewMakeFieldLabel = makeFieldLabel("عنوان تیکت");
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = m385dp(6);
        Unit unit = Unit.INSTANCE;
        linearLayout5.addView(textViewMakeFieldLabel, layoutParams);
        AppCompatEditText appCompatEditTextMakeSingleLineInput = makeSingleLineInput("عنوان تیکت را اینجا وارد کنید");
        this.titleInput = appCompatEditTextMakeSingleLineInput;
        if (appCompatEditTextMakeSingleLineInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("titleInput");
            appCompatEditTextMakeSingleLineInput = null;
        }
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m385dp(6);
        Unit unit2 = Unit.INSTANCE;
        linearLayout5.addView(appCompatEditTextMakeSingleLineInput, layoutParams2);
        TextView textViewMakeFieldLabel2 = makeFieldLabel("دپارتمان");
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m385dp(12);
        Unit unit3 = Unit.INSTANCE;
        linearLayout5.addView(textViewMakeFieldLabel2, layoutParams3);
        LinearLayout linearLayout6 = new LinearLayout(this.ctx);
        linearLayout6.setOrientation(0);
        linearLayout6.setLayoutDirection(1);
        linearLayout6.setGravity(16);
        this.departChipWrap = linearLayout6;
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = m385dp(8);
        Unit unit4 = Unit.INSTANCE;
        linearLayout5.addView(linearLayout6, layoutParams4);
        rebuildDepartChips();
        TextView textViewMakeFieldLabel3 = makeFieldLabel("متن پیام");
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = m385dp(12);
        Unit unit5 = Unit.INSTANCE;
        linearLayout5.addView(textViewMakeFieldLabel3, layoutParams5);
        AppCompatEditText appCompatEditTextMakeMultiLineInput = makeMultiLineInput("جزئیات مشکل یا درخواست خود را بنویسید...");
        this.messageInput = appCompatEditTextMakeMultiLineInput;
        if (appCompatEditTextMakeMultiLineInput == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageInput");
        } else {
            appCompatEditText = appCompatEditTextMakeMultiLineInput;
        }
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.topMargin = m385dp(6);
        Unit unit6 = Unit.INSTANCE;
        linearLayout5.addView(appCompatEditText, layoutParams6);
        TextView textView = new TextView(this.ctx);
        textView.setText("ارسال تیکت");
        textView.setTextColor(-16052459);
        textView.setTextSize(14.0f);
        textView.setGravity(17);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setIncludeFontPadding(false);
        textView.setPadding(m385dp(16), m385dp(11), m385dp(16), m385dp(11));
        textView.setBackground(roundedBg(this.accent, 0, 0, dpF(12)));
        textView.setClickable(true);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(true ^ this.isTouchDevice);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view4) {
                TicketSupportScreenView.buildCreateContainer$lambda$42$lambda$41(this.f$0, view4);
            }
        });
        this.submitButton = textView;
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.topMargin = m385dp(16);
        Unit unit7 = Unit.INSTANCE;
        linearLayout5.addView(textView, layoutParams7);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$20$lambda$19(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.sendingTicket) {
            return;
        }
        this$0.switchMode(Mode.LIST);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$22$lambda$21(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.sendingTicket) {
            return;
        }
        this$0.switchMode(Mode.LIST);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00a2  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00e7  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final boolean buildCreateContainer$lambda$30(TicketSupportScreenView this$0, View view, MotionEvent motionEvent) {
        LinearLayout linearLayout;
        Integer numValueOf;
        int iIntValue;
        LinearLayout linearLayout2;
        LinearLayout linearLayout3;
        View view2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        int actionMasked = motionEvent.getActionMasked();
        LinearLayout linearLayout4 = null;
        View view3 = null;
        View view4 = null;
        if (actionMasked == 0) {
            this$0.createDragStartRawY = motionEvent.getRawY();
            LinearLayout linearLayout5 = this$0.createSheetCard;
            if (linearLayout5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout4 = linearLayout5;
            }
            this$0.createDragStartTranslation = linearLayout4.getTranslationY();
        } else if (actionMasked == 1) {
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
                numValueOf = null;
            }
            iIntValue = numValueOf == null ? numValueOf.intValue() : this$0.m385dp(320);
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f && !this$0.sendingTicket) {
                this$0.switchMode(Mode.LIST);
            } else {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                    linearLayout3 = null;
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                    Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                } else {
                    view4 = view2;
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        } else if (actionMasked == 2) {
            float fCoerceAtLeast = RangesKt.coerceAtLeast(this$0.createDragStartTranslation + RangesKt.coerceAtLeast(motionEvent.getRawY() - this$0.createDragStartRawY, 0.0f), 0.0f);
            LinearLayout linearLayout6 = this$0.createSheetCard;
            if (linearLayout6 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout6 = null;
            }
            linearLayout6.setTranslationY(fCoerceAtLeast);
            LinearLayout linearLayout7 = this$0.createSheetCard;
            if (linearLayout7 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout7 = null;
            }
            Integer numValueOf2 = Integer.valueOf(linearLayout7.getHeight());
            if (!(numValueOf2.intValue() > 0)) {
                numValueOf2 = null;
            }
            int iIntValue2 = numValueOf2 != null ? numValueOf2.intValue() : this$0.m385dp(320);
            View view5 = this$0.createSheetScrim;
            if (view5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            } else {
                view3 = view5;
            }
            view3.setAlpha(RangesKt.coerceIn(1.0f - (fCoerceAtLeast / (iIntValue2 * 0.9f)), 0.0f, 1.0f));
        } else {
            if (actionMasked != 3) {
                return false;
            }
            linearLayout = this$0.createSheetCard;
            if (linearLayout == null) {
            }
            numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
            }
            if (numValueOf == null) {
            }
            linearLayout2 = this$0.createSheetCard;
            if (linearLayout2 == null) {
            }
            if (linearLayout2.getTranslationY() <= iIntValue * 0.22f) {
                linearLayout3 = this$0.createSheetCard;
                if (linearLayout3 == null) {
                }
                linearLayout3.animate().translationY(0.0f).setDuration(180L).start();
                view2 = this$0.createSheetScrim;
                if (view2 != null) {
                }
                view4.animate().alpha(1.0f).setDuration(180L).start();
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildCreateContainer$lambda$42$lambda$41(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitTicket();
    }

    private final void buildThreadContainer() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setVisibility(8);
        this.threadContainer = linearLayout;
        LinearLayout linearLayout2 = new LinearLayout(this.ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setBackground(roundedBg(336401178, DefaultTimeBar.DEFAULT_UNPLAYED_COLOR, m385dp(1), dpF(12)));
        linearLayout2.setPadding(m385dp(10), m385dp(8), m385dp(10), m385dp(8));
        TextView textView = new TextView(this.ctx);
        textView.setText("بازگشت");
        textView.setTextColor(-2299660);
        textView.setTextSize(12.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold == null) {
            typefaceBold = textView.getTypeface();
        }
        textView.setTypeface(typefaceBold);
        textView.setIncludeFontPadding(false);
        textView.setGravity(17);
        textView.setPadding(m385dp(10), m385dp(6), m385dp(10), m385dp(6));
        textView.setBackground(roundedBg(537727770, 1157627903, m385dp(1), dpF(999)));
        textView.setClickable(true);
        textView.setFocusable(!this.isTouchDevice);
        textView.setFocusableInTouchMode(!this.isTouchDevice);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TicketSupportScreenView.buildThreadContainer$lambda$47$lambda$46(this.f$0, view);
            }
        });
        LinearLayout linearLayout3 = new LinearLayout(this.ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        TextView textView2 = new TextView(this.ctx);
        textView2.setTextColor(-1);
        textView2.setTextSize(14.0f);
        Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold2 == null) {
            typefaceBold2 = textView2.getTypeface();
        }
        textView2.setTypeface(typefaceBold2);
        textView2.setIncludeFontPadding(false);
        textView2.setText("تیکت");
        this.threadTitle = textView2;
        TextView textView3 = new TextView(this.ctx);
        textView3.setTextColor(-4930087);
        textView3.setTextSize(11.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = textView3.getTypeface();
        }
        textView3.setTypeface(typefaceRegular);
        textView3.setIncludeFontPadding(false);
        this.threadMeta = textView3;
        TextView textView4 = this.threadTitle;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadTitle");
            textView4 = null;
        }
        linearLayout3.addView(textView4);
        TextView textView5 = this.threadMeta;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadMeta");
            textView5 = null;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = m385dp(4);
        Unit unit = Unit.INSTANCE;
        linearLayout3.addView(textView5, layoutParams);
        linearLayout2.addView(linearLayout3, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView);
        LinearLayout linearLayout4 = this.threadContainer;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadContainer");
            linearLayout4 = null;
        }
        linearLayout4.addView(linearLayout2);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams2.topMargin = m385dp(10);
        frameLayout.setLayoutParams(layoutParams2);
        LinearLayout linearLayout5 = this.threadContainer;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadContainer");
            linearLayout5 = null;
        }
        linearLayout5.addView(frameLayout);
        this.messagesAdapter = new TicketMessageAdapter(this, this.messageItems, this.sessionUserId, this.isTouchDevice);
        RecyclerView recyclerView = new RecyclerView(this.ctx);
        recyclerView.setLayoutDirection(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.ctx, 1, false));
        TicketMessageAdapter ticketMessageAdapter = this.messagesAdapter;
        if (ticketMessageAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesAdapter");
            ticketMessageAdapter = null;
        }
        recyclerView.setAdapter(ticketMessageAdapter);
        recyclerView.setOverScrollMode(2);
        recyclerView.setClipToPadding(false);
        recyclerView.setVerticalScrollBarEnabled(false);
        recyclerView.setPaddingRelative(0, 0, 0, m385dp(12));
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$buildThreadContainer$5$1
            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView2, int dx, int dy) {
                Intrinsics.checkNotNullParameter(recyclerView2, "recyclerView");
                if (dy <= 0) {
                    return;
                }
                RecyclerView.LayoutManager layoutManager = recyclerView2.getLayoutManager();
                LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
                if (linearLayoutManager == null) {
                    return;
                }
                int itemCount = linearLayoutManager.getItemCount();
                int iFindLastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition();
                if (itemCount <= 0 || iFindLastVisibleItemPosition < itemCount - 5) {
                    return;
                }
                this.this$0.maybeLoadNextMessages();
            }
        });
        this.messagesRecycler = recyclerView;
        frameLayout.addView(recyclerView, new FrameLayout.LayoutParams(-1, -1));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        progressBar.setVisibility(8);
        this.messagesLoading = progressBar;
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        Unit unit2 = Unit.INSTANCE;
        frameLayout.addView(progressBar, layoutParams3);
        FrameLayout frameLayoutMakeLoadingMoreOverlay = makeLoadingMoreOverlay();
        this.messagesLoadingMoreOverlay = frameLayoutMakeLoadingMoreOverlay;
        if (frameLayoutMakeLoadingMoreOverlay == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesLoadingMoreOverlay");
            frameLayoutMakeLoadingMoreOverlay = null;
        }
        frameLayout.addView(frameLayoutMakeLoadingMoreOverlay, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout6 = new LinearLayout(this.ctx);
        linearLayout6.setOrientation(0);
        linearLayout6.setLayoutDirection(1);
        linearLayout6.setGravity(16);
        linearLayout6.setBackground(roundedBg(this.cardFill, this.cardStroke, m385dp(1), dpF(12)));
        linearLayout6.setPadding(m385dp(8), m385dp(8), m385dp(8), m385dp(8));
        TextView textView6 = new TextView(this.ctx);
        textView6.setText("ارسال");
        textView6.setTextColor(-16052459);
        textView6.setTextSize(13.0f);
        textView6.setGravity(17);
        Typeface typefaceBold3 = NativeFonts.INSTANCE.bold(this.ctx);
        if (typefaceBold3 == null) {
            typefaceBold3 = textView6.getTypeface();
        }
        textView6.setTypeface(typefaceBold3);
        textView6.setIncludeFontPadding(false);
        textView6.setPadding(m385dp(14), m385dp(10), m385dp(14), m385dp(10));
        textView6.setBackground(roundedBg(this.accent, 0, 0, dpF(10)));
        textView6.setClickable(true);
        textView6.setFocusable(!this.isTouchDevice);
        textView6.setFocusableInTouchMode(!this.isTouchDevice);
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                TicketSupportScreenView.buildThreadContainer$lambda$59$lambda$58(this.f$0, view);
            }
        });
        this.replySendButton = textView6;
        this.replyInput = makeReplyInput("پاسخ خود را بنویسید...");
        TextView textView7 = this.replySendButton;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replySendButton");
            textView7 = null;
        }
        linearLayout6.addView(textView7, new LinearLayout.LayoutParams(-2, -2));
        AppCompatEditText appCompatEditText = this.replyInput;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replyInput");
            appCompatEditText = null;
        }
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams4.setMarginStart(m385dp(8));
        Unit unit3 = Unit.INSTANCE;
        linearLayout6.addView(appCompatEditText, layoutParams4);
        LinearLayout linearLayout7 = this.threadContainer;
        if (linearLayout7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadContainer");
            linearLayout7 = null;
        }
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = m385dp(10);
        layoutParams5.bottomMargin = m385dp(6);
        Unit unit4 = Unit.INSTANCE;
        linearLayout7.addView(linearLayout6, layoutParams5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildThreadContainer$lambda$47$lambda$46(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.switchMode(Mode.LIST);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildThreadContainer$lambda$59$lambda$58(TicketSupportScreenView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.submitReply();
    }

    private final TextView makeFieldLabel(String title) {
        TextView textView = new TextView(this.ctx);
        textView.setText(title);
        textView.setTextColor(-3154708);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        return textView;
    }

    private final AppCompatEditText makeSingleLineInput(String hint) {
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint(hint);
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setSingleLine();
        appCompatEditText.setGravity(21);
        appCompatEditText.setPadding(m385dp(12), m385dp(12), m385dp(12), m385dp(12));
        applyLoginLikeFieldStyle(appCompatEditText);
        return appCompatEditText;
    }

    private final AppCompatEditText makeReplyInput(String hint) {
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint(hint);
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setGravity(21);
        appCompatEditText.setMinLines(1);
        appCompatEditText.setMaxLines(3);
        appCompatEditText.setSingleLine(false);
        appCompatEditText.setHorizontallyScrolling(false);
        appCompatEditText.setPadding(m385dp(12), m385dp(10), m385dp(12), m385dp(10));
        applyLoginLikeFieldStyle(appCompatEditText);
        return appCompatEditText;
    }

    private final AppCompatEditText makeMultiLineInput(String hint) {
        AppCompatEditText appCompatEditText = new AppCompatEditText(this.ctx);
        appCompatEditText.setHint(hint);
        appCompatEditText.setTextColor(-1);
        appCompatEditText.setHintTextColor(2142817248);
        appCompatEditText.setTextSize(14.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(this.ctx);
        if (typefaceRegular == null) {
            typefaceRegular = appCompatEditText.getTypeface();
        }
        appCompatEditText.setTypeface(typefaceRegular);
        appCompatEditText.setGravity(53);
        appCompatEditText.setMinLines(5);
        appCompatEditText.setMaxLines(8);
        appCompatEditText.setPadding(m385dp(12), m385dp(12), m385dp(12), m385dp(12));
        applyLoginLikeFieldStyle(appCompatEditText);
        return appCompatEditText;
    }

    private final void applyLoginLikeFieldStyle(final AppCompatEditText field) {
        field.setBackground(roundedBg(this.fieldFill, this.fieldStroke, m385dp(2), dpF(16)));
        field.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda11
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                TicketSupportScreenView.applyLoginLikeFieldStyle$lambda$66(field, this, view, z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyLoginLikeFieldStyle$lambda$66(AppCompatEditText field, TicketSupportScreenView this$0, View view, boolean z) {
        Intrinsics.checkNotNullParameter(field, "$field");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        field.setBackground(this$0.roundedBg(this$0.fieldFill, z ? this$0.accent : this$0.fieldStroke, this$0.m385dp(2), this$0.dpF(16)));
    }

    private final void rebuildDepartChips() {
        LinearLayout linearLayout = this.departChipWrap;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("departChipWrap");
            linearLayout = null;
        }
        linearLayout.removeAllViews();
        int i = 0;
        for (Object obj : this.departOptions) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            final DepartOption departOption = (DepartOption) obj;
            boolean z = departOption.getId() == this.selectedDepartId;
            TextView textView = new TextView(this.ctx);
            textView.setText(departOption.getTitle());
            textView.setTextSize(11.0f);
            textView.setIncludeFontPadding(false);
            textView.setGravity(17);
            Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
            if (typefaceMedium == null) {
                typefaceMedium = textView.getTypeface();
            }
            textView.setTypeface(typefaceMedium);
            textView.setPadding(m385dp(10), m385dp(7), m385dp(10), m385dp(7));
            textView.setTextColor(z ? -16052459 : -2562318);
            textView.setBackground(roundedBg(z ? this.accent : 370021662, z ? 0 : 1090519039, m385dp(1), dpF(999)));
            textView.setClickable(true);
            textView.setFocusable(!this.isTouchDevice);
            textView.setFocusableInTouchMode(!this.isTouchDevice);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    TicketSupportScreenView.rebuildDepartChips$lambda$70$lambda$68$lambda$67(this.f$0, departOption, view);
                }
            });
            LinearLayout linearLayout2 = this.departChipWrap;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("departChipWrap");
                linearLayout2 = null;
            }
            TextView textView2 = textView;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            if (i > 0) {
                layoutParams.setMarginStart(m385dp(6));
            }
            Unit unit = Unit.INSTANCE;
            linearLayout2.addView(textView2, layoutParams);
            i = i2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void rebuildDepartChips$lambda$70$lambda$68$lambda$67(TicketSupportScreenView this$0, DepartOption option, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(option, "$option");
        this$0.selectedDepartId = option.getId();
        this$0.rebuildDepartChips();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void switchMode(Mode next) {
        this.mode = next;
        LinearLayout linearLayout = this.listContainer;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("listContainer");
            linearLayout = null;
        }
        linearLayout.setVisibility(next == Mode.THREAD ? 8 : 0);
        LinearLayout linearLayout2 = this.threadContainer;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadContainer");
            linearLayout2 = null;
        }
        linearLayout2.setVisibility(next == Mode.THREAD ? 0 : 8);
        if (next == Mode.CREATE) {
            showCreateSheet();
        } else {
            hideCreateSheet$default(this, false, 1, null);
        }
        int i = WhenMappings.$EnumSwitchMapping$0[next.ordinal()];
        if (i == 1) {
            hideState();
            if (isLoggedIn() && this.ticketItems.isEmpty() && !this.loadingTickets) {
                resetTicketsAndLoad();
                return;
            }
            return;
        }
        if (i == 2) {
            hideState();
            return;
        }
        if (i != 3) {
            return;
        }
        hideState();
        if (!isLoggedIn() || this.activeTicket == null || !this.messageItems.isEmpty() || this.loadingMessages) {
            return;
        }
        TicketItem ticketItem = this.activeTicket;
        Intrinsics.checkNotNull(ticketItem);
        resetMessagesAndLoad(ticketItem.getId());
    }

    private final void showCreateSheet() {
        if (this.createContainer == null || this.createSheetCard == null || this.createSheetShown) {
            return;
        }
        final int iResolveCreateSheetHeight = resolveCreateSheetHeight();
        LinearLayout linearLayout = this.createSheetCard;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout = null;
        }
        ViewGroup.LayoutParams layoutParams = linearLayout.getLayoutParams();
        FrameLayout.LayoutParams layoutParams2 = layoutParams instanceof FrameLayout.LayoutParams ? (FrameLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 != null && layoutParams2.height != iResolveCreateSheetHeight) {
            layoutParams2.height = iResolveCreateSheetHeight;
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setLayoutParams(layoutParams2);
        }
        this.createSheetShown = true;
        FrameLayout frameLayout = this.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(0);
        View view = this.createSheetScrim;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view = null;
        }
        view.setAlpha(0.0f);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(1.0f).setDuration(200L).start();
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout2 = linearLayout4;
        }
        linearLayout2.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                TicketSupportScreenView.showCreateSheet$lambda$73(this.f$0, iResolveCreateSheetHeight);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showCreateSheet$lambda$73(TicketSupportScreenView this$0, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            LinearLayout linearLayout = this$0.createSheetCard;
            LinearLayout linearLayout2 = null;
            if (linearLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout = null;
            }
            Integer numValueOf = Integer.valueOf(linearLayout.getHeight());
            if (!(numValueOf.intValue() > 0)) {
                numValueOf = null;
            }
            if (numValueOf != null) {
                i = numValueOf.intValue();
            }
            LinearLayout linearLayout3 = this$0.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout3.setTranslationY(i);
            LinearLayout linearLayout4 = this$0.createSheetCard;
            if (linearLayout4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            } else {
                linearLayout2 = linearLayout4;
            }
            linearLayout2.animate().translationY(0.0f).setDuration(220L).start();
        }
    }

    static /* synthetic */ void hideCreateSheet$default(TicketSupportScreenView ticketSupportScreenView, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        ticketSupportScreenView.hideCreateSheet(z);
    }

    private final void hideCreateSheet(boolean animated) {
        FrameLayout frameLayout = this.createContainer;
        if (frameLayout == null || this.createSheetCard == null) {
            return;
        }
        LinearLayout linearLayout = null;
        FrameLayout frameLayout2 = null;
        if (!this.createSheetShown) {
            if (frameLayout == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
                frameLayout = null;
            }
            if (frameLayout.getVisibility() != 0) {
                return;
            }
        }
        this.createSheetShown = false;
        if (!animated) {
            View view = this.createSheetScrim;
            if (view == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
                view = null;
            }
            view.setAlpha(0.0f);
            LinearLayout linearLayout2 = this.createSheetCard;
            if (linearLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout2 = null;
            }
            LinearLayout linearLayout3 = this.createSheetCard;
            if (linearLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
                linearLayout3 = null;
            }
            linearLayout2.setTranslationY(linearLayout3.getHeight());
            FrameLayout frameLayout3 = this.createContainer;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            } else {
                frameLayout2 = frameLayout3;
            }
            frameLayout2.setVisibility(8);
            return;
        }
        LinearLayout linearLayout4 = this.createSheetCard;
        if (linearLayout4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
            linearLayout4 = null;
        }
        Integer numValueOf = Integer.valueOf(linearLayout4.getHeight());
        if (!(numValueOf.intValue() > 0)) {
            numValueOf = null;
        }
        int iIntValue = numValueOf != null ? numValueOf.intValue() : m385dp(320);
        View view2 = this.createSheetScrim;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetScrim");
            view2 = null;
        }
        view2.animate().alpha(0.0f).setDuration(180L).start();
        LinearLayout linearLayout5 = this.createSheetCard;
        if (linearLayout5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createSheetCard");
        } else {
            linearLayout = linearLayout5;
        }
        linearLayout.animate().translationY(iIntValue).setDuration(200L).withEndAction(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                TicketSupportScreenView.hideCreateSheet$lambda$75(this.f$0);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void hideCreateSheet$lambda$75(TicketSupportScreenView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.createSheetShown) {
            return;
        }
        FrameLayout frameLayout = this$0.createContainer;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createContainer");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
    }

    private final int resolveCreateSheetHeight() {
        float f = getResources().getDisplayMetrics().heightPixels;
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (0.58f * f), m385dp(340));
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast((int) (f * 0.92f), iCoerceAtLeast);
        if (this.createFormContent == null) {
            return iCoerceAtLeast;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(RangesKt.coerceAtLeast(getResources().getDisplayMetrics().widthPixels - m385dp(28), m385dp(220)), 1073741824);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        LinearLayout linearLayout = this.createFormContent;
        LinearLayout linearLayout2 = null;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createFormContent");
            linearLayout = null;
        }
        linearLayout.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int iM385dp = m385dp(44);
        LinearLayout linearLayout3 = this.createFormContent;
        if (linearLayout3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("createFormContent");
        } else {
            linearLayout2 = linearLayout3;
        }
        return RangesKt.coerceAtMost(RangesKt.coerceAtLeast(linearLayout2.getMeasuredHeight() + iM385dp, iCoerceAtLeast), iCoerceAtLeast2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openTicketThread(TicketItem item) {
        this.activeTicket = item;
        TextView textView = this.threadTitle;
        AppCompatEditText appCompatEditText = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadTitle");
            textView = null;
        }
        String title = item.getTitle();
        if (StringsKt.isBlank(title)) {
            title = "تیکت #" + item.getId();
        }
        textView.setText(title);
        TextView textView2 = this.threadMeta;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("threadMeta");
            textView2 = null;
        }
        textView2.setText("شماره #" + item.getId() + "   •   " + ticketStatusLabel(item.getStatus()) + "   •   " + item.getCreatedAt());
        AppCompatEditText appCompatEditText2 = this.replyInput;
        if (appCompatEditText2 != null) {
            if (appCompatEditText2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("replyInput");
            } else {
                appCompatEditText = appCompatEditText2;
            }
            appCompatEditText.setText("");
        }
        switchMode(Mode.THREAD);
        resetMessagesAndLoad(item.getId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetTicketsAndLoad() {
        this.ticketItems.clear();
        TicketListAdapter ticketListAdapter = this.ticketsAdapter;
        if (ticketListAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsAdapter");
            ticketListAdapter = null;
        }
        ticketListAdapter.notifyDataSetChanged();
        this.currentTicketPage = 1;
        this.hasMoreTickets = true;
        loadTickets(1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNextTickets() {
        if (this.loadingTickets || !this.hasMoreTickets) {
            return;
        }
        loadTickets(this.currentTicketPage + 1, false);
    }

    private final void loadTickets(final int page, final boolean reset) {
        if (this.loadingTickets || !isLoggedIn()) {
            return;
        }
        this.loadingTickets = true;
        FrameLayout frameLayout = null;
        if (reset) {
            ProgressBar progressBar = this.ticketsLoading;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("ticketsLoading");
                progressBar = null;
            }
            progressBar.setVisibility(0);
            FrameLayout frameLayout2 = this.ticketsLoadingMoreOverlay;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("ticketsLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout2;
            }
            frameLayout.setVisibility(8);
        } else {
            FrameLayout frameLayout3 = this.ticketsLoadingMoreOverlay;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("ticketsLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout3;
            }
            frameLayout.setVisibility(0);
        }
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                TicketSupportScreenView.loadTickets$lambda$79(this.f$0, page, reset);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadTickets$lambda$79(final TicketSupportScreenView this$0, final int i, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ParseResult<TicketItem> ticketListResponse = this$0.parseTicketListResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/tickets", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("userID", String.valueOf(this$0.sessionUserId)), TuplesKt.m787to("page", String.valueOf(i)), TuplesKt.m787to("per_page", "20")), this$0.authHeaders(), null, false, 96, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.loadTickets$lambda$79$lambda$77(this.f$0, ticketListResponse, z, i);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.loadTickets$lambda$79$lambda$78(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadTickets$lambda$79$lambda$77(final TicketSupportScreenView this$0, ParseResult parsed, boolean z, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loadingTickets = false;
        ProgressBar progressBar = this$0.ticketsLoading;
        TicketListAdapter ticketListAdapter = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout = this$0.ticketsLoadingMoreOverlay;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsLoadingMoreOverlay");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
        if (!parsed.getOk()) {
            if (this$0.mode == Mode.LIST) {
                this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت تیکت\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadTickets$1$1$1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        this.this$0.resetTicketsAndLoad();
                    }
                });
                return;
            }
            return;
        }
        if (z) {
            int size = this$0.ticketItems.size();
            this$0.ticketItems.clear();
            if (size > 0) {
                TicketListAdapter ticketListAdapter2 = this$0.ticketsAdapter;
                if (ticketListAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("ticketsAdapter");
                    ticketListAdapter2 = null;
                }
                ticketListAdapter2.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.ticketItems.size();
        this$0.ticketItems.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            TicketListAdapter ticketListAdapter3 = this$0.ticketsAdapter;
            if (ticketListAdapter3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("ticketsAdapter");
            } else {
                ticketListAdapter = ticketListAdapter3;
            }
            ticketListAdapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentTicketPage = i;
        this$0.hasMoreTickets = parsed.getItems().size() >= 20;
        if (this$0.ticketItems.isEmpty() && this$0.mode == Mode.LIST) {
            this$0.showState("هنوز تیکتی ثبت نشده است.", "ثبت تیکت جدید", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadTickets$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.switchMode(TicketSupportScreenView.Mode.CREATE);
                }
            });
        } else if (this$0.mode == Mode.LIST) {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadTickets$lambda$79$lambda$78(final TicketSupportScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        boolean z = false;
        this$0.loadingTickets = false;
        ProgressBar progressBar = this$0.ticketsLoading;
        FrameLayout frameLayout = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout2 = this$0.ticketsLoadingMoreOverlay;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("ticketsLoadingMoreOverlay");
        } else {
            frameLayout = frameLayout2;
        }
        frameLayout.setVisibility(8);
        if (this$0.mode == Mode.LIST) {
            if (e instanceof FkApiClient.ApiException) {
                FkApiClient.ApiException apiException = (FkApiClient.ApiException) e;
                if (apiException.getCode() == 401 || apiException.getCode() == 403) {
                    z = true;
                }
            }
            if (z) {
                this$0.showState("برای پشتیبانی، ابتدا وارد حساب شوید.", "ورود به حساب", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadTickets$1$2$1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        Function0 function0 = this.this$0.onRequireLogin;
                        if (function0 != null) {
                            function0.invoke();
                        }
                    }
                });
            } else {
                this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت تیکت\u200cها"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadTickets$1$2$2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        this.this$0.resetTicketsAndLoad();
                    }
                });
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetMessagesAndLoad(long ticketId) {
        this.messageItems.clear();
        TicketMessageAdapter ticketMessageAdapter = this.messagesAdapter;
        if (ticketMessageAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesAdapter");
            ticketMessageAdapter = null;
        }
        ticketMessageAdapter.notifyDataSetChanged();
        this.currentMessagePage = 1;
        this.hasMoreMessages = true;
        loadMessages(ticketId, 1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void maybeLoadNextMessages() {
        TicketItem ticketItem = this.activeTicket;
        if (ticketItem != null) {
            long id = ticketItem.getId();
            if (this.loadingMessages || !this.hasMoreMessages) {
                return;
            }
            loadMessages(id, this.currentMessagePage + 1, false);
        }
    }

    private final void loadMessages(final long ticketId, final int page, final boolean reset) {
        if (this.loadingMessages || ticketId <= 0 || !isLoggedIn()) {
            return;
        }
        this.loadingMessages = true;
        FrameLayout frameLayout = null;
        if (reset) {
            ProgressBar progressBar = this.messagesLoading;
            if (progressBar == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesLoading");
                progressBar = null;
            }
            progressBar.setVisibility(0);
            FrameLayout frameLayout2 = this.messagesLoadingMoreOverlay;
            if (frameLayout2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout2;
            }
            frameLayout.setVisibility(8);
        } else {
            FrameLayout frameLayout3 = this.messagesLoadingMoreOverlay;
            if (frameLayout3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesLoadingMoreOverlay");
            } else {
                frameLayout = frameLayout3;
            }
            frameLayout.setVisibility(0);
        }
        this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                TicketSupportScreenView.loadMessages$lambda$82(ticketId, page, this, reset);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadMessages$lambda$82(final long j, final int i, final TicketSupportScreenView this$0, final boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            final ParseResult<TicketMessage> ticketMessageResponse = this$0.parseTicketMessageResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/getTicket", "GET", MapsKt.linkedMapOf(TuplesKt.m787to("ticketID", String.valueOf(j)), TuplesKt.m787to("page", String.valueOf(i)), TuplesKt.m787to("per_page", "20")), this$0.authHeaders(), null, false, 96, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.loadMessages$lambda$82$lambda$80(this.f$0, ticketMessageResponse, z, i, j);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.loadMessages$lambda$82$lambda$81(this.f$0, th, j);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadMessages$lambda$82$lambda$80(final TicketSupportScreenView this$0, ParseResult parsed, boolean z, int i, final long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.loadingMessages = false;
        ProgressBar progressBar = this$0.messagesLoading;
        TicketMessageAdapter ticketMessageAdapter = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout = this$0.messagesLoadingMoreOverlay;
        if (frameLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesLoadingMoreOverlay");
            frameLayout = null;
        }
        frameLayout.setVisibility(8);
        if (!parsed.getOk()) {
            if (this$0.mode == Mode.THREAD) {
                this$0.showState(SafeUserMessage.INSTANCE.fromRaw(parsed.getMessage(), "خطا در دریافت پیام\u200cهای تیکت"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadMessages$1$1$1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        this.this$0.resetMessagesAndLoad(j);
                    }
                });
                return;
            }
            return;
        }
        if (z) {
            int size = this$0.messageItems.size();
            this$0.messageItems.clear();
            if (size > 0) {
                TicketMessageAdapter ticketMessageAdapter2 = this$0.messagesAdapter;
                if (ticketMessageAdapter2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("messagesAdapter");
                    ticketMessageAdapter2 = null;
                }
                ticketMessageAdapter2.notifyItemRangeRemoved(0, size);
            }
        }
        int size2 = this$0.messageItems.size();
        this$0.messageItems.addAll(parsed.getItems());
        if (!parsed.getItems().isEmpty()) {
            TicketMessageAdapter ticketMessageAdapter3 = this$0.messagesAdapter;
            if (ticketMessageAdapter3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesAdapter");
            } else {
                ticketMessageAdapter = ticketMessageAdapter3;
            }
            ticketMessageAdapter.notifyItemRangeInserted(size2, parsed.getItems().size());
        }
        this$0.currentMessagePage = i;
        this$0.hasMoreMessages = parsed.getItems().size() >= 20;
        if (this$0.messageItems.isEmpty() && this$0.mode == Mode.THREAD) {
            this$0.showState("برای این تیکت پیامی ثبت نشده است.", "بازگشت", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadMessages$1$1$2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.switchMode(TicketSupportScreenView.Mode.LIST);
                }
            });
        } else if (this$0.mode == Mode.THREAD) {
            this$0.hideState();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadMessages$lambda$82$lambda$81(final TicketSupportScreenView this$0, Throwable e, final long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.loadingMessages = false;
        ProgressBar progressBar = this$0.messagesLoading;
        FrameLayout frameLayout = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesLoading");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        FrameLayout frameLayout2 = this$0.messagesLoadingMoreOverlay;
        if (frameLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messagesLoadingMoreOverlay");
        } else {
            frameLayout = frameLayout2;
        }
        frameLayout.setVisibility(8);
        if (this$0.mode == Mode.THREAD) {
            this$0.showState(SafeUserMessage.INSTANCE.fromThrowable(e, "خطا در دریافت پیام\u200cهای تیکت"), "تلاش دوباره", new Function0<Unit>() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$loadMessages$1$2$1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.resetMessagesAndLoad(j);
                }
            });
        }
    }

    private final void submitTicket() {
        String string;
        String string2;
        if (this.sendingTicket) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        AppCompatEditText appCompatEditText = this.titleInput;
        String string3 = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("titleInput");
            appCompatEditText = null;
        }
        Editable text = appCompatEditText.getText();
        final String string4 = (text == null || (string2 = text.toString()) == null) ? null : StringsKt.trim((CharSequence) string2).toString();
        if (string4 == null) {
            string4 = "";
        }
        AppCompatEditText appCompatEditText2 = this.messageInput;
        if (appCompatEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageInput");
            appCompatEditText2 = null;
        }
        Editable text2 = appCompatEditText2.getText();
        if (text2 != null && (string = text2.toString()) != null) {
            string3 = StringsKt.trim((CharSequence) string).toString();
        }
        final String str = string3 != null ? string3 : "";
        if (StringsKt.isBlank(string4)) {
            showToast("عنوان تیکت را وارد کنید");
        } else {
            if (StringsKt.isBlank(str)) {
                showToast("متن تیکت را وارد کنید");
                return;
            }
            this.sendingTicket = true;
            setSubmitLoading(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitTicket$lambda$85(string4, this, str);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitTicket$lambda$85(String title, final TicketSupportScreenView this$0, String message) {
        Intrinsics.checkNotNullParameter(title, "$title");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(message, "$message");
        try {
            String string = new JSONObject().put("titleTicket", title).put("depart", this$0.selectedDepartId).put("userID", this$0.sessionUserId).put("textTicket", message).toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final Pair<Boolean, String> sendTicketResponse = this$0.parseSendTicketResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/sendTickets", "POST", null, this$0.authHeaders(), string, false, 72, null));
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitTicket$lambda$85$lambda$83(this.f$0, sendTicketResponse);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitTicket$lambda$85$lambda$84(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitTicket$lambda$85$lambda$83(TicketSupportScreenView this$0, Pair parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.sendingTicket = false;
        this$0.setSubmitLoading(false);
        if (!((Boolean) parsed.getFirst()).booleanValue()) {
            String str = (String) parsed.getSecond();
            if (str == null) {
                str = "ارسال تیکت ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        AppCompatEditText appCompatEditText = this$0.titleInput;
        AppCompatEditText appCompatEditText2 = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("titleInput");
            appCompatEditText = null;
        }
        appCompatEditText.setText("");
        AppCompatEditText appCompatEditText3 = this$0.messageInput;
        if (appCompatEditText3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("messageInput");
        } else {
            appCompatEditText2 = appCompatEditText3;
        }
        appCompatEditText2.setText("");
        this$0.selectedDepartId = ((DepartOption) CollectionsKt.first((List) this$0.departOptions)).getId();
        this$0.rebuildDepartChips();
        String str2 = (String) parsed.getSecond();
        if (str2 == null) {
            str2 = "تیکت شما با موفقیت ایجاد شد";
        }
        this$0.showToast(str2);
        this$0.switchMode(Mode.LIST);
        this$0.resetTicketsAndLoad();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitTicket$lambda$85$lambda$84(TicketSupportScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.sendingTicket = false;
        this$0.setSubmitLoading(false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "ارسال تیکت ناموفق بود"));
    }

    private final void submitReply() {
        String string;
        if (this.sendingReply) {
            return;
        }
        if (!isLoggedIn()) {
            Function0<Unit> function0 = this.onRequireLogin;
            if (function0 != null) {
                function0.invoke();
                return;
            }
            return;
        }
        TicketItem ticketItem = this.activeTicket;
        if (ticketItem != null) {
            final long id = ticketItem.getId();
            AppCompatEditText appCompatEditText = this.replyInput;
            final String string2 = null;
            if (appCompatEditText == null) {
                Intrinsics.throwUninitializedPropertyAccessException("replyInput");
                appCompatEditText = null;
            }
            Editable text = appCompatEditText.getText();
            if (text != null && (string = text.toString()) != null) {
                string2 = StringsKt.trim((CharSequence) string).toString();
            }
            if (string2 == null) {
                string2 = "";
            }
            if (StringsKt.isBlank(string2)) {
                showToast("متن پاسخ را وارد کنید");
                return;
            }
            this.sendingReply = true;
            setReplyLoading(true);
            this.executor.execute(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitReply$lambda$89(this.f$0, id, string2);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitReply$lambda$89(final TicketSupportScreenView this$0, long j, String text) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(text, "$text");
        try {
            String string = new JSONObject().put("userID", this$0.sessionUserId).put("ticketID", j).put("message", text).toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            final Triple<Boolean, String, TicketMessage> responseTicketResponse = this$0.parseResponseTicketResponse(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, this$0.apiBase, "/ResponseTicket", "POST", null, this$0.authHeaders(), string, false, 72, null), text);
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitReply$lambda$89$lambda$87(this.f$0, responseTicketResponse);
                }
            });
        } catch (Throwable th) {
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$$ExternalSyntheticLambda15
                @Override // java.lang.Runnable
                public final void run() {
                    TicketSupportScreenView.submitReply$lambda$89$lambda$88(this.f$0, th);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitReply$lambda$89$lambda$87(TicketSupportScreenView this$0, Triple parsed) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(parsed, "$parsed");
        this$0.sendingReply = false;
        this$0.setReplyLoading(false);
        if (!((Boolean) parsed.getFirst()).booleanValue()) {
            String str = (String) parsed.getSecond();
            if (str == null) {
                str = "ارسال پاسخ ناموفق بود";
            }
            this$0.showToast(str);
            return;
        }
        AppCompatEditText appCompatEditText = this$0.replyInput;
        RecyclerView recyclerView = null;
        if (appCompatEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replyInput");
            appCompatEditText = null;
        }
        appCompatEditText.setText("");
        TicketMessage ticketMessage = (TicketMessage) parsed.getThird();
        if (ticketMessage != null) {
            int size = this$0.messageItems.size();
            this$0.messageItems.add(ticketMessage);
            TicketMessageAdapter ticketMessageAdapter = this$0.messagesAdapter;
            if (ticketMessageAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesAdapter");
                ticketMessageAdapter = null;
            }
            ticketMessageAdapter.notifyItemInserted(size);
            RecyclerView recyclerView2 = this$0.messagesRecycler;
            if (recyclerView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("messagesRecycler");
            } else {
                recyclerView = recyclerView2;
            }
            recyclerView.scrollToPosition(CollectionsKt.getLastIndex(this$0.messageItems));
        }
        String str2 = (String) parsed.getSecond();
        if (str2 == null) {
            str2 = "پاسخ شما با موفقیت ارسال شد";
        }
        this$0.showToast(str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void submitReply$lambda$89$lambda$88(TicketSupportScreenView this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        this$0.sendingReply = false;
        this$0.setReplyLoading(false);
        this$0.showToast(SafeUserMessage.INSTANCE.fromThrowable(e, "ارسال پاسخ ناموفق بود"));
    }

    private final void setSubmitLoading(boolean loading) {
        TextView textView = this.submitButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.submitButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.75f : 1.0f);
        TextView textView4 = this.submitButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("submitButton");
        } else {
            textView2 = textView4;
        }
        textView2.setText(loading ? "در حال ارسال..." : "ارسال تیکت");
    }

    private final void setReplyLoading(boolean loading) {
        TextView textView = this.replySendButton;
        TextView textView2 = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replySendButton");
            textView = null;
        }
        textView.setEnabled(!loading);
        TextView textView3 = this.replySendButton;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replySendButton");
            textView3 = null;
        }
        textView3.setAlpha(loading ? 0.75f : 1.0f);
        TextView textView4 = this.replySendButton;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("replySendButton");
        } else {
            textView2 = textView4;
        }
        textView2.setText(loading ? "..." : "ارسال");
    }

    private final Pair<Boolean, String> parseSendTicketResponse(String raw) {
        Object objNextValue;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        if (objNextValue == null) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return TuplesKt.m787to(false, "پاسخ نامعتبر است");
        }
        boolean bool = toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS));
        String strOptString = jSONObject.optString("message", "");
        Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
        String string = StringsKt.trim((CharSequence) strOptString).toString();
        return TuplesKt.m787to(Boolean.valueOf(bool), StringsKt.isBlank(string) ? null : string);
    }

    private final Triple<Boolean, String, TicketMessage> parseResponseTicketResponse(String raw, String fallbackText) {
        Object objNextValue;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        try {
            objNextValue = new JSONTokener(raw).nextValue();
        } catch (Throwable unused) {
            objNextValue = null;
        }
        if (objNextValue == null) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        JSONObject jSONObject = objNextValue instanceof JSONObject ? (JSONObject) objNextValue : null;
        if (jSONObject == null) {
            return new Triple<>(false, "پاسخ نامعتبر است", null);
        }
        Intrinsics.checkNotNullExpressionValue(jSONObject.optString("code", ""), "optString(...)");
        if (!StringsKt.isBlank(StringsKt.trim((CharSequence) r2).toString())) {
            return new Triple<>(false, jSONObject.optString("message", "ارسال پاسخ ناموفق بود"), null);
        }
        boolean bool = toBool(jSONObject.opt(NotificationCompat.CATEGORY_STATUS));
        String strPickString = pickString(jSONObject, "message");
        if (!bool) {
            return new Triple<>(false, strPickString != null ? strPickString : "ارسال پاسخ ناموفق بود", null);
        }
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("message_obj");
        Long l = toLong(jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.opt("ID") : null);
        long jLongValue = l != null ? l.longValue() : -System.currentTimeMillis();
        String str2 = fallbackText;
        if (StringsKt.isBlank(str2)) {
            String strPickString2 = pickString(jSONObjectOptJSONObject, "message");
            str2 = strPickString2 != null ? strPickString2 : "";
        }
        String str3 = str2;
        Long l2 = toLong(jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.opt("user_id") : null);
        long jLongValue2 = l2 != null ? l2.longValue() : this.sessionUserId;
        String strPickString3 = pickString(jSONObjectOptJSONObject, "created_at");
        if (strPickString3 == null) {
            strPickString3 = "اکنون";
        }
        return new Triple<>(true, strPickString, new TicketMessage(jLongValue, str3, jLongValue2, strPickString3));
    }

    public final boolean handleBackPressed() {
        if (this.mode == Mode.THREAD) {
            switchMode(Mode.LIST);
            return true;
        }
        if (this.mode != Mode.CREATE) {
            return false;
        }
        switchMode(Mode.LIST);
        return true;
    }

    private final ParseResult<TicketItem> parseTicketListResponse(String raw) {
        JSONArray jSONArray;
        Long l;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            boolean z = objNextValue instanceof JSONObject;
            if (z) {
                JSONObject jSONObject = (JSONObject) objNextValue;
                String strOptString = jSONObject.optString("code", "");
                Intrinsics.checkNotNull(strOptString);
                if (true ^ StringsKt.isBlank(strOptString)) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت تیکت\u200cها"), null, 4, null);
                }
            }
            if (objNextValue instanceof JSONArray) {
                Intrinsics.checkNotNull(objNextValue);
                jSONArray = (JSONArray) objNextValue;
            } else if (z) {
                JSONObject jSONObject2 = (JSONObject) objNextValue;
                JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
                if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = jSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null) {
                    Intrinsics.checkNotNull(objNextValue);
                    jSONArray = numericObjectToArray(jSONObject2);
                    if (jSONArray == null) {
                        jSONArray = new JSONArray();
                    }
                } else {
                    jSONArray = jSONArrayOptJSONArray;
                }
            } else {
                jSONArray = new JSONArray();
            }
            ArrayList arrayList = new ArrayList(jSONArray.length());
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null && ((l = toLong(jSONObjectOptJSONObject.opt("ID"))) != null || (l = toLong(jSONObjectOptJSONObject.opt(TtmlNode.ATTR_ID))) != null)) {
                    long jLongValue = l.longValue();
                    String strPickString = pickString(jSONObjectOptJSONObject, "title");
                    if (strPickString == null) {
                        strPickString = "";
                    }
                    String str2 = strPickString;
                    if (StringsKt.isBlank(str2)) {
                        str2 = "تیکت #" + jLongValue;
                    }
                    String str3 = str2;
                    Integer num = toInt(jSONObjectOptJSONObject.opt(NotificationCompat.CATEGORY_STATUS));
                    int iIntValue = num != null ? num.intValue() : 0;
                    Integer num2 = toInt(jSONObjectOptJSONObject.opt("depart"));
                    int iIntValue2 = num2 != null ? num2.intValue() : 0;
                    String strPickString2 = pickString(jSONObjectOptJSONObject, "created_at", "createdAt");
                    if (strPickString2 == null) {
                        strPickString2 = "";
                    }
                    String str4 = strPickString2;
                    if (StringsKt.isBlank(str4)) {
                        str4 = "-";
                    }
                    arrayList.add(new TicketItem(jLongValue, str3, iIntValue, iIntValue2, str4));
                }
            }
            return new ParseResult<>(true, null, arrayList, 2, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
    }

    private final ParseResult<TicketMessage> parseTicketMessageResponse(String raw) {
        JSONArray jSONArray;
        Long l;
        String str = raw;
        if (str == null || StringsKt.isBlank(str)) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
        try {
            Object objNextValue = new JSONTokener(raw).nextValue();
            boolean z = objNextValue instanceof JSONObject;
            if (z) {
                JSONObject jSONObject = (JSONObject) objNextValue;
                String strOptString = jSONObject.optString("code", "");
                Intrinsics.checkNotNull(strOptString);
                if (true ^ StringsKt.isBlank(strOptString)) {
                    return new ParseResult<>(false, jSONObject.optString("message", "خطا در دریافت پیام\u200cها"), null, 4, null);
                }
            }
            if (objNextValue instanceof JSONArray) {
                Intrinsics.checkNotNull(objNextValue);
                jSONArray = (JSONArray) objNextValue;
            } else if (z) {
                JSONObject jSONObject2 = (JSONObject) objNextValue;
                JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
                if (jSONArrayOptJSONArray == null && (jSONArrayOptJSONArray = jSONObject2.optJSONArray(FirebaseAnalytics.Param.ITEMS)) == null) {
                    Intrinsics.checkNotNull(objNextValue);
                    jSONArray = numericObjectToArray(jSONObject2);
                    if (jSONArray == null) {
                        jSONArray = new JSONArray();
                    }
                } else {
                    jSONArray = jSONArrayOptJSONArray;
                }
            } else {
                jSONArray = new JSONArray();
            }
            ArrayList arrayList = new ArrayList(jSONArray.length());
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null && ((l = toLong(jSONObjectOptJSONObject.opt("ID"))) != null || (l = toLong(jSONObjectOptJSONObject.opt(TtmlNode.ATTR_ID))) != null)) {
                    long jLongValue = l.longValue();
                    String strPickString = pickString(jSONObjectOptJSONObject, "message", "text");
                    String str2 = strPickString == null ? "" : strPickString;
                    Long l2 = toLong(jSONObjectOptJSONObject.opt("user_id"));
                    long jLongValue2 = (l2 == null && (l2 = toLong(jSONObjectOptJSONObject.opt("userID"))) == null) ? 0L : l2.longValue();
                    String strPickString2 = pickString(jSONObjectOptJSONObject, "created_at", "createdAt");
                    if (strPickString2 == null) {
                        strPickString2 = "";
                    }
                    String str3 = strPickString2;
                    if (StringsKt.isBlank(str3)) {
                        str3 = "-";
                    }
                    arrayList.add(new TicketMessage(jLongValue, str2, jLongValue2, str3));
                }
            }
            return new ParseResult<>(true, null, arrayList, 2, null);
        } catch (Throwable unused) {
            return new ParseResult<>(false, "پاسخ نامعتبر است", null, 4, null);
        }
    }

    private final void showState(String message, String buttonTitle, Function0<Unit> action) {
        TextView textView = this.stateText;
        LinearLayout linearLayout = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateText");
            textView = null;
        }
        textView.setText(SafeUserMessage.INSTANCE.fromRaw(message, "خطا در دریافت تیکت\u200cها"));
        this.stateAction = action;
        String str = buttonTitle;
        if (str == null || StringsKt.isBlank(str)) {
            TextView textView2 = this.stateButton;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView2 = null;
            }
            textView2.setVisibility(8);
        } else {
            TextView textView3 = this.stateButton;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView3 = null;
            }
            textView3.setVisibility(0);
            TextView textView4 = this.stateButton;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("stateButton");
                textView4 = null;
            }
            textView4.setText(str);
        }
        LinearLayout linearLayout2 = this.stateOverlay;
        if (linearLayout2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
        } else {
            linearLayout = linearLayout2;
        }
        linearLayout.setVisibility(0);
    }

    private final void hideState() {
        LinearLayout linearLayout = this.stateOverlay;
        if (linearLayout == null) {
            Intrinsics.throwUninitializedPropertyAccessException("stateOverlay");
            linearLayout = null;
        }
        linearLayout.setVisibility(8);
        this.stateAction = null;
    }

    private final FrameLayout makeLoadingMoreOverlay() {
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutDirection(1);
        linearLayout.setGravity(16);
        linearLayout.setPadding(m385dp(12), m385dp(8), m385dp(12), m385dp(8));
        linearLayout.setBackground(roundedBg(-653454566, 654311423, m385dp(1), dpF(12)));
        ProgressBar progressBar = new ProgressBar(this.ctx);
        progressBar.setIndeterminate(true);
        Drawable indeterminateDrawable = progressBar.getIndeterminateDrawable();
        if (indeterminateDrawable != null) {
            indeterminateDrawable.setTint(this.accent);
        }
        TextView textView = new TextView(this.ctx);
        textView.setText("در حال بارگیری بیشتر...");
        textView.setTextColor(DefaultTimeBar.DEFAULT_BUFFERED_COLOR);
        textView.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this.ctx);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setIncludeFontPadding(false);
        linearLayout.addView(progressBar, new LinearLayout.LayoutParams(m385dp(14), m385dp(14)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart(m385dp(8));
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(textView, layoutParams);
        FrameLayout frameLayout = new FrameLayout(this.ctx);
        frameLayout.setVisibility(8);
        frameLayout.setClickable(false);
        frameLayout.setFocusable(false);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 81;
        layoutParams2.bottomMargin = m385dp(18);
        Unit unit2 = Unit.INSTANCE;
        frameLayout.addView(linearLayout, layoutParams2);
        return frameLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Triple<Integer, Integer, Integer> ticketStatusStyle(int status) {
        if (status == 1) {
            return new Triple<>(521282584, 1430184070, -10955126);
        }
        if (status == 2) {
            return new Triple<>(337516296, 1173730066, -468598);
        }
        if (status == 3) {
            return new Triple<>(437330998, 1433712383, -4728833);
        }
        if (status == 4) {
            return new Triple<>(857673487, 1442802282, -25701);
        }
        return new Triple<>(337516296, 1173730066, -468598);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String departLabel(int depart) {
        Object next;
        String title;
        Iterator<T> it = this.departOptions.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (((DepartOption) next).getId() == depart) {
                break;
            }
        }
        DepartOption departOption = (DepartOption) next;
        return (departOption == null || (title = departOption.getTitle()) == null) ? "عمومی" : title;
    }

    private final void showToast(String text) {
        Toast.makeText(this.ctx, SafeUserMessage.INSTANCE.fromRaw(text, "عملیات انجام نشد"), 0).show();
    }

    private final boolean isLoggedIn() {
        if (this.sessionUserId > 0) {
            String str = this.sessionToken;
            if (!(str == null || StringsKt.isBlank(str))) {
                return true;
            }
        }
        return false;
    }

    private final Map<String, String> authHeaders() {
        String str = this.sessionToken;
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        long j = this.sessionUserId;
        if (j > 0) {
            linkedHashMap.put("x-fk-user-id", String.valueOf(j));
        }
        String str2 = str;
        if (!(str2 == null || StringsKt.isBlank(str2))) {
            linkedHashMap.put("x-fk-session", str);
        }
        return linkedHashMap;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    private final String pickString(JSONObject obj, String... keys) {
        if (obj == null) {
            return null;
        }
        for (String str : keys) {
            Object objOpt = obj.opt(str);
            if (objOpt != null && !Intrinsics.areEqual(objOpt, JSONObject.NULL)) {
                String string = StringsKt.trim((CharSequence) objOpt.toString()).toString();
                if (!StringsKt.isBlank(string)) {
                    return string;
                }
            }
        }
        return null;
    }

    private final Long toLong(Object v) {
        if (v instanceof Number) {
            return Long.valueOf(((Number) v).longValue());
        }
        if (v instanceof String) {
            return StringsKt.toLongOrNull(StringsKt.trim((CharSequence) StringsKt.replace$default((String) v, ",", "", false, 4, (Object) null)).toString());
        }
        return null;
    }

    private final Integer toInt(Object v) {
        if (v instanceof Number) {
            return Integer.valueOf(((Number) v).intValue());
        }
        if (v instanceof String) {
            return StringsKt.toIntOrNull(StringsKt.trim((CharSequence) v).toString());
        }
        return null;
    }

    private final boolean toBool(Object v) {
        if (v instanceof Boolean) {
            return ((Boolean) v).booleanValue();
        }
        if (v instanceof Number) {
            if (((Number) v).intValue() != 0) {
                return true;
            }
        } else if (v instanceof String) {
            String string = StringsKt.trim((CharSequence) v).toString();
            Locale US = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US, "US");
            String lowerCase = string.toLowerCase(US);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (Intrinsics.areEqual(lowerCase, "1") || Intrinsics.areEqual(lowerCase, "true") || Intrinsics.areEqual(lowerCase, "ok") || Intrinsics.areEqual(lowerCase, FirebaseAnalytics.Param.SUCCESS)) {
                return true;
            }
        }
        return false;
    }

    private final JSONArray numericObjectToArray(JSONObject obj) {
        boolean z;
        Iterator<String> itKeys = obj.keys();
        JSONArray jSONArray = new JSONArray();
        boolean z2 = false;
        while (itKeys.hasNext()) {
            String next = itKeys.next();
            Intrinsics.checkNotNull(next);
            String str = next;
            int i = 0;
            while (true) {
                if (i >= str.length()) {
                    z = true;
                    break;
                }
                if (!Character.isDigit(str.charAt(i))) {
                    z = false;
                    break;
                }
                i++;
            }
            if (z) {
                Object objOpt = obj.opt(next);
                if (objOpt instanceof JSONObject) {
                    jSONArray.put(objOpt);
                    z2 = true;
                }
            }
        }
        if (z2) {
            return jSONArray;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: dp */
    public final int m385dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.executor.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0017B/\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0002\u0010\fJ\b\u0010\r\u001a\u00020\u000eH\u0016J \u0010\u000f\u001a\u00020\u000b2\u000e\u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u000eH\u0016J \u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u000eH\u0016J\u0018\u0010\u0016\u001a\u00020\u000b2\u000e\u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketListAdapter$VH;", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketItem;", "isTouchDevice", "", "onClick", "Lkotlin/Function1;", "", "(Lcom/filmkio/nativescreen/account/TicketSupportScreenView;Ljava/util/List;ZLkotlin/jvm/functions/Function1;)V", "getItemCount", "", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    final class TicketListAdapter extends RecyclerView.Adapter<C2685VH> {
        private final List<TicketItem> data;
        private final boolean isTouchDevice;
        private final Function1<TicketItem, Unit> onClick;
        final /* synthetic */ TicketSupportScreenView this$0;

        /* JADX WARN: Multi-variable type inference failed */
        public TicketListAdapter(TicketSupportScreenView ticketSupportScreenView, List<TicketItem> data, boolean z, Function1<? super TicketItem, Unit> onClick) {
            Intrinsics.checkNotNullParameter(data, "data");
            Intrinsics.checkNotNullParameter(onClick, "onClick");
            this.this$0 = ticketSupportScreenView;
            this.data = data;
            this.isTouchDevice = z;
            this.onClick = onClick;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2685VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            TicketSupportScreenView ticketSupportScreenView = this.this$0;
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setPadding(ticketSupportScreenView.m385dp(12), ticketSupportScreenView.m385dp(10), ticketSupportScreenView.m385dp(12), ticketSupportScreenView.m385dp(10));
            linearLayout.setBackground(ticketSupportScreenView.roundedBg(ticketSupportScreenView.cardFill, ticketSupportScreenView.cardStroke, ticketSupportScreenView.m385dp(1), ticketSupportScreenView.dpF(12)));
            linearLayout.setClickable(true);
            linearLayout.setFocusable(!this.isTouchDevice);
            linearLayout.setFocusableInTouchMode(!this.isTouchDevice);
            return new C2685VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2685VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2685VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m385dp(10);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.TicketSupportScreenView$TicketListAdapter$VH */
        /* JADX INFO: compiled from: TicketSupportScreenView.kt */
        @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketListAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketListAdapter;Landroid/widget/LinearLayout;)V", "metaText", "Landroid/widget/TextView;", "statusChip", "topTitle", "bind", "", "item", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketItem;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2685VH extends RecyclerView.ViewHolder {
            private final TextView metaText;
            private final LinearLayout root;
            private final TextView statusChip;
            final /* synthetic */ TicketListAdapter this$0;
            private final TextView topTitle;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2685VH(TicketListAdapter ticketListAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = ticketListAdapter;
                this.root = root;
                LinearLayout linearLayout = new LinearLayout(ticketListAdapter.this$0.ctx);
                linearLayout.setOrientation(0);
                linearLayout.setLayoutDirection(1);
                linearLayout.setGravity(16);
                TextView textView = new TextView(ticketListAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView = ticketListAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(14.0f);
                Typeface typefaceBold = NativeFonts.INSTANCE.bold(ticketSupportScreenView.ctx);
                textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
                textView.setIncludeFontPadding(false);
                textView.setMaxLines(1);
                textView.setEllipsize(TextUtils.TruncateAt.END);
                this.topTitle = textView;
                TextView textView2 = new TextView(ticketListAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView2 = ticketListAdapter.this$0;
                textView2.setTextSize(11.0f);
                Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ticketSupportScreenView2.ctx);
                textView2.setTypeface(typefaceMedium == null ? textView2.getTypeface() : typefaceMedium);
                textView2.setGravity(17);
                textView2.setIncludeFontPadding(false);
                textView2.setPadding(ticketSupportScreenView2.m385dp(10), ticketSupportScreenView2.m385dp(4), ticketSupportScreenView2.m385dp(10), ticketSupportScreenView2.m385dp(4));
                this.statusChip = textView2;
                linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
                linearLayout.addView(textView2);
                TextView textView3 = new TextView(ticketListAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView3 = ticketListAdapter.this$0;
                textView3.setTextColor(-5324327);
                textView3.setTextSize(12.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(ticketSupportScreenView3.ctx);
                textView3.setTypeface(typefaceRegular == null ? textView3.getTypeface() : typefaceRegular);
                textView3.setIncludeFontPadding(false);
                textView3.setLineSpacing(ticketSupportScreenView3.m385dp(1), 1.0f);
                this.metaText = textView3;
                root.addView(linearLayout);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.topMargin = ticketListAdapter.this$0.m385dp(8);
                Unit unit = Unit.INSTANCE;
                root.addView(textView3, layoutParams);
            }

            public final void bind(final TicketItem item) {
                Intrinsics.checkNotNullParameter(item, "item");
                this.topTitle.setText(item.getTitle());
                this.metaText.setText("شماره #" + item.getId() + "   •   دپارتمان: " + this.this$0.this$0.departLabel(item.getDepart()) + "   •   تاریخ: " + item.getCreatedAt());
                Triple tripleTicketStatusStyle = this.this$0.this$0.ticketStatusStyle(item.getStatus());
                this.statusChip.setText(this.this$0.this$0.ticketStatusLabel(item.getStatus()));
                this.statusChip.setTextColor(((Number) tripleTicketStatusStyle.getThird()).intValue());
                this.statusChip.setBackground(this.this$0.this$0.roundedBg(((Number) tripleTicketStatusStyle.getFirst()).intValue(), ((Number) tripleTicketStatusStyle.getSecond()).intValue(), this.this$0.this$0.m385dp(1), this.this$0.this$0.dpF(999)));
                LinearLayout linearLayout = this.root;
                final TicketListAdapter ticketListAdapter = this.this$0;
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.TicketSupportScreenView$TicketListAdapter$VH$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        TicketSupportScreenView.TicketListAdapter.C2685VH.bind$lambda$5(ticketListAdapter, item, view);
                    }
                });
            }

            /* JADX INFO: Access modifiers changed from: private */
            public static final void bind$lambda$5(TicketListAdapter this$0, TicketItem item, View view) {
                Intrinsics.checkNotNullParameter(this$0, "this$0");
                Intrinsics.checkNotNullParameter(item, "$item");
                this$0.onClick.invoke(item);
            }
        }
    }

    /* JADX INFO: compiled from: TicketSupportScreenView.kt */
    @Metadata(m779d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0017B#\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bJ\b\u0010\f\u001a\u00020\rH\u0016J \u0010\u000e\u001a\u00020\u000f2\u000e\u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\rH\u0016J \u0010\u0012\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\rH\u0016J\u0018\u0010\u0016\u001a\u00020\u000f2\u000e\u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u0003H\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessageAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessageAdapter$VH;", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView;", "data", "", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessage;", "userId", "", "isTouchDevice", "", "(Lcom/filmkio/nativescreen/account/TicketSupportScreenView;Ljava/util/List;JZ)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onViewAttachedToWindow", "VH", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private final class TicketMessageAdapter extends RecyclerView.Adapter<C2687VH> {
        private final List<TicketMessage> data;
        private final boolean isTouchDevice;
        final /* synthetic */ TicketSupportScreenView this$0;
        private final long userId;

        public TicketMessageAdapter(TicketSupportScreenView ticketSupportScreenView, List<TicketMessage> data, long j, boolean z) {
            Intrinsics.checkNotNullParameter(data, "data");
            this.this$0 = ticketSupportScreenView;
            this.data = data;
            this.userId = j;
            this.isTouchDevice = z;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public C2687VH onCreateViewHolder(ViewGroup parent, int viewType) {
            Intrinsics.checkNotNullParameter(parent, "parent");
            LinearLayout linearLayout = new LinearLayout(parent.getContext());
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            return new C2687VH(this, linearLayout);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(C2687VH holder, int position) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            holder.bind(this.data.get(position));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.data.size();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onViewAttachedToWindow(C2687VH holder) {
            Intrinsics.checkNotNullParameter(holder, "holder");
            super.onViewAttachedToWindow(holder);
            ViewGroup.LayoutParams layoutParams = holder.itemView.getLayoutParams();
            RecyclerView.LayoutParams layoutParams2 = layoutParams instanceof RecyclerView.LayoutParams ? (RecyclerView.LayoutParams) layoutParams : null;
            if (layoutParams2 != null) {
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                layoutParams2.bottomMargin = this.this$0.m385dp(8);
                holder.itemView.setLayoutParams(layoutParams2);
            }
        }

        /* JADX INFO: renamed from: com.filmkio.nativescreen.account.TicketSupportScreenView$TicketMessageAdapter$VH */
        /* JADX INFO: compiled from: TicketSupportScreenView.kt */
        @Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, m780d2 = {"Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessageAdapter$VH;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "root", "Landroid/widget/LinearLayout;", "(Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessageAdapter;Landroid/widget/LinearLayout;)V", "bubble", "dateText", "Landroid/widget/TextView;", "messageText", "bind", "", "item", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView$TicketMessage;", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
        public final class C2687VH extends RecyclerView.ViewHolder {
            private final LinearLayout bubble;
            private final TextView dateText;
            private final TextView messageText;
            private final LinearLayout root;
            final /* synthetic */ TicketMessageAdapter this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C2687VH(TicketMessageAdapter ticketMessageAdapter, LinearLayout root) {
                super(root);
                Intrinsics.checkNotNullParameter(root, "root");
                this.this$0 = ticketMessageAdapter;
                this.root = root;
                LinearLayout linearLayout = new LinearLayout(ticketMessageAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView = ticketMessageAdapter.this$0;
                linearLayout.setOrientation(1);
                linearLayout.setLayoutDirection(1);
                linearLayout.setPadding(ticketSupportScreenView.m385dp(10), ticketSupportScreenView.m385dp(8), ticketSupportScreenView.m385dp(10), ticketSupportScreenView.m385dp(8));
                this.bubble = linearLayout;
                TextView textView = new TextView(ticketMessageAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView2 = ticketMessageAdapter.this$0;
                textView.setTextColor(-1);
                textView.setTextSize(13.0f);
                Typeface typefaceRegular = NativeFonts.INSTANCE.regular(ticketSupportScreenView2.ctx);
                textView.setTypeface(typefaceRegular == null ? textView.getTypeface() : typefaceRegular);
                textView.setIncludeFontPadding(false);
                textView.setLineSpacing(ticketSupportScreenView2.m385dp(2), 1.0f);
                textView.setSingleLine(false);
                textView.setMaxLines(Integer.MAX_VALUE);
                textView.setEllipsize(null);
                textView.setHorizontallyScrolling(false);
                textView.setGravity(GravityCompat.START);
                textView.setTextAlignment(5);
                textView.setTextDirection(1);
                if (Build.VERSION.SDK_INT >= 23) {
                    textView.setBreakStrategy(0);
                    textView.setHyphenationFrequency(0);
                }
                this.messageText = textView;
                TextView textView2 = new TextView(ticketMessageAdapter.this$0.ctx);
                TicketSupportScreenView ticketSupportScreenView3 = ticketMessageAdapter.this$0;
                textView2.setTextColor(-5324327);
                textView2.setTextSize(11.0f);
                Typeface typefaceRegular2 = NativeFonts.INSTANCE.regular(ticketSupportScreenView3.ctx);
                textView2.setTypeface(typefaceRegular2 == null ? textView2.getTypeface() : typefaceRegular2);
                textView2.setIncludeFontPadding(false);
                this.dateText = textView2;
                linearLayout.addView(textView);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.topMargin = ticketMessageAdapter.this$0.m385dp(6);
                Unit unit = Unit.INSTANCE;
                linearLayout.addView(textView2, layoutParams);
                root.addView(linearLayout);
            }

            public final void bind(TicketMessage item) {
                Intrinsics.checkNotNullParameter(item, "item");
                boolean z = item.getUserId() == this.this$0.userId;
                LinearLayout linearLayout = this.root;
                int i = GravityCompat.END;
                linearLayout.setGravity(z ? 8388613 : 8388611);
                ViewGroup.LayoutParams layoutParams = this.bubble.getLayoutParams();
                LinearLayout.LayoutParams layoutParams2 = layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : null;
                if (layoutParams2 == null) {
                    layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                }
                layoutParams2.width = -1;
                layoutParams2.height = -2;
                if (!z) {
                    i = 8388611;
                }
                layoutParams2.gravity = i;
                TicketSupportScreenView ticketSupportScreenView = this.this$0.this$0;
                layoutParams2.setMarginStart(z ? ticketSupportScreenView.m385dp(44) : ticketSupportScreenView.m385dp(10));
                layoutParams2.setMarginEnd(z ? this.this$0.this$0.m385dp(10) : this.this$0.this$0.m385dp(44));
                this.bubble.setLayoutParams(layoutParams2);
                this.bubble.setBackground(this.this$0.this$0.roundedBg(z ? 589048381 : 454171152, z ? 1248305663 : 955624721, this.this$0.this$0.m385dp(1), this.this$0.this$0.dpF(12)));
                TextView textView = this.messageText;
                String text = item.getText();
                if (StringsKt.isBlank(text)) {
                    text = "-";
                }
                textView.setText(text);
                this.dateText.setText(item.getCreatedAt());
            }
        }
    }
}
