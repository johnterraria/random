package com.filmkio.nativescreen.account;

import androidx.core.app.NotificationCompat;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0002\b#\b\u0087\b\u0018\u00002\u00020\u0001B\u0083\u0001\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r\u0012\u0012\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u0010\u0012\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\r\u0012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\r¢\u0006\u0002\u0010\u0014J\u000b\u0010%\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00120\rHÆ\u0003J\u000f\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00120\rHÆ\u0003J\u000b\u0010(\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010)\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010*\u001a\u00020\u0007HÆ\u0003J\t\u0010+\u001a\u00020\tHÆ\u0003J\u000b\u0010,\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010-\u001a\u00020\tHÆ\u0003J\u000f\u0010.\u001a\b\u0012\u0004\u0012\u00020\u000e0\rHÆ\u0003J\u0015\u0010/\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u0010HÆ\u0003J\u009d\u0001\u00100\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u000b\u001a\u00020\t2\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0014\b\u0002\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u00102\u000e\b\u0002\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\r2\u000e\b\u0002\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\rHÆ\u0001J\u0013\u00101\u001a\u00020\u00072\b\u00102\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00103\u001a\u00020\tHÖ\u0001J\t\u00104\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0018R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0018R\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001cR\u0011\u0010\u000b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0016R\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\r¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001cR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u001d\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\u0010¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0018¨\u00065"}, m780d2 = {"Lcom/filmkio/nativescreen/account/UserPanelData;", "", "userName", "", "displayName", "email", "subscriberStatus", "", "dayLeft", "", "expireDate", "progressPercent", "notifications", "", "Lcom/filmkio/nativescreen/account/NotifItem;", "summary", "", "menu", "Lcom/filmkio/nativescreen/account/PanelMenuItem;", NotificationCompat.CATEGORY_SOCIAL, "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;ILjava/util/List;Ljava/util/Map;Ljava/util/List;Ljava/util/List;)V", "getDayLeft", "()I", "getDisplayName", "()Ljava/lang/String;", "getEmail", "getExpireDate", "getMenu", "()Ljava/util/List;", "getNotifications", "getProgressPercent", "getSocial", "getSubscriberStatus", "()Z", "getSummary", "()Ljava/util/Map;", "getUserName", "component1", "component10", "component11", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class UserPanelData {
    public static final int $stable = 8;
    private final int dayLeft;
    private final String displayName;
    private final String email;
    private final String expireDate;
    private final List<PanelMenuItem> menu;
    private final List<NotifItem> notifications;
    private final int progressPercent;
    private final List<PanelMenuItem> social;
    private final boolean subscriberStatus;
    private final Map<String, Integer> summary;
    private final String userName;

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getUserName() {
        return this.userName;
    }

    public final List<PanelMenuItem> component10() {
        return this.menu;
    }

    public final List<PanelMenuItem> component11() {
        return this.social;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getDisplayName() {
        return this.displayName;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getEmail() {
        return this.email;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final boolean getSubscriberStatus() {
        return this.subscriberStatus;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getDayLeft() {
        return this.dayLeft;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getExpireDate() {
        return this.expireDate;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final int getProgressPercent() {
        return this.progressPercent;
    }

    public final List<NotifItem> component8() {
        return this.notifications;
    }

    public final Map<String, Integer> component9() {
        return this.summary;
    }

    public final UserPanelData copy(String userName, String displayName, String email, boolean subscriberStatus, int dayLeft, String expireDate, int progressPercent, List<NotifItem> notifications, Map<String, Integer> summary, List<PanelMenuItem> menu, List<PanelMenuItem> social) {
        Intrinsics.checkNotNullParameter(notifications, "notifications");
        Intrinsics.checkNotNullParameter(summary, "summary");
        Intrinsics.checkNotNullParameter(menu, "menu");
        Intrinsics.checkNotNullParameter(social, "social");
        return new UserPanelData(userName, displayName, email, subscriberStatus, dayLeft, expireDate, progressPercent, notifications, summary, menu, social);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof UserPanelData)) {
            return false;
        }
        UserPanelData userPanelData = (UserPanelData) other;
        return Intrinsics.areEqual(this.userName, userPanelData.userName) && Intrinsics.areEqual(this.displayName, userPanelData.displayName) && Intrinsics.areEqual(this.email, userPanelData.email) && this.subscriberStatus == userPanelData.subscriberStatus && this.dayLeft == userPanelData.dayLeft && Intrinsics.areEqual(this.expireDate, userPanelData.expireDate) && this.progressPercent == userPanelData.progressPercent && Intrinsics.areEqual(this.notifications, userPanelData.notifications) && Intrinsics.areEqual(this.summary, userPanelData.summary) && Intrinsics.areEqual(this.menu, userPanelData.menu) && Intrinsics.areEqual(this.social, userPanelData.social);
    }

    public int hashCode() {
        String str = this.userName;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        String str2 = this.displayName;
        int iHashCode2 = (iHashCode + (str2 == null ? 0 : str2.hashCode())) * 31;
        String str3 = this.email;
        int iHashCode3 = (((((iHashCode2 + (str3 == null ? 0 : str3.hashCode())) * 31) + Boolean.hashCode(this.subscriberStatus)) * 31) + Integer.hashCode(this.dayLeft)) * 31;
        String str4 = this.expireDate;
        return ((((((((((iHashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31) + Integer.hashCode(this.progressPercent)) * 31) + this.notifications.hashCode()) * 31) + this.summary.hashCode()) * 31) + this.menu.hashCode()) * 31) + this.social.hashCode();
    }

    public String toString() {
        return "UserPanelData(userName=" + this.userName + ", displayName=" + this.displayName + ", email=" + this.email + ", subscriberStatus=" + this.subscriberStatus + ", dayLeft=" + this.dayLeft + ", expireDate=" + this.expireDate + ", progressPercent=" + this.progressPercent + ", notifications=" + this.notifications + ", summary=" + this.summary + ", menu=" + this.menu + ", social=" + this.social + ")";
    }

    public UserPanelData(String str, String str2, String str3, boolean z, int i, String str4, int i2, List<NotifItem> notifications, Map<String, Integer> summary, List<PanelMenuItem> menu, List<PanelMenuItem> social) {
        Intrinsics.checkNotNullParameter(notifications, "notifications");
        Intrinsics.checkNotNullParameter(summary, "summary");
        Intrinsics.checkNotNullParameter(menu, "menu");
        Intrinsics.checkNotNullParameter(social, "social");
        this.userName = str;
        this.displayName = str2;
        this.email = str3;
        this.subscriberStatus = z;
        this.dayLeft = i;
        this.expireDate = str4;
        this.progressPercent = i2;
        this.notifications = notifications;
        this.summary = summary;
        this.menu = menu;
        this.social = social;
    }

    public final String getUserName() {
        return this.userName;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public final String getEmail() {
        return this.email;
    }

    public final boolean getSubscriberStatus() {
        return this.subscriberStatus;
    }

    public final int getDayLeft() {
        return this.dayLeft;
    }

    public final String getExpireDate() {
        return this.expireDate;
    }

    public final int getProgressPercent() {
        return this.progressPercent;
    }

    public final List<NotifItem> getNotifications() {
        return this.notifications;
    }

    public final Map<String, Integer> getSummary() {
        return this.summary;
    }

    public final List<PanelMenuItem> getMenu() {
        return this.menu;
    }

    public final List<PanelMenuItem> getSocial() {
        return this.social;
    }
}
