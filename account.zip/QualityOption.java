package com.filmkio.nativescreen.account;

import com.google.firebase.messaging.Constants;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0005HÆ\u0003J'\u0010\u0010\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000b¨\u0006\u0016"}, m780d2 = {"Lcom/filmkio/nativescreen/account/QualityOption;", "", Constants.ScionAnalytics.PARAM_LABEL, "", "value", "", "qNum", "(Ljava/lang/String;II)V", "getLabel", "()Ljava/lang/String;", "getQNum", "()I", "getValue", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class QualityOption {
    public static final int $stable = 0;
    private final String label;
    private final int qNum;
    private final int value;

    public static /* synthetic */ QualityOption copy$default(QualityOption qualityOption, String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = qualityOption.label;
        }
        if ((i3 & 2) != 0) {
            i = qualityOption.value;
        }
        if ((i3 & 4) != 0) {
            i2 = qualityOption.qNum;
        }
        return qualityOption.copy(str, i, i2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getValue() {
        return this.value;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getQNum() {
        return this.qNum;
    }

    public final QualityOption copy(String label, int value, int qNum) {
        Intrinsics.checkNotNullParameter(label, "label");
        return new QualityOption(label, value, qNum);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QualityOption)) {
            return false;
        }
        QualityOption qualityOption = (QualityOption) other;
        return Intrinsics.areEqual(this.label, qualityOption.label) && this.value == qualityOption.value && this.qNum == qualityOption.qNum;
    }

    public int hashCode() {
        return (((this.label.hashCode() * 31) + Integer.hashCode(this.value)) * 31) + Integer.hashCode(this.qNum);
    }

    public String toString() {
        return "QualityOption(label=" + this.label + ", value=" + this.value + ", qNum=" + this.qNum + ")";
    }

    public QualityOption(String label, int i, int i2) {
        Intrinsics.checkNotNullParameter(label, "label");
        this.label = label;
        this.value = i;
        this.qNum = i2;
    }

    public final String getLabel() {
        return this.label;
    }

    public final int getQNum() {
        return this.qNum;
    }

    public final int getValue() {
        return this.value;
    }
}
