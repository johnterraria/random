package com.filmkio.nativescreen.account;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0010\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0002\u0010\bJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0002\u0010\u000eJ0\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001¢\u0006\u0002\u0010\u0014J\u0013\u0010\u0015\u001a\u00020\u00032\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0005HÖ\u0001R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000e¨\u0006\u001a"}, m780d2 = {"Lcom/filmkio/nativescreen/account/SimpleResult;", "", "ok", "", "message", "", "userId", "", "(ZLjava/lang/String;Ljava/lang/Long;)V", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "getUserId", "()Ljava/lang/Long;", "Ljava/lang/Long;", "component1", "component2", "component3", "copy", "(ZLjava/lang/String;Ljava/lang/Long;)Lcom/filmkio/nativescreen/account/SimpleResult;", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class SimpleResult {
    public static final int $stable = 0;
    private final String message;
    private final boolean ok;
    private final Long userId;

    public static /* synthetic */ SimpleResult copy$default(SimpleResult simpleResult, boolean z, String str, Long l, int i, Object obj) {
        if ((i & 1) != 0) {
            z = simpleResult.ok;
        }
        if ((i & 2) != 0) {
            str = simpleResult.message;
        }
        if ((i & 4) != 0) {
            l = simpleResult.userId;
        }
        return simpleResult.copy(z, str, l);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final boolean getOk() {
        return this.ok;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Long getUserId() {
        return this.userId;
    }

    public final SimpleResult copy(boolean ok, String message, Long userId) {
        return new SimpleResult(ok, message, userId);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SimpleResult)) {
            return false;
        }
        SimpleResult simpleResult = (SimpleResult) other;
        return this.ok == simpleResult.ok && Intrinsics.areEqual(this.message, simpleResult.message) && Intrinsics.areEqual(this.userId, simpleResult.userId);
    }

    public int hashCode() {
        int iHashCode = Boolean.hashCode(this.ok) * 31;
        String str = this.message;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        Long l = this.userId;
        return iHashCode2 + (l != null ? l.hashCode() : 0);
    }

    public String toString() {
        return "SimpleResult(ok=" + this.ok + ", message=" + this.message + ", userId=" + this.userId + ")";
    }

    public SimpleResult(boolean z, String str, Long l) {
        this.ok = z;
        this.message = str;
        this.userId = l;
    }

    public final boolean getOk() {
        return this.ok;
    }

    public final String getMessage() {
        return this.message;
    }

    public final Long getUserId() {
        return this.userId;
    }
}
