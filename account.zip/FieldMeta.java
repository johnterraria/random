package com.filmkio.nativescreen.account;

import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.Constants;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AccountModels.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0010\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B#\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0001\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\u0002\u0010\u0007J\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0001HÆ\u0003J\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0002\u0010\u000bJ2\u0010\u0012\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006HÆ\u0001¢\u0006\u0002\u0010\u0013J\u0013\u0010\u0014\u001a\u00020\u00062\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0015\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0001¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u0019"}, m780d2 = {"Lcom/filmkio/nativescreen/account/FieldMeta;", "", Constants.ScionAnalytics.PARAM_LABEL, "", "value", NotificationCompat.CATEGORY_STATUS, "", "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Boolean;)V", "getLabel", "()Ljava/lang/String;", "getStatus", "()Ljava/lang/Boolean;", "Ljava/lang/Boolean;", "getValue", "()Ljava/lang/Object;", "component1", "component2", "component3", "copy", "(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Boolean;)Lcom/filmkio/nativescreen/account/FieldMeta;", "equals", "other", "hashCode", "", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final /* data */ class FieldMeta {
    public static final int $stable = 8;
    private final String label;
    private final Boolean status;
    private final Object value;

    public static /* synthetic */ FieldMeta copy$default(FieldMeta fieldMeta, String str, Object obj, Boolean bool, int i, Object obj2) {
        if ((i & 1) != 0) {
            str = fieldMeta.label;
        }
        if ((i & 2) != 0) {
            obj = fieldMeta.value;
        }
        if ((i & 4) != 0) {
            bool = fieldMeta.status;
        }
        return fieldMeta.copy(str, obj, bool);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final Object getValue() {
        return this.value;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final Boolean getStatus() {
        return this.status;
    }

    public final FieldMeta copy(String label, Object value, Boolean status) {
        return new FieldMeta(label, value, status);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof FieldMeta)) {
            return false;
        }
        FieldMeta fieldMeta = (FieldMeta) other;
        return Intrinsics.areEqual(this.label, fieldMeta.label) && Intrinsics.areEqual(this.value, fieldMeta.value) && Intrinsics.areEqual(this.status, fieldMeta.status);
    }

    public int hashCode() {
        String str = this.label;
        int iHashCode = (str == null ? 0 : str.hashCode()) * 31;
        Object obj = this.value;
        int iHashCode2 = (iHashCode + (obj == null ? 0 : obj.hashCode())) * 31;
        Boolean bool = this.status;
        return iHashCode2 + (bool != null ? bool.hashCode() : 0);
    }

    public String toString() {
        return "FieldMeta(label=" + this.label + ", value=" + this.value + ", status=" + this.status + ")";
    }

    public FieldMeta(String str, Object obj, Boolean bool) {
        this.label = str;
        this.value = obj;
        this.status = bool;
    }

    public final String getLabel() {
        return this.label;
    }

    public final Object getValue() {
        return this.value;
    }

    public final Boolean getStatus() {
        return this.status;
    }
}
