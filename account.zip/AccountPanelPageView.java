package com.filmkio.nativescreen.account;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import com.filmkio.AppState;
import com.filmkio.C2629R;
import com.filmkio.PanelSingleActivity;
import com.filmkio.ScreenMotionKt;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.history.HistoryScreenView;
import com.filmkio.nativescreen.querygrid.QueryBase;
import com.filmkio.nativescreen.querygrid.QueryGridModelsKt;
import com.filmkio.nativescreen.querygrid.QuerySeed;
import com.filmkio.nativescreen.watchlist.WatchlistScreenView;
import com.google.android.gms.common.Scopes;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: AccountPanelPageView.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0013\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007J\u0010\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\tH\u0002J\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0014\u001a\u00020\tH\u0002J\u0006\u0010\u0017\u001a\u00020\u0018J\u0010\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\u001c\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\u001d\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\u001e\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\u001f\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010 \u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010!\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010\"\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010#\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010$\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010%\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\u0010\u0010&\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0005H\u0002J\"\u0010'\u001a\u00020\u00052\b\u0010(\u001a\u0004\u0018\u00010\u00052\u0006\u0010)\u001a\u00020\t2\u0006\u0010*\u001a\u00020\tH\u0002J\u0018\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020\u00052\u0006\u0010.\u001a\u00020\u0005H\u0002J4\u0010/\u001a\u00020,2\u0006\u00100\u001a\u0002012\b\u0010(\u001a\u0004\u0018\u00010\u00052\b\u00102\u001a\u0004\u0018\u00010\u00052\u0006\u0010)\u001a\u00020\t2\u0006\u0010*\u001a\u00020\tH\u0002J\u0010\u00103\u001a\u00020,2\u0006\u00100\u001a\u000201H\u0002J(\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\t2\u0006\u00107\u001a\u00020\t2\u0006\u00108\u001a\u00020\t2\u0006\u00109\u001a\u00020\u0016H\u0002J\u0010\u0010:\u001a\u0002052\u0006\u0010;\u001a\u00020\tH\u0002R\u000e\u0010\b\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006<"}, m780d2 = {"Lcom/filmkio/nativescreen/account/AccountPanelPageView;", "Landroid/widget/FrameLayout;", "ctx", "Landroid/content/Context;", "titleText", "", "pageKey", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V", "cardFill", "", "cardStroke", "headerBg", "listsView", "Lcom/filmkio/nativescreen/account/ListsScreenView;", "requestsView", "Lcom/filmkio/nativescreen/account/RequestsScreenView;", "screenBg", "ticketSupportView", "Lcom/filmkio/nativescreen/account/TicketSupportScreenView;", "dp", "v", "dpF", "", "handleBackPressed", "", "isArtistsPage", "key", "isBoxOfficePage", "isEditProfilePage", "isFaqPage", "isListsPage", "isPaymentHistoryPage", "isPlaySettingsPage", "isRequestsPage", "isSupportPage", "isTop250MoviesPage", "isTop250SeriesPage", "isWatchHistoryPage", "isWatchlistPage", "normalizeHistoryPlayerType", "type", "season", "part", "openArtistArchiveFromPanel", "", "queryName", "displayName", "openPlayerFromPanel", "postId", "", "title", "openSingleFromPanel", "roundedBg", "Landroid/graphics/drawable/GradientDrawable;", "fill", "stroke", "strokeWidth", "radius", "solidBg", "color", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AccountPanelPageView extends FrameLayout {
    public static final int $stable = 8;
    private final int cardFill;
    private final int cardStroke;
    private final Context ctx;
    private final int headerBg;
    private ListsScreenView listsView;
    private final String pageKey;
    private RequestsScreenView requestsView;
    private final int screenBg;
    private TicketSupportScreenView ticketSupportView;
    private final String titleText;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AccountPanelPageView(Context ctx, String titleText, String pageKey) {
        super(ctx);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(titleText, "titleText");
        Intrinsics.checkNotNullParameter(pageKey, "pageKey");
        this.ctx = ctx;
        this.titleText = titleText;
        this.pageKey = pageKey;
        this.screenBg = -16315632;
        this.headerBg = -16117737;
        this.cardFill = -15722719;
        this.cardStroke = 978213481;
        setLayoutDirection(1);
        setBackgroundColor(-16315632);
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutDirection(1);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        addView(linearLayout);
        LinearLayout linearLayout2 = new LinearLayout(ctx);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutDirection(1);
        linearLayout2.setGravity(16);
        linearLayout2.setBackground(solidBg(-16117737));
        linearLayout2.setPadding(m376dp(14), m376dp(10), m376dp(14), m376dp(10));
        TextView textView = new TextView(ctx);
        textView.setText(titleText);
        textView.setTextColor(-1);
        textView.setTextSize(20.0f);
        Typeface typefaceBold = NativeFonts.INSTANCE.bold(ctx);
        textView.setTypeface(typefaceBold == null ? textView.getTypeface() : typefaceBold);
        textView.setGravity(8388629);
        textView.setTextAlignment(5);
        textView.setSingleLine(true);
        FrameLayout frameLayout = new FrameLayout(ctx);
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setForeground(roundedBg(270017585, 822083583, m376dp(1), dpF(10)));
        frameLayout.setPadding(m376dp(10), m376dp(10), m376dp(10), m376dp(10));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountPanelPageView.lambda$4$lambda$3(this.f$0, view);
            }
        });
        ImageView imageView = new ImageView(ctx);
        imageView.setImageResource(C2629R.drawable.ic_back_arrow_left);
        imageView.setColorFilter(-1);
        frameLayout.addView(imageView, new FrameLayout.LayoutParams(m376dp(22), m376dp(22), 17));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginStart(m376dp(10));
        Unit unit = Unit.INSTANCE;
        linearLayout2.addView(textView, layoutParams);
        linearLayout2.addView(frameLayout, new LinearLayout.LayoutParams(m376dp(44), m376dp(44)));
        linearLayout.addView(linearLayout2);
        String string = StringsKt.trim((CharSequence) pageKey).toString();
        Locale US = Locale.US;
        Intrinsics.checkNotNullExpressionValue(US, "US");
        String lowerCase = string.toLowerCase(US);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        String apiBase = AppState.INSTANCE.getApiBase();
        apiBase = apiBase == null ? "" : apiBase;
        if (isWatchHistoryPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new HistoryScreenView(ctx, apiBase, null, 0, new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$historyView$1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    this.this$0.openSingleFromPanel(j);
                }
            }, new Function5<Long, String, String, Integer, Integer, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$historyView$2
                {
                    super(5);
                }

                @Override // kotlin.jvm.functions.Function5
                public /* bridge */ /* synthetic */ Unit invoke(Long l, String str, String str2, Integer num, Integer num2) {
                    invoke(l.longValue(), str, str2, num.intValue(), num2.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j, String str, String str2, int i, int i2) {
                    this.this$0.openPlayerFromPanel(j, str, str2, i, i2);
                }
            }, null, false, null, 256, null), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isWatchlistPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new WatchlistScreenView(ctx, apiBase, null, 0, new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$watchlistView$1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    this.this$0.openSingleFromPanel(j);
                }
            }, null, false, null, 128, null), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isPaymentHistoryPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new PaymentHistoryScreenView(ctx, apiBase, null), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isSupportPage(lowerCase)) {
            this.requestsView = null;
            this.listsView = null;
            TicketSupportScreenView ticketSupportScreenView = new TicketSupportScreenView(ctx, apiBase, null);
            this.ticketSupportView = ticketSupportScreenView;
            linearLayout.addView(ticketSupportScreenView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isRequestsPage(lowerCase)) {
            this.ticketSupportView = null;
            this.listsView = null;
            RequestsScreenView requestsScreenView = new RequestsScreenView(ctx, apiBase, null);
            this.requestsView = requestsScreenView;
            linearLayout.addView(requestsScreenView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isPlaySettingsPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new PlaySettingsScreenView(ctx, apiBase, null), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isEditProfilePage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new EditProfileScreenView(ctx, apiBase, null), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isListsPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            ListsScreenView listsScreenView = new ListsScreenView(ctx, apiBase, null, new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView.2
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    AccountPanelPageView.this.openSingleFromPanel(j);
                }
            });
            this.listsView = listsScreenView;
            linearLayout.addView(listsScreenView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isArtistsPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new ArtistsDirectoryScreenView(ctx, apiBase, CollectionsKt.listOf("/artistsApp"), new Function2<String, String, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$artistsView$1
                {
                    super(2);
                }

                @Override // kotlin.jvm.functions.Function2
                public /* bridge */ /* synthetic */ Unit invoke(String str, String str2) {
                    invoke2(str, str2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2(String queryName, String displayName) {
                    Intrinsics.checkNotNullParameter(queryName, "queryName");
                    Intrinsics.checkNotNullParameter(displayName, "displayName");
                    this.this$0.openArtistArchiveFromPanel(queryName, displayName);
                }
            }), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isTop250MoviesPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new TopChartScreenView(ctx, apiBase, CollectionsKt.listOf("/top250movies"), new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$topMoviesView$1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    this.this$0.openSingleFromPanel(j);
                }
            }), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isTop250SeriesPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new TopChartScreenView(ctx, apiBase, CollectionsKt.listOf("/top250series"), new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$topSeriesView$1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    this.this$0.openSingleFromPanel(j);
                }
            }), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isBoxOfficePage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new TopChartScreenView(ctx, apiBase, CollectionsKt.listOf("/boxoffice"), new Function1<Long, Unit>() { // from class: com.filmkio.nativescreen.account.AccountPanelPageView$boxOfficeView$1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                    invoke(l.longValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(long j) {
                    this.this$0.openSingleFromPanel(j);
                }
            }), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        if (isFaqPage(lowerCase)) {
            this.ticketSupportView = null;
            this.requestsView = null;
            this.listsView = null;
            linearLayout.addView(new FaqScreenView(ctx, apiBase, CollectionsKt.listOf("/faqs")), new LinearLayout.LayoutParams(-1, 0, 1.0f));
            return;
        }
        this.ticketSupportView = null;
        this.requestsView = null;
        this.listsView = null;
        ScrollView scrollView = new ScrollView(ctx);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setOverScrollMode(2);
        linearLayout.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayout3 = new LinearLayout(ctx);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutDirection(1);
        linearLayout3.setPadding(m376dp(16), m376dp(18), m376dp(16), m376dp(20));
        scrollView.addView(linearLayout3, new FrameLayout.LayoutParams(-1, -2));
        TextView textView2 = new TextView(ctx);
        textView2.setText(titleText);
        textView2.setTextColor(-1);
        textView2.setTextSize(18.0f);
        Typeface typefaceBold2 = NativeFonts.INSTANCE.bold(ctx);
        textView2.setTypeface(typefaceBold2 == null ? textView2.getTypeface() : typefaceBold2);
        textView2.setGravity(5);
        linearLayout3.addView(textView2);
        TextView textView3 = new TextView(ctx);
        textView3.setText("این صفحه آماده شده و به\u200cزودی داده\u200cهای \"" + titleText + "\" به API متصل می\u200cشود.");
        textView3.setTextColor(-4666915);
        textView3.setTextSize(13.0f);
        Typeface typefaceRegular = NativeFonts.INSTANCE.regular(ctx);
        textView3.setTypeface(typefaceRegular == null ? textView3.getTypeface() : typefaceRegular);
        textView3.setLineSpacing(m376dp(2), 1.0f);
        textView3.setGravity(5);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = m376dp(8);
        Unit unit2 = Unit.INSTANCE;
        linearLayout3.addView(textView3, layoutParams2);
        LinearLayout linearLayout4 = new LinearLayout(ctx);
        linearLayout4.setOrientation(1);
        linearLayout4.setLayoutDirection(1);
        linearLayout4.setPadding(m376dp(12), m376dp(12), m376dp(12), m376dp(12));
        linearLayout4.setBackground(roundedBg(-15722719, 978213481, m376dp(1), dpF(12)));
        TextView textView4 = new TextView(ctx);
        textView4.setText("شناسه صفحه");
        textView4.setTextColor(-5324327);
        textView4.setTextSize(12.0f);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(ctx);
        textView4.setTypeface(typefaceMedium == null ? textView4.getTypeface() : typefaceMedium);
        TextView textView5 = new TextView(ctx);
        String str = pageKey;
        textView5.setText(StringsKt.isBlank(str) ? "-" : str);
        textView5.setTextColor(-1);
        textView5.setTextSize(14.0f);
        Typeface typefaceBold3 = NativeFonts.INSTANCE.bold(ctx);
        textView5.setTypeface(typefaceBold3 == null ? textView5.getTypeface() : typefaceBold3);
        textView5.setTextDirection(3);
        linearLayout4.addView(textView4);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = m376dp(6);
        Unit unit3 = Unit.INSTANCE;
        linearLayout4.addView(textView5, layoutParams3);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = m376dp(14);
        Unit unit4 = Unit.INSTANCE;
        linearLayout3.addView(linearLayout4, layoutParams4);
    }

    static final void lambda$4$lambda$3(AccountPanelPageView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.handleBackPressed()) {
            return;
        }
        Context context = this$0.ctx;
        ComponentActivity componentActivity = context instanceof ComponentActivity ? (ComponentActivity) context : null;
        if (componentActivity != null) {
            componentActivity.getOnBackPressedDispatcher().onBackPressed();
            return;
        }
        Activity activity = context instanceof Activity ? (Activity) context : null;
        if (activity != null) {
            activity.finish();
        }
    }

    private final boolean isWatchHistoryPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "watch_history", false, 2, (Object) null) || Intrinsics.areEqual(key, "history") || StringsKt.contains$default((CharSequence) str, (CharSequence) "seen", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "watched", false, 2, (Object) null);
    }

    private final boolean isWatchlistPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "watchlist", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "marked", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "bookmark", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "favorite", false, 2, (Object) null);
    }

    private final boolean isPaymentHistoryPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "purchase_history", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "payment_history", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "order_history", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "orders", false, 2, (Object) null);
    }

    private final boolean isSupportPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "support", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "ticket", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "tickets", false, 2, (Object) null);
    }

    private final boolean isPlaySettingsPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "play_settings", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "playset", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "player_settings", false, 2, (Object) null);
    }

    private final boolean isRequestsPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "requests", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "request", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "content_request", false, 2, (Object) null);
    }

    private final boolean isEditProfilePage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "edit_profile", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "profile_edit", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "account_edit", false, 2, (Object) null) || Intrinsics.areEqual(key, Scopes.PROFILE);
    }

    private final boolean isListsPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "lists", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "list", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "collection", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "playlist", false, 2, (Object) null);
    }

    private final boolean isArtistsPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "artists", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "artist", false, 2, (Object) null);
    }

    private final boolean isTop250MoviesPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "top250_movies", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "top_movies", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "top250movie", false, 2, (Object) null);
    }

    private final boolean isTop250SeriesPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "top250_series", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "top_series", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "top250tv", false, 2, (Object) null);
    }

    private final boolean isBoxOfficePage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "boxoffice", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "box_office", false, 2, (Object) null);
    }

    private final boolean isFaqPage(String key) {
        String str = key;
        return StringsKt.contains$default((CharSequence) str, (CharSequence) "faq", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) str, (CharSequence) "questions", false, 2, (Object) null);
    }

    public final boolean handleBackPressed() {
        TicketSupportScreenView ticketSupportScreenView = this.ticketSupportView;
        if (ticketSupportScreenView != null && ticketSupportScreenView.handleBackPressed()) {
            return true;
        }
        RequestsScreenView requestsScreenView = this.requestsView;
        if (requestsScreenView != null && requestsScreenView.handleBackPressed()) {
            return true;
        }
        ListsScreenView listsScreenView = this.listsView;
        return listsScreenView != null && listsScreenView.handleBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openSingleFromPanel(long postId) {
        if (postId <= 0) {
            return;
        }
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) PanelSingleActivity.class);
            intent.putExtra(PanelSingleActivity.EXTRA_POST_ID, postId);
            if (!(this.ctx instanceof Activity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openPlayerFromPanel(long postId, String type, String title, int season, int part) {
        if (postId <= 0) {
            return;
        }
        String strNormalizeHistoryPlayerType = normalizeHistoryPlayerType(type, season, part);
        if (!Intrinsics.areEqual(strNormalizeHistoryPlayerType, "series")) {
            season = -1;
        }
        if (!Intrinsics.areEqual(strNormalizeHistoryPlayerType, "series")) {
            part = -1;
        }
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) PanelSingleActivity.class);
            intent.putExtra(PanelSingleActivity.EXTRA_POST_ID, postId);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_OPEN_PLAYER, true);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_DIRECT, true);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_MODE, "online");
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_TYPE, strNormalizeHistoryPlayerType);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_TITLE, title);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_SEASON, season);
            intent.putExtra(PanelSingleActivity.EXTRA_AUTO_PLAYER_PART, part);
            if (!(this.ctx instanceof Activity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
            openSingleFromPanel(postId);
        }
    }

    private final String normalizeHistoryPlayerType(String type, int season, int part) {
        String lowerCase;
        String string;
        if (type == null || (string = StringsKt.trim((CharSequence) type).toString()) == null) {
            lowerCase = null;
        } else {
            Locale US = Locale.US;
            Intrinsics.checkNotNullExpressionValue(US, "US");
            lowerCase = string.toLowerCase(US);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        }
        if (lowerCase == null) {
            lowerCase = "";
        }
        return (Intrinsics.areEqual(lowerCase, "series") || Intrinsics.areEqual(lowerCase, "serial") || Intrinsics.areEqual(lowerCase, "tv") || Intrinsics.areEqual(lowerCase, "tvseries")) ? "series" : (Intrinsics.areEqual(lowerCase, "post") || Intrinsics.areEqual(lowerCase, "movie") || Intrinsics.areEqual(lowerCase, "movies") || Intrinsics.areEqual(lowerCase, "film") || (season < 0 && part < 0)) ? "post" : "series";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openArtistArchiveFromPanel(String queryName, String displayName) {
        String string = StringsKt.trim((CharSequence) queryName).toString();
        if (StringsKt.isBlank(string)) {
            return;
        }
        String string2 = StringsKt.trim((CharSequence) displayName).toString();
        if (StringsKt.isBlank(string2)) {
            string2 = string;
        }
        QuerySeed querySeed = new QuerySeed("آرشیو " + string2, new QueryBase(MapsKt.linkedMapOf(TuplesKt.m787to("post_type", "any"), TuplesKt.m787to("compare", "like"), TuplesKt.m787to("meta_key", CollectionsKt.listOf("cast_list")), TuplesKt.m787to("meta_value", CollectionsKt.listOf(string)))), "newest");
        try {
            Intent intent = new Intent(this.ctx, (Class<?>) PanelSingleActivity.class);
            intent.putExtra(PanelSingleActivity.EXTRA_QUERY_SEED_JSON, QueryGridModelsKt.toJsonString(querySeed));
            if (!(this.ctx instanceof Activity)) {
                intent.addFlags(268435456);
            }
            ScreenMotionKt.startActivityWithScreenMotion(this.ctx, intent);
        } catch (Throwable unused) {
        }
    }

    private final GradientDrawable roundedBg(int fill, int stroke, int strokeWidth, float radius) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(strokeWidth, stroke);
        gradientDrawable.setCornerRadius(radius);
        return gradientDrawable;
    }

    private final GradientDrawable solidBg(int color) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(color);
        return gradientDrawable;
    }

    /* JADX INFO: renamed from: dp */
    private final int m376dp(int v) {
        return (int) TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }

    private final float dpF(int v) {
        return TypedValue.applyDimension(1, v, getResources().getDisplayMetrics());
    }
}
