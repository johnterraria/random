package com.filmkio;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import androidx.lifecycle.Lifecycle;
import androidx.media3.p004ui.DefaultTimeBar;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;
import com.filmkio.nativescreen.NativeFonts;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.util.SafeUserMessage;
import com.google.firebase.messaging.Constants;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.p007io.CloseableKt;
import kotlin.p007io.TextStreamsKt;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: SplashActivity.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000¨\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\u0003\n\u0002\b\f\b\u0007\u0018\u0000 g2\u00020\u0001:\u0003ghiB\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010.\u001a\u00020\u00112\u0006\u0010/\u001a\u00020\u0016H\u0002J\b\u00100\u001a\u00020\u0004H\u0002J\b\u00101\u001a\u000202H\u0002J\b\u00103\u001a\u000202H\u0002J\b\u00104\u001a\u00020\u0011H\u0002J\b\u00105\u001a\u00020\u0014H\u0002J\u0010\u00106\u001a\u0002022\u0006\u00107\u001a\u000208H\u0002J\u0010\u00109\u001a\u00020\u00142\u0006\u0010:\u001a\u00020\u0014H\u0002J\u0010\u0010;\u001a\u00020\u00162\u0006\u0010<\u001a\u00020\u0011H\u0002J\u0010\u0010=\u001a\u00020\u00112\u0006\u0010>\u001a\u00020?H\u0002J\u0010\u0010@\u001a\u00020\u00112\u0006\u0010A\u001a\u00020\u0014H\u0002J\"\u0010B\u001a\u0002022\u0006\u0010C\u001a\u00020D2\u0006\u0010E\u001a\u00020\u00042\b\b\u0002\u0010F\u001a\u00020\u0014H\u0002J\b\u0010G\u001a\u00020\u0004H\u0002J\b\u0010H\u001a\u00020\u0004H\u0002J(\u0010I\u001a\u00020\u00062\u0006\u0010J\u001a\u00020\u00112\u0006\u0010K\u001a\u00020\u00142\u0006\u0010L\u001a\u00020\u00142\u0006\u0010M\u001a\u00020\u0014H\u0002J\b\u0010N\u001a\u000202H\u0002J\u0012\u0010O\u001a\u0002022\b\u0010P\u001a\u0004\u0018\u00010QH\u0014J\b\u0010R\u001a\u000202H\u0014J\b\u0010S\u001a\u000202H\u0014J\b\u0010T\u001a\u000202H\u0014J\b\u0010U\u001a\u000202H\u0002J\u0012\u0010V\u001a\u00020\u00142\b\u0010W\u001a\u0004\u0018\u00010XH\u0002J*\u0010Y\u001a\u0002022\b\u0010Z\u001a\u0004\u0018\u00010\u00112\u0006\u0010E\u001a\u00020\u00042\u0006\u0010F\u001a\u00020\u00142\u0006\u0010[\u001a\u00020\u0004H\u0002J\u0010\u0010\\\u001a\u0002022\u0006\u0010]\u001a\u00020^H\u0002J\b\u0010_\u001a\u000202H\u0002J\b\u0010`\u001a\u000202H\u0002J\u0010\u0010a\u001a\u0002022\u0006\u0010/\u001a\u00020\u0016H\u0002J\u0010\u0010b\u001a\u00020\u00112\u0006\u0010c\u001a\u00020\u0011H\u0002J\b\u0010d\u001a\u000202H\u0002J\u001a\u0010e\u001a\u0002022\u0006\u0010/\u001a\u00020\u00162\b\u0010f\u001a\u0004\u0018\u00010\u0011H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\n \t*\u0004\u0018\u00010\b0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010 \u001a\u0004\u0018\u00010!X\u0082\u000e¢\u0006\u0002\n\u0000R\u001b\u0010\"\u001a\u00020#8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b&\u0010'\u001a\u0004\b$\u0010%R#\u0010(\u001a\n \t*\u0004\u0018\u00010)0)8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b,\u0010'\u001a\u0004\b*\u0010+R\u000e\u0010-\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000¨\u0006j"}, m780d2 = {"Lcom/filmkio/SplashActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "awaitingInstallPermissionReturn", "", "errorText", "Landroid/widget/TextView;", "executor", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "isResumedForDialogs", "isUpdateDownloading", "logoWeb", "Landroid/webkit/WebView;", "mainHandler", "Landroid/os/Handler;", "pendingInstallApkPath", "", "pendingInstallForce", "pendingInstallTargetVersion", "", "pendingUpdateDialogInfo", "Lcom/filmkio/SplashActivity$MobileUpdateInfo;", "progress", "Landroid/widget/ProgressBar;", "retryBtn", "Landroid/widget/Button;", "stageText", "updateDialog", "Landroid/app/Dialog;", "updateDialogUi", "Lcom/filmkio/SplashActivity$UpdateDialogUi;", "updateDownloadCall", "Lokhttp3/Call;", "updateHttpClient", "Lokhttp3/OkHttpClient;", "getUpdateHttpClient", "()Lokhttp3/OkHttpClient;", "updateHttpClient$delegate", "Lkotlin/Lazy;", "updateStatePrefs", "Landroid/content/SharedPreferences;", "getUpdateStatePrefs", "()Landroid/content/SharedPreferences;", "updateStatePrefs$delegate", "versionText", "buildUpdateMessage", "info", "canShowUpdateDialogNow", "cancelUpdateDownload", "", "clearPendingInstallState", "currentAppVersion", "currentAppVersionCode", "disableForceDark", "settings", "Landroid/webkit/WebSettings;", "dp", "value", "fetchMobileUpdate", "apiBase", "formatBytes", "bytes", "", "formatVersionForUi", "versionCode", "installDownloadedUpdate", "apkFile", "Ljava/io/File;", "force", "targetVersion", "isActivityInvalidForDialog", "isMobileClient", "makeUpdateDialogButton", "text", "fill", "stroke", "textColor", "maybeShowPendingUpdateDialog", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onDestroy", "onPause", "onResume", "openMain", "parseVersionCode", "raw", "", "persistPendingInstallState", "path", "awaitingPermission", "reportBootstrapError", Constants.IPC_BUNDLE_KEY_SEND_ERROR, "", "restorePendingInstallState", "setupSplashLogo", "showMobileUpdateDialog", "stageToText", "stage", "startBootstrap", "startInternalUpdateDownload", "rawUrl", "Companion", "MobileUpdateInfo", "UpdateDialogUi", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class SplashActivity extends AppCompatActivity {
    private static final String PREF_PENDING_INSTALL_APK_PATH = "pending_install_apk_path";
    private static final String PREF_PENDING_INSTALL_AWAITING_PERMISSION = "pending_install_awaiting_permission";
    private static final String PREF_PENDING_INSTALL_FORCE = "pending_install_force";
    private static final String PREF_PENDING_INSTALL_TARGET_VERSION = "pending_install_target_version";
    private boolean awaitingInstallPermissionReturn;
    private TextView errorText;
    private boolean isResumedForDialogs;
    private volatile boolean isUpdateDownloading;
    private WebView logoWeb;
    private String pendingInstallApkPath;
    private boolean pendingInstallForce;
    private int pendingInstallTargetVersion;
    private MobileUpdateInfo pendingUpdateDialogInfo;
    private ProgressBar progress;
    private Button retryBtn;
    private TextView stageText;
    private Dialog updateDialog;
    private UpdateDialogUi updateDialogUi;
    private volatile Call updateDownloadCall;
    private TextView versionText;
    private static final Companion Companion = new Companion(null);
    public static final int $stable = 8;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /* JADX INFO: renamed from: updateHttpClient$delegate, reason: from kotlin metadata */
    private final Lazy updateHttpClient = LazyKt.lazy(new Function0<OkHttpClient>() { // from class: com.filmkio.SplashActivity$updateHttpClient$2
        @Override // kotlin.jvm.functions.Function0
        public final OkHttpClient invoke() {
            return new OkHttpClient.Builder().build();
        }
    });

    /* JADX INFO: renamed from: updateStatePrefs$delegate, reason: from kotlin metadata */
    private final Lazy updateStatePrefs = LazyKt.lazy(new Function0<SharedPreferences>() { // from class: com.filmkio.SplashActivity$updateStatePrefs$2
        {
            super(0);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final SharedPreferences invoke() {
            return this.this$0.getSharedPreferences("filmkio_update_state", 0);
        }
    });

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$16$lambda$15(View view) {
    }

    /* JADX INFO: compiled from: SplashActivity.kt */
    @Metadata(m779d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0082\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, m780d2 = {"Lcom/filmkio/SplashActivity$Companion;", "", "()V", "PREF_PENDING_INSTALL_APK_PATH", "", "PREF_PENDING_INSTALL_AWAITING_PERMISSION", "PREF_PENDING_INSTALL_FORCE", "PREF_PENDING_INSTALL_TARGET_VERSION", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: SplashActivity.kt */
    @Metadata(m779d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0018\b\u0082\b\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\u0006\u0010\t\u001a\u00020\u0006\u0012\b\u0010\n\u001a\u0004\u0018\u00010\b¢\u0006\u0002\u0010\u000bJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0006HÆ\u0003J\u000b\u0010\u0018\u001a\u0004\u0018\u00010\bHÆ\u0003J\t\u0010\u0019\u001a\u00020\u0006HÆ\u0003J\u000b\u0010\u001a\u001a\u0004\u0018\u00010\bHÆ\u0003JI\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\b\b\u0002\u0010\t\u001a\u00020\u00062\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\bHÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u00032\b\u0010\u001d\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001e\u001a\u00020\u0006HÖ\u0001J\t\u0010\u001f\u001a\u00020\bHÖ\u0001R\u0013\u0010\n\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012¨\u0006 "}, m780d2 = {"Lcom/filmkio/SplashActivity$MobileUpdateInfo;", "", "hasUpdate", "", "force", "version", "", "updateUrl", "", "sizeMb", "changelog", "(ZZILjava/lang/String;ILjava/lang/String;)V", "getChangelog", "()Ljava/lang/String;", "getForce", "()Z", "getHasUpdate", "getSizeMb", "()I", "getUpdateUrl", "getVersion", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "toString", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    static final /* data */ class MobileUpdateInfo {
        private final String changelog;
        private final boolean force;
        private final boolean hasUpdate;
        private final int sizeMb;
        private final String updateUrl;
        private final int version;

        public static /* synthetic */ MobileUpdateInfo copy$default(MobileUpdateInfo mobileUpdateInfo, boolean z, boolean z2, int i, String str, int i2, String str2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                z = mobileUpdateInfo.hasUpdate;
            }
            if ((i3 & 2) != 0) {
                z2 = mobileUpdateInfo.force;
            }
            boolean z3 = z2;
            if ((i3 & 4) != 0) {
                i = mobileUpdateInfo.version;
            }
            int i4 = i;
            if ((i3 & 8) != 0) {
                str = mobileUpdateInfo.updateUrl;
            }
            String str3 = str;
            if ((i3 & 16) != 0) {
                i2 = mobileUpdateInfo.sizeMb;
            }
            int i5 = i2;
            if ((i3 & 32) != 0) {
                str2 = mobileUpdateInfo.changelog;
            }
            return mobileUpdateInfo.copy(z, z3, i4, str3, i5, str2);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getHasUpdate() {
            return this.hasUpdate;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final boolean getForce() {
            return this.force;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getVersion() {
            return this.version;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getUpdateUrl() {
            return this.updateUrl;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final int getSizeMb() {
            return this.sizeMb;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getChangelog() {
            return this.changelog;
        }

        public final MobileUpdateInfo copy(boolean hasUpdate, boolean force, int version, String updateUrl, int sizeMb, String changelog) {
            return new MobileUpdateInfo(hasUpdate, force, version, updateUrl, sizeMb, changelog);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof MobileUpdateInfo)) {
                return false;
            }
            MobileUpdateInfo mobileUpdateInfo = (MobileUpdateInfo) other;
            return this.hasUpdate == mobileUpdateInfo.hasUpdate && this.force == mobileUpdateInfo.force && this.version == mobileUpdateInfo.version && Intrinsics.areEqual(this.updateUrl, mobileUpdateInfo.updateUrl) && this.sizeMb == mobileUpdateInfo.sizeMb && Intrinsics.areEqual(this.changelog, mobileUpdateInfo.changelog);
        }

        public int hashCode() {
            int iHashCode = ((((Boolean.hashCode(this.hasUpdate) * 31) + Boolean.hashCode(this.force)) * 31) + Integer.hashCode(this.version)) * 31;
            String str = this.updateUrl;
            int iHashCode2 = (((iHashCode + (str == null ? 0 : str.hashCode())) * 31) + Integer.hashCode(this.sizeMb)) * 31;
            String str2 = this.changelog;
            return iHashCode2 + (str2 != null ? str2.hashCode() : 0);
        }

        public String toString() {
            return "MobileUpdateInfo(hasUpdate=" + this.hasUpdate + ", force=" + this.force + ", version=" + this.version + ", updateUrl=" + this.updateUrl + ", sizeMb=" + this.sizeMb + ", changelog=" + this.changelog + ")";
        }

        public MobileUpdateInfo(boolean z, boolean z2, int i, String str, int i2, String str2) {
            this.hasUpdate = z;
            this.force = z2;
            this.version = i;
            this.updateUrl = str;
            this.sizeMb = i2;
            this.changelog = str2;
        }

        public final boolean getHasUpdate() {
            return this.hasUpdate;
        }

        public final boolean getForce() {
            return this.force;
        }

        public final int getVersion() {
            return this.version;
        }

        public final String getUpdateUrl() {
            return this.updateUrl;
        }

        public final int getSizeMb() {
            return this.sizeMb;
        }

        public final String getChangelog() {
            return this.changelog;
        }
    }

    /* JADX INFO: compiled from: SplashActivity.kt */
    @Metadata(m779d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\rJ\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001c\u001a\u00020\tHÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u001f\u001a\u0004\u0018\u00010\u0005HÆ\u0003JQ\u0010 \u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\u00052\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010!\u001a\u00020\"2\b\u0010#\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010$\u001a\u00020%HÖ\u0001J\t\u0010&\u001a\u00020'HÖ\u0001R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u000f¨\u0006("}, m780d2 = {"Lcom/filmkio/SplashActivity$UpdateDialogUi;", "", "dialog", "Landroid/app/Dialog;", "messageView", "Landroid/widget/TextView;", "progressWrap", "Landroid/widget/LinearLayout;", "progressBar", "Landroid/widget/ProgressBar;", "progressLabel", "updateButton", "cancelButton", "(Landroid/app/Dialog;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/ProgressBar;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V", "getCancelButton", "()Landroid/widget/TextView;", "getDialog", "()Landroid/app/Dialog;", "getMessageView", "getProgressBar", "()Landroid/widget/ProgressBar;", "getProgressLabel", "getProgressWrap", "()Landroid/widget/LinearLayout;", "getUpdateButton", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
    private static final /* data */ class UpdateDialogUi {
        private final TextView cancelButton;
        private final Dialog dialog;
        private final TextView messageView;
        private final ProgressBar progressBar;
        private final TextView progressLabel;
        private final LinearLayout progressWrap;
        private final TextView updateButton;

        public static /* synthetic */ UpdateDialogUi copy$default(UpdateDialogUi updateDialogUi, Dialog dialog, TextView textView, LinearLayout linearLayout, ProgressBar progressBar, TextView textView2, TextView textView3, TextView textView4, int i, Object obj) {
            if ((i & 1) != 0) {
                dialog = updateDialogUi.dialog;
            }
            if ((i & 2) != 0) {
                textView = updateDialogUi.messageView;
            }
            TextView textView5 = textView;
            if ((i & 4) != 0) {
                linearLayout = updateDialogUi.progressWrap;
            }
            LinearLayout linearLayout2 = linearLayout;
            if ((i & 8) != 0) {
                progressBar = updateDialogUi.progressBar;
            }
            ProgressBar progressBar2 = progressBar;
            if ((i & 16) != 0) {
                textView2 = updateDialogUi.progressLabel;
            }
            TextView textView6 = textView2;
            if ((i & 32) != 0) {
                textView3 = updateDialogUi.updateButton;
            }
            TextView textView7 = textView3;
            if ((i & 64) != 0) {
                textView4 = updateDialogUi.cancelButton;
            }
            return updateDialogUi.copy(dialog, textView5, linearLayout2, progressBar2, textView6, textView7, textView4);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final Dialog getDialog() {
            return this.dialog;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final TextView getMessageView() {
            return this.messageView;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final LinearLayout getProgressWrap() {
            return this.progressWrap;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final ProgressBar getProgressBar() {
            return this.progressBar;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final TextView getProgressLabel() {
            return this.progressLabel;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final TextView getUpdateButton() {
            return this.updateButton;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final TextView getCancelButton() {
            return this.cancelButton;
        }

        public final UpdateDialogUi copy(Dialog dialog, TextView messageView, LinearLayout progressWrap, ProgressBar progressBar, TextView progressLabel, TextView updateButton, TextView cancelButton) {
            Intrinsics.checkNotNullParameter(dialog, "dialog");
            Intrinsics.checkNotNullParameter(messageView, "messageView");
            Intrinsics.checkNotNullParameter(progressWrap, "progressWrap");
            Intrinsics.checkNotNullParameter(progressBar, "progressBar");
            Intrinsics.checkNotNullParameter(progressLabel, "progressLabel");
            Intrinsics.checkNotNullParameter(updateButton, "updateButton");
            return new UpdateDialogUi(dialog, messageView, progressWrap, progressBar, progressLabel, updateButton, cancelButton);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof UpdateDialogUi)) {
                return false;
            }
            UpdateDialogUi updateDialogUi = (UpdateDialogUi) other;
            return Intrinsics.areEqual(this.dialog, updateDialogUi.dialog) && Intrinsics.areEqual(this.messageView, updateDialogUi.messageView) && Intrinsics.areEqual(this.progressWrap, updateDialogUi.progressWrap) && Intrinsics.areEqual(this.progressBar, updateDialogUi.progressBar) && Intrinsics.areEqual(this.progressLabel, updateDialogUi.progressLabel) && Intrinsics.areEqual(this.updateButton, updateDialogUi.updateButton) && Intrinsics.areEqual(this.cancelButton, updateDialogUi.cancelButton);
        }

        public int hashCode() {
            int iHashCode = ((((((((((this.dialog.hashCode() * 31) + this.messageView.hashCode()) * 31) + this.progressWrap.hashCode()) * 31) + this.progressBar.hashCode()) * 31) + this.progressLabel.hashCode()) * 31) + this.updateButton.hashCode()) * 31;
            TextView textView = this.cancelButton;
            return iHashCode + (textView == null ? 0 : textView.hashCode());
        }

        public String toString() {
            return "UpdateDialogUi(dialog=" + this.dialog + ", messageView=" + this.messageView + ", progressWrap=" + this.progressWrap + ", progressBar=" + this.progressBar + ", progressLabel=" + this.progressLabel + ", updateButton=" + this.updateButton + ", cancelButton=" + this.cancelButton + ")";
        }

        public UpdateDialogUi(Dialog dialog, TextView messageView, LinearLayout progressWrap, ProgressBar progressBar, TextView progressLabel, TextView updateButton, TextView textView) {
            Intrinsics.checkNotNullParameter(dialog, "dialog");
            Intrinsics.checkNotNullParameter(messageView, "messageView");
            Intrinsics.checkNotNullParameter(progressWrap, "progressWrap");
            Intrinsics.checkNotNullParameter(progressBar, "progressBar");
            Intrinsics.checkNotNullParameter(progressLabel, "progressLabel");
            Intrinsics.checkNotNullParameter(updateButton, "updateButton");
            this.dialog = dialog;
            this.messageView = messageView;
            this.progressWrap = progressWrap;
            this.progressBar = progressBar;
            this.progressLabel = progressLabel;
            this.updateButton = updateButton;
            this.cancelButton = textView;
        }

        public final Dialog getDialog() {
            return this.dialog;
        }

        public final TextView getMessageView() {
            return this.messageView;
        }

        public final LinearLayout getProgressWrap() {
            return this.progressWrap;
        }

        public final ProgressBar getProgressBar() {
            return this.progressBar;
        }

        public final TextView getProgressLabel() {
            return this.progressLabel;
        }

        public final TextView getUpdateButton() {
            return this.updateButton;
        }

        public final TextView getCancelButton() {
            return this.cancelButton;
        }
    }

    private final OkHttpClient getUpdateHttpClient() {
        return (OkHttpClient) this.updateHttpClient.getValue();
    }

    private final SharedPreferences getUpdateStatePrefs() {
        return (SharedPreferences) this.updateStatePrefs.getValue();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C2629R.layout.activity_splash);
        getWindow().getDecorView().setLayoutDirection(1);
        View viewFindViewById = findViewById(C2629R.id.stage_text);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(...)");
        this.stageText = (TextView) viewFindViewById;
        View viewFindViewById2 = findViewById(C2629R.id.error_text);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById2, "findViewById(...)");
        this.errorText = (TextView) viewFindViewById2;
        View viewFindViewById3 = findViewById(C2629R.id.retry_btn);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById3, "findViewById(...)");
        this.retryBtn = (Button) viewFindViewById3;
        View viewFindViewById4 = findViewById(C2629R.id.progress);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById4, "findViewById(...)");
        this.progress = (ProgressBar) viewFindViewById4;
        View viewFindViewById5 = findViewById(C2629R.id.splash_logo_web);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById5, "findViewById(...)");
        this.logoWeb = (WebView) viewFindViewById5;
        View viewFindViewById6 = findViewById(C2629R.id.version_text);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById6, "findViewById(...)");
        this.versionText = (TextView) viewFindViewById6;
        WebView webView = this.logoWeb;
        Button button = null;
        if (webView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            webView = null;
        }
        webView.setFocusable(false);
        WebView webView2 = this.logoWeb;
        if (webView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            webView2 = null;
        }
        webView2.setFocusableInTouchMode(false);
        setupSplashLogo();
        TextView textView = this.versionText;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("versionText");
            textView = null;
        }
        textView.setText("نسخه " + currentAppVersion());
        restorePendingInstallState();
        Button button2 = this.retryBtn;
        if (button2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("retryBtn");
        } else {
            button = button2;
        }
        button.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SplashActivity.onCreate$lambda$0(this.f$0, view);
            }
        });
        startBootstrap();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(SplashActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.startBootstrap();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        boolean z = true;
        this.isResumedForDialogs = true;
        String str = this.pendingInstallApkPath;
        if (str == null || StringsKt.isBlank(str)) {
            restorePendingInstallState();
        }
        String str2 = this.pendingInstallApkPath;
        String str3 = str2;
        if (str3 != null && !StringsKt.isBlank(str3)) {
            z = false;
        }
        if (!z) {
            File file = new File(str2);
            if (!file.exists()) {
                clearPendingInstallState();
            } else {
                int iMax = Math.max(RangesKt.coerceAtLeast(currentAppVersionCode(), 0), RangesKt.coerceAtLeast(parseVersionCode(currentAppVersion()), 0));
                int i = this.pendingInstallTargetVersion;
                if (i > 0 && iMax >= i) {
                    clearPendingInstallState();
                    Dialog dialog = this.updateDialog;
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    this.updateDialog = null;
                    this.updateDialogUi = null;
                    startBootstrap();
                    return;
                }
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    return;
                }
                if (this.awaitingInstallPermissionReturn) {
                    this.awaitingInstallPermissionReturn = false;
                    persistPendingInstallState(this.pendingInstallApkPath, this.pendingInstallForce, this.pendingInstallTargetVersion, false);
                    installDownloadedUpdate(file, this.pendingInstallForce, this.pendingInstallTargetVersion);
                    return;
                }
            }
        }
        maybeShowPendingUpdateDialog();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        this.isResumedForDialogs = false;
        super.onPause();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        cancelUpdateDownload();
        this.isResumedForDialogs = false;
        Dialog dialog = this.updateDialog;
        if (dialog != null) {
            dialog.dismiss();
        }
        this.updateDialog = null;
        this.updateDialogUi = null;
        this.pendingUpdateDialogInfo = null;
        super.onDestroy();
    }

    private final void startBootstrap() {
        Button button = this.retryBtn;
        ProgressBar progressBar = null;
        if (button == null) {
            Intrinsics.throwUninitializedPropertyAccessException("retryBtn");
            button = null;
        }
        button.setVisibility(8);
        TextView textView = this.errorText;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("errorText");
            textView = null;
        }
        textView.setVisibility(8);
        ProgressBar progressBar2 = this.progress;
        if (progressBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("progress");
        } else {
            progressBar = progressBar2;
        }
        progressBar.setVisibility(0);
        this.executor.execute(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity.startBootstrap$lambda$6(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startBootstrap$lambda$6(final SplashActivity this$0) {
        Object objM7195constructorimpl;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            String strBootstrap = ApiBootstrapper.INSTANCE.bootstrap(this$0, new SplashActivity$startBootstrap$1$apiBase$1(this$0));
            try {
                Result.Companion companion = Result.INSTANCE;
                CrashLogReporter.INSTANCE.flushPending(this$0, strBootstrap);
                Result.m7195constructorimpl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m7195constructorimpl(ResultKt.createFailure(th));
            }
            final MobileUpdateInfo mobileUpdateInfo = null;
            Object obj = null;
            if (this$0.isMobileClient()) {
                try {
                    Result.Companion companion3 = Result.INSTANCE;
                    objM7195constructorimpl = Result.m7195constructorimpl(this$0.fetchMobileUpdate(strBootstrap));
                } catch (Throwable th2) {
                    Result.Companion companion4 = Result.INSTANCE;
                    objM7195constructorimpl = Result.m7195constructorimpl(ResultKt.createFailure(th2));
                }
                if (!Result.m7201isFailureimpl(objM7195constructorimpl)) {
                    obj = objM7195constructorimpl;
                }
                mobileUpdateInfo = (MobileUpdateInfo) obj;
            }
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    SplashActivity.startBootstrap$lambda$6$lambda$3(this.f$0, mobileUpdateInfo);
                }
            });
        } catch (Throwable th3) {
            try {
                Result.Companion companion5 = Result.INSTANCE;
                this$0.reportBootstrapError(th3);
                Result.m7195constructorimpl(Unit.INSTANCE);
            } catch (Throwable th4) {
                Result.Companion companion6 = Result.INSTANCE;
                Result.m7195constructorimpl(ResultKt.createFailure(th4));
            }
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    SplashActivity.startBootstrap$lambda$6$lambda$5(this.f$0, th3);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startBootstrap$lambda$6$lambda$3(SplashActivity this$0, MobileUpdateInfo mobileUpdateInfo) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.isActivityInvalidForDialog()) {
            return;
        }
        if (mobileUpdateInfo != null && mobileUpdateInfo.getHasUpdate()) {
            if (this$0.canShowUpdateDialogNow()) {
                this$0.showMobileUpdateDialog(mobileUpdateInfo);
                return;
            } else {
                this$0.pendingUpdateDialogInfo = mobileUpdateInfo;
                return;
            }
        }
        this$0.openMain();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startBootstrap$lambda$6$lambda$5(SplashActivity this$0, Throwable e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        ProgressBar progressBar = this$0.progress;
        Button button = null;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("progress");
            progressBar = null;
        }
        progressBar.setVisibility(8);
        TextView textView = this$0.errorText;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("errorText");
            textView = null;
        }
        textView.setVisibility(0);
        TextView textView2 = this$0.errorText;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("errorText");
            textView2 = null;
        }
        textView2.setText(SafeUserMessage.INSTANCE.fromThrowable(e, "BOOT_FAILED"));
        Button button2 = this$0.retryBtn;
        if (button2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("retryBtn");
        } else {
            button = button2;
        }
        button.setVisibility(0);
    }

    private final void setupSplashLogo() {
        String text;
        WebView webView;
        WebView webView2 = this.logoWeb;
        WebView webView3 = null;
        if (webView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            webView2 = null;
        }
        webView2.setBackgroundColor(0);
        WebView webView4 = this.logoWeb;
        if (webView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            webView4 = null;
        }
        WebSettings settings = webView4.getSettings();
        Intrinsics.checkNotNullExpressionValue(settings, "getSettings(...)");
        settings.setJavaScriptEnabled(false);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        disableForceDark(settings);
        try {
            InputStream inputStreamOpen = getAssets().open("loader/FilmKio-Logo-Loader-Sweep.svg");
            Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "open(...)");
            Reader inputStreamReader = new InputStreamReader(inputStreamOpen, Charsets.UTF_8);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                text = TextStreamsKt.readText(bufferedReader);
                CloseableKt.closeFinally(bufferedReader, null);
            } finally {
            }
        } catch (Throwable unused) {
            text = "";
        }
        if (StringsKt.isBlank(text)) {
            WebView webView5 = this.logoWeb;
            if (webView5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            } else {
                webView3 = webView5;
            }
            webView3.setVisibility(8);
            return;
        }
        String strTrimIndent = StringsKt.trimIndent("\n            <html>\n            <head>\n              <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n              <meta name=\"color-scheme\" content=\"light\"/>\n              <style>\n                html,body{width:100%;height:100%;margin:0;background:transparent;color-scheme:light;}\n                svg{width:100%;height:100%;}\n              </style>\n            </head>\n            <body style=\"margin:0;display:flex;align-items:center;justify-content:center;background:transparent;\">\n              " + text + "\n            </body>\n            </html>\n        ");
        WebView webView6 = this.logoWeb;
        if (webView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("logoWeb");
            webView = null;
        } else {
            webView = webView6;
        }
        webView.loadDataWithBaseURL("file:///android_asset/", strTrimIndent, "text/html", "utf-8", null);
    }

    private final void disableForceDark(WebSettings settings) {
        if (WebViewFeature.isFeatureSupported("FORCE_DARK")) {
            try {
                WebSettingsCompat.setForceDark(settings, 0);
            } catch (Throwable unused) {
            }
        }
    }

    private final void openMain() {
        SplashActivity splashActivity = this;
        Intent intent = new Intent(splashActivity, (Class<?>) MainActivity.class);
        Intent intent2 = getIntent();
        intent.setAction(intent2 != null ? intent2.getAction() : null);
        Intent intent3 = getIntent();
        intent.setData(intent3 != null ? intent3.getData() : null);
        Intent intent4 = getIntent();
        if (intent4 != null && intent4.hasExtra("extra_force_home_crash_test")) {
            Intent intent5 = getIntent();
            intent.putExtra("extra_force_home_crash_test", intent5 != null && intent5.getBooleanExtra("extra_force_home_crash_test", false));
        }
        intent.addFlags(AccessibilityEventCompat.TYPE_VIEW_TARGETED_BY_SCROLL);
        ScreenMotionKt.startActivityWithScreenMotion(splashActivity, intent);
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String stageToText(String stage) {
        return Intrinsics.areEqual(stage, "arvan") ? "دریافت آدرس سرور" : Intrinsics.areEqual(stage, "home") ? "بارگذاری صفحه اصلی" : stage;
    }

    private final String currentAppVersion() {
        try {
            String str = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            return str == null ? "" : str;
        } catch (Throwable unused) {
            return "";
        }
    }

    private final int currentAppVersionCode() {
        int longVersionCode = 0;
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) {
                longVersionCode = (int) packageInfo.getLongVersionCode();
            } else {
                longVersionCode = packageInfo.versionCode;
            }
        } catch (Throwable unused) {
        }
        return longVersionCode;
    }

    private final boolean isMobileClient() {
        return Intrinsics.areEqual(AppState.INSTANCE.getClientPlatform(), "android");
    }

    private final MobileUpdateInfo fetchMobileUpdate(String apiBase) {
        int iMax = Math.max(RangesKt.coerceAtLeast(currentAppVersionCode(), 0), RangesKt.coerceAtLeast(parseVersionCode(currentAppVersion()), 0));
        String clientPlatform = AppState.INSTANCE.getClientPlatform();
        if (StringsKt.isBlank(clientPlatform)) {
            clientPlatform = "android";
        }
        JSONObject jSONObject = new JSONObject(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, apiBase, "/updateapp", "GET", MapsKt.mapOf(TuplesKt.m787to("platform", clientPlatform), TuplesKt.m787to("version", currentAppVersion()), TuplesKt.m787to("version_code", String.valueOf(iMax)), TuplesKt.m787to("version_name", currentAppVersion())), null, null, false, 112, null));
        int versionCode = parseVersionCode(jSONObject.opt("version"));
        boolean z = versionCode <= 0 || iMax <= 0 ? !(versionCode <= 0 || iMax > 0) : versionCode > iMax;
        boolean zOptBoolean = jSONObject.optBoolean("force", false);
        String strOptString = jSONObject.optString("update_url");
        Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
        String string = StringsKt.trim((CharSequence) strOptString).toString();
        if (StringsKt.isBlank(string)) {
            string = null;
        }
        String str = string;
        int iCoerceAtLeast = RangesKt.coerceAtLeast(jSONObject.optInt("size", 0), 0);
        String strOptString2 = jSONObject.optString("changelog");
        Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
        String string2 = StringsKt.trim((CharSequence) strOptString2).toString();
        return new MobileUpdateInfo(z, zOptBoolean, versionCode, str, iCoerceAtLeast, StringsKt.isBlank(string2) ? null : string2);
    }

    private final void showMobileUpdateDialog(final MobileUpdateInfo info) {
        TextView textView;
        boolean z;
        int i;
        TextView textViewMakeUpdateDialogButton;
        Dialog dialog;
        try {
            if (!canShowUpdateDialogNow()) {
                if (isActivityInvalidForDialog()) {
                    return;
                }
                this.pendingUpdateDialogInfo = info;
                return;
            }
            if (!info.getHasUpdate()) {
                openMain();
                return;
            }
            final String updateUrl = info.getUpdateUrl();
            String str = updateUrl;
            if ((str == null || StringsKt.isBlank(str)) && !info.getForce()) {
                openMain();
                return;
            }
            Dialog dialog2 = this.updateDialog;
            if ((dialog2 != null && dialog2.isShowing()) && (dialog = this.updateDialog) != null) {
                dialog.dismiss();
            }
            final Dialog dialog3 = new Dialog(this);
            dialog3.setOwnerActivity(this);
            Window window = dialog3.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(0));
            }
            Window window2 = dialog3.getWindow();
            if (window2 != null) {
                window2.setDimAmount(0.0f);
            }
            FrameLayout frameLayout = new FrameLayout(this);
            frameLayout.setLayoutDirection(1);
            frameLayout.setBackgroundColor(1711276032);
            frameLayout.setClickable(true);
            frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda10
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SplashActivity.showMobileUpdateDialog$lambda$13$lambda$12(info, dialog3, view);
                }
            });
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            linearLayout.setLayoutDirection(1);
            linearLayout.setGravity(1);
            linearLayout.setPadding(m374dp(22), m374dp(20), m374dp(22), m374dp(18));
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-234156785);
            gradientDrawable.setCornerRadius(m374dp(14));
            gradientDrawable.setStroke(m374dp(1), DefaultTimeBar.DEFAULT_UNPLAYED_COLOR);
            linearLayout.setBackground(gradientDrawable);
            linearLayout.setClickable(true);
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SplashActivity.showMobileUpdateDialog$lambda$16$lambda$15(view);
                }
            });
            TextView textView2 = new TextView(this);
            textView2.setText("بروزرسانی اپلیکیشن");
            textView2.setTextColor(-1);
            textView2.setTextSize(18.0f);
            textView2.setGravity(17);
            textView2.setIncludeFontPadding(false);
            Typeface typefaceBold = NativeFonts.INSTANCE.bold(this);
            if (typefaceBold == null) {
                typefaceBold = textView2.getTypeface();
            }
            textView2.setTypeface(typefaceBold);
            linearLayout.addView(textView2, new LinearLayout.LayoutParams(-2, -2));
            TextView textView3 = new TextView(this);
            textView3.setText(buildUpdateMessage(info));
            textView3.setTextColor(-654311425);
            textView3.setTextSize(14.0f);
            textView3.setGravity(17);
            textView3.setIncludeFontPadding(false);
            Typeface typefaceMedium = NativeFonts.INSTANCE.medium(this);
            if (typefaceMedium == null) {
                typefaceMedium = textView3.getTypeface();
            }
            textView3.setTypeface(typefaceMedium);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.topMargin = m374dp(12);
            Unit unit = Unit.INSTANCE;
            linearLayout.addView(textView3, layoutParams);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            linearLayout2.setLayoutDirection(1);
            linearLayout2.setVisibility(8);
            ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setIndeterminate(true);
            progressBar.setMax(1000);
            TextView textView4 = new TextView(this);
            textView4.setTextColor(-922746881);
            textView4.setTextSize(12.0f);
            textView4.setGravity(17);
            textView4.setIncludeFontPadding(false);
            Typeface typefaceMedium2 = NativeFonts.INSTANCE.medium(this);
            if (typefaceMedium2 == null) {
                typefaceMedium2 = textView4.getTypeface();
            }
            textView4.setTypeface(typefaceMedium2);
            textView4.setText("در حال آماده\u200cسازی دانلود...");
            linearLayout2.addView(progressBar, new LinearLayout.LayoutParams(-1, m374dp(8)));
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.topMargin = m374dp(8);
            Unit unit2 = Unit.INSTANCE;
            linearLayout2.addView(textView4, layoutParams2);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.topMargin = m374dp(12);
            Unit unit3 = Unit.INSTANCE;
            linearLayout.addView(linearLayout2, layoutParams3);
            LinearLayout linearLayout3 = new LinearLayout(this);
            linearLayout3.setOrientation(0);
            linearLayout3.setGravity(17);
            linearLayout3.setLayoutDirection(1);
            TextView textViewMakeUpdateDialogButton2 = makeUpdateDialogButton("بروزرسانی", -676591, 0, -16052459);
            textViewMakeUpdateDialogButton2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SplashActivity.showMobileUpdateDialog$lambda$27$lambda$26(this.f$0, info, updateUrl, view);
                }
            });
            if (!info.getForce()) {
                textViewMakeUpdateDialogButton = makeUpdateDialogButton("انصراف دانلود", -15986670, 452984831, -4931894);
                textViewMakeUpdateDialogButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda13
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        SplashActivity.showMobileUpdateDialog$lambda$29$lambda$28(this.f$0, dialog3, view);
                    }
                });
                textView = textView4;
                LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, m374dp(44), 1.0f);
                layoutParams4.setMarginEnd(m374dp(6));
                Unit unit4 = Unit.INSTANCE;
                linearLayout3.addView(textViewMakeUpdateDialogButton2, layoutParams4);
                z = false;
                LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(0, m374dp(44), 1.0f);
                layoutParams5.setMarginStart(m374dp(6));
                Unit unit5 = Unit.INSTANCE;
                linearLayout3.addView(textViewMakeUpdateDialogButton, layoutParams5);
                i = -1;
            } else {
                textView = textView4;
                z = false;
                i = -1;
                linearLayout3.addView(textViewMakeUpdateDialogButton2, new LinearLayout.LayoutParams(-1, m374dp(44)));
                textViewMakeUpdateDialogButton = null;
            }
            LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(i, -2);
            layoutParams6.topMargin = m374dp(16);
            Unit unit6 = Unit.INSTANCE;
            linearLayout.addView(linearLayout3, layoutParams6);
            frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(RangesKt.coerceAtMost(m374dp(340), getResources().getDisplayMetrics().widthPixels - m374dp(40)), -2, 17));
            dialog3.setContentView(frameLayout);
            dialog3.setCancelable(!info.getForce() ? true : z);
            dialog3.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda14
                @Override // android.content.DialogInterface.OnKeyListener
                public final boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
                    return SplashActivity.showMobileUpdateDialog$lambda$33(info, dialog3, this, dialogInterface, i2, keyEvent);
                }
            });
            if (!info.getForce()) {
                dialog3.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda15
                    @Override // android.content.DialogInterface.OnCancelListener
                    public final void onCancel(DialogInterface dialogInterface) {
                        SplashActivity.showMobileUpdateDialog$lambda$34(this.f$0, dialogInterface);
                    }
                });
            }
            dialog3.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda16
                @Override // android.content.DialogInterface.OnDismissListener
                public final void onDismiss(DialogInterface dialogInterface) {
                    SplashActivity.showMobileUpdateDialog$lambda$35(this.f$0, dialog3, info, dialogInterface);
                }
            });
            try {
                if (!canShowUpdateDialogNow()) {
                    if (isActivityInvalidForDialog()) {
                        return;
                    }
                    this.pendingUpdateDialogInfo = info;
                    return;
                }
                dialog3.show();
                this.pendingUpdateDialogInfo = null;
                Window window3 = dialog3.getWindow();
                if (window3 != null) {
                    window3.setLayout(-1, -1);
                }
                this.updateDialog = dialog3;
                this.updateDialogUi = new UpdateDialogUi(dialog3, textView3, linearLayout2, progressBar, textView, textViewMakeUpdateDialogButton2, textViewMakeUpdateDialogButton);
            } catch (WindowManager.BadTokenException unused) {
                if (isActivityInvalidForDialog()) {
                    return;
                }
                this.pendingUpdateDialogInfo = info;
            } catch (IllegalStateException unused2) {
                if (isActivityInvalidForDialog()) {
                    return;
                }
                this.pendingUpdateDialogInfo = info;
            } catch (Throwable unused3) {
                if (isActivityInvalidForDialog()) {
                    return;
                }
                this.pendingUpdateDialogInfo = info;
            }
        } catch (WindowManager.BadTokenException unused4) {
            if (isActivityInvalidForDialog()) {
                return;
            }
            this.pendingUpdateDialogInfo = info;
        } catch (IllegalStateException unused5) {
            if (isActivityInvalidForDialog()) {
                return;
            }
            this.pendingUpdateDialogInfo = info;
        } catch (Throwable unused6) {
            if (isActivityInvalidForDialog()) {
                return;
            }
            this.pendingUpdateDialogInfo = info;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$13$lambda$12(MobileUpdateInfo info, Dialog dialog, View view) {
        Intrinsics.checkNotNullParameter(info, "$info");
        Intrinsics.checkNotNullParameter(dialog, "$dialog");
        if (info.getForce()) {
            return;
        }
        dialog.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$27$lambda$26(SplashActivity this$0, MobileUpdateInfo info, String str, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(info, "$info");
        this$0.startInternalUpdateDownload(info, str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$29$lambda$28(SplashActivity this$0, Dialog dialog, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(dialog, "$dialog");
        this$0.cancelUpdateDownload();
        dialog.dismiss();
        this$0.openMain();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean showMobileUpdateDialog$lambda$33(MobileUpdateInfo info, Dialog dialog, SplashActivity this$0, DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter(info, "$info");
        Intrinsics.checkNotNullParameter(dialog, "$dialog");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (keyEvent.getAction() != 1 || i != 4) {
            return false;
        }
        if (info.getForce()) {
            return true;
        }
        dialog.dismiss();
        this$0.openMain();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$34(SplashActivity this$0, DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.openMain();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showMobileUpdateDialog$lambda$35(SplashActivity this$0, Dialog dialog, MobileUpdateInfo info, DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(dialog, "$dialog");
        Intrinsics.checkNotNullParameter(info, "$info");
        if (this$0.updateDialog == dialog) {
            this$0.updateDialog = null;
            this$0.updateDialogUi = null;
            if (info.getForce()) {
                return;
            }
            this$0.cancelUpdateDownload();
        }
    }

    private final String buildUpdateMessage(MobileUpdateInfo info) {
        StringBuilder sb = new StringBuilder();
        sb.append("نسخه جدید اپلیکیشن آماده است.");
        if (info.getVersion() > 0) {
            sb.append("\nنسخه: " + formatVersionForUi(info.getVersion()));
        }
        if (info.getSizeMb() > 0) {
            sb.append("\nحجم: " + info.getSizeMb() + " مگابایت");
        }
        String changelog = info.getChangelog();
        if (!(changelog == null || StringsKt.isBlank(changelog))) {
            sb.append("\n\n" + info.getChangelog());
        }
        if (info.getForce()) {
            sb.append("\n\nاین بروزرسانی اجباری است.");
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    private final void startInternalUpdateDownload(final MobileUpdateInfo info, String rawUrl) {
        UpdateDialogUi updateDialogUi;
        final String string = rawUrl != null ? StringsKt.trim((CharSequence) rawUrl).toString() : null;
        if (string == null) {
            string = "";
        }
        if (StringsKt.isBlank(string)) {
            Toast.makeText(this, "لینک بروزرسانی نامعتبر است.", 0).show();
            if (info.getForce()) {
                return;
            }
            Dialog dialog = this.updateDialog;
            if (dialog != null) {
                dialog.dismiss();
            }
            openMain();
            return;
        }
        if (this.isUpdateDownloading || (updateDialogUi = this.updateDialogUi) == null) {
            return;
        }
        updateDialogUi.getProgressWrap().setVisibility(0);
        updateDialogUi.getProgressBar().setIndeterminate(true);
        updateDialogUi.getProgressLabel().setText("در حال شروع دانلود...");
        updateDialogUi.getUpdateButton().setText("در حال دانلود...");
        updateDialogUi.getUpdateButton().setEnabled(false);
        updateDialogUi.getUpdateButton().setAlpha(0.7f);
        TextView cancelButton = updateDialogUi.getCancelButton();
        if (cancelButton != null) {
            cancelButton.setEnabled(true);
        }
        updateDialogUi.getMessageView().setText(buildUpdateMessage(info));
        this.executor.execute(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity.startInternalUpdateDownload$lambda$43(this.f$0, string, info);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r1v13, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v22 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v27 */
    /* JADX WARN: Type inference failed for: r1v31 */
    /* JADX WARN: Type inference failed for: r1v33 */
    /* JADX WARN: Type inference failed for: r1v39 */
    /* JADX WARN: Type inference failed for: r1v40 */
    /* JADX WARN: Type inference failed for: r1v46 */
    /* JADX WARN: Type inference failed for: r1v47 */
    public static final void startInternalUpdateDownload$lambda$43(final SplashActivity this$0, String targetUrl, final MobileUpdateInfo info) {
        boolean z;
        final boolean z2;
        boolean z3;
        ?? IsSuccessful;
        Throwable th;
        ?? r1;
        InputStream inputStream;
        Throwable th2;
        FileOutputStream fileOutputStream;
        Response response;
        Throwable th3;
        Response response2;
        long jElapsedRealtime;
        byte[] bArr;
        FileOutputStream fileOutputStream2;
        File file;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(targetUrl, "$targetUrl");
        Intrinsics.checkNotNullParameter(info, "$info");
        Call callNewCall = this$0.getUpdateHttpClient().newCall(new Request.Builder().url(targetUrl).get().build());
        this$0.updateDownloadCall = callNewCall;
        this$0.isUpdateDownloading = true;
        int i = 0;
        try {
            Response responseExecute = callNewCall.execute();
            try {
                Response response3 = responseExecute;
                IsSuccessful = response3.isSuccessful();
                try {
                    if (IsSuccessful == 0) {
                        throw new IOException("HTTP " + response3.code());
                    }
                    ResponseBody responseBodyBody = response3.body();
                    if (responseBodyBody == null) {
                        throw new IOException("EMPTY_BODY");
                    }
                    long j = 0;
                    final long jCoerceAtLeast = RangesKt.coerceAtLeast(responseBodyBody.getContentLength(), 0L);
                    File file2 = new File(this$0.getCacheDir(), "updates/filmkio-update.apk");
                    File parentFile = file2.getParentFile();
                    if (parentFile != null) {
                        try {
                            parentFile.mkdirs();
                        } catch (Throwable th4) {
                            th = th4;
                            r1 = responseExecute;
                        }
                    }
                    if (file2.exists()) {
                        file2.delete();
                    }
                    InputStream inputStreamByteStream = responseBodyBody.byteStream();
                    try {
                        InputStream inputStream2 = inputStreamByteStream;
                        FileOutputStream fileOutputStream3 = new FileOutputStream(file2);
                        try {
                            FileOutputStream fileOutputStream4 = fileOutputStream3;
                            byte[] bArr2 = new byte[16384];
                            final long j2 = 0;
                            long j3 = 0;
                            while (true) {
                                int i2 = inputStream2.read(bArr2);
                                if (i2 == -1) {
                                    break;
                                }
                                try {
                                    fileOutputStream4.write(bArr2, i, i2);
                                    response2 = responseExecute;
                                    j2 += (long) i2;
                                    try {
                                        jElapsedRealtime = SystemClock.elapsedRealtime();
                                    } catch (Throwable th5) {
                                        th = th5;
                                        fileOutputStream = fileOutputStream3;
                                        inputStream = inputStreamByteStream;
                                    }
                                } catch (Throwable th6) {
                                    fileOutputStream = fileOutputStream3;
                                    inputStream = inputStreamByteStream;
                                    th3 = th6;
                                    IsSuccessful = responseExecute;
                                }
                                try {
                                    if (jElapsedRealtime - j3 < 120 && (jCoerceAtLeast <= j || j2 < jCoerceAtLeast)) {
                                        responseExecute = response2;
                                        i = 0;
                                    }
                                    this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda1
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            SplashActivity.m375xbcf245f8(this.f$0, jCoerceAtLeast, j2);
                                        }
                                    });
                                    fileOutputStream3 = fileOutputStream;
                                    fileOutputStream4 = fileOutputStream2;
                                    inputStreamByteStream = inputStream;
                                    file2 = file;
                                    responseExecute = response2;
                                    j3 = jElapsedRealtime;
                                    bArr2 = bArr;
                                    i = 0;
                                    j = 0;
                                } catch (Throwable th7) {
                                    th = th7;
                                    th3 = th;
                                    IsSuccessful = response2;
                                    try {
                                        throw th3;
                                    } catch (Throwable th8) {
                                        try {
                                            CloseableKt.closeFinally(fileOutputStream, th3);
                                            throw th8;
                                        } catch (Throwable th9) {
                                            th = th9;
                                            th2 = th;
                                            try {
                                                throw th2;
                                            } catch (Throwable th10) {
                                                CloseableKt.closeFinally(inputStream, th2);
                                                throw th10;
                                            }
                                        }
                                    }
                                }
                                bArr = bArr2;
                                fileOutputStream = fileOutputStream3;
                                fileOutputStream2 = fileOutputStream4;
                                file = file2;
                                inputStream = inputStreamByteStream;
                            }
                            fileOutputStream = fileOutputStream3;
                            final File file3 = file2;
                            inputStream = inputStreamByteStream;
                            Response response4 = responseExecute;
                            try {
                                fileOutputStream4.flush();
                                Unit unit = Unit.INSTANCE;
                                try {
                                    CloseableKt.closeFinally(fileOutputStream, null);
                                    Unit unit2 = Unit.INSTANCE;
                                    try {
                                        CloseableKt.closeFinally(inputStream, null);
                                        if (file3.length() <= 0) {
                                            throw new IOException("EMPTY_APK_FILE");
                                        }
                                        this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda2
                                            @Override // java.lang.Runnable
                                            public final void run() {
                                                SplashActivity.startInternalUpdateDownload$lambda$43$lambda$41$lambda$40(this.f$0, file3, info);
                                            }
                                        });
                                        CloseableKt.closeFinally(response4, null);
                                        return;
                                    } catch (Throwable th11) {
                                        th = th11;
                                        IsSuccessful = response4;
                                    }
                                } catch (Throwable th12) {
                                    th = th12;
                                    IsSuccessful = response4;
                                    th2 = th;
                                    throw th2;
                                }
                            } catch (Throwable th13) {
                                th = th13;
                                response = response4;
                                th3 = th;
                                IsSuccessful = response;
                                throw th3;
                            }
                        } catch (Throwable th14) {
                            th = th14;
                            fileOutputStream = fileOutputStream3;
                            inputStream = inputStreamByteStream;
                            response = responseExecute;
                        }
                    } catch (Throwable th15) {
                        th = th15;
                        inputStream = inputStreamByteStream;
                        IsSuccessful = responseExecute;
                    }
                } catch (Throwable th16) {
                    th = th16;
                }
            } catch (Throwable th17) {
                th = th17;
                IsSuccessful = responseExecute;
            }
            th = th;
            r1 = IsSuccessful;
            try {
                throw th;
            } catch (Throwable th18) {
                CloseableKt.closeFinally(r1, th);
                throw th18;
            }
        } catch (Throwable th19) {
            if (!callNewCall.getCanceled() && !(th19 instanceof InterruptedIOException)) {
                if (th19 instanceof IOException) {
                    String message = th19.getMessage();
                    if (message != null) {
                        z = true;
                        z3 = StringsKt.contains((CharSequence) message, (CharSequence) "canceled", true);
                        if (!z3) {
                        }
                        this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                SplashActivity.startInternalUpdateDownload$lambda$43$lambda$42(this.f$0, z2, info);
                            }
                        });
                    }
                    z = true;
                    if (!z3) {
                    }
                    this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda3
                        @Override // java.lang.Runnable
                        public final void run() {
                            SplashActivity.startInternalUpdateDownload$lambda$43$lambda$42(this.f$0, z2, info);
                        }
                    });
                }
                z2 = false;
                this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        SplashActivity.startInternalUpdateDownload$lambda$43$lambda$42(this.f$0, z2, info);
                    }
                });
            }
            z = true;
            z2 = z;
            this$0.mainHandler.post(new Runnable() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    SplashActivity.startInternalUpdateDownload$lambda$43$lambda$42(this.f$0, z2, info);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: startInternalUpdateDownload$lambda$43$lambda$41$lambda$39$lambda$38$lambda$37 */
    public static final void m375xbcf245f8(SplashActivity this$0, long j, long j2) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        UpdateDialogUi updateDialogUi = this$0.updateDialogUi;
        if (updateDialogUi == null) {
            return;
        }
        updateDialogUi.getProgressWrap().setVisibility(0);
        if (j > 0) {
            updateDialogUi.getProgressBar().setIndeterminate(false);
            updateDialogUi.getProgressBar().setProgress(RangesKt.coerceIn((int) ((1000 * j2) / j), 0, 1000));
            int iCoerceIn = RangesKt.coerceIn((int) ((100 * j2) / j), 0, 100);
            updateDialogUi.getProgressLabel().setText("در حال دانلود... " + iCoerceIn + "٪ (" + this$0.formatBytes(j2) + " از " + this$0.formatBytes(j) + ")");
            return;
        }
        updateDialogUi.getProgressBar().setIndeterminate(true);
        updateDialogUi.getProgressLabel().setText("در حال دانلود... " + this$0.formatBytes(j2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startInternalUpdateDownload$lambda$43$lambda$41$lambda$40(SplashActivity this$0, File apkFile, MobileUpdateInfo info) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(apkFile, "$apkFile");
        Intrinsics.checkNotNullParameter(info, "$info");
        this$0.isUpdateDownloading = false;
        this$0.updateDownloadCall = null;
        UpdateDialogUi updateDialogUi = this$0.updateDialogUi;
        if (updateDialogUi == null) {
            return;
        }
        updateDialogUi.getProgressWrap().setVisibility(0);
        updateDialogUi.getProgressBar().setIndeterminate(true);
        updateDialogUi.getProgressLabel().setText("دانلود کامل شد. در حال شروع نصب...");
        updateDialogUi.getUpdateButton().setText("نصب بروزرسانی");
        updateDialogUi.getUpdateButton().setEnabled(false);
        updateDialogUi.getUpdateButton().setAlpha(0.7f);
        TextView cancelButton = updateDialogUi.getCancelButton();
        if (cancelButton != null) {
            cancelButton.setEnabled(false);
        }
        this$0.installDownloadedUpdate(apkFile, info.getForce(), info.getVersion());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startInternalUpdateDownload$lambda$43$lambda$42(SplashActivity this$0, boolean z, MobileUpdateInfo info) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(info, "$info");
        this$0.isUpdateDownloading = false;
        this$0.updateDownloadCall = null;
        UpdateDialogUi updateDialogUi = this$0.updateDialogUi;
        if (updateDialogUi == null) {
            return;
        }
        updateDialogUi.getUpdateButton().setText("بروزرسانی");
        updateDialogUi.getUpdateButton().setEnabled(true);
        updateDialogUi.getUpdateButton().setAlpha(1.0f);
        TextView cancelButton = updateDialogUi.getCancelButton();
        if (cancelButton != null) {
            cancelButton.setEnabled(true);
        }
        updateDialogUi.getProgressBar().setIndeterminate(false);
        updateDialogUi.getProgressBar().setProgress(0);
        if (z) {
            updateDialogUi.getProgressWrap().setVisibility(8);
            updateDialogUi.getMessageView().setText(this$0.buildUpdateMessage(info));
            return;
        }
        updateDialogUi.getProgressWrap().setVisibility(0);
        updateDialogUi.getProgressLabel().setText("دانلود بروزرسانی ناموفق بود. دوباره تلاش کنید.");
        if (info.getForce()) {
            return;
        }
        Toast.makeText(this$0, "دانلود بروزرسانی انجام نشد.", 0).show();
    }

    static /* synthetic */ void installDownloadedUpdate$default(SplashActivity splashActivity, File file, boolean z, int i, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = splashActivity.pendingInstallTargetVersion;
        }
        splashActivity.installDownloadedUpdate(file, z, i);
    }

    private final void installDownloadedUpdate(final File apkFile, final boolean force, final int targetVersion) {
        Object objM7195constructorimpl;
        Object objM7195constructorimpl2;
        Object objM7195constructorimpl3;
        TextView cancelButton;
        TextView updateButton;
        Object objM7195constructorimpl4;
        TextView updateButton2;
        this.pendingInstallApkPath = apkFile.getAbsolutePath();
        this.pendingInstallForce = force;
        int iCoerceAtLeast = RangesKt.coerceAtLeast(targetVersion, 0);
        this.pendingInstallTargetVersion = iCoerceAtLeast;
        persistPendingInstallState(this.pendingInstallApkPath, this.pendingInstallForce, iCoerceAtLeast, this.awaitingInstallPermissionReturn);
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            this.awaitingInstallPermissionReturn = true;
            persistPendingInstallState(this.pendingInstallApkPath, this.pendingInstallForce, this.pendingInstallTargetVersion, true);
            UpdateDialogUi updateDialogUi = this.updateDialogUi;
            LinearLayout progressWrap = updateDialogUi != null ? updateDialogUi.getProgressWrap() : null;
            if (progressWrap != null) {
                progressWrap.setVisibility(0);
            }
            ProgressBar progressBar = updateDialogUi != null ? updateDialogUi.getProgressBar() : null;
            if (progressBar != null) {
                progressBar.setIndeterminate(true);
            }
            TextView progressLabel = updateDialogUi != null ? updateDialogUi.getProgressLabel() : null;
            if (progressLabel != null) {
                progressLabel.setText("برای نصب، مجوز نصب از منابع ناشناس را فعال کنید.");
            }
            TextView updateButton3 = updateDialogUi != null ? updateDialogUi.getUpdateButton() : null;
            if (updateButton3 != null) {
                updateButton3.setText("ادامه نصب");
            }
            TextView updateButton4 = updateDialogUi != null ? updateDialogUi.getUpdateButton() : null;
            if (updateButton4 != null) {
                updateButton4.setEnabled(true);
            }
            TextView updateButton5 = updateDialogUi != null ? updateDialogUi.getUpdateButton() : null;
            if (updateButton5 != null) {
                updateButton5.setAlpha(1.0f);
            }
            if (updateDialogUi != null && (updateButton2 = updateDialogUi.getUpdateButton()) != null) {
                updateButton2.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda4
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        SplashActivity.installDownloadedUpdate$lambda$44(this.f$0, apkFile, force, targetVersion, view);
                    }
                });
            }
            cancelButton = updateDialogUi != null ? updateDialogUi.getCancelButton() : null;
            if (cancelButton != null) {
                cancelButton.setEnabled(!force);
            }
            Intent intent = new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.parse("package:" + getPackageName()));
            try {
                Result.Companion companion = Result.INSTANCE;
                SplashActivity splashActivity = this;
                startActivity(intent);
                objM7195constructorimpl4 = Result.m7195constructorimpl(Unit.INSTANCE);
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                objM7195constructorimpl4 = Result.m7195constructorimpl(ResultKt.createFailure(th));
            }
            if (Result.m7198exceptionOrNullimpl(objM7195constructorimpl4) != null) {
                this.awaitingInstallPermissionReturn = false;
                persistPendingInstallState(this.pendingInstallApkPath, this.pendingInstallForce, this.pendingInstallTargetVersion, false);
                Toast.makeText(this, "امکان باز کردن تنظیمات نصب وجود ندارد.", 0).show();
                return;
            }
            return;
        }
        this.awaitingInstallPermissionReturn = false;
        persistPendingInstallState(this.pendingInstallApkPath, this.pendingInstallForce, this.pendingInstallTargetVersion, false);
        try {
            Result.Companion companion3 = Result.INSTANCE;
            SplashActivity splashActivity2 = this;
            objM7195constructorimpl = Result.m7195constructorimpl(FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apkFile));
        } catch (Throwable th2) {
            Result.Companion companion4 = Result.INSTANCE;
            objM7195constructorimpl = Result.m7195constructorimpl(ResultKt.createFailure(th2));
        }
        if (Result.m7198exceptionOrNullimpl(objM7195constructorimpl) != null) {
            Toast.makeText(this, "فایل بروزرسانی آماده نصب نیست.", 0).show();
            return;
        }
        Uri uri = (Uri) objM7195constructorimpl;
        Intent intent2 = new Intent("android.intent.action.INSTALL_PACKAGE");
        intent2.setData(uri);
        intent2.addFlags(1);
        intent2.putExtra("android.intent.extra.RETURN_RESULT", true);
        Intent intent3 = new Intent("android.intent.action.VIEW");
        intent3.setDataAndType(uri, "application/vnd.android.package-archive");
        intent3.addFlags(1);
        try {
            Result.Companion companion5 = Result.INSTANCE;
            SplashActivity splashActivity3 = this;
            startActivity(intent2);
            objM7195constructorimpl2 = Result.m7195constructorimpl(true);
        } catch (Throwable th3) {
            Result.Companion companion6 = Result.INSTANCE;
            objM7195constructorimpl2 = Result.m7195constructorimpl(ResultKt.createFailure(th3));
        }
        if (Result.m7198exceptionOrNullimpl(objM7195constructorimpl2) != null) {
            try {
                Result.Companion companion7 = Result.INSTANCE;
                SplashActivity splashActivity4 = this;
                startActivity(intent3);
                objM7195constructorimpl3 = Result.m7195constructorimpl(true);
            } catch (Throwable th4) {
                Result.Companion companion8 = Result.INSTANCE;
                objM7195constructorimpl3 = Result.m7195constructorimpl(ResultKt.createFailure(th4));
            }
            if (Result.m7201isFailureimpl(objM7195constructorimpl3)) {
                objM7195constructorimpl3 = false;
            }
            objM7195constructorimpl2 = Boolean.valueOf(((Boolean) objM7195constructorimpl3).booleanValue());
        }
        if (!((Boolean) objM7195constructorimpl2).booleanValue()) {
            Toast.makeText(this, "امکان شروع نصب بروزرسانی وجود ندارد.", 0).show();
            if (force) {
                return;
            }
            clearPendingInstallState();
            Dialog dialog = this.updateDialog;
            if (dialog != null) {
                dialog.dismiss();
            }
            openMain();
            return;
        }
        UpdateDialogUi updateDialogUi2 = this.updateDialogUi;
        LinearLayout progressWrap2 = updateDialogUi2 != null ? updateDialogUi2.getProgressWrap() : null;
        if (progressWrap2 != null) {
            progressWrap2.setVisibility(0);
        }
        ProgressBar progressBar2 = updateDialogUi2 != null ? updateDialogUi2.getProgressBar() : null;
        if (progressBar2 != null) {
            progressBar2.setIndeterminate(true);
        }
        TextView progressLabel2 = updateDialogUi2 != null ? updateDialogUi2.getProgressLabel() : null;
        if (progressLabel2 != null) {
            progressLabel2.setText("در حال نصب بروزرسانی... بعد از اتمام، بازگردید.");
        }
        TextView updateButton6 = updateDialogUi2 != null ? updateDialogUi2.getUpdateButton() : null;
        if (updateButton6 != null) {
            updateButton6.setText("ادامه نصب");
        }
        TextView updateButton7 = updateDialogUi2 != null ? updateDialogUi2.getUpdateButton() : null;
        if (updateButton7 != null) {
            updateButton7.setEnabled(true);
        }
        TextView updateButton8 = updateDialogUi2 != null ? updateDialogUi2.getUpdateButton() : null;
        if (updateButton8 != null) {
            updateButton8.setAlpha(1.0f);
        }
        if (updateDialogUi2 != null && (updateButton = updateDialogUi2.getUpdateButton()) != null) {
            updateButton.setOnClickListener(new View.OnClickListener() { // from class: com.filmkio.SplashActivity$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SplashActivity.installDownloadedUpdate$lambda$54(this.f$0, apkFile, force, targetVersion, view);
                }
            });
        }
        cancelButton = updateDialogUi2 != null ? updateDialogUi2.getCancelButton() : null;
        if (cancelButton == null) {
            return;
        }
        cancelButton.setEnabled(!force);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void installDownloadedUpdate$lambda$44(SplashActivity this$0, File apkFile, boolean z, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(apkFile, "$apkFile");
        this$0.installDownloadedUpdate(apkFile, z, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void installDownloadedUpdate$lambda$54(SplashActivity this$0, File apkFile, boolean z, int i, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(apkFile, "$apkFile");
        this$0.installDownloadedUpdate(apkFile, z, i);
    }

    private final void cancelUpdateDownload() {
        Call call = this.updateDownloadCall;
        if (call != null) {
            call.cancel();
        }
        this.updateDownloadCall = null;
        this.isUpdateDownloading = false;
    }

    private final String formatBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        double d = bytes / 1024.0d;
        if (d < 1024.0d) {
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String str = String.format("%.0f KB", Arrays.copyOf(new Object[]{Double.valueOf(d)}, 1));
            Intrinsics.checkNotNullExpressionValue(str, "format(...)");
            return str;
        }
        double d2 = d / 1024.0d;
        if (d2 < 1024.0d) {
            StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
            String str2 = String.format("%.1f MB", Arrays.copyOf(new Object[]{Double.valueOf(d2)}, 1));
            Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
            return str2;
        }
        StringCompanionObject stringCompanionObject3 = StringCompanionObject.INSTANCE;
        String str3 = String.format("%.2f GB", Arrays.copyOf(new Object[]{Double.valueOf(d2 / 1024.0d)}, 1));
        Intrinsics.checkNotNullExpressionValue(str3, "format(...)");
        return str3;
    }

    private final void persistPendingInstallState(String path, boolean force, int targetVersion, boolean awaitingPermission) {
        String str = path;
        if (str == null || StringsKt.isBlank(str)) {
            getUpdateStatePrefs().edit().remove(PREF_PENDING_INSTALL_APK_PATH).remove(PREF_PENDING_INSTALL_FORCE).remove(PREF_PENDING_INSTALL_TARGET_VERSION).remove(PREF_PENDING_INSTALL_AWAITING_PERMISSION).apply();
        } else {
            getUpdateStatePrefs().edit().putString(PREF_PENDING_INSTALL_APK_PATH, path).putBoolean(PREF_PENDING_INSTALL_FORCE, force).putInt(PREF_PENDING_INSTALL_TARGET_VERSION, RangesKt.coerceAtLeast(targetVersion, 0)).putBoolean(PREF_PENDING_INSTALL_AWAITING_PERMISSION, awaitingPermission).apply();
        }
    }

    private final void restorePendingInstallState() {
        String string = getUpdateStatePrefs().getString(PREF_PENDING_INSTALL_APK_PATH, null);
        String string2 = string != null ? StringsKt.trim((CharSequence) string).toString() : null;
        if (string2 == null) {
            string2 = "";
        }
        if (StringsKt.isBlank(string2)) {
            this.pendingInstallApkPath = null;
            this.pendingInstallForce = false;
            this.pendingInstallTargetVersion = 0;
            this.awaitingInstallPermissionReturn = false;
            return;
        }
        this.pendingInstallApkPath = string2;
        this.pendingInstallForce = getUpdateStatePrefs().getBoolean(PREF_PENDING_INSTALL_FORCE, false);
        this.pendingInstallTargetVersion = RangesKt.coerceAtLeast(getUpdateStatePrefs().getInt(PREF_PENDING_INSTALL_TARGET_VERSION, 0), 0);
        this.awaitingInstallPermissionReturn = getUpdateStatePrefs().getBoolean(PREF_PENDING_INSTALL_AWAITING_PERMISSION, false);
    }

    private final void clearPendingInstallState() {
        this.pendingInstallApkPath = null;
        this.pendingInstallForce = false;
        this.pendingInstallTargetVersion = 0;
        this.awaitingInstallPermissionReturn = false;
        persistPendingInstallState(null, false, 0, false);
    }

    private final void maybeShowPendingUpdateDialog() {
        MobileUpdateInfo mobileUpdateInfo = this.pendingUpdateDialogInfo;
        if (mobileUpdateInfo != null && canShowUpdateDialogNow()) {
            showMobileUpdateDialog(mobileUpdateInfo);
        }
    }

    private final boolean canShowUpdateDialogNow() {
        Window window;
        View decorView;
        return !isActivityInvalidForDialog() && this.isResumedForDialogs && getLifecycle().getState().isAtLeast(Lifecycle.State.RESUMED) && hasWindowFocus() && (window = getWindow()) != null && (decorView = window.getDecorView()) != null && decorView.isAttachedToWindow() && decorView.getWindowToken() != null;
    }

    private final boolean isActivityInvalidForDialog() {
        if (isFinishing()) {
            return true;
        }
        return Build.VERSION.SDK_INT >= 17 && isDestroyed();
    }

    private final int parseVersionCode(Object raw) {
        String string;
        Integer intOrNull;
        if (raw == null || (string = raw.toString()) == null) {
            string = "";
        }
        String string2 = StringsKt.trim((CharSequence) string).toString();
        String str = string2;
        if (StringsKt.isBlank(str)) {
            return 0;
        }
        Integer intOrNull2 = StringsKt.toIntOrNull(string2);
        if (intOrNull2 != null) {
            return RangesKt.coerceAtLeast(intOrNull2.intValue(), 0);
        }
        MatchResult matchResultFind$default = Regex.find$default(new Regex("^(\\d+)\\.(\\d+)(?:\\.(\\d+))?$"), str, 0, 2, null);
        if (matchResultFind$default != null) {
            Integer intOrNull3 = StringsKt.toIntOrNull(matchResultFind$default.getGroupValues().get(1));
            int iIntValue = intOrNull3 != null ? intOrNull3.intValue() : 0;
            Integer intOrNull4 = StringsKt.toIntOrNull(matchResultFind$default.getGroupValues().get(2));
            int iIntValue2 = intOrNull4 != null ? intOrNull4.intValue() : 0;
            String str2 = (String) CollectionsKt.getOrNull(matchResultFind$default.getGroupValues(), 3);
            return RangesKt.coerceAtLeast((iIntValue * 10000) + (iIntValue2 * 100) + ((str2 == null || (intOrNull = StringsKt.toIntOrNull(str2)) == null) ? 0 : intOrNull.intValue()), 0);
        }
        Integer intOrNull5 = StringsKt.toIntOrNull(new Regex("\\D+").replace(str, ""));
        if (intOrNull5 != null) {
            return RangesKt.coerceAtLeast(intOrNull5.intValue(), 0);
        }
        return 0;
    }

    private final String formatVersionForUi(int versionCode) {
        if (versionCode <= 0) {
            return "0";
        }
        if (versionCode >= 10000) {
            int i = versionCode / 10000;
            int i2 = (versionCode % 10000) / 100;
            int i3 = versionCode % 100;
            if (i3 > 0) {
                return i + "." + i2 + "." + i3;
            }
            if (i2 > 0) {
                return i + "." + i2;
            }
            return String.valueOf(i);
        }
        return String.valueOf(versionCode);
    }

    private final TextView makeUpdateDialogButton(String text, int fill, int stroke, int textColor) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(fill);
        gradientDrawable.setCornerRadius(m374dp(12));
        gradientDrawable.setStroke(m374dp(1), stroke);
        SplashActivity splashActivity = this;
        TextView textView = new TextView(splashActivity);
        textView.setText(text);
        textView.setTextColor(textColor);
        textView.setTextSize(14.0f);
        textView.setGravity(17);
        textView.setIncludeFontPadding(false);
        Typeface typefaceMedium = NativeFonts.INSTANCE.medium(splashActivity);
        if (typefaceMedium == null) {
            typefaceMedium = textView.getTypeface();
        }
        textView.setTypeface(typefaceMedium);
        textView.setClickable(true);
        textView.setBackground(gradientDrawable);
        return textView;
    }

    /* JADX INFO: renamed from: dp */
    private final int m374dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private final void reportBootstrapError(Throwable error) throws JSONException {
        String apiBase;
        if (isMobileClient() && (apiBase = AppState.INSTANCE.getApiBase()) != null) {
            String clientPlatform = AppState.INSTANCE.getClientPlatform();
            if (StringsKt.isBlank(clientPlatform)) {
                clientPlatform = "android";
            }
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("platform", clientPlatform);
            jSONObject.put("source", "splash_bootstrap");
            String message = error.getMessage();
            if (message == null) {
                message = "BOOT_FAILED";
            }
            jSONObject.put("message", message);
            jSONObject.put("stack", Log.getStackTraceString(error));
            jSONObject.put("version_name", currentAppVersion());
            jSONObject.put("version_code", currentAppVersionCode());
            String string = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            try {
                Result.Companion companion = Result.INSTANCE;
                SplashActivity splashActivity = this;
                Result.m7195constructorimpl(FkApiClient.signedRequest$default(FkApiClient.INSTANCE, apiBase, "/clientLog", "POST", null, null, string, false, 88, null));
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m7195constructorimpl(ResultKt.createFailure(th));
            }
        }
    }
}