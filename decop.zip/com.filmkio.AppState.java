package com.filmkio;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AppState.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001a\u0010\f\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u0006\"\u0004\b\u000e\u0010\bR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR\u001e\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0086\u000e¢\u0006\u0010\n\u0002\u0010\u0018\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001c\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001e¨\u0006\u001f"}, m780d2 = {"Lcom/filmkio/AppState;", "", "()V", "apiBase", "", "getApiBase", "()Ljava/lang/String;", "setApiBase", "(Ljava/lang/String;)V", "clientName", "getClientName", "setClientName", "clientPlatform", "getClientPlatform", "setClientPlatform", "homeJson", "getHomeJson", "setHomeJson", "saveIntervalSec", "", "getSaveIntervalSec", "()Ljava/lang/Integer;", "setSaveIntervalSec", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "session", "Lcom/filmkio/Session;", "getSession", "()Lcom/filmkio/Session;", "setSession", "(Lcom/filmkio/Session;)V", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class AppState {
    private static volatile String apiBase;
    private static volatile String homeJson;
    private static volatile Integer saveIntervalSec;
    private static volatile Session session;
    public static final AppState INSTANCE = new AppState();
    private static volatile String clientPlatform = "tv";
    private static volatile String clientName = "FilmKioTV";
    public static final int $stable = 8;

    private AppState() {
    }

    public final String getApiBase() {
        return apiBase;
    }

    public final void setApiBase(String str) {
        apiBase = str;
    }

    public final String getHomeJson() {
        return homeJson;
    }

    public final void setHomeJson(String str) {
        homeJson = str;
    }

    public final Session getSession() {
        return session;
    }

    public final void setSession(Session session2) {
        session = session2;
    }

    public final Integer getSaveIntervalSec() {
        return saveIntervalSec;
    }

    public final void setSaveIntervalSec(Integer num) {
        saveIntervalSec = num;
    }

    public final String getClientPlatform() {
        return clientPlatform;
    }

    public final void setClientPlatform(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        clientPlatform = str;
    }

    public final String getClientName() {
        return clientName;
    }

    public final void setClientName(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        clientName = str;
    }
}