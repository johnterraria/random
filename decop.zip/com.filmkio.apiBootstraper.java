package com.filmkio;

import android.content.Context;
import androidx.webkit.ProxyConfig;
import com.filmkio.nativescreen.net.FkApiClient;
import com.filmkio.nativescreen.net.FkNetworkCompat;
import com.filmkio.nativescreen.taxtv.TaxTvStore;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.Typography;
import okhttp3.OkHttpClient;

/* JADX INFO: compiled from: ApiBootstrapper.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(m779d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\"\u0010\r\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00120\u0011J\u0010\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0004H\u0002J\u0010\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\b\u0010\u0016\u001a\u00020\u0004H\u0002J\u0010\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0012\u0010\u0019\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\u0019\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0004H\u0002¢\u0006\u0002\u0010\u001dJ\u0010\u0010\u001e\u001a\u00020\u00122\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u0018\u0010\u001f\u001a\u00020\u00122\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0018\u001a\u00020\u0004H\u0002J\u001f\u0010 \u001a\u00020\u00122\u0006\u0010!\u001a\u00020\"2\b\u0010#\u001a\u0004\u0018\u00010\u001bH\u0002¢\u0006\u0002\u0010$R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u001b\u0010\u0007\u001a\u00020\b8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000b\u0010\f\u001a\u0004\b\t\u0010\n¨\u0006%"}, m780d2 = {"Lcom/filmkio/ApiBootstrapper;", "", "()V", "ARVAN_URL", "", "KEY_API_BASE", "PREFS", ProxyConfig.MATCH_HTTP, "Lokhttp3/OkHttpClient;", "getHttp", "()Lokhttp3/OkHttpClient;", "http$delegate", "Lkotlin/Lazy;", "bootstrap", "ctx", "Landroid/content/Context;", "onStage", "Lkotlin/Function1;", "", "cleanTextUrl", "txt", "clearApiBase", "fetchArvanApiBase", "fetchHome", "apiBase", "loadApiBase", "parseRetryAfterMillis", "", "value", "(Ljava/lang/String;)Ljava/lang/Long;", "prefetchTaxTv", "saveApiBase", "sleepBeforeRetry", "attempt", "", "retryAfterMs", "(ILjava/lang/Long;)V", "app_mobileRelease"}, m781k = 1, m782mv = {1, 9, 0}, m784xi = 48)
public final class ApiBootstrapper {
    private static final String ARVAN_URL = "https://resorcefu.s3.ir-thr-at1.arvanstorage.ir/address";
    private static final String KEY_API_BASE = "api_base";
    private static final String PREFS = "filmkio_prefs";
    public static final ApiBootstrapper INSTANCE = new ApiBootstrapper();

    /* JADX INFO: renamed from: http$delegate, reason: from kotlin metadata */
    private static final Lazy http = LazyKt.lazy(LazyThreadSafetyMode.SYNCHRONIZED, (Function0) new Function0<OkHttpClient>() { // from class: com.filmkio.ApiBootstrapper$http$2
        @Override // kotlin.jvm.functions.Function0
        public final OkHttpClient invoke() {
            return FkNetworkCompat.INSTANCE.bootstrapClientBuilder().build();
        }
    });
    public static final int $stable = 8;

    private ApiBootstrapper() {
    }

    private final OkHttpClient getHttp() {
        return (OkHttpClient) http.getValue();
    }

    public final String bootstrap(Context ctx, Function1<? super String, Unit> onStage) throws Throwable {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(onStage, "onStage");
        FkNetworkCompat.INSTANCE.initialize(ctx);
        String strLoadApiBase = loadApiBase(ctx);
        String str = strLoadApiBase;
        if (!(str == null || StringsKt.isBlank(str))) {
            onStage.invoke("home");
            try {
                String strFetchHome = fetchHome(strLoadApiBase);
                AppState.INSTANCE.setApiBase(strLoadApiBase);
                AppState.INSTANCE.setHomeJson(strFetchHome);
                prefetchTaxTv(strLoadApiBase);
                return strLoadApiBase;
            } catch (Throwable unused) {
                clearApiBase(ctx);
            }
        }
        onStage.invoke("arvan");
        String strFetchArvanApiBase = fetchArvanApiBase();
        saveApiBase(ctx, strFetchArvanApiBase);
        onStage.invoke("home");
        String strFetchHome2 = fetchHome(strFetchArvanApiBase);
        AppState.INSTANCE.setApiBase(strFetchArvanApiBase);
        AppState.INSTANCE.setHomeJson(strFetchHome2);
        prefetchTaxTv(strFetchArvanApiBase);
        return strFetchArvanApiBase;
    }

    private final void prefetchTaxTv(String apiBase) {
        try {
            Result.Companion companion = Result.INSTANCE;
            ApiBootstrapper apiBootstrapper = this;
            Result.m7195constructorimpl(TaxTvStore.INSTANCE.fetch(apiBase, false, 0L));
        } catch (Throwable th) {
            Result.Companion companion2 = Result.INSTANCE;
            Result.m7195constructorimpl(ResultKt.createFailure(th));
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x0083, code lost:
    
        throw new java.lang.RuntimeException("ARVAN_FAIL_" + r7.code());
     */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0058 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00d1 A[LOOP:0: B:3:0x0004->B:51:0x00d1, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0067 A[ADDED_TO_REGION, EDGE_INSN: B:60:0x0067->B:24:0x0067 BREAK  A[LOOP:0: B:3:0x0004->B:51:0x00d1], REMOVE, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00d5 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.String fetchArvanApiBase() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 227
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.filmkio.ApiBootstrapper.fetchArvanApiBase():java.lang.String");
    }

    private final String fetchHome(String apiBase) {
        return FkApiClient.INSTANCE.signedGet(apiBase, "/homePage", MapsKt.emptyMap());
    }

    private final String cleanTextUrl(String txt) {
        String strReplace = new Regex("/+$").replace(StringsKt.trim(StringsKt.trim((CharSequence) txt).toString(), Typography.quote), "");
        if (StringsKt.endsWith$default(strReplace, "/home", false, 2, (Object) null)) {
            strReplace = StringsKt.removeSuffix(strReplace, (CharSequence) "/home");
        }
        return new Regex("/+$").replace(strReplace, "");
    }

    private final String loadApiBase(Context ctx) {
        return ctx.getSharedPreferences(PREFS, 0).getString(KEY_API_BASE, null);
    }

    private final void saveApiBase(Context ctx, String apiBase) {
        ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY_API_BASE, apiBase).apply();
    }

    private final void clearApiBase(Context ctx) {
        ctx.getSharedPreferences(PREFS, 0).edit().remove(KEY_API_BASE).apply();
    }

    private final Long parseRetryAfterMillis(String value) {
        String string;
        Long longOrNull;
        if (value == null || (string = StringsKt.trim((CharSequence) value).toString()) == null || (longOrNull = StringsKt.toLongOrNull(string)) == null) {
            return null;
        }
        return Long.valueOf(RangesKt.coerceIn(longOrNull.longValue(), 0L, 8L) * 1000);
    }

    private final void sleepBeforeRetry(int attempt, Long retryAfterMs) {
        long jMax = Math.max((attempt != 1 ? attempt != 2 ? 1800L : 900L : 350L) + Random.INSTANCE.nextLong(80L, 220L), retryAfterMs != null ? retryAfterMs.longValue() : 0L);
        if (jMax <= 0) {
            return;
        }
        try {
            Thread.sleep(jMax);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }
}